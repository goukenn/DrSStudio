<?php
//<summary>used to add google map controller model on the web site</summary>

define("IGK_APP_LOGO", "/R/Img/app_logo.png");

abstract class IGKAppCtrl extends IGKCtrlTypeBase
{
	private $m_user;
	public function getUser(){
		return $this->m_user;
	}
	protected function setUser($user){
		$this->m_user = $user;
	}
	public static function InitEnvironment($ctrl){
		//init application environment
		IGKIO::CreateDir($ctrl->getDataDir());
		IGKIO::CreateDir($ctrl->getDataDir()."/R");
		
		
		//create dummy image app_app_ico
		$s = IGKGD::Create(256,128);		
		IGKIO::WriteToFileAsUtf8WBOM($ctrl->getDataDir().IGK_APP_LOGO,  $s->RenderText(), true);	
IGKIO::WriteToFileAsUtf8WBOM($ctrl->getDataDir().IGK_APP_LOGO.".gkds", <<<EOF
<gkds>
  <Project>
    <SurfaceType>IconSurface</SurfaceType>
  </Project>
  <Documents>
    <LayerDocument PixelOffset="None" BackgroundTransparent="True" Width="256" Height="128" Id="LayerDocument_918761">
      <Layer Id="Layer_17003755">       
      </Layer>
    </LayerDocument>
  </Documents>
</gkds>
EOF
	, true);
	
	}
	public function getAppImgUri(){
		//return igk_html_uri(igk_io_baseUri()."/".igk_io_basePath($this->getDataDir().IGK_APP_LOGO));
		return igk_html_resolv_img_uri($this->getDataDir().IGK_APP_LOGO);
	}
	
	/*public function get_app_imguri() {
		chdir('..');
	/*	$f = "D:\\wamp\\www\\igkdev\\test";
		igk_wln(self::GetBaseDirRelativePath($f));
		igk_wln(igk_io_basePath($f));
		igk_wln(igk_io_baseRelativePath($f));
		
		$f = "D:\\wamp\\www\\igkdev\\test\\inform";
		igk_wln("1".self::GetBaseDirRelativePath($f));
		igk_wln("2".igk_io_basePath($f));
		igk_wln("3".igk_io_baseRelativePath($f));
		
		$f = $this->getDataDir().IGK_APP_LOGO;
		igk_wln("4".igk_io_fullpath2Uri($f));
		
		igk_wln("<img src='".igk_io_fullpath2Uri($f)."' alt='ok'></img>");
		//return;
		*/
		//return;
		// $f = $this->getDataDir().IGK_APP_LOGO;
		// igk_wln("?exists ".file_exists($f));
		// igk_wln("?base dir : ".igk_io_baseDir(""));
		// igk_wln("?current dir (getcwd) : ".getcwd());
		// igk_wln("2.current relative path ::: ".igk_io_currentRelativePath($f));
		// igk_wln("2.current relative exists 2 : ".file_exists(igk_io_currentRelativePath($f)) );
		
		
		// igk_wln("assoc : ".$this->getDataDir().IGK_APP_LOGO);
		
	/*	igk_wln("des : ".R::GetImgResUri("config_logo"));
		
		igk_wln("def : ". $this->getAppImgUri());
		igk_wln("resolv :". igk_html_resolv_img_uri($this->getDataDir().IGK_APP_LOGO));
		// igk_wln(igk_io_baseUri());
		// igk_wln(igk_io_basePath($f));
	}*/
	protected function IsUserAllowedTo($authDemand)
	{
		if ($this->User == null)
			return false;
		if ($this->User->clLevel == -1)
			return true;		
		return false;
	}
	public function getAppTitle(){
		return  igk_getv($this->Configs, "clAppTitle");
	}
	public function getBasicUriPattern(){
		return  igk_getv($this->Configs, "clBasicUriPattern");
	}
	public function getcanAddChild(){
		return false;
	}	
	public function IsActive(){//get if this app is currently active from uri	
		$inf = igk_sys_ac_getpatterninfo();	
		return (($inf!=null) && preg_match( igk_sys_ac_getpattern( $this->getBasicUriPattern()),  igk_io_root_base_uri()));	
	}
	public function getIsVisible(){
		$inf = igk_sys_ac_getpatterninfo();	
		$c = !$this->getAppNotActive() &&  $this->IsActive();		
		return $c;
	}
	public function getAppNotActive(){//activate from data
		return igk_getv($this->Configs, "clAppNotActive");
	}
	public static function GetAdditionalConfigInfo()
	{
		return array("clAppTitle",
		"clBasicUriPattern",
		"clAppNotActive"=>(object)array("clType"=>"bool", "clDefaultValue"=>"0"));
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clBasicUriPattern"] = igk_getr("clBasicUriPattern"); 
		$t["clAppTitle"] = igk_getr("clAppTitle"); 
		$t["clAppNotActive"] = igk_getr("clAppNotActive"); 
	}
	public function storeDBConfigsSetting(){
		parent::storeDBConfigsSetting();
		$this->register_action();
	}
	protected function InitComplete(){
		parent::InitComplete();
		$this->register_action();
	}
	private function register_action(){	
		$c = igk_getv($this->Configs, "clBasicUriPattern");
		$k = $this->getParam("appkeys");
		if (!empty($k))
		{
			igk_sys_ac_unregister($k);
		}
		if ($c)
		{
			//register app contains
			$k = "".$c."(/:function(/:params+)?)?";		
			igk_sys_ac_register($k, $this->getUri("evaluateUri"));
			$this->setParam("appkeys", $k);
		}
	}
	
	public final function evaluateUri()
	{
		$inf = igk_sys_ac_getpatterninfo();		
		$p = $inf->getParams();
		$c = igk_getv($p, "function");
		$p = igk_getv($p, "params");
		if (empty($c))
		{
			$this->renderDefaultDoc();
		}
		else{
			if (method_exists($this, $c))
			{
				if (is_array($p) == false)
					$p = array($p);			
				call_user_func_array(array($this, $c), $p);		
			}
			else{
				$this->renderError($c);			
			}
		}
		exit;
	}
	
	
	public function get_data_schemas(){
		$u = $this->App->Session->User;
		if (($u ==null) || !igk_sys_isuser_authorize($u, "igk:get_schematable"))
		{
			igk_wln("u is null" .igk_parsebool($u == null));
			
			//igk_navto($this->getAppUri(""));
			exit;
		}
		//header("Content-Type: application/xml");		
		$f = $this->getDataDir()."/data.schema.xml";
		if (file_exists($f))
		{
			$s = IGKHtmlReader::LoadFile($f);
			$s->RenderXML();
		}
		else{
			$d =  IGKHtmlItem::CreateWebNode("data-schemas");
			$d->RenderXML();
		}
		exit;
	}
	public function load_data_files(){		
		if (isset($_FILES["clFileName"]))
		{
		$f = $this->getDataDir()."/data.schema.xml";
		$dom =  IGKHtmlItem::CreateWebNode("dummy");
		$dom->Load(IGKIO::ReadAllText($_FILES["clFileName"]["tmp_name"]));
				$d = new IGKHtmlDoc($this->App, true);
			$div = $d->Body->add("div");
			
			
		if (igk_count($dom->getElementsByTagName("data-schemas")) == 1){
			igk_io_move_uploaded_file($_FILES["clFileName"]["tmp_name"], $f);
			$div->add("div", array("class"=>"igk-title"))->Content = R::ngets("Title.GoodJOB");
			$div->add("div", array("class"=>"igk-notify igk-notify-success"))->Content = R::ngets("msg.fileuploaded");
		}		
		else{
			$div->add("div", array("class"=>"igk-title"))->Content = R::ngets("Title.Error");
			$div->add("div", array("class"=>"igk-notify igk-notify-danger"))->Content = R::ngets("error.msg.filenotvalid");
		}
		$d->RenderAJX();
		unset($d);
		unset($dom);
		}
		else{
			igk_navtobase("/");
		}
		exit;
	}
	protected function getRootPattern(){
		$t = array();
		$s = preg_match_all("/(\^\/)?(?P<name>[^\/]+)/i", $this->getBasicUriPattern(), $t);
		if ($s>0){
			$o = $t["name"][0];
			return $o;
		}
		return null;
	}
	public function getAppUri($function=null){
		
		$f = igk_io_baseuri()."/".$this->getRootPattern();
		if ($function)
			$f .= "/".$function;
			
		return $f;
	}
	public function load_data(){
	
	
		$doc = new IGKHtmlDoc($this->App, true);
		$d = $doc->Body->add("div");
		$frm = $d->addForm();
		$frm["action"]= $this->getAppUri("load_data_files");
		$frm["method"]="POST";
		$i = $frm->addInput("clFileName", "file");
		$i["class"]="dispn";
	//	$i["style"]="display:none;";
		$i["multiple"]="false";
		$i["accept"] = "text/xml";
		$i["onchange"] = "this.form.submit(); return false;";
		$frm->addInput("clRuri", "hidden", $this->getAppUri(""));
		//$frm->addInput("clLoad", "submit");
		$frm->addScript()->Content = 
<<<EOF
(function(){var f = \$ns_igk.getParentScriptByTagName('form'); f.clFileName.click();})();
EOF;

		$doc->RenderAJX();
		exit;
	}
	///<summary> save data schema</summary>
	public function save_data_schema()
	{
		//must be admin for that functions		
		$dom =  IGKHtmlItem::CreateWebNode(IGK_SCHEMA_TAGNAME);	
		$dom["ControllerName"]=$this->Name;
		$dom["Platform"] = IGK_PLATEFORM_NAME;
		$dom["PlatformVersion"] =IGK_WEBFRAMEWORK;
		
		$e =  IGKHtmlItem::CreateWebNode("Entries");
		//build schemas
		$d = $this->loadDataFromSchemas();
		if ($d ){
			$tabs = array();
			foreach($d as $k=>$v)
			{
				$b = $dom->add("DataDefinition");
				$b["TableName"] = $k;
				$tabs[] = $k;
				foreach($v as $c){
					$col = $b->add("Column");
					$col->loadDataAsAttribute($c);
				}
			}
			
			$db = igk_getdata_adapter($this);
			$r = null;
			if ($db){
				
				$db->connect();
			
					foreach($tabs as $tabname)
					{
						try{
						$r = $db->selectAll($tabname);
						if ($r->RowCount>0)
						{
							$s = $e->add($tabname);
							foreach($r->Rows as $c=>$cc)
							{
								$irow = $s->add("Row");
								$irow->loadDataAsAttribute($cc);
							}
						}
						}
						catch(Exception $ex)
						{
						}
					}				
				$db->close();				
			}
		}
		//build data entries
		if ($e->HasChilds){
			$dom->add($e);
		}
		header("Content-Type: application/xml");
		$dom->RenderAJX();
		exit;
	}

	protected function bind_func($func, $args){		
		if ($func)
		{		
			$cl = get_class($this);
			
			if (method_exists($cl, $func))
			{
				call_user_func_array(array($this,$func), $args);
				return true;
			}
		}
		return false;
	}
	
	protected function appLoginForm($div){
			////$div = $div->addDiv()->setClass("container");
			$frm = $div->addForm();
			
			$frm["action"] = $this->getUri("login");
			$frm["class"] = "igk-login-form";			
			$cd = $frm->addDiv()->setClass("form-group");
			$cd->addSLabelInput("clLogin", "text")->input->setClass("igk-form-control")->setAttribute("placeholder", R::ngets("tip.login"));
			$cd->addSLabelInput("clPwd", "password")->input->setClass("igk-form-control")->setAttribute("placeholder", R::ngets("tip.pwd"));	
			
			igk_notify_sethost($frm->addDiv());
			
			$frm->addDiv()->setClass("igk-pad-t-4  alignc")
			->addInput("btn.connect", "submit", R::ngets("btn.connect"))->setClass("igk-btn igk-btn-default igk-form-control igk-btn-connect");
			
	}
	public function administration(){
		$doc = new IGKHtmlDoc($this->App, true);
		$div = $doc->body->addDiv();
		$div["class"] = "igk-notify igk-notify-warning";
		$div["style"] = "display:block; position:absolute; top:50%; min-height:96px; margin-top:-48px;";		
		$div->Content = "No administration page";	
	
		
		$div = $doc->body->addDiv();		
		$div["style"] = "font-size: 3em; ";
		$div->addA($this->getAppUri(""))->setClass("glyphicons no-decoration")->Content = "&#xe021;";
		
		$doc->RenderAJX();
	}
	protected function renderError($c){
			//render error
			$f = igk_io_currentRelativePath("Pages/error_404.html");		
			if (file_exists($f))
			{
				include($f);
			}
			else{
			$d = new IGKHtmlDoc($this->App, true);			
			
			$d->Title = "Application Error";
			$div = $d->Body->add("div");
			$div->add("div", array("class"=>"igk-title"))->Content = R::ngets("Title.Error");
			$div->add("div", array("class"=>"igk-notify igk-notify-danger"))->Content = "No function $c found";
			$d->RenderAJX();
			unset($d);
			}
	}
	protected function renderDefaultDoc(){
			//render error
			$d = new IGKHtmlDoc($this->App, true);
			$d->Title = R::ngets("title.app_1", igk_getv($this->Configs, "clAppTitle"));
			$div = $d->Body->addDiv();
			$div->setClass("igk-powered-view fitw fith overflow-y-a");
			$s = $div->addDiv();
			$r = $s->addDiv()->setClass("igk-container");
			$r->add("div", array("class"=>"igk-title"))->Content = R::ngets("Title.App_1", $this->AppTitle);
			$r->add("blockquote", array("class"=>""))->Content = R::ngets("msg.welcome_1",$this->AppTitle);	
			
			$s = $div->addDiv();
			$this->setCurrentView("default", true);
			$s->Load($this->TargetNode->Render());
			$d->RenderAJX();
			unset($d);
	}

	public function  createNewDoc(){
		$doc = new IGKHtmlDoc($this->App, true);
		$doc->Title = $this->AppTitle;
		return $doc;
	}
	//list exposed functions
	public function functions(){
		$doc = new IGKHtmlDoc($this->App, true);
		
		$d = $bodybox = $doc->body->addBodyBox();
		
		$m = $d->addDiv()->addDiv()->addContainer();
		$r = $m->addRow();
		$cl = get_class($this);
		$ref = new ReflectionClass($cl);
		
		$sf = $this->getDeclaredFileName();
		$r->addDiv()->Content = "File : ".igk_io_basepath($sf);
		
		// $m = $d->addDiv()->addDiv()->addContainer();
		// $r = $m->addRow();
		// foreach(get_class_methods("ReflectionMethod") as $k=>$v)
		// {
			// $r->addDiv()->setClass("igk-col-lg-12-2")->setContent($v);
		// }		
		$m = $d->addDiv()->addDiv()->addContainer();
		$r = $m->addRow();
		$func = array();
		foreach(get_class_methods($cl) as $k=>$v)
		{
			$refmethod = new ReflectionMethod($cl, $v);
			$n = $refmethod->getName();
			switch($n)
			{
				case "__construct":
				case __FUNCTION__:
					continue;
				
				default:	
			$fname = $refmethod->getFileName();
			if ($refmethod->isPublic() && !$refmethod->isStatic() && 
				(($fname == $sf) ||
				IGKString::EndWith($refmethod->getName(), "_contract" )))
			{
				$func[] = $refmethod->getName();
				//$b->addDiv()->setContent($refmethod->getFileName());
			}
				break;
			}
			
			
		}	
			usort($func, function($a,$b){
				return strcmp(strtolower($a), strtolower($b));
			});			
			foreach($func as $k){
					$b = $r->addDiv()->setClass("igk-col-lg-12-2 igk-sm-list-item")
					->setStyle("padding-top:8px; padding-bottom:8px")
					->addDiv();
				$b->addA($this->getAppUri($k))
				->setContent($k);
			}
		$bodybox->setStyle("position:relative; color: #eee; margin-bottom:300px;padding-bottom:0px; overflow-y:auto; color:indigo;");
		$bodybox->addDiv()->setClass("posfix loc_b loc_r loc_l dispb footer-box igk-fixfitw")
		->setAttribute("igk-fix-loc-scroll-width", "1")
		->setStyle("min-height:80px;background-color:#ddd; z-index: 10; width: auto;")->Content= "footer";	
		$doc->body->addScript()->Content = <<<EOF
(function(){
	igk.ready(function(){
		
	});
})();
EOF;
		$doc->RenderAJX();
	}
}
?>