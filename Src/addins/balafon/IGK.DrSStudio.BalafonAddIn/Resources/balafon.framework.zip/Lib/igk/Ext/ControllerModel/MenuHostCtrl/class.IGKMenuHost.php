<?php
//controller code class declaration
//file is a part of the controller tab list
abstract class IGKMenuHostCtrl extends IGKCtrlTypeBase
{
	public function getName(){return get_class($this);}
	protected function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}
	public static function GetInfo()
	{
		
	}
	//@@@ init target node
	protected function initTargetNode(){
		$node =  parent::initTargetNode();
		return $node;
	}	
	public static function GetAdditionalConfigInfo()
	{
		return array("clAllowMenuNavigation"=>new IGKAdditionCtrlInfo("bool", true));
	}
	public static function SetAdditionalConfigInfo(& $tab)
	{
		$tab["clAllowMenuNavigation"] = igk_getr("clAllowMenuNavigation");
	}
	//----------------------------------------
	//Please Enter your code declaration here
	//----------------------------------------
	//@@@ parent view control
	public function View(){
		extract($this->getSystemVars());
		$t = $this->TargetNode;
		$t->ClearChilds();
		$igkmenuctrl->setParentView($t);
		if ($this->Configs->clAllowMenuNavigation)
		{
		//igk_wln($t->Render());
		$v_tabs = $t->getElementsByTagName("a");
		foreach($v_tabs as $k=>$v)
		{
			$n = igk_regex_get("/p=(?P<name>[^&]+)/i","name", $v["href"] );
			$v["href"] = "#".$n;
			$v["igk-navigation-target"]= $n;
		}
		//exit;
		
		$t->addScript()->Content =<<<EOF
		
		var node = IGK.getParentScript();
		var parent = document.getElementById("{$this->app->Configs->web_pagectrl}");	
		IGK.ready(function(){
IGK.winui.navigationBar.init(node, parent,  {duration:1000, interval:20, "orientation":"vertical"});
});
EOF;
		}
	}
	
	
}
?>