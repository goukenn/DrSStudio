<?php

///<summary>horizontal pane panel used to add animation pane on a target node</summary>
final class IGKJS_HorizontalPane extends IGKObject
{
	private $m_target;
	private $m_script;
	private $m_pageNode;
	private $m_bulletZone;
	private $m_AnimDuration;
	private $m_AnimInterval;
	private $m_IsAutoAnimate;
	private $m_AnimType; //translation or fade
	private $m_AnimPeriod;
	
	private $m_rootNode;
	
	
	public function getpageNode(){return $this->m_pageNode; }
	public function getTarget(){return $this->m_target;}
	public function getScript(){return $this->m_script; }
	public function getbulletZone(){return $this->m_bulletZone; }
	public function getAnimInterval(){return $this->m_AnimInterval; }
	public function getAnimDuration(){return $this->m_AnimDuration; }
	public function getAnimPeriod(){return $this->m_AnimPeriod;}
	public function getIsAutoAnimate(){return $this->m_IsAutoAnimate; }
	public function getAnimType() { return $this->m_AnimType;}
	public function setAnimType($value){$this->m_AnimType = $value;}	
	public function setAnimInterval($value){ $this->m_AnimInterval = $value; }
	public function setAnimDuration($value){ $this->m_AnimDuration = $value; }
	public function setAnimPeriod($value){$this->m_AnimPeriod =$value;}	
	public function setIsAutoAnimate($value){ $this->m_IsAutoAnimate = $value; }
	
	public function __construct($target)
	{
		$this->m_AnimDuration = 500;
		$this->m_AnimInterval = 20;
		$this->m_AnimPeriod = 5000;
		$this->m_target = $target;
		$this->m_IsAutoAnimate = true;
		$this->m_AnimType = "translation";/// fade, rotation
		//fit parent
		
		$this->m_pageNode = $target->addDiv();		
		$this->m_pageNode["igk-control-type"]="igk-pane";
		
		igk_css_regclass(".igk-pane", "{sys:fitw,fith,dispib,posr,no-wrap,fitw,nopadding,nomargin,no-overflow} margin-bottom:0px;");
		igk_css_regclass(".igk-pane-page", "{sys:dispib,fitw,alignt,fith} ");
		igk_css_regclass(".horizontalpane_bullet", "{sys:dispib} [res:bullet] width:16px; height:16px; background-repeat:no-repeat;");
		igk_css_regclass(".horizontalpane_bulletzone", "width:100%; position:absolute; z-index:100;display:block; height:32px; bottom:0px;");
		igk_css_regclass(".horizontalpane_bulletzone:after",  "content:' '; display:table;");
		igk_css_regclass(".horizontalpane_btn_notavailable", "background-position:-48px 0px;");
		igk_css_regclass(".horizontalpane_btn_available", "background-position:0px 0px;");		
		igk_css_regclass(".horizontalpane_btn_prev", "[res:navbtn_previous]");
		igk_css_regclass(".horizontalpane_btn_next", "[res:navbtn_next]");		
		igk_css_regclass(".horizontalpane_btn_prev, .horizontalpane_btn_next", "z-index:50");		
		igk_css_regclass(".igk-pane-manager", "{sys:posr}");
		igk_css_regclass(".igk-pane-manager .igk-pane-option", "{sys:floatl,dispib} width:32px; height:32px;");
		igk_css_regclass(".igk-pane-manager .igk-pane-option:hover", "[bgcl:igk-btn-default-hover-bg] background-position: 0px 32px;");
		
		
	}
	public function addPage($attribute=null)
	{
		$p = new IGKJS_HorizontalPage();
		if ($attribute)
			$p->AppendAttributes($attribute);
		$this->m_pageNode->add($p);			
		return $p;
	}
	public function Clear(){
		$this->m_pageNode->ClearChilds();
	}
	public function flush()
	{	
		if ($this->m_bulletZone == null)
		{
			$this->m_bulletZone  =  $this->m_target->addDiv();	
			$this->m_bulletZone["igk-control-type"]="horizontalpane_bulletzone";
			$this->m_bulletZone["class"]="horizontalpane_bulletzone";
		}    
		
		if ($this->m_script == null)
			$this->m_script = $this->m_target->addScript();	
		$b = igk_parsebool($this->m_IsAutoAnimate);
		$this->m_script->Content = <<<EOF
(function(q){ igk.winui.horizontalScrollPane.init(q, {autoanimate: {$b}, animtype: '{$this->m_AnimType}', period: {$this->m_AnimPeriod}},  {duration:{$this->m_AnimDuration}, interval: {$this->m_AnimInterval}, orientation:'horizontal'});})(ns_igk.getParentScript());
EOF;
		
		
	}

}

final class IGKJS_HorizontalPageOptions extends IGKHtmlWebMasterNodeBase
{
	private $m_owner;
	public function __construct($owner){	
		parent::__construct("div");
		$this->setClass("posab loc_l loc_r loc_t");
		$this->setStyle("z-index:200");
		$this->add("span")
		->setClass("igk-hbox")
		->Content = "options";
		$this->m_owner = $owner;
	}
}
final class IGKJS_HorizontalPage extends IGKHtmlItem
{
	private $m_options;
	private $m_file; //sorce file
	
	public function __construct(){	
		parent::__construct("div");
		$this["class"] = "igk-pane-page";
		$this["igk-control-type"]="igk-pane-page";
		$this->m_options = new IGKJS_HorizontalPageOptions($this);
	}
	public function setFile($file){
		$this->m_file = $file;
	}
	public function innerHTML(& $o = null){
		$s = parent::innerHTML($o);
		$s .= $this->m_options->Render($o);
		return $s;
	}
}

//horizontal pane item
interface IIGKHTMLHorizontalPaneListener{
	function getAddHorizontalPageUri();
	function buildPages($horizontalPane);
	function clearPagesUri();
	function getOptionsUri();
	
}
final class IGKHTMLHorizontalAnimType 
{
	const none="none";
	const translation="translation";
	const rotation="rotation";
	const fade="fade";
}
final class IGKHTMLHorizontalPaneManager extends IGKHtmlComponentNodeItem
{
	private $m_owner;
	private $m_paneAdd;
	private $m_paneClear;
	private $m_paneOptions;
	public function getIsVisible(){
		 return IGKApp::getInstance()->IsSupportViewMode(IGKViewMode::WEBMASTER);
	}
	public function addHPaneOption($typename){			
		$d = $this->addDiv();
		$d->setClass("igk-pane-option igk-trans-all-200ms");		
		$d->add("span")->setClass("igk-hbox")->Content = $typename;		
		$m_script = $d->addScript();
		$no = (object)array();
		$no->item = $d;
		$no->script = $m_script ;
		return $no;
	}
	public function __construct($owner)
	{
		parent::__construct("div");
		$this->setClass("igk-pane-manager");//->setStyle("border:1px solid black;");
		$this->m_pandeAdd = $this->addHPaneOption("add");
		$this->m_pandeAdd->item->setStyle("[res:add_32x32]; cursor:cell;");
		
		$this->m_paneClear = $this->addHPaneOption("clearall");
		$this->m_paneClear->item->setStyle("[res:del_32x32]; cursor: pointer;");
		
		$this->m_paneOptions = $this->addHPaneOption("options");
		$this->m_paneOptions->item->setStyle("[res:option_32x32]; cursor: pointer;");
		
		$this->addDiv()->setClass("igk-cleartab")->Content = " ";
		
		$this->m_owner =$owner;
	}
	public function addUri(){
		$tab = igk_get_allheaders();
		$pane = $this->m_owner;
		
		
		if (igk_getr('ie', 0) == 1)
		{
			$pane->RenderAJX();
			exit;
		}
		
		
		if (igk_getv($tab, "IGK_UPLOADFILE", false) ==false)
		{
			$s = IGKHtmlItem::CreateWebNode("script");
$s->Content = <<<EOF
ns_igk.winui.notify.showError("cant upload file IGK_UPLOADFILE not founds ");
EOF;
$s->RenderAJX();
$pane->RenderAJX();
			exit;
		}
		$type = igk_getv($tab, "IGK_UP_FILE_TYPE","text/html");
		$fname = igk_getv($tab, "IGK_FILE_NAME", "file.data");
		$bfname = igk_io_basenamewithoutext($fname);
		$s = file_get_contents("php://input");
		$dir = $pane->Folder;
		
		if (!empty($s))
		{		
			switch(strtolower($type ))
			{
				case "image/jpeg":
				case "image/jpg":
				case "image/png":
					igk_io_save_file_as_utf8_wbom($dir."/".$fname, $s, true);
					$div=  IGKHtmlItem::CreateWebNode("div");
					$img =  $div->addElement("igk:img");
					$img["src"] = igk_html_uri(igk_io_basePath($dir."/".$fname));
					$img->setClass("fitw");
					igk_io_save_file_as_utf8_wbom($dir."/".$fname.".phtml", $div->Render(null) , true);
					break;
				default:
					igk_io_save_file_as_utf8_wbom($dir."/".$fname.".phtml", $s, true);				
				break;
			}
			$pane->clearPages();
			$pane->configure();
			$pane->flush();
			$pane->RenderAJX();
		}		
		exit;
	}
	public function optionsUri(){
		$pane = $this->m_owner;
		if ($pane){
			igk_wl($pane->getOptionsXML($this->getController()->getUri("set_nav_options", $this)));
		}
	}
	
	public function update_nav_options()
	{
		$pane = $this->m_owner;
		if (!$pane)
		{
			return;
		}
		$pane->Pane->AnimPeriod = igk_getr('AnimPeriod', 500);
		$pane->Pane->AnimInterval = igk_getr('AnimInterval', 20);
		$pane->Pane->AnimPeriod = igk_getr('AnimPeriod', 1000);
		igk_frame_close("nav_options_frame");
		$pane->storeDBConfigsSetting();
		$pane->flush();		
		$pane->RenderAJX();
		igk_exit();
	}
	public function set_nav_options(){
		$pane = $this->m_owner;
		if (!$pane)
		{
			return;
		}
		$def = false;
		$p = igk_getr("menu");
		switch($p){
			case "option":
				$frame = igk_add_new_frame($this, "nav_options_frame");
				$frame->Title = R::ngets("title.options");
				$d = $frame->Content ;
				$d->ClearChilds();
				$frm = $d->addForm();
				$frm["action"] = $this->getController()->getUri("update_nav_options", $this);
				$frm["igk-js-ajx-form"] = "1";
				$pane->EditPaneOptions($frm);								
				$frame->RenderAJX();
			break;
			case "setanimtype":
			$p = igk_getr("n");
			$pane->Pane->AnimType = $p;		
			$def= true;
			break;
		}
	
		//store config		
		//------------
		if ($def){
		$pane->storeDBConfigsSetting();
		$pane->flush();		
		$pane->RenderAJX();
		}
		exit;
	}

	public function clearUri(){
		$pane = $this->m_owner;
		$tab = igk_io_getfiles($pane->Folder, "/(.)*/i");
		foreach($tab as $k=>$v){
			if (is_file($v))
				unlink($v);
		}
		$pane->clearPages();
		$pane->configure();
		$pane->flush();
		$pane->RenderAJX();	
	}
	public function getUriSetting(){
		$p = $this->m_owner->getPageViewListener();
		$obj = (object)array("addUri"=>null,"clearUri"=>null, "optsUri"=>null);
			if ($p)
			{
				$obj->addUri = $p->getAddHorizontalPageUri();
				$obj->optsUri = $p->getOptionsUri();
				$obj->clearUri = $p->clearPagesUri();
			}
			else{
				$obj->addUri = $this->getController()->getUri("addUri", $this);
				$obj->optsUri = $this->getController()->getUri("optionsUri", $this);
				$obj->clearUri = $this->getController()->getUri("clearUri", $this);;
			}
			return $obj;
	}
	public function Render($options =null){
			//check if web master view		
			
			$obj = $this->getUriSetting();
		
		$this->m_pandeAdd->script->Content = <<<EOF
igk.winui.horizontalScrollPane.initdrag('{$obj->addUri}');
EOF;

		if (isset($obj->clearUri ))
		$this->m_paneClear->script->Content = <<<EOF
igk.winui.horizontalScrollPane.initclearpage('{$obj->clearUri}');
EOF;

		if (isset($obj->optsUri ))
		$this->m_paneOptions->script->Content = <<<EOF
igk.winui.horizontalScrollPane.initoptions('{$obj->optsUri }');
EOF;

		$s = parent::Render($options);
		return $s;
	}
}
final class IGKHTMLHorizontalPaneItem extends IGKHtmlItem
{
	private $m_pane;
	private $m_pagelistener;
	private $m_manager;
	private $m_infobox;
	private $m_infoboxScript;
	
	private $m_pattern;
	private $m_folder;
	private $m_ConfigFileName;
	
	public function getFolder(){return $this->m_folder; }
	public function setFolder($v){ $this->m_folder = IGKIO::GetDir($v); }
	
	public function getConfigFileName(){ return $this->m_ConfigFileName;}
	public function setConfigFileName($v){ $this->m_ConfigFileName = $v;}
	
	public function getPattern(){return $this->m_pattern; }
	public function setPattern($v){$this->m_pattern = $v; }
	
	public function getPane(){return $this->m_pane; }
	
	
	private function loadConfigSetting(){
		$f = $this->Folder."/".$this->ConfigFileName;
		
		if (!file_exists($f))
			return;
		$div =  IGKHtmlReader::LoadFile($f);		
		$d = igk_getv($div->getElementsByTagName("config"), 0);	
		if ($d)
		{
			foreach($d->Childs as $k)
			{
				
				if ($k->Type == "HtmlText")
				continue;
				$r = $k->TagName;
				$this->Pane->$r = trim($k->innerHTML);
			}
		}
	}
	public function storeDBConfigsSetting()
	{
		$f = $this->Folder."/".$this->ConfigFileName;
		$d = IGKHtmlItem::CreateWebNode("config");
		//store
		
		$d->add("AnimType")->Content = $this->m_pane->AnimType;
		$d->add("AnimInterval")->Content = $this->m_pane->AnimInterval;
		$d->add("AnimPeriod")->Content = $this->m_pane->AnimPeriod;		
		$d->add("AnimDuration")->Content = $this->m_pane->AnimDuration;	
		$d->SaveToFile($f);
	}
	public function getOptionsXML($uri){		
		$d = IGKHtmlItem::CreateWebNode("div");
		$d->add("li")->setAttributes(array("uri"=>$uri."&menu=option", "ajx"=>1, "complete"=>"ns_igk.winui.horizontalScrollPane.append_to_body_from(this)"))->Content = "options";
		$d->add("sep");
		
		foreach(igk_get_class_constants('IGKHTMLHorizontalAnimType') as $k=>$v)
			$d->add("li")->setAttributeç($this->m_pane->AnimType==$v, "class", "+igk-checked")
			->setAttributes(array("uri"=>$uri."&menu=setanimtype&n=".$v, "ajx"=>1))			
			->Content = $v;
		return $d->getinnerHTML();
	}
	public function EditPaneOptions($target){
		if ($target==null)
			return;
	$pane= $this->m_pane;
	
		$s = <<<EOF
<igk:labelInput igk:id='AnimDuration' igk:value='{$pane->AnimDuration}' />
<igk:labelInput igk:id='AnimInterval' igk:value='{$pane->AnimInterval}'/>
<igk:labelInput igk:id='AnimPeriod' igk:value='{$pane->AnimPeriod}'/>
<igk:HSep />
<input type="submit" class="igk-btn igk-btn-default" value="[lang:btn.update]" / >
EOF;
$target->Load( igk_html_databinding_treatresponse($s,null,null));
		
	}
	public function __construct(){
		parent::__construct("div");
		
		$this->m_pane = new IGKJS_HorizontalPane($this);
		$this->m_pattern = "/\.phtml$/i";
		$this->m_manager = new IGKHTMLHorizontalPaneManager($this);
		$this->m_infobox = $this->addDiv()->setClass("posab igk-anchor-all");
		$this->add($this->m_manager);
		
		$this->m_infobox->addDiv()->setClass("disptable fitw fith")
		->addDiv()->setClass("disptabc alignc alignm")->addWebMasterNode()
		->setClass("igk-title igk-text-inactive")
		->setStyle("font-family: dengxian")
		->Content = R::ngets("msg.nopageaddedtopane");
		$this->m_infoboxScript = $this->m_infobox->addScript();
		
		$this->m_ConfigFileName = "config.xml";
		
	}
	public function loadData($data){
		foreach($data->getElementsByTagName("page") as $e){
			$p = $this->addPage();
			$p->Load($e->innerHtml());
			$p->setFile($e["file"]);
		}
	}
	
	public function Render($options =null)
	{
		$this->m_infobox->IsVisible = !$this->m_pane->pageNode->HasChilds;
		$p = $this->getPageViewListener();
		$uri = null;
		if (IGKApp::getInstance()->IsSupportViewMode(IGKViewMode::WEBMASTER))
		{
		if ($p){
			$uri = $p->getAddHorizontalPageUri();
		}
		else{
			$uri = $this->m_manager->getController()->getUri("addUri", $this->m_manager);
		}
		$this->m_infoboxScript->Content = <<<EOF
igk.winui.horizontalScrollPane.initdrag('{$uri}');
EOF;
	$this->m_infoboxScript->setIsVisible(true);
}
else {
	$this->m_infoboxScript->Content = null;
	$this->m_infoboxScript->setIsVisible(false);
}
		return parent::Render($options);
	}
	public function setPageViewListener($listener)
	{
		if (($listener == null) || !igk_reflection_class_implement($listener, 'IIGKHTMLHorizontalPaneListener'))
			throw new Exception("listener is not a valid value ");
		$this->m_pagelistener = $listener;
	}
	public function getPageViewListener()
	{
		return $this->m_pagelistener ;
	}
	public function flush(){
		$this->m_pane->flush();
	}
	public function addPage($attributes=null){
		return $this->m_pane->addPage($attributes);
	}
	public function clearPages(){
		$this->m_pane->Clear();
	}
	public function configure(		
		$AnimDuration = 500,
		$AnimInterval = 20,
		$AnimPeriod = 25000,
		$IsAutoAnimate = true,
		$AnimType = "translation"/// fade, rotation
		){
	$this->m_pane->AnimDuration = $AnimDuration;
	$this->m_pane->AnimInterval = $AnimInterval;
	$this->m_pane->AnimPeriod = $AnimPeriod;
	$this->m_pane->IsAutoAnimate = $IsAutoAnimate;
	$this->m_pane->AnimType = $AnimType;
		
		if ($this->m_pagelistener !=null)
		{
			$this->m_pagelistener->buildPages($this);
		}
		else{
			
			$data = IGKHtmlItem::CreateWebNode("horizontal-pane-data");
			$dir = $this->Folder;
			$p = $this->Pattern;
			IGKIO::CreateDir($dir);
			IGKIO::WriteToFile($dir."/.htaccess", "allow from all", false);						
			foreach(igk_io_getfiles($dir, $p, false) as $k=>$v)
			{
				$v_p = $data->add("page");
				$v_p["file"] = $v;
				$v_p->LoadFile($v);
			}
			$this->loadData($data);
			$this->loadConfigSetting();
		}
	}
}

?>