<?php
/*
//igk_redirection.php
//this file manage error on framework. by redirecting data if IGKSystemUri contains reference
//or framework contains Sites/....
*/
require_once(dirname(__FILE__)."/igk_framework.php");

function redirectDie()
{
	header("Status: 301"); // for fast cgi
	header($_SERVER['SERVER_PROTOCOL'] . " 301 permanent");
	exit;
}

$index_file =dirname(__FILE__)."/../../index.php";
chdir(dirname(__FILE__)."/../../");




// for fast cgi
header("Status: 200 OK"); 
header($_SERVER['SERVER_PROTOCOL'] . " 200 OK");

if (!file_exists($index_file))
{
	igk_wln("index file not exit");
	return;
}
chdir(dirname($index_file));
header("Status: 200 OK"); // for fast cgi
header($_SERVER['SERVER_PROTOCOL'] . " 200 OK");
define("IGK_FORCSS", 1);

include_once($index_file);


IGKApp::$BASEDIR = getcwd();
$code = igk_getv($_REQUEST, "code", 902);//no code found



$args = igk_getquery_args(igk_getv($_SERVER,"REDIRECT_QUERY_STRING"));
$_REQUEST = array_merge($_REQUEST, $args);
//$_REQUEST["server_error"] = $_SERVER;



	
$query = igk_getv($_SERVER, "REQUEST_URI");
$redirect = igk_getv($_SERVER, "REDIRECT_URL");
$redirect_status = igk_getv($_SERVER, "REDIRECT_STATUS");
$r = igk_getv($_SERVER, "REDIRECT_REQUEST_METHOD");
	
	if ($r == "POST" && ($code!=901))
	{	
		igk_notifyctrl()->addMsg("Posted data are lost . ".$code);
	}
	
	$app = IGKApp::getInstance();	
	$v_ruri = igk_io_baseRequestUri();
	
	$tab = explode('?',$v_ruri);
	$uri = igk_getv($tab, 0);
	$params = igk_getv( $tab, 1);

	$page = "/".$uri;
	
	//primitive actions	
	$actionctrl = igk_getctrl(IGK_SYSACTION_CTRL);	

	if ($actionctrl  && ($e = $actionctrl->matche($page)))
	{		
		$app->Session->RedirectionContext = 1;
		$actionctrl->invokeUriPattern($e);
		return;
	}
	try{
	//default page management
	if (igk_sys_ispagesupported($page))
	{		
		$tab = $_REQUEST;
		igk_resetr();
		$_REQUEST["p"] = $page;
		$_REQUEST["l"] = $lang;
		$_REQUEST["from_error"] = true;
		$app->ControllerManager->InvokeUri();
		igk_render_doc();
		exit;
	}
	
	}
	catch(Exception $ex)
	{
		
	}
	//virtual web drive
	$dir = getcwd()."/Sites/".$page;
	if (is_dir($dir))
	{
		$s = igk_io_currentRelativeUri("/Sites/".$page);		
		chdir($dir);
		R::ChangeLang($lang);
		$IGK_APP_DIR = $dir;
		//remove all variable
		include("index.php");
		exit;
	}
header("Status: 301"); // for fast cgi
header($_SERVER['SERVER_PROTOCOL'] . " 301 permanent");

$error_ctrl = igk_getctrl(igk_sys_getconfig("error_ctrl"), false);
if ($error_ctrl && method_exists(get_class($error_ctrl) , "ViewError"))
{
	$error_ctrl->ViewError($code, $redirect);
}
else{
$doc = new IGKHtmlDoc(IGKApp::getInstance(), true);
$container = $doc->Body->addDiv();
$container["class"] = "fitw fith igk-powered-view";
$container["style"] = "overflow:auto";

$container->add("div", array("class"=>"igk-error-title igk-title-4"))->Content = "ERROR";
$t= $container->addDiv();
$t["class"] = "igk-notifybox igk-notifybox-danger";
$t->add("blockquote")->Content = R::ngets("msg.error.requestedpagenotfount_1", $code  ." : " .$redirect. "");

$container->addDiv()->addA(igk_io_baseuri())->Content = "home";
//$t->add("div")->Content = $c;
$doc->Title = R::ngets("title.error_1", igk_sys_getconfig("website_title"));

$doc->RenderAJX();	
}
exit;
?>