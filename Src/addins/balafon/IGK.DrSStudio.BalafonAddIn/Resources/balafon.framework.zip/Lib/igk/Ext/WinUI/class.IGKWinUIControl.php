<?php
//UTILITY FUNCTION

//----------------------------------------------------------------
//represent a base winui control
//----------------------------------------------------------------
class IGKWinUIControl extends IGKHtmlItem
{
	private $m_id;
	
	public function Render($options = null)
	{
		return parent::Render($options);
	}
	protected function innerHTML (& $xmloptions =null)
	{
		return parent::innerHTML($xmloptions);
	}
	public function __construct($tagname)
	{
		$this->m_id = igk_new_id();
		parent::__construct($tagname);		
	}
	
}
?>