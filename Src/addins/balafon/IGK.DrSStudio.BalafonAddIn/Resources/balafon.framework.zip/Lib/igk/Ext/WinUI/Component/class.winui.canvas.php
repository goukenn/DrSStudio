<?php

class IGKHtmlCanvaNode extends IGKHtmlItem
{
	private $m_ctrl;
	
	public function __construct($ctrl){
		parent::__construct("canvas");
		$this->m_ctrl = $ctrl;	
		$this["width"] = "320px";
		$this ["height"] = "500px;";
	}
	public function innerHTML(& $xmlOption=null)
	{
		$o = parent::innerHTML($xmloption );
		$script =  IGKHtmlItem::CreateWebNode("script");
		$script->Content = "window.igk.winui.canva.initctrl('".$this->m_ctrl->getUri("getCanvaRendering")."');";
		$o .= $script->Render();
		return $o;
	}
}

?>