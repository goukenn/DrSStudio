<?php
/*
USED TO ADD A FORUM ON A plateform CONTROLLER 

*/
abstract class IGKForumCtrl  extends IGKCtrlTypeBase
{
	protected function InitComplete(){
		parent::InitComplete();		
		
	}	
}
?>