<?php
//create index if not exist
//try to destroy session
@session_destroy();

require_once(dirname(__FILE__)."/igk_framework.php");
$file =dirname(__FILE__)."/../../index.php";
$htaccess =dirname(__FILE__)."/../../.htaccess";
IGKApp::$BASEDIR = dirname($file);
$redirect = igk_getr("redirect", 1);

IGKControllerManagerObject::ClearCache();
IGKApp::SetIsInit(false);

if (file_exists($file))
{	
	include_once($file);	
	if ($redirect)
	{
		header("Location: ../../Configs");
		igk_exit();
	}
}
else{
	$indexsrc = igk_getbaseindex();
	if (igk_io_save_file_as_utf8($file, $indexsrc , true))
	{
		igk_io_save_file_as_utf8($htaccess, igk_getbase_access(), true);
		$file = realpath($file);
		include_once($file);	
		 if ($redirect)
		 {
			header("Location: ../../Configs");
		 }
	}
}
exit;
?>