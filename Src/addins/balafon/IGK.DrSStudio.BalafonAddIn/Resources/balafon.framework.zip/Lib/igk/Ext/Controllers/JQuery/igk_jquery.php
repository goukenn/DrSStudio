<?php
/*
boot strap structure controller 
*/
final class IGKJQueryCtrl extends IGKConfigCtrlBase
{
	public function getName(){
		return "jquery";
	}
	public function getIsSystemController()
	{
		return true;
	}
	public function getIsEnabled(){
		return igk_sys_getconfig("JQuery.Enabled", false);
	}
	protected function InitComplete(){		
		parent::InitComplete();
		$this->app->addNewDocumentCreatedEvent($this, "docCreated");
		$this->_loadInfo();	
	}
	public function docCreated($n, $a)
	{
		if ($a !=null)
			$this->__bindJquery($a);
	}
	private function _loadInfo(){
		$this->__bindJquery($this->App->Doc);		
	}
	public function __bindJquery($doc){
		$f =  igk_io_baseDir("/Lib/jquery/jquery.min.js");
		if (file_exists($f))		
		{
			if ($this->IsEnabled)
			{
				$doc->Body->appendScript($f, false,  -100);
			}
			else {
				$doc->Body->removeScript($f);
			}
		}
	}
	
	public function getConfigPage()
	{
		return "jquery";
	}
	public function View(){
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();
		igk_html_add_title($c, "title.ConfigJQuery");
		$c->addHSep();
		igk_add_article($this, "bootstrap", $c->addDiv(), null, true);
		
		$c->addHSep();
		
		
		$div = $c->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("update_jquery_setting");
		
		$d = $frm->addDiv();
		$d["class"]="form-group";
		//enable boot strap
		$ct = $d->addSLabelInput("clEnableJQuery", 
		"checkbox" , "1");
		$ct->input["onchange"] = igk_js_post_form_uri(
		$this->getUri("update_jquery_setting_ajx"),
		"function(xhr){ if (this.isReady()){ }}"
		);
		$ct->input["checked"] =  (igk_parsebool($this->IsEnabled)=="true")?"true": null;
		
		$d->addHSep();
		$s = $d->addDiv();		
		
	}
	public function update_jquery_setting()
	{
		$this->update_jquery_setting_ajx();
	}
	public function update_jquery_setting_ajx()
	{
		$this->App->Configs->SetConfig("JQuery.Enabled",igk_getr("clEnableJQuery", false));		
		$this->_loadInfo();
		igk_save_config();	
		$this->View();
	}
}
?>