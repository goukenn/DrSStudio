<?php
//-------------------------------------------------
///community default manager
//-------------------------------------------------
final class IGKCommunityLink extends IGKConfigCtrlBase
{

	public function getIsSystemController()
	{
		return true;
	}
	
	public function getConfigPage()
	{
		return "community";
	}
	
	public function comm_rm()
	{
		//remove communauty
		
		$id = igk_getr("clId");
		if (igk_qr_confirm())
		{			
			igk_db_delete(IGK_MYSQL_DATAADAPTER, $this->getCommunityTable() ,array("clId"=>$id));		
		}
		else{
			$frame = igk_add_confirm_frame($this,"confirm_rm_frame", $this->getUri("comm_rm&clId=".$id));
			$frame->Form->Div->Content = R::ngets("msg.confirmsuppression");			
			$frame->Form->Div->addInput("clId", "hidden", $id);			
		}
		$this->View();
	}
	public function comm_addComm()
	{
		$k = igk_get_robj();
		igk_db_insert(IGK_MYSQL_DATAADAPTER,$this->getCommunityTable(), $k);
		$this->View();
	}
	public function comm_addCommunityFrame()
	{	
		$frame = igk_add_new_frame($this, "add_comm");
		$frame->Title = R::ngets("title.addCommunity");
		
		$frm = $frame->Content->addForm();
		$frm["action"] = $this->getUri("comm_addComm");
		
		$ul = $frm->add("ul");
		;
		$li = $ul->add("li");
		$li->addLabel("lb.name" , "clName");
		$li->addInput("clName", "text", "");
		$li = $ul->add("li");
		$li->addLabel("lb.Url" , "clLink");
		$li->addInput("clLink", "text", "");
		
		$li = $ul->add("li");
		$li->addLabel("lb.ImageKey" , "clImageKey");
		
		$li->addInput("clImageKey", "text", "");
		
		$li = $ul->add("li");
		$li->addLabel("lb.AVailable" , "clAvailable");
		$li->addInput("clAvailable", "checkbox", "1");
		
		$d = $frm->addDiv();
		$d->addInput("btnOk", "submit", R::ngets("btn.add"));
		return $frame;
	}
	
	public function comm_addCommunityFrame_ajx()
	{
		$frm = $this->comm_addCommunityFrame();
		$frm->RenderAJX();
	}
	public function comm_block()
	{
		$t = igk_getr("t");
		$id = igk_getr("clId");
		igk_db_update(IGK_MYSQL_DATAADAPTER, $this->getCommunityTable() ,array("clAvailable"=>$t), array("clId"=>$id));
		$this->View();
	}
	public function getCommunityTable()
	{
		return "tbigk_community";
	}
	public function View(){
		$c = $this->TargetNode;		
		if (!$this->IsVisible)
		{
			igk_html_rm($c);
			return;
		}
		IGKHtmlUtils::AddItem($c, $this->ConfigNode);		
		$c->ClearChilds();
		
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("update_community");
		igk_html_add_title($frm,"title.configure.community");
		$frm->addHSep();
		igk_add_article($this, "community_desc", $frm->addDiv(), null, true);
		$frm->addHSep();
		$ul = $frm->add("ul");
		$table = $this->getCommunityTable();
		
		$tab =  null;
		try{
		 $tab = igk_db_get_entries(IGK_MYSQL_DATAADAPTER, $table);
		}
		catch(Exception $ex){
		}

		if (($tab==null) || ($tab->RowCount == 0))
		{
			$ul->add("li")->Content = "No Communauty database created or entries found";
		}
		else{
			foreach($tab->Rows as $k)
			{
				if (!$k)
					continue;				
				$li = $ul->addLi();
				$lb = $li->add("label");
				$lb["for"] = $k->clName.".clLink";
				$lb->Content = $k->clName;
				
				$li->addInput("clLink[]", "text", $k->clLink);
				$li->addInput("clIds[]", "hidden", $k->clId);
				if (igk_getv($k, "clAvailable", 1)){
					IGKHtmlUtils::AddImgLnk($li, $this->getUri("comm_block&t=0&clId=".$k->clId), "unblock");
				}
				else{
					IGKHtmlUtils::AddImgLnk($li, $this->getUri("comm_block&t=1&clId=".$k->clId), "block");
				}
				IGKHtmlUtils::AddImgLnk($li, $this->getUri("comm_rm&clId=".$k->clId), "drop");
			}
			
			
		}
		
		if ($tab!=null){
			$ul = $frm->addDiv();
			IGKHtmlUtils::AddImgLnk($ul, igk_js_post_frame($this->getUri("comm_addCommunityFrame_ajx")), "add");
		}
		
		 $frm->AddHSep();
	     $frm->addBtn("btn_send", R::ngets("btn.update"));
		
	}
	
	
	public function update_community()
	{
		$d = igk_get_robj();
		if (isset($d->clIds))
		{
			
				$adapt = igk_getdata_adapter(IGK_MYSQL_DATAADAPTER, false);	
				if($adapt)
				{
					$adapt->connect(null);
					 $table = $this->getCommunityTable();
					 for($i =0; $i< count($d->clIds); $i++)
						{
							$adapt->update($table, array("clLink"=>mysql_real_escape_string($d->clLink[$i])), "`clId`='".
							mysql_real_escape_string($d->clIds[$i])
							."'" );
						}
					$adapt->close();
					igk_notifyctrl()->addMsgr("msg.CommunityLinkUpdated");
				}	
			
		}
		else{
					igk_notifyctrl()->addMsgr("msg.CommunityLinkUpdated");
		}
		$this->View();
		//igk_navtocurrent();
	}
	
	public function addGooglePlus($target){
		$lnk = $this->App->Doc->addLink("googleplus:uri");
		$lnk["rel"] = "canonical";
		$lnk["href"] = $this->App->Configs->community_googleplus_uri;
		$src = $this->App->Doc->addScript("https://apis.google.com/js/plusone.js");
		$gdiv = $target->add("span");
		$gdiv->add("g:plusone")->addNothing();
	}
	
}
?>