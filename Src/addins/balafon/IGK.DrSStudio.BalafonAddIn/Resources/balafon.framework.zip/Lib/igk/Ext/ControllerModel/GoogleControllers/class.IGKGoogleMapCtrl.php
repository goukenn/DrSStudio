<?php
//<summary>used to add google map controller model on the web site</summary>
abstract class IGKGoogleMapCtrl extends IGKCtrlTypeBase
{
	public function getcanAddChild(){
		return false;
	}
	public static function GetAdditionalConfigInfo()
	{
		return array("clGoogleMapUrl");
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clGoogleMapUrl"] = igk_getr("clGoogleMapUrl");
	}
	public function View()
	{
		$t = $this->TargetNode;
		$t->ClearChilds();
		$lnk = igk_getv($this->Configs, "clGoogleMapUrl", "http://www.google.fr");
		$s = <<<EOF
<iframe class="noborder googlemap_map" src="{$lnk}"></iframe>
EOF;
	$t->Load($s);
		
	}
}
?>