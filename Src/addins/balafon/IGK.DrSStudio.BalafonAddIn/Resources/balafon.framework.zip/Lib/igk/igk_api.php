<?php
define("IGK_API_CTRL", "API");
define("IGK_API_VERSION", "1.0.0.0");
//will be used for api use
final class IGKApiFunctionCtrl extends IGKConfigCtrlBase
{
	public function getName(){return IGK_API_CTRL;}
	public function getVersion(){return IGK_API_VERSION; }
	public function getIsVisible(){ 	
		return false;
	}
	
	public $message =  array();
	
	public function getIsSystemController(){ return true; }
	
	public function getConfigPage()
	{
		return "api";
	}	
	public function IsFunctionExposed( $function )
	{
		return true;
	}
	public function request()
	{
	/*
	how to used exemple : http://localhost/IGKDEV/?c=API&f=request&u=admin&pwd=admin&q=P2M9bGFuZyZmPWdldGxhbmdrZXlzJmZvcm1hdD14bWw=
	
	*/
		$u = igk_getr("u");
		$pwd = igk_getr("pwd");
		$this->ConfigCtrl->logout(false, true);
		if (!$this->ConfigCtrl->IsConnected)
		{
			$this->ConfigCtrl->connect($u, $pwd, false);
		}
		
		if ($this->ConfigCtrl->IsConnected)
		{
			session_start();
			
			$q = base64_decode(igk_getr("q")); 
			igk_resetr();
			igk_loadr($q);
			$node->add("ExecutionResponse")->Content =  $this->App->ControllerManager->InvokeFunctionUri($q);
			$this->ConfigCtrl->logout(false, true);			
		}
		else{
			igk_debug("connection failed ");
		}		
		exit;
	}

	public function beginRequest(){
		$u = igk_getr("u");
		$pwd = igk_getr("pwd");
		//$this->ConfigCtrl->logout(false, false);
		if (!$this->ConfigCtrl->IsConnected)
		{
			$this->ConfigCtrl->connect($u, $pwd, false);
		}
		
		$node =  IGKHtmlItem::CreateWebNode("APIResponse");
		if ($this->ConfigCtrl->IsConnected)
		{
			//session_start();			
			$node->add("status")->Content = "OK";
			$this->setParam("api:u", $u);
			$this->setParam("api:pwd", $pwd);
			$node->add("SessionId")->Content = session_id();
			igk_show_prev(getallheaders());
		}
		else{
			igk_debug("connection failed ");			
			$node->add("status")->Content = "NOK";
			$node->add("message")->Content = $this->message[0];
		}	
		$node->renderAJX();		
		exit;
	}
	public function sendRequest()
	{
		
		
		$node =  IGKHtmlItem::CreateWebNode("APIResponse");
		$q = base64_decode(igk_getr("q")); 		
		// $node->add("user")->Content = $this->getParam("api:u");
		// $node->add("pwd")->Content = $this->getParam("api:pwd");
		$node->add("Connected")->Content = igk_parsebool($this->ConfigCtrl->IsConnected);		
		$node->add("Request")->Content = $q;
		if ($q){
			igk_resetr();
			igk_loadr($q);
			$node->add("ExecutionResponse")->Content = $this->App->ControllerManager->InvokeFunctionUri($q);
		}
		$node->renderAJX();		
		exit;
	}
	public function endRequest(){
		//igk_show_prev(getallheaders());
		$node =  IGKHtmlItem::CreateWebNode("APIResponse");
		if ($this->ConfigCtrl->IsConnected)
		{
			$this->ConfigCtrl->logout(false, true);				
			$node->Content = "OK";		
		}
		$node->renderAJX();
		exit;
	}
}
?>