<?php
/*
*Include here your default data base definition. this file will be include in some data
*base access file
*/
// define("dBName", "myDB");
// define("dBSerer", "localhost");
// define("dBType", "mysql");
// define("dBUser", "root");
// define("dBPwd", "");
?>