<?php
class IGKSitemapGeneratorTools extends IGKToolCtrlBase
{

	public function getImageUri(){ 		
		$uri = igk_html_uri(igk_io_basePath($this->getCtrlFile("/../Default/R/Img/pics_48x48/tool_sitemapgen.png")));
		return $uri;
	}
	public function doAction()
	{
		$out = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		
		$map =  IGKHtmlItem::CreateWebNode("urlset");
		$map["xmlns"] = "http://www.sitemaps.org/schemas/sitemap/0.9";
		
		//buid sitemap
		$pages = igk_sys_pagelist();
		
		foreach($pages as $k=>$v)
		{
			$url = $map->add("url");
			$url->add("loc")->Content = igk_html_uri(igk_str_rm_last(igk_io_baseUri(),'/')."/".$v);
		}
		
		$out .= $map->Render((object) array("Indent"=>true));
		
		
		
		igk_io_save_file_as_utf8(igk_io_currentBasePath("sitemap.xml"), $out);
		igk_notifyctrl()->addMsgr("msg.sitemapgenerated");
		igk_navtocurrent();
	}
}
?>