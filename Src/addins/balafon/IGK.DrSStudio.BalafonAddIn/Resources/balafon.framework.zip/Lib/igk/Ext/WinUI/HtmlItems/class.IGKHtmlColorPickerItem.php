<?php
//igk.winui.colorpicker
final class IGKHtmlColorPickerItem extends IGKHtmlItem
{
	private $m_script;
	private $r;
	private $g;
	private $b;
	public function getWebValue(){
		$v_r = IGKNumber::ToBase($this->r, 16, 2);
		$v_g = IGKNumber::ToBase($this->g, 16, 2);
		$v_b = IGKNumber::ToBase($this->b, 16, 2);
		
		return "#".$v_r.$v_g.$v_b;
	}
	public function __construct(){
		parent::__construct("div");
		$this->setClass("igk-picker-box");
		
		$this->addDiv()->setClass("progress IGK-picker-track")->setId("r")->addDiv()->setClass("progress-bar")->loadDataAsAttribute(
			array(
			"aria-valuenow"=>"60", 
			"role"=>"progress-bar",
			"aria-valuemin"=>"0",
			"aria-valuemax"=>"100",
			"style"=>"width:60%;"
		));
		$this->addDiv()->setClass("progress IGK-picker-track")->setId("g");
		$this->addDiv()->setClass("progress IGK-picker-track")->setId("b");
		
		$frm = $this->addDiv()->addForm();
		$frm->addInput("clValue", "hidden",$this->getWebValue());
		$this->addDiv()->Content = $this->getWebValue();
		
		
		$this->addScript()->Content =<<<EOF
(function(q){ function initColorpicker(){
	
}})(\$ns_igk.getParentScript());
EOF;
		
		igk_css_regclass(".igk-picker-box", "{sys:dispb} min-height:96px; width: 200px; padding-top:8px; padding-bottom:8px; margin:0px; margin-left:auto; margin-right:auto; border:1px solid #aaa;");	
		
		igk_css_regclass(".igk-picker-box .igk-picker-track", "{sys:dispb} min-height:16px;  border:1px solid #eee; background-color: red; margin:0px");
		igk_css_regclass(".igk-picker-box > .igk-picker-track:not(:first-of-type):not(:last-of-type)", "margin-top:16px;margin-bottom:16px;");
		igk_css_regclass(".igk-picker-box > .igk-picker-track:first-of-type", "margin-bottom:8px !important; background-color:blue;");
		igk_css_regclass(".igk-picker-box > .igk-picker-track:last-of-type", "margin-top:8px !important;");
		
		igk_css_regclass(".igk-picker-box #r","background-color:red;");
		igk_css_regclass(".igk-picker-box #g","background-color:green;");
		igk_css_regclass(".igk-picker-box #b","background-color:blue");
	}
	

}

?>