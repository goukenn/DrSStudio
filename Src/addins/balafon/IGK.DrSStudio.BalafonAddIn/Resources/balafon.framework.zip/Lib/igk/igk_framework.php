<?php
/*
//
//STATIC METHOD START WITH CAPITAL LETTER.
//INSTANCE METHOD START WITH LOWER LETTER
//
//file: igk_framework.php
//
*/
define("IGK_WEBFRAMEWORK", "8.7");
define("IGK_FRAMEWORK","IGKDEV-WFM");
define("IGK_AUTHOR", "C.A.D. BONDJE DOUE");
define("IGK_AUTHOR_CONTACT", "bondje.doue@igkdev.be");
define("IGK_PLATEFORM_NAME", "BALAFON");
define("IGK_VERSION", "8.7.2.0211");
define("IGK_RELEASE_DATE", "11/02/15");
define("IGK_START_DATE", "01/01/13");
define("IGK_COPYRIGHT", "IGKDEV &copy; 2015 all rights reserved");
define("IGK_WEB_SITE", "http://www.igkdev.com");
define("IGK_LIB_DIR", dirname(__FILE__));

include_once("igk_autorisation.php");
include_once("igk_config.php");
require_once("igk_gd.phtml");
require_once(dirname(__FILE__)."/../Fpdf/fpdf.php");


function igk_exit(){
exit;
}

//------------------------------------------------------------------------
//global system functions
//------------------------------------------------------------------------
///<summary>get the system version. alias function of constant IGK_VERSION</summary>
function igk_sys_version(){return IGK_VERSION; }
///<summary>get the system author. alias function of constant IGK_AUTHOR</summary>
function igk_sys_author(){ return IGK_AUTHOR; }
///<summary>get system configuration value</summary>
function igk_sys_getconfig($name, $defaultvalue=null){ //get system configs by name
	return igk_getv(IGKApp::getInstance()->getConfigs(),$name, $defaultvalue); 
}
///<summary>include file in system configuration</summary>
function igk_sys_include($name){
	return include(igk_io_currentRelativePath($name));
}
///<summary>require file in system configuration</summary>
function igk_sys_require($name){
	require(igk_io_currentRelativePath($name));
}
///<summary>get system debug zone controller</summary>
///<remark>only one at time</sumary>
function igk_sys_debugzone_ctrl()
{
	return igk_getctrl(igk_getv(IGKApp::getInstance()->getConfigs(), "debugHostCtrl", null), false);
}
function igk_sys_errorzone_ctrl(){
	return igk_getctrl(igk_getv(IGKApp::getInstance()->getConfigs(), "errorHostCtrl", null), false);
}

function igk_create_dynamic($data){
	$m = new IGKDynamicObject();
	$m->initProperties($data);
	return $m;
}

function igk_sys_create_user($userdata, 
 $usertable="tbigk_users",//table from
 $authtable="tbigk_autorisations", //authorization list table
 $grouptable="tbigk_groups", //groups list
 $groupauth="tbigk_groupautorisations",//group association table,
 $usergrouptable="tbigk_usergroups"
 )
{
	$b = new IGKUserInfo();
	$b->loadData($userdata);
	$b->authtable = $authtable;
	$b->grouptable = $grouptable;
	$b->groupauthtable = $groupauth;
	$b->usertable = $usertable;
	$b->usergrouptable = $usergrouptable;
	return $b;
}
function igk_sys_isuser_authorize($u, $authname){
	return $u->IsAuthorize($authname);
}

///<summary>get uri action pattern info</summary>
function igk_sys_ac_getpatterninfo(){//get current uri action pattern info
	return igk_getctrl(IGK_SYSACTION_CTRL)->getPatternInfo();
}
function igk_sys_ac_getpattern($basePatternUri){
	return igk_getctrl(IGK_SYSACTION_CTRL)->getPattern($basePatternUri);
}
///<summary>use to register action</summary>
function igk_sys_ac_register($uriPattern, $uri){
	igk_getctrl(IGK_SYSACTION_CTRL)->sys_ac_register($uriPattern, $uri);
}
function igk_sys_ac_unregister($uriPattern){
	igk_getctrl(IGK_SYSACTION_CTRL)->sys_ac_unregister($uriPattern);
}
///<summary> get a new powerd node block to add to body</summary>
function igk_sys_powered_node(){
	// if (!true){
	$d =  IGKHtmlItem::CreateWebNode("div");
	$d["class"]="igk-powered";
	$d->Content = "Powered by <a href=\"".IGK_WEB_SITE."\" >IGKDEV</a> ";	
	$d->addScript()->Content = "if (window.igk)window.igk.initpowered();";
	return $d;
	// }
	// return null;
}
//------------------------------------------------------------------------
//global utility functions
//------------------------------------------------------------------------


//log function 
function igk_log_write($msg)
{
	$s = igk_getctrl(IGK_LOG_CTRL);
	if ($s){
		$s->write($msg);
	}
}
function igk_log_write_i($tag, $msg)
{
	$s = igk_getctrl(IGK_LOG_CTRL);
	if ($s){
		$s->write_i($tag, $msg);
	}
}
///<summary>used to bind attribuyte to type</summary>
///<exemple>bind attribute</exemple>
function igk_bind_attribute($type, $name, $attribute, $allowmultiple=true, $inherits=false){
	switch($type)
	{
		case "class":
			IGKAttribute::Register($name, $attribute,$allowmultiple, $inherits);
			break;
		case "method":
			break;
	}
}
///<summary>user fonctions . get fullname </summary>
function igk_user_fullname($u)
{
	return igk_getv($u, "clFirstName")." ".igk_getv($u, "clLastName");
}
///<summary>get the current uri </summary>
function igk_uri(){
	return igk_getv($_SERVER, 'REQUEST_QUERY');
}
function igk_web_prefix(){//used to get the web page config website_prefix
	return IGKApp::getInstance()->Configs->website_prefix;
}
function igk_web_defaultpage(){
	return igk_getv(IGKApp::getInstance()->Configs, "menu_defaultPage", "default");
}
function igk_web_get_config($name){//get the webpage web configuration files
	return igk_getv(IGKApp::getInstance()->Configs, $name);
}



function igk_new_response()
{
	return new IGKHtmlResponse();
}
///<summary>show an alert to document information </summary>
///<remark>document must be fully loaded. can be uses at the InitComplete </remark>
function igk_alert($mgs)
{
	$frame = igk_add_new_frame(igk_getctrl(IGK_FRAME_CTRL), "alert_frame");	
	$frame->Title = R::ngets("title.alert");
	$frame->Content->ClearChilds();
	$frm = $frame->Content->addForm();
	$frm->addDiv()->Content = $msg;
}

function igk_can_set_ctrlparent($ctrl, $parentName){//detect if a ctrl can be a child of $parentName
	$p = igk_getctrl($parentName ,false);
	while($p)
	{
		if (($p == $ctrl) || (!$p->CanAddChild))
			return false;
		$p = $p->getWebParentCtrl();
	}	
	return true;
}
//-----------------------
//RESOURCES FUNCTION
function igk_r_getdisplay($key, $param=null){	
	return R::ngets($key, $param)->getValue();
}


//get regex from pattern
function igk_regex_get($pattern , $key, $value, $index = 0)
{
	$t = array();
	$c = preg_match_all($pattern, $value,$t); 
	
	if ($c>0)
	{
		if ($c==1){
		return $t[$key][0];
		}
		else{
			return $t[$index][$key];	
		}
	}
	return null;
}
///<summary>
///used to parse string value to compatible xml value.
///</summary>
function igk_parsexmlvalue($value, $isvalue=false, $isandroidres=false)
{
	$value =  preg_replace_callback("/(?<value>('|([&]((quot);)*)))/i", function($tmatch) use ($isvalue, $isandroidres){	
		switch($tmatch["value"])
		{
			case "&":
				return "&amp;";
				break;
			case "&quot;":
				return "\"";
			case "'":
				if ($isandroidres)
					return "\\'";
				break;
				
		}
		//igk_show_prev($tmatch);
		return $tmatch[0];
	}, $value); 
	;
	return $value;
}

///<summary>send mail to from</summary>
function igk_mail_sendmail($to, $from, $title, $message, $replyto=null)
{
	return igk_getctrl("igkmailctrl")->sendmail($from, $to, $title, $message, $replyto);
}
///<summary>get mail style sheet</summary>
function igk_mail_stylesheet(){
	$s =HtmlItem::CreateWebNode("style");
	$s["type"]="text/css";
	$f = igk_io_currentRelativePath(igk_sys_getconfig("mail_style_sheet", igk_io_basePath(IGKIO::GetDir(dirname(__FILE__)."/Default/Styles/mail.css"))));
	if (file_exists($f))
	{
		$v_s = igk_str_remove_lines(IGKIO::ReadAllText($f));
		$v_s = igk_css_treat(IGKApp::getInstance()->getDoc()->getTheme(), $v_s);
		$s->setContent($v_s);
	}
	else{
		igk_wln(getcwd());
		igk_wln("file not exists ".$f);
	}
	
	return $s->Render();
}

//@ check if the name if a valid identifier
function igk_isidentifier($name)
{
	return preg_match(IGK_ISIDENTIFIER_REGEX, $name);
}

//----------------------------------------------------
//VALIDATOR functions
//----------------------------------------------------
function igk_val_init()
{
	IGKValidator::Init();
}
function igk_val_cbcss($e, $name)
{
	if ($e && isset($e[$name]))
		return "err_c";//error cibling
}
function igk_val_regParam($ctrl, $name)
{
	
	$ctrl->setParam($name.":error", igk_val_node());
	$ctrl->setParam($name.":errorcibling", igk_val_cibling());
}
function igk_val_unregParam($ctrl, $name)
{
	$ctrl->setParam($name.":error", null);
	$ctrl->setParam($name.":errorcibling",null);
}
function igk_val_cibling(){
	return IGKValidator::Cibling();
}
function igk_val_node(){
return IGKValidator::Error();
}
function igk_val_haserror(){
	return IGKValidator::Error()->HasChilds;
}
function igk_val_isStrNullOrEmpty($tname, $msg){
		if (IGKValidator::IsStringNullOrEmpty($tname)){ IGKValidator::Error()->add("li")->Content = $mg; }
}
function igk_val_ispic($type, $msg){
		if (!igk_io_fileIsPicture($type)){ IGKValidator::Error()->add("li")->Content = $msg; }
}
function igk_val_add_error($msg, $cibling=null)
{
	$li = igk_val_node()->add("li");
	$li->Content = $msg;
	IGKValidator::AddCibling($cibling);
	$li->cibling = $cibling;
	return $li;
}
function igk_val_check($callback, $object, $name, $msg)
{
	
	if (is_bool($callback))
	{
		if ($callback)
		{
			igk_val_add_error($msg, $name);			
		}
		return;
	}	
	$v = call_user_func_array(array("IGKValidator",$callback), array($object->$name));	
	if ($v)
	{
		igk_val_add_error($msg, $name);
	}
}


function igk_sort_byNodeIndex($a,$b)
{
	if ($a->TargetNode && $b->TargetNode)
	{
		$i = $a->TargetNode->Index;
		$j = $b->TargetNode->Index;
		return ($i == $j)? 0: (($i<$j) ? -1 : 1); 
	}
	return strcmp($a->Name, $b->Name);
}

function igk_add_loading_frame($t)
{
	$uri = R::GetImgUri("waitcursor");
	if ($uri)
	$t->addDiv(array("class"=>"dispib"))->addScript()->Content = "igk.media.webplayer.init(igk.getParentScript(),'{$uri}');";
}
//Comparaison func
function igk_cmp_refobj($o,$i)
{
	if (($o==null) && ($i==null))
		return true;
	if ((($o==null) && ($i!=null)) || (($o!=null) && ($i==null)) )
		return false;
	$cmp = igk_new_id();
	igk_debug_wln($cmp);
	$o->$cmp = true;
	igk_debug_wln(" : ". $o->$cmp);
	igk_debug_wln(" : ". $i->$cmp);
	$r = (!empty($i->$cmp));
	//clean up
	unset($o->$cmp);
	return $r;
}

// get the controller types
function igk_sys_ctrl_type($ctrl)
{
	$s = get_class($ctrl);
	if (igk_reflection_class_extends($s, "IGKCtrlTypeBase"))
	{
		$t = class_parents($s);
		$ht = IGKCtrlTypeManager::GetControllerTypes();
		$ht = igk_array_key_value_toggle($ht);
		
		foreach($t as $k=>$v)
		{
			if (isset($ht[$v]))
				return $ht[$v];
		}
	}
	return "unknow";
}

function igk_sys_buildconfirm_ajx($ctrl, $id,  $uri, $callback, $message, $hiddenEntries=null)
{	
	if (igk_qr_confirm())
	{						
		$ctrl->call($callback);		
	}
	else{
		$frame = igk_frame_add_confirm($ctrl,$id, $uri);
		$frame->Form->Div->Content = $message;
		if ($hiddenEntries)
		{
			foreach($hiddenEntries as $k=>$v)
			{
				$frame->Form->addInput($k, "hidden",$v);	
			}
		}
		igk_wl($frame->Render());
	}	
}
//return that requrest in on ajx context. to enable ajx context function name must end with "_ajx" or the requested uri must add a ajx=1 variable
function igk_sys_isAJX()
{
	return IGKApp::getInstance()->Session->URI_AJX_CONTEXT;
}
function igk_sys_ispagesupported($key)
{
	$tab = igk_getctrl(IGK_MENU_CTRL)->getPageList();
	$tab = igk_array_tokeys($tab);	
	return isset($tab[$key]);	
}
function igk_sys_islanguagesupported($key)
{
 	$tab = igk_getctrl(IGK_LANGUAGE_CTRL)->Languages;
	$tab = igk_array_tokeys($tab);	
	return isset($tab[$key]);
}

//------------------------------------------------------------------------------------------------------------------------------
//javascript utility functions
//------------------------------------------------------------------------------------------------------------------------------

//<summary>used to post frame to uri. used in href of <a></a> element </summary>
///<remark>if frame need to be shown used ajax mecanism</remark>
//@uri: to post
//@ctrl: controller to where response must be send in ajax syntax
function igk_js_ctrl_posturi($ctrl, $uri)
{
	$q = IGK_STR_EMPTY;
	if ($ctrl!=null)
	{
		$q = ",'".$ctrl->TargetNode["id"]."'";
	}
	else
		$q = ",null";	
	return "javascript:window.igk.ctrl.frames.postframe(this, '".$ctrl->getUri($uri)."&ajx=1'".$q.");";
}

//<summary>used to get javascript uri component to post frame on the javascript context</summary>
function igk_js_post_frame($uri, $ctrl =null, $global=true)
{
	return "javascript:".igk_js_post_frame_cmd($uri, $ctrl, $global);
}
//post form data and render a frame
function igk_js_ajx_postform_frame($uri){
	return "javascript:  \$ns_igk.ajx.postform(\$igk(this).getForm(), '".
	$uri.
	"' , function(xhr){ if (this.isReady()){ \$ns_igk.ctrl.frames.appendFrameResponseToBody(xhr.responseText);  }});  return false;";
}
///<summary>get the post frame javascript command</summary>
function igk_js_post_frame_cmd($uri, $ctrl =null, $global=true)
{
	$q = IGK_STR_EMPTY;
	if ($ctrl!=null)
	{
		$q = ",'".$ctrl->TargetNode["id"]."'";
	}
	else
		$q = ",null";
	if ($global)
		$q .=",true";
	else 
		$q .=",false";
	return "ns_igk.ctrl.frames.postframe(this, '".$uri."&ajx=1'".$q.");";
}
//<summary>used to post uri from link</summary>
//@uri: uri to post
//@method: method response. for view
function igk_js_ajx_post_auri($uri, $method=null)
{
	return "javascript: window.igk.web.a_posturi(this,'".$uri."', ".(($method==null)?'null': $method).");";
}
//post a link uri
function igk_js_ajx_post_luri($parentTag){
	return "javascript: return window.igk.ajx.a_postResponse(this, '".$parentTag."');";
}
///<summary>get a link javascript a posturi</summary>
function igk_js_ajx_aposturi($uri, $targetNodeId){//used in list demand to post uri script
	return "javascript: window.igk.ajx.aposturi('".$uri."', '".$targetNodeId."');";
}
function igk_js_ajx_post_body_uri($uri){//used in list demand to post uri script

	$funcd = "function(xhr){ if (this.isReady()){ this.replaceBody();}} ";
	return "javascript: \$ns_igk.ajx.post('".$uri."', null,  ".$funcd."); return false; ";
}
///<summary> get a javascript link uri contain in a form </summary>
function igk_js_a_postform($uri){
	return "javascript: return (function(q){var f = window.igk.getParentByTagName(q, 'form');  if (f){f.action ='".$uri."'; f.submit();return false;}})(this);";
}
///<summary> render script node content</script>
function igk_js_render_script($script){
	$s =  IGKHtmlItem::CreateWebNode("script");
	$s->setContent($script);
	$s->RenderAJX();
}
///<summary> get a javascript src that will post uri to server</summary>
function igk_js_post_uri($uri, $jsfunc=null){
	$jsfunc = $jsfunc ? $jsfunc : "null";
	return "javascript: window.igk.ajx.post('".$uri."', null, {$jsfunc});";
}
///<summary>get a javascript expression to from parent form variable to uri expression</summary> 
///<args name="uri" >uri where to post form</args>
///<args name="jsfunc" >javascript function expression to pass</args>
function igk_js_post_form_uri($uri, $jsfunc=null){
	$c = IGK_STR_EMPTY;
	if ($jsfunc)
		$c .= ",".$jsfunc;		
	return "javascript: window.igk.ajx.postform(this.form, '".$uri."' ".$c."); ";
}
//------------------------------------------------------------------------------------------------------------------------------
//ZIP Utility functions
//------------------------------------------------------------------------------------------------------------------------------
function igk_zip_entry_isdir($e) 
{
	return ((zip_entry_compressionmethod($e) == "stored") || IGKString::EndWith(zip_entry_name($e),"/"));	
}
function igk_zip_create_dir($outdir, $name)
{
	$t = explode('/',$name);
	
	if (is_dir($outdir))
	{
		$d = $outdir;
		foreach($t as $k)
		{
			if (empty($k))continue;
			$d = $d.DIRECTORY_SEPARATOR.$k;
			if (!is_dir($d))
				@mkdir($d);
		}
	}
}
function igk_zip_extract($outdir,$hzip, $e)
{
	if (!is_dir($outdir))
		return;
		
	$d = IGKIO::GetDir($outdir.DIRECTORY_SEPARATOR.zip_entry_name($e));
	
	if (IGKIO::CreateDir(dirname($d)))
	{
		$content = zip_entry_read($e,zip_entry_filesize($e));
		igk_io_save_file_as_utf8_wbom($d, $content,true);
		// $hfile = @fopen($d, 'w+');
		// if ($hfile)
		// {
			// zip_entry_open($hzip, $e, 'r');
			// fwrite($hfile, zip_entry_read($e,zip_entry_filesize($e)));
			// zip_entry_close($e);		
			// fclose($hfile); 
		// }
	}
}

function igk_zip_content($file, $name,  $content)
{
	$zip = new ZipArchive();
	$zip->open($file, ZIPARCHIVE::CREATE);		
	$zip->addFromString($name, $content);
	$zip->close();			
}
function igk_unzip_content($content)
{		
}
function igk_zip_dir($dir, $zip, $folder=null, $regex = null)
{
		
	$hdir = opendir($dir);		
	if (is_resource($hdir))
	{
		
		while( $d  = readdir($hdir))
		{
			
			if (($d==".") || ($d=="..") || (($regex!==null) && preg_match($regex, $d)))
			{					
				continue;
			}
			$f = $dir."/".$d;
			if (is_dir($f))
			{
				$zip->addEmptyDir($folder==null ? $d : $folder."/".$d);
				igk_zip_dir($f,$zip, $folder==null ? $d : $folder."/".$d, $regex);
			}
			else if (is_file($f))
			{
				$zip->addFile($f, $folder==null ? $d : $folder."/".$d);
			}
		}			
		closedir($hdir);
	}
}
	


//get the number of items



function igk_count($item)
{
	if (is_array($item))
		return count($item);
	if (is_object ($item) )
	{
		if (method_exists(get_class($item), "getCount"))
			return $item->getCount();
		if (method_exists(get_class($item), "getRowCount"))
			return $item->RowCount();
	}	
	return 0;
}
function igk_render_doc(){//render the document
	IGKApp::RenderDocument();
}
function igk_get_allheaders(){
	if (function_exists("getallheaders"))
	{
		return getallheaders();
	}
	$tab = array();
	 foreach ($_SERVER as $name => $value)
	   {
		   if (substr($name, 0, 5) == 'HTTP_')
		   {
			   //$name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
			   $name = str_replace(' ', '-',  substr($name, 5));
			   $tab[$name] = $value;
		   } else if ($name == "CONTENT_TYPE") {
			   $tab["Content-Type"] = $value;
		   } else if ($name == "CONTENT_LENGTH") {
			   $tab["Content-Length"] = $value;
		   }
	   } 
	return $tab;
}
///return the base index.php content
function igk_getbaseindex()
{
$showError = <<<EOF
//Display ERRORS
ini_set("display_errors", "1");
error_reporting(E_ALL);
EOF;

return <<<EOF
<?php
$showError
//
//require framework
//
\$IGK_APP_DIR = dirname(__FILE__);
require_once("Lib/igk/igk_framework.php");
try{
//------------------------------------------------------------------------------------------
//call init environment method before start the session to load and create all required file
//------------------------------------------------------------------------------------------
igk_initenv(dirname(__FILE__));
//Start SESSION
session_start();
//SET DEFAULT HEADER
igk_setheader('200', "Content-Type: text/html; charset=utf-8");
//start Application. file is require to check if is included
IGKApp::Init(__FILE__);
}
catch (Exception \$Ex)
{
	// show some errors
	igk_show_exception(\$Ex);
	igk_wln("<a href=\"?c=".IGK_SESSION_CTRL."&f=ClearS\" >Clear session</a>");
}
?>
EOF;
}
//return -1 not a class 
function igk_reflection_class_isabstract($name)
{
	if (class_exists($name))
	{
		$v_rc = new ReflectionClass($name);
		return $v_rc->isAbstract();
	}
	return -1;
}
function igk_reflection_getclass_var($obj)
{
	if (is_object($obj))
		return get_class_vars( get_class( $obj));
	if (is_string($obj))
	{
		if (class_exists($obj))
		{
			return get_class_vars($obj);
		}
	}
	return null;
}

//return the name of the class if exist or throw a exception
function igk_reflection_class_exists($name){
	if (!class_exists($name))
		throw new Exception("class $name doesn't exists");
	return $name;
}
function igk_reflection_interface_exists($name){
	if (!interface_exists($name))
		throw new Exception("class $name doesn't exists");
	return $name;
}
function igk_reflection_class_implement($objOrClassName, $name){
	igk_reflection_interface_exists($name);
	if ($objOrClassName){
		$n = $objOrClassName;		
		if (is_object($objOrClassName))
		{
			$n = get_class($objOrClassName);
		}
		$tab = class_implements($n);
		if (isset($tab[$name]))
			return true;			
	}
	return false;
}

function igk_reflection_class_extends($objOrClassName, $name){
	igk_reflection_class_exists($name);
	if ($objOrClassName){
		$n = $objOrClassName;		
		if (is_object($objOrClassName))
		{
			$n = get_class($objOrClassName);
		}
		if (is_subclass_of($n, $name))		
			return true;			
	}
	return false;
}

//sort array
function igk_usort(& $item, $params)
{
	if (is_array($item))
		usort($item, $params);
	else{
		$item->Sort($params);
	}
}

//return the global page list
function igk_sys_pagelist(){
	return igk_getctrl(IGK_MENU_CTRL)->getPageList();
}
//get if this page is a system registrated page
function igk_sys_is_page($page)
{
	$tb = igk_sys_pagelist();
	$p = strtolower($page);
	foreach($tb as $k)
	{
		if ($k == $p)
		return true;
	}
	return false;
}

///<summary>mark a controller as a system controller</summary>
function igk_sys_regSysController($className){//classname of the controller to mark
	if (class_exists($className))
	{
		IGKControllerBase::RegSysController($className);
	}
}

function igk_sys_viewctrl($name)
{
	$ctrl = igk_getctrl($name);
	if ($ctrl!=null){
		$ctrl->View();
	}
}

//to manage changement
function igk_sys_regchange($key, & $state)
{
	return igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange($key, $state);
}
function igk_sys_ischanged($key, & $state)
{
	return igk_getctrl(IGK_CHANGE_MAN_CTRL)->isChanged($key, $state);
}
///register a method for view call back
function igk_sys_regview($ctrlname, $ctrl, $callback)
{
	$c = igk_getctrl($ctrlname , false);
	if (($c == null) || ($ctrl == null) && ($c!== $ctrl))
		return;
	$c->regView($ctrl, $callback);
}
function igk_sys_unregview($ctrlname, $ctrl)
{
	$ctrl = igk_getctrl($ctrlname , false);
	if (($ctrl == null) || ($ctrl == null) )return;
	$ctrl->unregView($ctrl);
}


function igk_sys_regpagefolderChanged($name, $ctrl , $method)
{ 
	IGKApp::getInstance()->registerPageFolderChangedMethod($name, array($ctrl, $method));
}
function igk_sys_unregpagefolderChanged($name)
{
	IGKApp::getInstance()->unregisterPageFolderChangedMethod($name);
}
///<summary>get all controllers</summary>
function igk_sys_getall_ctrl(){//return all controller instanciated on the api domain
	return IGKApp::getInstance()->getControllerManager()->getControllers();
}
function igk_sys_getuserctrls(){
	return  IGKApp::getInstance()->getControllerManager()->getUserControllers();
}

function igk_sys_getdefaultCtrlConf(){//return the default configuration options				
	return array(
			"clTargetNodeIndex"=>0, //target index
			"clDisplayName"=>null,  //the visible name of this controller
			"clRegisterName"=>null, //name for registration
			"clDataAdapterName"=>"CSV", //data adapter name. default is CSV
			"clParentCtrl"=>null, //the parent of this controller
			"clVisiblePages"=>"*",//visible for all page
			"clDescription"=>null, //description of this controller
			"clDataSchema"=>false, //support data schema
			);
}

//CONFIG FUNCTION
function igk_conf_canconfigure()
{
	return igk_getcltrl(IGK_CONF_CTRL)->getCanConfigure();
}
//String function UTILITY
function igk_str_join($str1, $str2, $pattern)
{
	return $str1.$pattern.$str2;
}
function igk_str_join_tab($tab, $separator=',', $key=true){
	return IGKString::Join($tab, $separator, $key);
}
function igk_str_expr($str){
	$str = str_replace(".","\.", $str);
	return $str;
}
function igk_str_explode($array, $str)
{
	$t = array();
	if(count($array)>0)
	{
		$k = explode($array[0], $str);
		$array = array_slice($array, 1);
		foreach($k as $k){
			$t = array_merge($t, igk_str_explode($array, $k));			
		}
	}
	else{
		$t[] = $str;
	}	
	return $t;
}
function igk_str_summary($content, $length=150)
{
	if (strlen($content)>$length)
	{
		$content = substr($content,0, $length)."...";
	}
	return $content;
}



///<summary>remove all line empty line</summary>
function igk_str_remove_empty_line($str){	
	$t = preg_split("/(\r\n)|(\n)/i", $str);
	//$t = explode("\r\n", $str);
	$o = IGK_STR_EMPTY;
	$i = 0;
	foreach($t as $k=>$v)
	{
		if (($v==null) || empty($v) || (strlen(trim($v)) == 0))
			continue;
		if ($i==1)
			$o .="\r\n";
		$o .= $v;
		$i= 1;
	}
	return $o;
}
///<summary>remove line</summary>
function igk_str_remove_lines($str){	
	$t = preg_split("/(\r\n)|(\n)|(\t)/i", $str);
	//$t = explode("\r\n", $str);
	$o = IGK_STR_EMPTY;
	$i = 0;
	foreach($t as $k=>$v)
	{
		if (($v==null) || empty($v) || (strlen(trim($v)) == 0))
			continue;
		$o .= $v;
	}
	return trim($o);
}
///<summary>remove magic cote from message</summary>
function igk_str_quotes($content){

	if (ini_get("magic_quotes_gpc") && is_string($content))
	{
		 $content = stripcslashes($content);
	}	
	return $content;
}

function igk_str_rm_last($str, $pattern)
{
	$c = strlen($pattern);
	while(IGKString::EndWith($str,$pattern))
	{
		$str = substr($str, 0, strlen($str)- $c);
	}
	return $str;
}
function igk_str_rm_start($str, $pattern)
{
	if ($pattern!=null) 
	{	
	$c = strlen($pattern);
	while( ($c >0) && IGKString::StartWith($str,$pattern))
	{
		$str = substr($str, $c);
	}
	}
	return $str;
}

function igk_is_debuging()
{
	$App = IGKApp::getInstance();
	return (igkServerInfo::IsLocal() && ($App->Configs->AllowDebugging ?$App->Configs->AllowDebugging : false));	
}


/// create and generate new id
function igk_new_id()
{
	 return md5(uniqid(rand()));
}
//MENU FUNCTION
/// retrive menu by name
function igk_menu_getmenu($name)
{
	return igk_getctrl(IGK_MENU_CTRL)->getMenu($name);
}
/// get the root menu of this item
function igk_menu_getRootMenu($name){
	return igk_getctrl(IGK_MENU_CTRL)->getRootMenu($name);
}
//retruve alla roots menus for special purpose
function igk_menu_getRoots(){
	return igk_getctrl(IGK_MENU_CTRL)->getRoots();
}
function igk_show_exception($Ex)
{
	if (!$Ex)
		return;
	// show some errors
	igk_wln("Error Append");
	igk_wln("Message: ".$Ex->getMessage());
	igk_wln("File : ".$Ex->getFile());
	igk_wln("Line : ".$Ex->getLine());
	igk_wln("<h2>Trace :</h2>");
	foreach($Ex->getTrace() as $k=>$v)
	{
		if (isset($v["file"])){
			igk_wln("File : ".$v["file"] . ", ".$v["line"]);
		}
	}
	igk_wln("<a href=\"?c=".IGK_SESSION_CTRL."&f=ClearS\" >Clear session</a>");
}
function igk_support_noextension_script()
{
//write this in a htaccess files so that server will excecute file 
//without extension as php script
//NOTE: server must support allow override property
$o = <<<EOF
AddHandler server-parsed .php
SetHandler Application/x-httpd-php
AddHandler Application/x-httpd-php .php
EOF;

$o = <<<EOF
   <FilesMatch "[^\.]+|(\.ph(p3?|tml)$)">
        SetHandler Application/x-httpd-php
    </FilesMatch>
EOF;
return $o;

}

//css helper function in platform
function igk_css_getbg_size($v){//some definition : background size
		$o = IGK_STR_EMPTY;
		$o .="-webkit-background-size: ".$v.";";
		$o .="-o-background-size: ".$v.";";
		$o .="-moz-background-size: ".$v.";";
		$o .="background-size: ".$v.";";
		return $o;
	}
function igk_css_get_fontdef($definition, $lineseparator=IGK_STR_EMPTY)
{
	$out = IGK_STR_EMPTY;
	$v = $definition;
	if (is_string($v))
	{
		$fdd = igk_io_cwdRelativePath(igk_io_syspath($v));	
		if (file_exists($fdd))
		{
		$format = "truetype";
		$f = "@font-face{";
		$f .= "font-family: \"".igk_io_basenamewithoutext(basename($fdd))."\"; ";
		$f .= "src: url('".igk_io_baseUri()."/".igk_html_uri($v)."') format(\"$format\")";	
		$f .= "}";	
		$out.= $f.$lineseparator;	
		}
		else{
			igk_wl("/* Font file doesn't exist : ".$fdd . "*/\n");
		}
	}
	else{
		//font package 
			$f = "@font-face{";
			$f .= "font-family: \"{$v->Name}\"; ";	
			foreach($v->Fonts as $s=>$t){				
				$fdd = igk_io_cwdRelativePath(igk_io_syspath($t->File));	
				if (file_exists($fdd))
				{
						$f .= "src: url('".igk_io_baseUri()."/".igk_html_uri($t->File)."') format(\"{$t->format}\");";
				}
			}
			$f .= "}";
			$out.= $f.$lineseparator;	
	}
	return $out;
}
//register default class value
function igk_css_regclass($classname, $defaultvalue, $override=true)
{
	$igk = IGKApp::getInstance();
	if ($igk===null)
		return;		
	$s = $igk->Doc->Theme[$classname];
	 if (empty($s))
	 {
		$igk->Doc->Theme[$classname] = $defaultvalue;
	 }
	 else{
		if ($override){
			$igk->Doc->Theme[$classname] = $defaultvalue;
		}
		else
		{
			$igk->Doc->Theme[$classname] = $s.$defaultvalue;
		}
	 }
}

function igk_css_reg_font_package($fontname, $file , $format="TrueType"){
	if (empty($file))
	{
		return;
	}
	$igk = IGKApp::getInstance();
	$ft = $igk->Doc->Theme->Font;	
	$r = igk_getv($ft, $fontname);
	if (($r == null) || !is_object($r))
	{
		$r = (object)array(
			"Name"=>$fontname,
			"Fonts"=>array()
		);
		$ft[$fontname] = $r;
	}		
	$r->Fonts[$file] = (object)array("File"=> $file, "format"=>$format);	
	$igk->Doc->Theme->def[".".$fontname] = "font-family: '".$fontname."';";
}
function igk_css_unreg_font_package($fontname){
	$igk = IGKApp::getInstance();
	$ft = $igk->Doc->Theme->Font;	
	$r = igk_getv($ft, $fontname);
	if ($r !== null){		
		$ft[$fontname] = null;
	}	
	//$r->Fonts[$file] = (object)array("File"=> $file, "format"=>$format);	
	$igk->Doc->Theme->def[".".$fontname] = null;//"font-family: '".$fontname."';";
}

function igk_css_regcolor($clname, $value, $override=true)
{
	
	$igk = IGKApp::getInstance();
	if ($igk===null)
		return;
	  if (($igk->Doc->Theme->cl[$clname] === null) ||($override))
	  {
		$igk->Doc->Theme->cl[$clname] = $value;
	  }
}
function igk_css_regpic($picname, $link)
{
	igk_getctrl(IGK_PIC_RES_CTRL)->regPicture($picname, $link);
}
function igk_css_get_style($classname){
	$igk = IGKApp::getInstance();
	if ($igk===null)
		return;
	  $b = $igk->Doc->Theme[$classname];
	if($b == null)
	{
		igk_debug_wln("not found found in theme definition ".$classname);
		$b = $igk->Doc->SysTheme[$classname];
		if ($b)
		{
			$o = igk_css_treat($igk->Doc->SysTheme, $b);
			return $o;
		}
	}		
	else{
			$o = igk_css_treat($igk->Doc->Theme, $b);
			return $o;
	}	
	igk_debug_wln("not found");
	return IGK_STR_EMPTY;
}

function igk_css_get_color_value($clname, $tab=null){
	$colors = $tab;
	if ($tab ==null){
		$colors = IGKApp::getInstance()->Doc->Theme->cl->Attributes->ToArray();
	}
	return igk_css_treatcolor($colors, $clname);
}
function igk_css_get_color($clname, $defaultvalue=null){//get or register a color to global themes
	
	$t= igk_css_get_color_value($clname, null) ;
	if ($t)
		return $t;
	return $defaultvalue;
}
///<summary>used to register a media query to the default document</summary>
function igk_css_regmedia($mediaExpression){//
	$igk = IGKApp::getInstance();
	if ($igk===null)
		return;
	return $igk->Doc->Theme->reg_media($mediaExpression);
}
function igk_css_get_sys_media($id){
		$igk = IGKApp::getInstance();
	if ($igk===null)
		return;
	return $igk->Doc->SysTheme->get_media($id);
}
function igk_css_get_media($id){
		$igk = IGKApp::getInstance();
	if ($igk===null)
		return;
	return $igk->Doc->Theme->get_media($id);
}
///<summary>get or know if this element is a know color or not </summary>
function igk_css_is_know_color($cl) {
	$igk = IGKApp::getInstance();
	if ($igk===null)
		return false;
	return isset($igk->Doc->Theme->cl[$cl]);
}
//@@ set or replace Append theme
function igk_css_Append($name, $value)
{
	$igk = IGKApp::getInstance();
	if ($igk===null)return;	
	$igk->Doc->Theme->Append[$name] = $value;
	
}
//<summary>used to resolv color value</summary>
function igk_css_treatcolor(& $colors , $value, $defined = false){
	if (is_object($value)){
		throw new Exception("object not allowed to be treated as color ");
		igk_exit();
	}
	if (empty($value)){	
		return $value;
	}
	//pattern {window_text_color} = will be replaced by it real color
	$reg2 = '/{\s*(?P<name>[\w_-]+)\s*\}/i';
	if ( ($c = preg_match_all($reg2,$value, $match)))
	{		
		for($i = 0; $i<$c ; $i++)
		{
			$v_m = $match[0][$i];
			$type = $match['name'][$i];
			for($i = 0; $i<$c ; $i++)
			{
				$v_m = $match[0][$i];
				$v_n = trim($match["name"][$i]);
				$value = str_replace($v_m, igk_css_treatcolor($colors, $colors[$v_n], true), $value);				
			}			
		}
	}	
	
	if (isset($colors[$value]))
	{
		return igk_css_treatcolor($colors , $colors[$value], true);
	}
	else{
		if (!$defined){
			igk_css_regcolor($value, IGK_STR_EMPTY);
			return IGK_STR_EMPTY;
		}
	}
	return $value;
}


function igk_css_treatstyle($value){
	if (empty($value))
		return;
	$igk = IGKApp::getInstance();
	return igk_css_treat($igk->Doc->Theme, $value);
}
/*
treate a css theme. evaluate the expression

*/
///<summary></summary>
///<arg name="$theme">system theme reference expression</arg>
///<arg name="$v">style expression</arg>
function igk_css_treat($theme, $v, $themeexport=false)
{

	//\s*(\w+)\s*:\s*([a-zA-Z0-9_]+)\s*\
	//regex for : [def:value]
	//$reg = '/\[\s*(?P<name>\w+)\s*:\s*(?P<value>[a-zA-Z0-9_\/\\\.\- \(\)%]+)\s*\](\s*(;|,))*/i';
	$reg = '/\[\s*(?P<name>\w+)\s*:\s*(?P<value>[a-zA-Z0-9_\/\\\.\- \(\)%]+)\s*\](\s*;*)*/i';
	//regex for getting : {sys:properties, ...}
	$reg2 = '/\{\s*(?P<name>[\w:\-_,\s]+)\s*\}\s*(;)*/i';
	//regex for link style heirarchie : (:style)  "/^\s*\(:(?P<name>([a-z0-9_\-])+)\)\s*$/i"
	$reg3 = IGK_CSS_CHILD_EXPRESSION_REGEX;
	$match = array();
	$c = 0;
	//child expression
	if ($c = preg_match_all($reg3, $v, $match))
	{
		for($i = 0; $i<$c ; $i++)
		{
			$n = $match[0][$i];
			//remove parent expression
			$v = str_replace($n, IGK_STR_EMPTY, $v);
		}		
	}
	

	if ( ($c = preg_match_all($reg,$v, $match)))
	{
		for($i = 0; $i<$c ; $i++)
		{
		$v_m = $match[0][$i];
		
		$type = $match['name'][$i];
		$value = $match['value'][$i];
		switch(strtolower($type))
		{
			case "trans": //for transition				
				$v = str_replace($v_m, "-webkit-transition: {$value};-ms-transition:{$value}; -moz-transition:{$value}; -o-transition: {$value}; transition: {$value};",$v);
				break;
			case "transform":
				$v = str_replace($v_m, "-webkit-transform: {$value};-ms-transition:{$value}; -moz-transition:{$value}; -o-transform: {$value}; transform: {$value};",$v);				
				break;
			case "anim":
				$v = str_replace($v_m, "-webkit-animation: {$value};-ms-animation:{$value}; -moz-animation:{$value}; -o-animation: {$value}; animation: {$value};", $v);								
				break;
			case "res":
				$vimg = R::GetImgResUri($value);			
				$v = str_replace($v_m, 
				( !empty($vimg) && !$themeexport? "background-image: url('".$vimg."');" : "")
				,$v);				
			break;
			case "bgres":
					$v = str_replace($v_m, 
					(!$themeexport? 
				"background-image: url('".igk_io_baseUri()."/".igk_html_uri($value)."');" : ""),$v);
				break;
			case "uri":
			$v = str_replace($v_m, 
			(!$themeexport? 
				"url('".igk_io_baseUri()."/".igk_html_uri($value)."')": ""),$v);
				break;
			//---------------------------------------------------------------------------------------------------
			//---------------------------------------COLOR DEFINITION -------------------------------------------
			//---------------------------------------------------------------------------------------------------
			//system color
			case "sysbgcl":
				$v = str_replace($v_m, 
				igk_css_getbgcl(igk_getv($theme->cl, $value,$value)), $v);	
				break;
			case "sysfcl":
				$v = str_replace($v_m, 
				igk_css_getfcl(igk_getv($theme->cl, $value,$value)), $v);		
				break;
			case "sysbcl":
				$v = str_replace($v_m, 
				igk_css_getbordercl(igk_getv($theme->cl, $value,$value)), $v);		
				break;
			case "syscl":
				$v = str_replace($v_m, 
				igk_getv($theme->cl, $value,$value), $v);		
				break;
			//global theme color
			case "fcl":
				$v = str_replace($v_m, 
				igk_css_getfcl(igk_css_get_color($value)), $v);				
			break;
			case "bgcl": //return background-color color				
				$v = str_replace($v_m,  igk_css_getbgcl( igk_css_get_color_value($value)), $v);				
			break;
			case "bcl": //return border-color
				$v = str_replace($v_m, igk_css_getbordercl(igk_css_get_color_value($value)), $v);		
			break;
			case "cl":
				$v = str_replace(str_replace(";",IGK_STR_EMPTY, $v_m), igk_css_get_color($value), $v);
				break;
			//------------------------------------------------------------------------------------
			//----------------------------------------------font definition
			//------------------------------------------------------------------------------------	
			case "ft"://return font-family
				$v = str_replace($v_m, $theme->ft[$value]?igk_css_getfont($value):null, $v);
			break;
			case "ftn"://return only the font name
				$h  = $theme->ft[$value]?$theme->ft[$value]: null;
				if ($h)
					$v = str_replace($v_m, "\"".$h."\"", $v);
				else 
					$v = str_replace($v_m, IGK_STR_EMPTY, $v);
				break;
			case "pr"://get properties definitions
				$v = str_replace($v_m, $theme->properties[$value].";", $v);
				break;
			//------------------------------------------------------------------------------------
			//----------------------------------------------from custom palette color definition
			//------------------------------------------------------------------------------------
			case "palcl":
				$r = igk_get_palette(); 
				$v = str_replace($v_m, $r? igk_getv($r,$value):null,$v);			
			break;
			case "palbgcl":
				$r = igk_get_palette(); 
				if ($r){
				$s = $r[$value];
				if (!empty($s))
					$v = str_replace($v_m, "background-color: ".$s.";", $v);
				else
					$v = str_replace($v_m, IGK_STR_EMPTY, $v);					
				}
				else{				
					$v = str_replace($v_m, IGK_STR_EMPTY, $v);					
				 }
			
				break;
			case "palfcl":
				$r = igk_get_palette(); 			
				$s = igk_getv($r,$value);
				if (!empty($s))
					$v = str_replace($v_m, "color: ".$s.";", $v);
				else
					$v = str_replace($v_m, IGK_STR_EMPTY, $v);
				break;
			
			default:
				$v = str_replace($v_m, IGK_STR_EMPTY, $v);
			break;
		}
		}
		
	}
	
	if ( ($c = preg_match_all($reg2,$v, $match)))
	{		
		for($i = 0; $i<$c ; $i++)
		{
			$v_m = $match[0][$i];
			$type = $match['name'][$i];
			for($i = 0; $i<$c ; $i++)
			{
				$v_m = $match[0][$i];
				$v_n = trim($match["name"][$i]);
				if (isset($theme[$v_n])){
					//for single item
					$v = str_replace($v_m, igk_css_treat($theme, $theme[$v_n]), $v);				
				}				
				else{
					$rtab = explode(':', $v_n);
				
					if (count($rtab) == 2)
					{
						$v_from = strtolower(trim($rtab[0]));
						
						switch($v_from){
							case "sys":
								//retrieve sys params 
								//comma separator expected
								$v_nn  = explode(',',trim($rtab[1]));								
								$sk = IGK_STR_EMPTY;
								foreach($v_nn as $r){									
									//replace with value
									$sk .= $theme->Doc->SysTheme->def[".".trim($r)];
								}
								$sk = igk_css_treat($theme->Doc->SysTheme, $sk);
								$v = str_replace($v_m, $sk, $v);
								break;
							default:
								//make null
								$v = str_replace($v_m, null, $v);				
								break;
						}
					}
					else {
						//no definition
						//for default item 
							$v_nn  = explode(',',trim($v_n));								
							$sk = IGK_STR_EMPTY;	
							$rv = IGK_STR_EMPTY;
							foreach($v_nn as $r)
							{									
								$sk .=  $theme->Doc->Theme->def->Attributes[trim($r)];									
								$rv .= igk_css_treat($theme, $theme->Doc->Theme->def->Attributes[trim($r)], IGK_STR_EMPTY);									
							}
						$v = str_replace($v_m, $rv, $v);
					}
				}
			}			
		}
	}	
	return $v;
}
function igk_get_palette($palname="default")
{
	$cp = igk_getctrl(IGK_PALETTE_CTRL);
	if ($cp == null)
	{
		return null;
	}
	$p = $palname=="default"? igk_getv(IGKApp::getInstance()->Configs, "CurrentPaletteName", "default") : $palname;
	return igk_getv( $cp->Palettes, $p, null);				
}


function igk_getg($key, $value=null)
{
	return igk_getrequest($_GET, $key, $value);
}
function igk_gets($key, $value=null){
	return igk_getrequest($_SESSION, $key, $value);
}
/// get request value
function igk_getr($key, $value=null)
{
	return igk_getrequest($_REQUEST, $key, $value);	
}
///<summary>get a check pas</summary>
function igk_getp($key, $value=null)
{
	return igk_getrequest($_POST, $key, $value);
}
function igk_getrequest($tab, $key, $value=null)
{
	if (is_object($key))
		return $value;
	if (isset($tab[$key]))
	{
		$t = $tab[$key];
		if (!is_array($t))
			return igk_str_quotes($t);
		return $t;
	}
	return $value;
}
///get request object value
function igk_getru($key, $value=null)
{
	if (is_object($key))
		return $value;
	if (isset($_REQUEST[$key]))
			return str_replace("-","_", igk_str_quotes($_REQUEST[$key] ));
	return $value;
}
//get default value
function igk_getdv($v, $default=null)
{
	if (isset($v))
		return $v;
	return $default;
}
//retreive requested object as object
function igk_get_robj()
{
	$t = array();	
	foreach($_REQUEST as $k=>$v)
	{
		if (IGKString::StartWith($k,"cl"))
		{
			$t[$k] = igk_str_quotes($v);
		}
	}	
	return (object)$t;
}
//reset request
function igk_resetr()
{
	$_REQUEST = array();
}
//load request uri
function igk_loadr($uri)
{
	if (count($uri) == 0)
		return;
	//uri
	$tab = array();
	$t = parse_url($uri);	
	$q  = $t["query"];	
	parse_str($q, $tab);
	$_REQUEST = $tab;
}
/// get request array
function igk_getrs(){
	return $_REQUEST;
}
function igk_qr_confirm()
{
	return (igk_getr("confirm", 0) == 1);
}
/// get object property value
function igk_getprop($obj, $prop)
{
	if ($obj == null)
		return;
	return $obj->$prop;	
}
/// set a request key=>$value
function igk_setr($key,$value)
{
	$_REQUEST[$key] = $value;
}




function igk_ansi2utf8($text)
{
$text = str_replace("¡","\xc2\xa1",$text);
$text = str_replace("¢","\xc2\xa2",$text);
$text = str_replace("£","\xc2\xa3",$text);
$text = str_replace("¤","\xc2\xa4",$text);
$text = str_replace("¥","\xc2\xa5",$text);
$text = str_replace("¦","\xc2\xa6",$text);
$text = str_replace("§","\xc2\xa7",$text);
$text = str_replace("¨","\xc2\xa8",$text);
$text = str_replace("©","\xc2\xa9",$text);
$text = str_replace("ª","\xc2\xaa",$text);
$text = str_replace("«","\xc2\xab",$text);
$text = str_replace("¬","\xc2\xac",$text);
$text = str_replace("­","\xc2\xad",$text);
$text = str_replace("®","\xc2\xae",$text);
$text = str_replace("¯","\xc2\xaf",$text);
$text = str_replace("°","\xc2\xb0",$text);
$text = str_replace("±","\xc2\xb1",$text);
$text = str_replace("²","\xc2\xb2",$text);
$text = str_replace("³","\xc2\xb3",$text);
$text = str_replace("´","\xc2\xb4",$text);
$text = str_replace("µ","\xc2\xb5",$text);
$text = str_replace("¶","\xc2\xb6",$text);
$text = str_replace("·","\xc2\xb7",$text);
$text = str_replace("¸","\xc2\xb8",$text);
$text = str_replace("¹","\xc2\xb9",$text);
$text = str_replace("º","\xc2\xba",$text);
$text = str_replace("»","\xc2\xbb",$text);
$text = str_replace("¼","\xc2\xbc",$text);
$text = str_replace("½","\xc2\xbd",$text);
$text = str_replace("¾","\xc2\xbe",$text);
$text = str_replace("¿","\xc2\xbf",$text);
$text = str_replace("À","\xc3\x80",$text);
$text = str_replace("Á","\xc3\x81",$text);
$text = str_replace("Â","\xc3\x82",$text);
$text = str_replace("Ã","\xc3\x83",$text);
$text = str_replace("Ä","\xc3\x84",$text);
$text = str_replace("Å","\xc3\x85",$text);
$text = str_replace("Æ","\xc3\x86",$text);
$text = str_replace("Ç","\xc3\x87",$text);
$text = str_replace("È","\xc3\x88",$text);
$text = str_replace("É","\xc3\x89",$text);
$text = str_replace("Ê","\xc3\x8a",$text);
$text = str_replace("Ë","\xc3\x8b",$text);
$text = str_replace("Ì","\xc3\x8c",$text);
$text = str_replace("Í","\xc3\x8d",$text);
$text = str_replace("Î","\xc3\x8e",$text);
$text = str_replace("Ï","\xc3\x8f",$text);
$text = str_replace("Ð","\xc3\x90",$text);
$text = str_replace("Ñ","\xc3\x91",$text);
$text = str_replace("Ò","\xc3\x92",$text);
$text = str_replace("Ó","\xc3\x93",$text);
$text = str_replace("Ô","\xc3\x94",$text);
$text = str_replace("Õ","\xc3\x95",$text);
$text = str_replace("Ö","\xc3\x96",$text);
$text = str_replace("×","\xc3\x97",$text);
$text = str_replace("Ø","\xc3\x98",$text);
$text = str_replace("Ù","\xc3\x99",$text);
$text = str_replace("Ú","\xc3\x9a",$text);
$text = str_replace("Û","\xc3\x9b",$text);
$text = str_replace("Ü","\xc3\x9c",$text);
$text = str_replace("Ý","\xc3\x9d",$text);
$text = str_replace("Þ","\xc3\x9e",$text);
$text = str_replace("ß","\xc3\x9f",$text);
$text = str_replace("à","\xc3\xa0",$text);
$text = str_replace("ý","\xc3\xbd",$text);
$text = str_replace("þ","\xc3\xbe",$text);
$text = str_replace("ÿ","\xc3\xbf",$text);
$text = str_replace("ä","\xc3\xa4",$text);
$text = str_replace("å","\xc3\xa5",$text);
$text = str_replace("æ","\xc3\xa6",$text);
$text = str_replace("ç","\xc3\xa7",$text);
$text = str_replace("è","\xc3\xa8",$text);
$text = str_replace("é","\xc3\xa9",$text);
$text = str_replace("ê","\xc3\xaa",$text);
$text = str_replace("ë","\xc3\xab",$text);
$text = str_replace("ì","\xc3\xac",$text);
$text = str_replace("í","\xc3\xad",$text);
$text = str_replace("î","\xc3\xae",$text);
$text = str_replace("ï","\xc3\xaf",$text);
$text = str_replace("ð","\xc3\xb0",$text);
$text = str_replace("ñ","\xc3\xb1",$text);
$text = str_replace("ò","\xc3\xb2",$text);
$text = str_replace("ó","\xc3\xb3",$text);
$text = str_replace("ô","\xc3\xb4",$text);
$text = str_replace("õ","\xc3\xb5",$text);
$text = str_replace("ö","\xc3\xb6",$text);
$text = str_replace("÷","\xc3\xb7",$text);
$text = str_replace("ø","\xc3\xb8",$text);
$text = str_replace("ù","\xc3\xb9",$text);
$text = str_replace("ú","\xc3\xba",$text);
$text = str_replace("û","\xc3\xbb",$text);
$text = str_replace("ü","\xc3\xbc",$text);
return $text;
}

/*
//retrieve all default page controller
*/
function igk_get_default_pagesctrl()
{
	$igk = IGKApp::getInstance();
	if ($igk==null)return;
	$t = array();
	foreach($igk->getControllerManager()->getControllers() as $k)
	{
		//get controllers
		$cl = get_class($k);
		$v_rc = new ReflectionClass($cl);
		if ($v_rc->isAbstract() || !igk_reflection_class_extends($cl, IGK_CTRLWEBPAGEBASECLASS ) )
			continue;
		$t[] = $k;
	}
	return $t;
}
function igk_csv_sep()
{
	$s = igk_get_uvar(IGK_CSV_SEPARATOR,",", true);
	if (!empty($s))
		return $s;
	return ",";
	
}
function igk_csv_getvalue($v)
{
	return IGKCSVDataAdapter::GetValue($v);
}
//format the string by retreive the {index} with args
function igk_get_string_format($str)
{
	$n = null;
	$tab = func_get_args();
	if (defined("__NAMESPACE__"))
		$n =  __NAMESPACE__ .'IGKFormatString::Create';		
	else
		$n = 'IGKFormatString::Create';
		
	return call_user_func_array($n, $tab) ;

}
function igk_get_string_propvalue($obj, $property)
{
	return IGKFormatGetValueString::Create($obj, $property);
}
//<summary>get user variables</summary>
function igk_get_uvar($name, $default=null, $reg=false, $comment=null)
{
	if (empty($name))
		return $default;
	$ctrl = igk_getctrl(IGK_USERVARS_CTRL);
	if ($ctrl == null)
		return $default;
	$t = igk_getv($ctrl->Vars, $name);
	if ($t)
		return $t["value"];
	if ($reg && $ctrl)
	{
		$ctrl->regVars($name,$default,$comment);
		$ctrl->__storeVars();
	}
	return $default;
}

function igk_notify_error($msg)
{
	$ctrl = igk_notifyctrl();
	if ($ctrl)
	{
		$ctrl->addError($msg);	
	}
	else{
		igk_wln("<div class=\"igk-notify-box igk-notify-box-error\" >".$msg."</div>");
	}
}
///<summary>used to render directory an message for box notification </summary>
function igk_notifybox_ajx($msg)
{
	igk_wln("<div class=\"igk-notify-box\" >".$msg."</div>");
}

///@@ get value in array
function igk_getv($array, $key, $default= null)
{	
	$r = null;
	$def = $default;				
	if (is_array($array))
	{
		if (isset($array[$key]))
			return $array[$key];
	}
	else if (is_object($array))
	{
		$cl = get_class($array);
		$t = class_implements($cl);
		if (isset($t["ArrayAccess"]))
		{
			$r = $array[$key];
			return $r?$r:$def;
		}
		else
		{
			$t =get_class_vars($cl);
			if (method_exists($cl, "__get"))
			{		
				
				$s = $array->__get($key);				
				return $s? $s : $def;
			}
			if (isset($array->$key))
				return $array->$key;		
		}
	}
	return $default;
}
///get the setted-value
function igk_getsv($value, $default=null)
{
	if (isset($value))
	{
		return $value;
	}
	return $default;
}
//get the value between value and value
function igk_gettv($value, $default)
{
	if (empty($value))
		return $default;
	if ($value==null)
		return $default;
	return $value;
}
/// Clear config session and restart Application
function igk_Clear_config_session()
{
	$ctrl = igk_getctrl(IGK_CONF_CTRL);		
	$uri = $ctrl->getUri("startconfig&q=".base64_encode(
	'?'.http_build_query(array(
	"u"=>$ctrl->User->clLogin,
	"pwd"=>$ctrl->User->clPwd,
	"selectedCtrl"=>$ctrl->getSelectedConfigCtrl()->getName(),
	"selectPage"=>$ctrl->getSelectedMenuName()
	)
	)));				
	igk_getctrl(IGK_SESSION_CTRL)->ClearS(false);
}

function igk_file_chmod($dirorfile, $mode, $recursif=false)
{
	$out = true;
	if ($recursif && is_dir($dirorfile))
	{
		
		$hdir = @opendir($dirorfile);
		if ($hdir)
		{
			
			while($r=readdir($hdir))
			{
				if (($r==".") || ($r==".."))
					continue;
				$f = igk_io_getdir( $dirorfile."/".$r);
				
				// igk_wln($dirorfile ."=== ". is_file($f));
				if (is_dir($f))
				{
					// igk_wln($f. " : Dir file : ".$out);
					$out = igk_file_chmod($f, $mode, $recursif) && $out;
				}
				else if (file_exists($f))
				{
					// igk_wln($f. " : ".$out);
					if (!@chmod($f, $mode))
						$out = false;
					// else{
						// igk_wln($f. " : Change mode : ".$out);
					// }
				}
				// igk_wln($f. " : ".$out);
			}
			closedir($hdir);
		}
	}
	$out = @chmod ($dirorfile , $mode) && $out;	
	return $out;
}

//<summary> parse bool to str string</summary>
function igk_parsebool($bool)
{	
	if (is_bool($bool))
		return ($bool)?"true": "false";
	return igk_parsebool(igk_getbool($bool));
}
function igk_parsebools($b)
{
	return R::ngets("V.".igk_parsebool($b));
}
function igk_getbool($v)//get boolean value
{
	if (is_bool($v))
		return $v;
	if (is_string($v))
	{
		switch(strtolower($v))
		{
			case "true":
			case "1":
				return true;
		}
		return false;
	}
	if ($v)
		return true;
	return false;
}
//<summary>parse numéric number to string</summary>
function igk_parse_num($num)
{
	if (is_numeric($num))
	{
		if ($num == 0)
			return "0";
		return trim($num).IGK_STR_EMPTY;
	}	
	return "0";
}
function igk_getquery_args($uri)
{
	$q = parse_url($uri);
	if (isset($q["query"]))
	{	
		$tab  = array();
		parse_str($q["query"], $tab);
		return $tab;
	}
	else{
		$tab  = array();
		parse_str($uri, $tab);
		return $tab;
	}
	return null;
}
//@ get the article extension
function igk_get_article_ext($lang=null){
	if ($lang)
	{
		return strtolower(".".$lang.".phtml");
	}
	return strtolower(".".R::GetCurrentLang().".phtml");
}
//get the article of a controller
function igk_get_article($ctrl, $name)
{
	return $ctrl->getArticle($name);
}

function igk_get_frame_ext(){
	return strtolower(".frame.phtml");
}
function igk_get_class_constants($classname)
{
	$r = new ReflectionClass($classname);
	return $r->getConstants();
}

function igk_get_current_base_uri($dir=null, $secured = false)
{
	$igk = IGKApp::getInstance();
	if ($igk->CurrentPageFolder!=IGK_HOME_PAGEFOLDER)
		$out = igk_io_baseUri($igk->CurrentPageFolder,$secured);
	else 
		$out = igk_io_baseUri(null,$secured );
	if ($dir)
		$out .= "/".$dir;
	return $out;	
}

function igk_php_check_and_savescript($file, $content, & $error, & $code)
{
		$f = $file;
		$v_c = $content;
		$v_old = null;
		if (file_exists($f))
		{
			$v_old = IGKIO::ReadAllText($f);
		}
		IGKIO::WriteToFileAsUtf8WBOM($f, $v_c, true);					
		$code =10;
		$error=array();
		
		$uri = igk_html_resolv_img_uri(IGKIO::GetDir(dirname(__FILE__)."/igk_checkfile.php"));
		$r = igk_post_uri($uri, array(
			"file"=>$f
		));		
		if ($r != 'ok')
		{		
			igk_wln($error);
			unlink($f);
			//write old value
			IGKIO::WriteToFileAsUtf8WBOM($f, $v_old,true);			
			return false;
		}	
		return true;
}
function igk_debuggerview()
{
	return igk_getctrl("igkdebugctrl")->getDebuggerView();
}
function igk_debug($d){
	IGKApp::$DEBUG = $d;
}
function igk_debug_show_dump_info()
{
	igk_show_prev($_REQUEST);
}
//write debug message. to debug node
function igk_debug_show( $msg ){
	if (!IGKApp::IsInit())
		return;
	if (igkServerInfo::IsLocal())	
	{	
		$tab = explode(':', $msg);
		$ctrl = igk_getctrl("igkdebugctrl" ,false);
		if ($ctrl == null)
			return;
		$lb =  IGKHtmlItem::CreateWebNode("div");
		
		if (count($tab) > 1)
		{
			$args  = array();
			preg_match_all('/((?P<name>([^:]+)):(?P<value>(.)*))$/i', $msg, $args);						
			$n = strtolower(trim($args["name"][0]));
			switch($n)
			{
				case "warning":					
				case "error":
				case "notice":
				case "info":
					$lb["class"]="igk-debug-".$n;
					$lb->Content = $args["value"][0];
					$ctrl->addMessage($lb);
					break;
				default:
					$lb["class"]="igk-debug-msg";
					$lb->Content = $msg;
					$ctrl->addMessage($lb);
					break;
			}
		}
		else{			
			$lb["class"]="igk-debug-msg";
			$lb->Content = $msg;
			$ctrl->addMessage($lb);
		}
		
	}
}
function igk_debug_wln($msg)
{
	if (IGKApp::$DEBUG) 
	{
		igk_wln($msg);
	}
}
function igk_debug_wl($msg)
{
	if (IGKApp::$DEBUG){
		igk_wln($msg);
	}
}
function igk_server_is_refreshing()
{
	return igk_getctrl("igkpagectrl",false)->isRefreshing;
}

//-------------------------------------------------------------------------------------------------------------------------
//CURRENCY FUNCTION
//-------------------------------------------------------------------------------------------------------------------------
function igk_currency_getamount($amout)
{
		$c = $amout.IGK_STR_EMPTY;
		if (!strstr($c,"."))
			$amout = $c.".00";		
	return $amout;
}
///ask to download file
function igk_download_file($name , $filename)
{
	if (file_exists($filename))
	{
		$size = @filesize($filename);
		igk_download_content($name, $size,  IGKIO::ReadAllText($filename));	
		return true;
	}
	return false;
}

/*
*@@@used to download content
*/

function igk_download_content($name, $size,  $content, $encoding="binary"){//download the content
	header("Content-Type: Application/force-download; name=\"" . $name . "\"");
	header("Content-Transfer-Encoding: ".$encoding);
	header("Content-Length: $size");
	header("Content-Disposition: attachment; filename=\"" . $name . "\"");
	header("Expires: 0");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	igk_wl( $content);
	igk_exit();	
}

function igk_get_cached_manifest()
{

	header("Content-Type: text/cache-manifest");
	igk_wl(igk_get_manifest_content());
}
function igk_get_manifest_content()
{
$info = "igkapp_manifest";
	$out = <<<EOF
CACHE MANIFEST
#{$info} - manifest
EOF;
}
//---------------------------------------------------------------------
//DATE UTILS FUNCTION
//---------------------------------------------------------------------
//
//return: 	-2 on error
//			1 if date1 > date2
//			0 if equal
//			-1 if date1 < date2
//---------------------------------------------------------------------
function igk_date_now($format =null)
{
	if ($format)
		return date($format);
	return date("Y-d-m_h:i:s");
}
function igk_date_compare($date1, $date2)
{
	try{
		$d1 = new DateTime($date1);
		$d2 = new DateTime($date2);
		if ($date1 > $date2)
			return 1;
		if ($date1 < $date2)
			return -1;
		return 0;
		}
		catch(Exception $ex){
			return -2;
		}	
}
//<summary>resolv the image uri</summary>
//pass the fullpath to file and return a http uri access to file
//usefool for URL
function igk_html_resolv_img_uri($path){
	// if (file_exists($path))
	// {
		// return igk_html_uri(igk_io_baseUri()."/".igk_io_basePath($path));
	// }

	$f = igk_io_currentRelativePath($path);
	if (!empty($f) && file_exists($f))
	{		
		$r = realpath($f);
		$s = igk_io_basePath($f);
		if ($s == $r)
		{//not resolved
			$m = igk_html_uri(igk_io_baseUri()."/".$f);				
			return $m;
		}
		return igk_html_uri(igk_io_baseUri()."/".$s);
	}		
	return null;
}

function igk_html_mustclosetag($tagname)
{
	return isset(IGKHtmlOptions::$MustCloseTag[$tagname]);
}
function igk_html_treatinput($node)
{	
	if ($node==null)
		return;
	$d = $node->getElementsByTagName("input");	
	if ($d && (igk_count($d)>0))
	{
		foreach($d as $k)
		{
			if (($k["class"] == null )&&($k["type"]!=null))
			{
				$k["class"] = "cl".strtolower($k["type"]);
			}
		}		
	}					
}

function igk_html_build_select_setting(){//get a selection setting object
	return (object)array(
		"allowEmpty"=>false,		
		"keysupport"=>false,
		"valuekey"=>null,
		"displaykey"=>null,
		"resolvtext"=>null
	);
}
///
// @attributes array of  [allowEmpty, valuekey, displaykey]
///@attr is html attributes
function igk_html_build_select($target, $name, $tab, $selectattributes=null, $selectedvalue=null, $attr=null){//build a select node
			$sel = $target->add("select");	
			$sel["id"]=$sel["name"] = $name;
			if ($selectedvalue == null)
			{
				$selectedvalue = igk_getr($name,null);
			}
			if (igk_getv($selectattributes,"allowEmpty"))
				$sel->add("option", array("value"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
			$kv = igk_getsv(igk_getv($selectattributes,"valuekey"));
			$dv = igk_getsv(igk_getv($selectattributes,"displaykey"));
			$ksu = igk_getv($selectattributes, "keysupport");
			$resolvtext = igk_getv($selectattributes, "resolvtext");
			if (is_array($tab))
			{
				foreach($tab as $v)
				{	
					$opt = $sel->add("option");
					$opt["value"] = $ksu? igk_getv($v, $kv): $v;
					$s = $ksu? igk_getv($v, $kv) : $v;
					if ($resolvtext )
						$opt->Content = R::ngets("enum.".($ksu? igk_getv($v, $dv) : $v));				
					else
						$opt->Content =  $ksu? igk_getv($v, $dv) : $v;				
					if ($s == $selectedvalue){
						$opt["selected"] = true;
					}
				}
			}
			$sel->AppendAttributes($attr);
			return $sel;
}

function igk_html_build_table($table, $queryresult){
		$r = $queryresult;
		if (!$r) 
			return;
		$tr = $table->add("tr");
		foreach($r->Columns as $k=>$v){
				$tr->add("th")->Content = $v->name;
		}			
		foreach($r->Rows as $k=>$v){
			$tr = $table->add("tr");
			foreach($v as $m=>$mm){
				$tr->add("td")->Content = $mm;
			}
		}		
}

function igk_html_getAllchilds($node)
{
	$tab = array();
	if ($node->HasChilds)
	{
		foreach($node->Childs as $k)
		{
			$tab[] = $k;
			$c = igk_html_getAllChilds($k);
			if (igk_count($c) > 0)
				$tab = array_merge($tab, $c);
		}
	}
	return $tab;
}
///<summary>return array of data binding node info</summary>
function igk_html_bindinginfo($node)
{
	$tab = igk_html_getAllchilds($node);
	$c = array();
	$ddd =  IGKHtmlItem::CreateWebNode("div");
	
	
	foreach($tab as $k)
	{	
		
		if ( ($h = igk_getv($k, "igk-data-binding")) !=null)
		{
			$c[] = (object)array(
				"node"=>$k, 
				"binding"=>$h, 
				"type"=>"igk-data-binding",
				"visiblerow"=>igk_getv($k, "igk-data-binding-visible-row", igk_getv(IGKApp::getInstance()->Configs, "app_visible_row", 50))
				);				
		}
		else if( igk_getbool(($h = igk_getv($k, "igk-data-row-binding"))) == true)
		{
			
			$c[] = (object)array(
				"node"=>$k, 
				"parent"=>$k->getParentNode(),
				"binding"=>$h, 
				"type"=>"igk-data-row-binding",
				"visiblerow"=>igk_getv($k, "igk-data-binding-visible-row", igk_getv(IGKApp::getInstance()->Configs, "app_visible_row", 50)),
				"rowcheck"=>igk_getv($k, "igk-data-row-checkexpression", null)
				);				
			igk_html_rm($k);
		}
		else if( igk_getbool(($h = igk_getv($k, "igk-data-full-row-binding"))) == true)
		{
				$c[] = (object)array(
				"node"=>$k, 
				"parent"=>$k->getParentNode(),
				"binding"=>$h, 
				"type"=>"igk-data-full-row-binding",
				"tag"=>igk_getv($k , "igk-data-full-row-binding-tag"),
				"visiblerow"=>igk_getv($k, "igk-data-binding-visible-row", igk_getv(IGKApp::getInstance()->Configs, "app_visible_row", 50))
				);				
			igk_html_rm($k);
		}
		
		
		//unset template properties
		$k["igk-data-binding"] = null;
		$k["igk-data-binding-visible-row"] = null;
		$k["igk-data-row-binding"] = null;
		$k["igk-data-full-row-binding"] = null;
		$k["igk-data-full-row-binding-tag"] = null;
	}
	return $c;
}

///<summary>Evaluate data by applying current row entries</summary>
/*
used to evaluate $value by replacing the current row data expression column
*/
function igk_html_treatbinding_evaldata($value, $row, $ctrl=null){

	extract((array)$row);
	$m = igk_html_databinding_treatresponse($value, $ctrl, $row);
	$tab = array();
	$c = preg_match_all("/(?P<name>(\\$(?P<value>([0-9a-z_]+))))/i", $m,  $tab);
	
	if($ctrl){
		//extract treated params
		$v_bindingobj = $ctrl->getParam(IGK_DATABINDING_RESPONSE_NAME);
		if ($v_bindingobj){
			extract($v_bindingobj->args);				
		}
	}
	$not_var = array();	
	if ($c>0)
	{
		$h = null;
		$vars = get_defined_vars();
		$vars = igk_array_tokeys(array_keys($vars));
		for($i = 0; $i<$c;$i++)
		{
			$n = $tab["name"][$i];
			$key = $tab["value"][$i];
			
			if (!isset($vars[$key]))
			{		
				if ($key == "igk")
				{
					$m = str_replace($n, "__IGK__", $m);
				}
				else {
					$m = str_replace($n,"'not_defined_".$key."'", $m);
				}
		
			}
		}
	}
	$s =IGK_STR_EMPTY;	
	$m = igk_html_beginbinding($m);	
	try{
		//expression in brank because of evaluation
		$s = "return \"{$m}\";";		
		$s = eval($s);				
		$s = igk_html_endbinding($s);	
		$s = str_replace("__IGK__", "\$igk",$s); // for javascript context	
	}
	catch(Exception $ex){		
		$s =  "evaluation failed ".$ex;
	}
	return 	$s;
}
function igk_html_istagname($v)
{
	return preg_match("/^".IGK_TAGNAME_CHAR_REGEX."+$/i", $v);
}
function igk_html_treatbinding($info, $row, $ctrl=null)
{	
	if ($info->visiblerow <=0)
	{
		return;
	}
	$output = array();
	$info->visiblerow--;
		switch(strtolower($info->type))
		{
			case "igk-data-binding":
			if (preg_match_all("/^(?P<tagname>(".IGK_TAGNAME_CHAR_REGEX.")+)\s*:(?P<value>(.)+)$/i", $info->binding, $output))
			{
				$s = $output["tagname"];
				$r = $info->node->add($output["tagname"][0]);
				{			
					$s = igk_html_treatbinding_evaldata($output['value'][0], $row,$ctrl);
					$r->Load($s);
				}
			}
			else{
				$rtab = explode(":",$info->binding);
				$c = igk_count($rtab);
				switch($c)
				{
					case 1:
						$info->node->Content = igk_html_treatbinding_evaldata($rtab[0], $row, $ctrl);
					break;
					case 2:	//add child to info node
						if (igk_html_istagname($rtab[0]))
						{
							$r = $info->node->add($rtab[0]);
							{				
								$s= igk_html_treatbinding_evaldata($rtab[1], $row, $ctrl);				
								$r->Content = $s;
							}
						}						
						else{
							return false;
						}
					break;
					default:
						return false;
				}
			}
			break;
			case "igk-data-row-binding":
				if (isset($info->rowcheck)){
					if (!igk_html_treatbinding_evaldata($info->rowcheck, $row, $ctrl))					
						continue;
				}
				$r =  IGKHtmlItem::CreateWebNode($info->node->TagName);
				$r->copyAttributes($info->node);
				$m = $info->node->getinnerHTML();				
				$m = str_replace("\"", "__''__", $m);
				$m = igk_html_treatbinding_evaldata($m, $row, $ctrl);				
				$m = str_replace("__''__","\"", $m);
				$r->Load($m);
				$info->parent->add($r);
				
			break;
			case "igk-data-full-row-binding":			
				$m = $info->node->getinnerHTML();
				$tag = $info->tag;
				if ($tag)
				{
					$r =  IGKHtmlItem::CreateWebNode($info->node->TagName);
					foreach($row as $k){
						$r->add($tag)->Content = $k;
					}									
					$s = $info->parent->add($r);
				}
				else{
					foreach($row as $k){
							$r =  IGKHtmlItem::CreateWebNode($info->node->TagName);
							$r->copyAttributes($info->node);					
							$r->Content = $k;						
							$s = $info->parent->add($r);
					}
				}
			break;
		}
		return true;
	}
	
function igk_html_bindnode($ctrl, $targetnode, $nodeTemplate, $entries)
{
	$d = $nodeTemplate;
	$o = array();
	if ($d->HasChilds)
	{//ass child
		$s = $d->innerHTML;
		$c = $d;
		$tabinfo = igk_html_bindinginfo($c);
		if ((igk_count($tabinfo) > 0)&& $entries)
		{
			igk_html_bindentry($ctrl, $entries, $tabinfo, $o, $c);			
		}
	}
	foreach($o as $k)
	{
		$targetnode->Load($k);
	}
}

///<summary>html bind data to target node</summary>
///<args name="entries">mixed , query result or object </entries>
function igk_html_binddata($ctrl, $targetnode, $templateArticleName, $entries=null, $rendertarget=true)
{	
	//create a dummy div;
	$d =  IGKHtmlItem::CreateWebNode("div");
	igk_add_article($ctrl, $templateArticleName, $d, null, false, false, false);
	return igk_html_bind_node($ctrl, $d, $targetnode, $entries, $rendertarget);	
}
function igk_html_bind_node($ctrl, $d, $targetnode, $entries=null, $rendertarget=true){
	$o = array();	
	if ($d->HasChilds)
	{	//ass child
		$s = $d->innerHTML;
		$c = $d;//copy node
		$tabinfo = 0;
		$v_info_count =0;
		
		$tabinfo = igk_html_bindinginfo($c);		
		$v_info_count = igk_count($tabinfo);
		if (($v_info_count>0) && $entries)
		{
			igk_html_bindentry($ctrl, $entries, $tabinfo, $o, $c);
		}
		else{
			$o[] = igk_html_eval_script($c->innerHTML, $ctrl, $entries);
			$c->ClearChilds();
		}
		
	}
	if ($targetnode == null)
		$targetnode =$c;
	foreach($o as $k)
	{	
		$b = $targetnode->Load($k);
	}
	if ($rendertarget)
		return $targetnode->Render();
	return IGK_STR_EMPTY;
}
function igk_html_bindentry($ctrl, $entries, $tabinfo, & $o, & $c){	
	$r = igk_getv($entries, "Rows");
	if ($r!=null)
	{//check if contains Rows properties
		foreach($entries->Rows as $k)
		{						
			//tread info			
			foreach($tabinfo as $m)
			{
				igk_html_treatbinding($m, $k, $ctrl);
			}
		}
	}
	else{
		if (is_array($entries))
		{
			foreach($entries as $k)
			{
				//tread info			
				foreach($tabinfo as $m)
				{
					igk_html_treatbinding($m, $k, $ctrl);
				}
			}
		}
		else{
			//by only object
			foreach($tabinfo as $m)
			{
				igk_html_treatbinding($m, $entries, $ctrl);
			}
		}
	}
	$o[] = igk_html_eval_script($c->innerHTML, $ctrl,null);
	$c->ClearChilds();
}

function igk_html_bind_target($ctrl, $targetnode, $textcontent, $entries=null)
{	
	//create a dummy div and load the content
	$d =  IGKHtmlItem::CreateWebNode("div");
	$d->Load($textcontent);
	return igk_html_bind_node($ctrl, $d,$targetnode, $entries);
}



///<summary>bind controller
/// data controller</summary>
///<remark></remark>
///$ctrl controller source of binding
///$content content of binding
function igk_html_bind_content($ctrl, $content, $row=null){//bind content a return a value. 
	$t =  IGKHtmlItem::CreateWebNode("div");
	igk_html_bind_target($ctrl, $t, $content, $row);
	return $t->innerHTML;
}


function igk_html_eval_script($htmlscript, $ctrl, $row)
{
	if (empty($htmlscript))
		return $htmlscript;
	$m = $htmlscript;	
	$m = igk_html_beginbinding($m);	
	$m = igk_html_treatbinding_evaldata($m, $row, $ctrl);		
	$m = igk_html_endbinding($m);
	return $m;
}
function igk_html_beginbinding($value)
{
	$value = str_replace("\"", "__''__", $value);
	return $value;
}
function igk_html_endbinding($value){//used to end binding expression
	$value = str_replace("__''__","\"", $value);	
	return $value;
}
function igk_html_clearbindinfo($ctrl){
	$obj = $ctrl->getParam(IGK_DATABINDING_RESPONSE_NAME);
	if ($obj!=null){
		unset($obj);
		$ctrl->setParam(IGK_DATABINDING_RESPONSE_NAME, null);
	}
}


function & igk_html_databinding_getobjForScripting($ctrl, $name)
{
	$obj=null;
	if ($ctrl==null)
		return $obj;
	$obj = $ctrl->getParam($name);					
	if ($obj == null)
	{
		$obj = new IGKDataBindingScript();	
		$ctrl->setParam($name, $obj);				
	}
	return $obj;
}
function igk_html_php_eval($obj, $ctrl, $row, $expression)
{	
	if (($expression)==null)
		return null;
	if ($obj!=null)	
	extract($obj->args);
	try{
		$k = "return ".$expression.";";
		$m = eval($k);			
	}catch(Exception $ex){
		igk_notifyctrl()->addError($ex->Message);
		igk_wln("error append ".$ex);
	}
	return $m;
}
///<summary>treat string data binding response before eval</summary>
///<param name="rep">reponse</param>
///<param name="$ctrl">controller</param>
function igk_html_databinding_treatresponse($rep, $ctrl, $row)
{
	//\s*(\w+)\s*:\s*([a-zA-Z0-9_]+)\s*\
	//regex for : [def:value]
	$reg = '/\[\s*(?P<name>\w+)\s*:(?P<value>([^\]])+)]/i';
	$reg_comment = '/(?P<comment>(\<\!--(?P<value>(.)+)--\>))/i';
	$comment  = array();
	if (preg_match($reg_comment, $rep))
	{
		
		if ( ($c = preg_match_all($reg_comment, $rep, $match)))
		{			
			for($i = 0; $i<$c ; $i++)
			{			
				$value = $match['comment'][$i];
				
				$rep = str_replace($value, "__COMMENT__".$i."__",$rep);
				$comment["__COMMENT__".$i."__"] = $value;
		    }			
		}
	}
	
	$match = array();
	$c = 0;
	$v = $rep;
	if ( ($c = preg_match_all($reg, $rep, $match)))
	{
		for($i = 0; $i<$c ; $i++)
		{
			$v_m = $match[0][$i];			
			$type = $match['name'][$i];
			$value = $match['value'][$i];
			switch(strtolower($type))
			{
				case "curi": //replace  with controller base uri
					if ($ctrl)
					{				
						$v = str_replace($v_m, 
							igk_io_baseUri()."/".$ctrl->getUri($value),$v);
					}
					else
					$v = str_replace($v_m, 
						igk_io_baseUri()."/".igk_html_uri($value),$v);
					break;
				
				case "uri"://replace with global uri
				$v = str_replace($v_m, 
					igk_io_baseUri()."/".igk_html_uri($value),$v);
					break;
				case "guri": //get uri
				$uri = igk_io_baseUri()."/".igk_html_uri($value);
				$result = igk_io_baseUri()."/".igk_getctrl(IGK_SYSACTION_CTRL)->getUri($value);
				$v = str_replace($v_m, $result,$v);
				break;
				case "lang"://do language replacement
					//igk_wln("evaluate lang ".$value . igk);
					
					// $rm = igk_html_eval_script($value, $ctrl, $row);
					// $obj = igk_html_databinding_getobjForScripting($ctrl,IGK_DATABINDING_RESPONSE_NAME);	
					// $m = igk_html_php_eval($obj, $ctrl, $row, $rm);	
					if (!empty($value))
						$v = str_replace($v_m, R::ngets($value)->getValue(), $v);
					else 
						$v = str_replace($v_m, $value, $v);
					break;
				case "conf": //do configuration zone replacement"
					$v = str_replace($v_m, igk_sys_getconfig($value), $v);
					break;
				case "func"://call system function
					$rm = igk_html_eval_script($value, $ctrl, $row);	
					$obj = igk_html_databinding_getobjForScripting($ctrl,IGK_DATABINDING_RESPONSE_NAME);	
					$m = igk_html_php_eval($obj, $ctrl, $row, $rm);
					$v = str_replace($v_m, $m, $v);
				break;
				case "funcv":
					$rm = igk_html_eval_script($value, $ctrl, $row);
					$m = eval("return ".$rm.";");
					$obj = igk_html_databinding_getobjForScripting($ctrl,IGK_DATABINDING_RESPONSE_NAME);				
					$obj->args["param1"] = $m;
					$v = str_replace($v_m, "\$param1", $v);										
					break;
				case "funcn"://define variable
				case "funce":
					$tab = explode(":", $value);
					if (igk_count($tab)>1)
					{
						$obj = igk_html_databinding_getobjForScripting($ctrl,IGK_DATABINDING_RESPONSE_NAME);										
						
						$name = $tab[0];
						$value = substr($value, IGKString::IndexOf($value, ":")+1);						
						if (!isset($obj->args[$name]))
						{
							$obj->args[$name] = null;
						}
						$rm = igk_html_eval_script($value, $ctrl, $row);
						
						//evaludation 
						$obj->args[$name] = igk_html_php_eval($obj, $ctrl, $row, $rm);
						if (strtolower($type)=="funcn")
							$v = str_replace($v_m, "\${$name}", $v);					
						else{
							$v = str_replace($v_m, IGK_STR_EMPTY, $v);					
						}
					}				
					break;
				case "exp":
					//evaluate expression
					//usage: [exp:variable_name:expression]
					$tab = explode(":", $value);
					if (igk_count($tab)>1)
					{	
						$rm = substr($value, strpos($tab[0], $value)+ strlen($tab[0])+1);												
						$obj = igk_html_databinding_getobjForScripting($ctrl,IGK_DATABINDING_RESPONSE_NAME);	
						igk_wln("e : ".$rm);
						$rm = igk_html_endbinding($rm);
						$obj->args[$tab[0]] = $rm;
						$v = str_replace($v_m, IGK_STR_EMPTY, $v);	
					}
					break;
				default:
					//no action
				break;
			}
		}		
	}

	//restore comment
	foreach($comment as $k=>$s)
	{
		$v = str_replace($k, $s, $v);
	}	
	return $v;
}


final class IGKDataBindingScript extends IGKObject //used to 
{
	var $args; //argument for data binding	
	public function __construct()
	{
		$this->args = array();
	}
}


function igk_html_buildform($ul, $param, $targettagname="li")
{
	foreach($param as $k)
	{
		$id = $k[0];
		$type = strtolower($k[1]);
		$required = igk_getv($k,2);		
		$args = igk_getv($k,3);		
		
		$li = $ul->add($targettagname);
		$a = null;
		$li->add("label", array("for"=>$id))->Content = R::ngets("lb.".$id)->getValue() . ($required?"*":IGK_STR_EMPTY);
		
		switch($type)
		{
			case "textarea":
				$a = $li->addTextArea($id);
				$a->Content = $args;
				break;
			case "radio":
			case "checkbox":
				$a = $li->addInput($id, $type);
				if (igk_getr($id)){
				$a["checked"] = "true";
				}
				break;
			case "hidden":
			case "text":			
			case "password":
			default:
				$a = $li->addInput($id, $type);
				$a["type"]=strtolower($type);
				$a["value"] = $args? igk_getv($args, "value", igk_getr($id)) :  igk_getr($id);
				break;
		}
		$a["id"]=$a["name"] = $id;
		$args = igk_getv($k,3);	
		if ($args !=null)
		{
			$a->AppendAttributes($args);
		}
		
	}
}
function igk_html_uri($uri)
{
	return str_replace("\\", "/",$uri);
}
//unscape text area content
function igk_html_unscape($out)
{
	$reg = "/(?P<name>([\\\][\"\'\\\]))/i";
	$c = preg_match_all($reg,$out, $t);

	for($i = 0; $i< $c;$i++)
	{
		switch($t["name"][$i])
		{
			case '\\"':
					$out = str_replace('\\"','"', $out);
					break;
			case "\\'":
					$out = str_replace("\\'",'\'', $out);
					break;
			case '\\':
					$out = str_replace('\\',"\\", $out);
					break;
		}
	}
	return $out;
}

function igk_html_toggle_class($target, $childtag="tr", $startindex=1,  $class1="table_darkrow", $class2="table_lightrow")
{
	IGKHtmlUtils::ToggleTableClassColor($target, $childtag, $startindex, $class1, $class2);
}
//add item to target
function igk_html_add($item, $target, $index = null)
{
	IGKHtmlUtils::AddItem($item, $target, $index);
}
//add a link items
function igk_html_a_link($target, $hrefuri, $clickuri=null)
{
	$a = $target->add("a");
	if ($a)
	{
		$a["href"] = $hrefuri;
		if ($clickuri)
		$a["onclick"] = "javascript:".$clickuri." return false;";
	}
	return $a;
}
//remove item
function igk_html_rm($item, $dispose=false){
	return IGKHtmlUtils::RemoveItem($item, $dispose);
}
function igk_html_new($node, $attributes = null)
{
	return IGKHtmlItem::CreateWebNode($node, $attributes);
}

function igk_is_conf_connected()
{
	return igk_getctrl(IGK_CONF_CTRL)->IsConnected;			
}
function igk_is_confpagefolder()
{
	return igk_getctrl(IGK_CONF_CTRL)->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER;			
}
//----------------------------------------------------------------------------------------
//igk javascript utiliy
//----------------------------------------------------------------------------------------
function igk_js_enable_tinymce($target, $mode='textareas', $elements=null)
{
$element_txt = 'null';
if ($elements)
{
	if (is_array($elements)){
		$element_txt = "{elements: \"".implode(',', $elements)."\"}";
	}
	else
		$element_txt = "{elements: \"".$elements."\"}";
}
$script = <<<EOF
if (\$ns_igk.tinyMCE) \$ns_igk.tinyMCE.init('{$mode}',{$element_txt});
EOF;
$sc = $target->add("script");
$sc->Content = $script;
return $sc;
}

//JAVASCRIPT FUNCTION
function igk_js_get_posturi($target, $uri, $func =null, $saveState=false){

$func = ($func==null)?"function(xhr){ if (this.isReady()){ this.setResponseTo(self);}}":$func;
$out = "javascript: (function(a){ var self = a; var q = igk.getParentById(self, '".$target["id"]."'); igk.ajx.post('".$uri."', null, ".$func.", ".igk_parsebool($saveState)."); })(this); ";
return $out;
}
function igk_js_lnk_confirm($text){
	return "igk.form.confirmLink(this, '$text'); return false;";
}
//-----------------------------------------
//igk utility function
//-----------------------------------------
function igk_loadcontroller($dirname)
{
	$files = igk_loadlib($dirname, "php");	
	return $files;
}
function igk_wln($msg)
{
	if (is_string($msg))
		igk_wl($msg."<br />");
	else{
		igk_show_prev($msg);
	}
}
function igk_wln_ob_get($obj){
	IGKOb::Start();
	igk_wln($obj);	
	$c = IGKOb::Content();
	IGKOb::Clear();
	return $c;
}
function igk_wl($msg){
	echo $msg;
}
function igk_print_ln($msg)
{
	igk_wl( $msg . "\n");
}
function igk_print($msg)
{
	igk_wl( $ms);
}
function igk_wln_area($msg)
{
	$t =  IGKHtmlItem::CreateWebNode("textarea");
	$t->Content = $msg;
	$t->RenderAJX();
}
///<summary>post data in uri script a return data</summary>
function igk_post_uri($uri, $args=null, $content="Application/x-www-form-urlencoded")
{
$postdata = null;

if ($args!=null)
	$postdata = http_build_query(
    $args
);

$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: '.$content,
        'content' => $postdata
    )
);
$context  = stream_context_create($opts);
$result = @file_get_contents($uri, false, $context);
return $result;
}
function igk_show_prev($obj)
{
	igk_wl( "<pre class=\"igk-prev\">");
	print_r($obj);
	igk_wl( "</pre>");
}
function igk_show_prevTo($target, $obj)
{
	$s = IGK_STR_EMPTY;
	ob_start();
	igk_show_prev($obj)	;	
	$s = ob_get_contents();
	ob_end_clean();
	$target->addDiv()->Content = $s;
	
}
function igk_show_code($obj)
{
	igk_wl( "<code>");
	igk_wl($obj);
	igk_wl( "</code>");
}
function igk_show_textarea($obj)
{
	igk_wl( "<textarea>");
	igk_wl($obj);
	igk_wl( "</textarea>");
}

function igk_show_keytype($array)
{
	igk_wl( "<pre>");
	$out = IGK_STR_EMPTY;
	if (is_array($array))
	{
	foreach($array as $k => $v)
	{
		$out .= $k . " =&gt; ".$v."\n"; 
	}
	}
	igk_wl( $out);
	igk_wl( "</pre>");
}
function igk_regtowebpage($ctrl)
{
		$c = igk_get_defaultwebpagectrl();
		if ($c)
			$c->regChildController($ctrl);
}
//<summary>Add article to view for this controller</summary>
//<param>
//<ctrl>controleur that require to add article</ctrl>
//<name>name or path to current article</ctrl>
//</param>
function igk_add_article($ctrl ,$name, $target, $tagname=null, $forcecreation=false, $evalExpression=true, $articleoptions=true)
{		
	
	$f = $name;
	$n = null;
	$d = dirname($name);
	
	if (!empty($d) && ($d!=".") && is_dir($d))
	{		
		$f = $ctrl->getArticleInDir(basename($name), $d);		
	}
	else{
		if(!file_exists($name) && ($ctrl !=null))
			$f = $ctrl->getArticle($name);	
		else 
			return;
	}
		if ($forcecreation && !file_exists($f))
		{
			//save article
			igk_io_save_file_as_utf8_wbom($f, IGK_STR_EMPTY, true);
			//IGKIO::WriteToFileAsUtf8WBOM($f, IGK_STR_EMPTY, true);
		}
		
		if (($target==null) && ($tagname==null))
		{
			return;
		}
		if ($tagname == null){
			$n = $target;
		}
		else{
			$n = $target->add($tagname);
		}
		
		if ($n ==null )
			throw new Exception("igk_add_article::target is null" );
		if (!is_dir($f) && file_exists($f))
		{
			$content = file_get_contents($f);
			if ($evalExpression){
				$content = igk_html_eval_script($content, $ctrl,null);
			}
			if ($tagname == null){		
				$target->Load($content);
				igk_html_treatinput($target);
			}
			else 
			{				
				if ($n!=null)
				{
					$n->Load($content);
					igk_html_treatinput($n);						
				}				
			}			
		}
		//add article options
		if ($articleoptions)
			$s = igk_add_article_options($ctrl, $n, $f);
		return $n;		
}



// function igk_add_article_w($ctrl,$name, $target, $evalExpression=true){//add article without options
	// if (!($ctrl->App->ConfigMode && $ctrl->App->Configs->allow_article_config && ($target!=null)) )
	// {
		// return;
	// }
	// $f = $name;
	// if(!file_exists($f))
		// $f = $ctrl->getArticle($f);	
	// if (file_exists($f))
	// {
		// $content = file_get_contents($f);
		// if ($evalExpression){
			// $content = igk_html_eval_script($content, $ctrl,null);
		// }					
		// $target->Load($content);
		// igk_html_treatinput($target);
		// return true;
	// }
	// return false;
// }

///<summary>add articles options</summary>
function igk_add_article_options($ctrl, $node, $filename){	//add article options
	if (! ($ctrl->App->Configs->allow_article_config && $ctrl->App->ConfigMode
	    && ($node!=null)))
	{
		return;
	}
	$c = new IGKHtmlArticleConfigNode($ctrl, $node, $filename);	
	
	return $c;
}

/*add article and treat image source as link*/
function igk_in_article($ctrl ,$name, $target, $tagname = null)
{
	if ($target==null)
		throw new Exception("igk_in_article:: target is null" );
		$f= $ctrl->getArticle($name);		
		if (file_exists($f))
		{
			$uri = igk_io_baseUri()."/". igk_io_basePath($f);
			if ($tagname == null)
			{
				$target->Load(file_get_contents($uri));
			}
			else{ 
				$s = $target->add($tagname);
				$s->Load(file_get_contents($uri));
			}
		}
		$m = $target->getElementsByTagName("image");
		if ($m){
		$dir = dirname(igk_io_basePath($f));
		foreach($m as $k=>$v)
		{
			if (!IGKValidator::IsUri($v->lnk) && is_file( IGKIO::GetDir($dir."/".$v->lnk)))
			{
				$v->lnk = igk_io_baseUri()."/". $dir."/".$v->lnk;	
			}			
		}
		}
	return null;
}

function igk_rm_article($ctrl , $name, $alllanguage=false){
	if ($alllanguage)
	{
		$d = dirname($name);	
		$exp = "/(\\\\".igk_str_expr(IGKIO::GetDir(basename($name))).")/i";
		//$exp = "/(\\\\class\.C)/i";
		if (!empty($d) && ($d!=".") && is_dir($d))
		{		
			$f = igk_io_getfiles($d, $exp, false);		
		}
		else{
			if(!file_exists($name))
			{
				$f = igk_io_getfiles($ctrl->getArticlesDir(), $exp, false);						
			}
		}
		if ($f){
			$i = 0;
			foreach($f as $k=>$v){
				unlink($v);
				$i++;
			}
			return $i;
		}
		
	}
	else{
		$f = $name;
		$n = null;
		$d = dirname($name);	
		if (!empty($d) && ($d!=".") && is_dir($d))
		{		
			$f = $ctrl->getArticleInDir(basename($name), $d);		
		}
		else{
			if(!file_exists($name))
				$f = $ctrl->getArticle($name);	
		}
		if (file_exists($f)){			
			unlink($f);
			return 1;
		}
	}
}


/*
*CHECK if the name is a reserved name
*/
function igk_ctrl_is_reservedname($name)
{
	if (preg_match("/^((a(bstract|nd|rray|s))|(c(a(llable|se|tch)|l(ass|one)|on(st|tinue)))|(d(e(clare|fault)|ie|o))|(e(cho|lse(if)?|mpty|nd(declare|for(each)?|if|switch|while)|val|x(it|tends)))|(f(inal|or(each)?|unction))|(g(lobal|oto))|(i(f|mplements|n(clude(_once)?|st(anceof|eadof)|terface)|sset))|
(n(amespace|ew))|(p(r(i(nt|vate)|otected)|ublic))|(re(quire(_once)?|turn))|(s(tatic|witch))|(t(hrow|r(ait|y)))|(u(nset|se))|
(__halt_compiler|break|list|(x)?or|var|while))$/i", trim($name)))
		return true;
	return false;

}
function igk_ctrl_info($name)
{
	return igk_getctrl(IGK_CUSTOM_CTRL_MAN_CTRL)->getInfo($name);
}


/*-------------------------------------------------------------------------------------
//io shortcut
/-------------------------------------------------------------------------------------*/

//---------------------------------------------------------------------------------
//IGK IO Functions
//---------------------------------------------------------------------------------

function igk_io_get_article_file($name, $dir, $lang="fr"){
	$file = "";
	if (preg_match("/\.(phtml|template|txt)$/i", $name))
				$file = $dir."/".$name;
			else{				
				$file =$dir."/".$name.".".strtolower($lang).".phtml";
			}
	return $file;
}
//return the dir from document root
function igk_io_rootBaseDir($dir=null){

	return IGKIO::GetRootBaseDir($dir);
}
///<summary> check if full path</summary> 
///<remark>path mus exists</summary>
function igk_io_is_fullpath($d){
	$k = IGKIO::GetDir($d);
	$c = realpath($k);
	return $k==$c;
}
///retreive the current uri
function igk_io_get_uri(){
	$s = igk_getv($_SERVER,"REQUEST_SCHEME")."://".igk_getv($_SERVER,"SERVER_NAME").igk_getv($_SERVER,"REQUEST_URI");
	return $s;
}

function igk_io_getdbconf_file($dir)
{
	return igk_io_getdir($dir."/".IGK_DATA_FOLDER."/".IGK_CTRL_DBCONF_FILE);
}
function igk_io_getconf_file($dir)
{
	return igk_io_getdir($dir."/".IGK_DATA_FOLDER."/".IGK_CTRL_CONF_FILE);	
}
function igk_io_getdir($dir)
{
	return IGKIO::GetDir($dir);
}
//@@ use to remove empty line from file
function igk_io_removeEmptyLine($file)
{	
	if (!file_exists($file))
		return;
		$f = IGKIO::ReadAllText($file);
		$o = igk_str_remove_empty_line($f);
		igk_io_save_file_as_utf8($file, $o, true);		
}
function igk_io_getrelativepath($source, $target)
{
			$o = IGK_STR_EMPTY;
			$v = $target;
			$sdir = $source;
			$i = strpos($target, $source);
			if ($i!== false)
			{
				//child of current dir
				$o = "./". igk_str_rm_start( substr($v,$i + strlen($sdir)), '/');
			}			
			else{
				$o = $v;
				//retrieve the parent at				 
				 $i = strpos($v, $sdir);
				 $p = "../";
				 $sdir = dirname($sdir);
				 $ci = 0;//depth
				 while(!empty($sdir) && ($sdir!= $v))
				 {					
					$ci++;
					//go to parent folder until found a correspondance					
					$sdir = dirname($sdir);
					if (strpos($v, $sdir)=== false)
					{
						$p.= "../";						
					}
					else
						break;
				 }					 
				 if ($sdir)
				 {
					$o = IGKIO::GetDir($p.igk_str_rm_start( substr($v,$i + strlen($sdir)), '/')); 
				 }
			}
			return $o;
}
///<summary>get file in current directory</summary>
function igk_io_getfiles($dir, $match="/(.)*/i", $recursive=true)
{
	return IGKIO::GetFiles($dir, $match,$recursive);
}
///return the fool request uri
function igk_io_fullrequestUri()
{
	return igk_html_uri(igk_str_rm_last(IGKIO::GetRootUri(), "/")."/".igk_str_rm_start($_SERVER["REQUEST_URI"],'/'));
}
function igk_io_baseRequestUri()
{
	$s = igk_io_baseUri();
	$d = igk_io_fullrequestUri();
	return igk_str_rm_start(substr($d, strlen($s)), '/');
}
///<summary>return the base request uri</summary>
function igk_io_root_base_uri(){
	$v_ruri = igk_io_baseRequestUri();	
	$tab = explode('?',$v_ruri);
	$uri = igk_getv($tab, 0);
	return "/".$uri;
}
///<summary>get the web site full uri according to uri file pass form basedir</summary>
///<exempl>if you pass string "info" to this function and your website is http://www.igkdev.be the response will be 
/// http://www.igkdev.be/info
/// </exemple>
function igk_io_htmluri($uri=null)
{
	return igk_str_rm_last(igk_io_baseUri(), '/'). (($uri)? "/".igk_html_uri($uri) : IGK_STR_EMPTY);
}
function igk_io_save_file_as_utf8($filename, $content, $override=true, $transform=true)
{
	$r =$transform ? igk_ansi2utf8(utf8_encode($content)) : $content;
	return IGKIO::WriteToFile($filename, $r, $override);
}
///<summary>shortcut to IGKIO::WriteToFileAsUtf8WBOM</summary>
function igk_io_save_file_as_utf8_wbom($filename, $content, $override=true)
{
	return IGKIO::WriteToFileAsUtf8WBOM($filename, $content, $override);
}
///<summary>shortcut to IGKIO::GetBaseUri</summary>
function igk_io_baseUri($dir=null, $secured=null)
{
	$s= igk_html_uri(IGKIO::GetBaseUri($dir, $secured));
	while(IGKString::EndWith($s,'/') && (($k =strlen($s))>0))
	{
		$s = substr($s, 0, $k-1);
	}
	return $s;
}
function igk_io_baseUri_i($dir, $secured=null){
	if(empty($dir))
		return IGK_STR_EMPTY;
	return igk_io_baseUri($dir, $secured);
}
//store array data to xml property value
function igk_io_store_dataXml($filename, $rootname, $t)
{

	$conf =  IGKHtmlItem::CreateWebNode($rootname);
	//function in function . allowed in php strange behaviour
	function getData($node, $t)
	{
		foreach($t as $k=>$v)	
		{
			if (is_array($v))
			{
				getData($node->add($k), $v);
			}	
			else{
				$node->add($k)->Content = $v;
			}
		}
	}
	getData($conf, $t);
	
	IGKIO::WriteToFileAsUtf8WBOM($filanem, 	$conf->Render(), true);
}
/// retourne le chemin complet . si chemin relatif fournit c'est le cwd qui intervient
function igk_io_getfullpath($path)
{
	return realpath($path);
}
///<summary> retourne le chemin relatif par rapport à la racine de site. A utiliser avec des fichiers contenus dans le site.</summary>
// function igk_io_currentbasePath($file)
// {
	// return igk_io_currentRelativePath($file);//igk_io_baseRelativePath($file));
// }
///<summary>get base directory</summary>
///<remark>return the directory full path</remark>
function igk_io_baseDir($dir=null)
{
	if ($dir==null)
		return IGKApp::$BASEDIR;
	return IGKIO::GetDir(IGKApp::$BASEDIR."/".$dir);
}
///<summary> retourne le chemin relatif à  partir de la racine du site. si le repertoire existe.</summary>
///<arg name="dir"> cwd path or full path</arg>
///<remark>dir must exist</remark>
function igk_io_basePath($dir)
{
	return igk_io_baseRelativePath(realpath($dir));
}
//<summary>retourne un chemin relatif à  partir de la racine du site spécifier par IGKApp::BaseDir</summary>
function igk_io_baseRelativePath($dir, $separator=DIRECTORY_SEPARATOR)
{
	if ($separator =="\\")
	{
		$dir = str_replace("/","\\",$dir);		
	}	
	return IGKIO::GetChildRelativePath(IGKApp::$BASEDIR, $dir, $separator);
}
///<summary>shortcut to IGKIO::GetCurrentRelativePath</summary>
///<remark></remark>
///<parma name='dir'> $dir : sever absolute path or basedir relative path</dir>
function igk_io_currentRelativePath($dir)
{	
	return IGKIO::GetCurrentDirRelativePath($dir);
}
/// get the current relative uri //dir according to web page base index
function igk_io_currentRelativeUri($dir=IGK_STR_EMPTY)
{
	return IGKIO::GetCurrentRelativeUri($dir);
}
function igk_io_cwdRelativePath($dir)
{
	return IGKIO::GetRelativePath($dir, getcwd());
}
///<summary>return the relative uri according to BASEDIR</summary>
function igk_io_fullpath2Uri($dir)
{
	return igk_io_currentRelativeUri(igk_io_baseRelativePath($dir));
}
//
///<summary>return the system full path according to BASEDIR.</summary>
///<code>exemple: in window will return c://wamp/website/[$relativepath]</code>
function igk_io_syspath($relativepath=null)
{
	return igk_io_getdir(IGKApp::$BASEDIR."/".$relativepath);
}

///<summary>move uploaded file to destination</summary>
function igk_io_move_uploaded_file($file, $destination)
{
	
	if (!@move_uploaded_file($file, $destination))
	{
		return false;		
	}
	return true;
}

function igk_io_moveUploadedFileToDataFolder($name, $dir, $pattern="pics_%d%")
{	
	$img = igk_getv($_FILES, $name);
	if ($img){	
		if (IGKIO::CreateDir($dir)){
			if (!file_exists($dir."/.htaccess"))
			{
				IGKIO::WriteToFile($dir."/.htaccess", "allow from all");
			}
			for($i = 0; $i<igk_count($img["name"]) ; $i++)
			{				
				if (igk_getv($img["error"],$i) == 0)
				{
					$r = str_replace("%d%", $i, $pattern);
					$f = $img["tmp_name"][$i];							
					$o = $dir.$r.".".igk_io_path_ext($img["name"][$i]);							
					igk_io_move_uploaded_file($f,$o);
				}
			}
		}
	}				
}
///<summary>Remove extension from filename @name file name</summary>
function igk_io_remove_ext($name)
{
	if (empty($name))
		return null;
	$t = explode(".", $name);
	if (count($t)>1){
		$s = substr($name, 0, strlen($name) - strlen($t[count($t)-1])-1);
		return $s;
	}
	return $name;
}
function igk_io_path_ext($fname)
{
	if (empty($fname))
		return null;
	$t = explode(".", $fname);
	if (count($t)>0){
		return $t[count($t)-1];
	}
	return null;
}
/// get basename without extension
function igk_io_basenamewithoutext($file)
{
	return igk_io_remove_ext(basename($file));
}

function igk_io_saveContentFromTextArea($file, $content, $overwrite=true)
{
	if (ini_get("magic_quotes_gpc")){
		 $content = stripcslashes($content);
	}
	return igk_io_save_file_as_utf8($file, $content, $overwrite);  //IGKIO::WriteToFileAsUtf8WBOM($file,  $content, $overwrite);
}
function igk_io_fileIsPicture($type)
{
	$t = array(
		"image/png"=>1,
		"image/jpeg"=>1,
		"image/svg+xml"=>1,
		"image/tiff"=>1,
		"image/gkds"=>1
	);
	return isset($t[$type]);
}

//-----------------------------------------------------------------------------------
//UTITLITY
//-----------------------------------------------------------------------------------
function igk_html_add_title($node, $title){
	if ($node==null)
		return;
		$d = $node->addDiv();
		$d["class"] ="igk-title";
		$d->Content = R::ngets($title);
		return $d;
}
//@close uri : uri when closing
//@target: receive the frame
function igk_add_new_frame($ctrl, $name, $closeuri =null, $target=null, $reloadcallback=null)
{
	$frame = igk_getctrl(IGK_FRAME_CTRL)->createFrame($name, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = IGKApp::getInstance()->Doc->body;
	IGKHtmlUtils::AddItem($frame,  $target);
	return $frame;
}
//create a frame that will contain a form 
function igk_add_new_frame_ex($ctrl, $id, $title, $uri, & $form, $closed=false){//!!!!! not used
	$frame = igk_add_new_frame($ctrl, $id);
	$div = $frame->Content;
	$div->ClearChilds();
	$frame->Title = $title; 
	$frm = $div->addForm();
	$frm["action"]=$uri;
	$frm["igk-ajx-target-response"] = $ctrl->TargetNode["id"];
	if ($closed)
		$frm["igk-frame-close"] = "1";
	$form = $frm;
	return $frame;
}
function igk_frame_close_frame_callback($frame)
{
	if (igk_qr_confirm())
	{		
		$p =  $frame->Owner->App->getControllerManager()->InvokeUri($frame->closeMethodUri);			
		return $p;
	}
}
function igk_frame_add_confirm($ctrl, $id, $uri=null, $closeuri = ".", $title=null,$target=null, $buttonmodel= 0)
{
 
	$frame = igk_add_new_frame($ctrl, $id, $closeuri,$target);
	$frame->Title = ($title==null)?R::ngets(IGK_CONFIRM_TITLE):$title;
	$frame->closeMethodUri = $uri;
	$frame->callbackMethod = "igk_frame_close_frame_callback";
	$d = $frame->Content;
	$d->ClearChilds();
	
	$igk = IGKApp::getInstance();
	$frame->Form = $d->addForm();
	$frame->Form["action"] = $frame->closeUri;
	$frame->Form["igk-confirmframe-response-target"] = $ctrl->TargetNode["id"];
	$frame->Form->Div = $frame->Form->addDiv();
	$frame->Form->addHSep();	
	$frame->Form->addInput("confirm", "hidden",1);
	$frame->Form->addInput("frame-id", "hidden",$id);
	$frame->Form->addInput("frame-close-uri", "hidden", igk_getctrl(IGK_FRAME_CTRL)->getUri("closeFrame_ajx&navigate=false&id=".$id));
	$frame->Form->addScript()->Content ="window.igk.winui.framebox.init_confirm_frame(igk.getlastscript(), '".$frame->closeUri."&cancel=1"."', ".($igk->Session->URI_AJX_CONTEXT?'true':'false').")";
	
	$canceluri = $frame->closeUri."&cancel=1";
	switch($buttonmodel)
	{
		case 0:
			$btn = $frame->Form->addBtn("btn_yes", R::ngets("btn.yes"), "submit");			
			
			$btn["onclick"] =  $igk->Session->URI_AJX_CONTEXT?"javascript: return window.igk.winui.framebox.btn.yes(this);":null;
			//no-			
			IGKHtmlUtils::AddBtnLnk($frame->Form, R::ngets("btn.cancel"), "javascript: ".igk_js_post_frame_cmd($canceluri) . " this['igk:framebox'].close(); return false;");
		break;
		case 1:
			$frame->Form->addBtn("btn_ok", R::ngets("btn.ok"), "submit", array("onclick"=>$igk->Session->URI_AJX_CONTEXT?"javascript:return window.igk.winui.framebox.btn.yes(this);":null) );			
			//cancel 
			IGKHtmlUtils::AddBtnLnk($frame->Form, R::ngets("btn.cancel"), "javascript: ".igk_js_post_frame_cmd($canceluri). " this['igk:framebox'].close(); return false;");
			break;
	}
	if ($ctrl->CurrentPageFolder == "Configs")
	{
		$frame["class"] = "+igk-cnf-framebox";
	}
	return $frame;
}
function igk_frame_close($name, $navigate=null)
{
	return igk_getctrl(IGK_FRAME_CTRL)->closeFrame($name, $navigate);
}
function igk_get_frame($name){
	return igk_getctrl(IGK_FRAME_CTRL)->getFrame($name);
}

//frame utility functions
function igk_frame_new($ctrl, $id, $closeuri=".", $target=null, $reloadcallback=null)
{
	$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame($id, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = IGKApp::getInstance()->Doc->body;
	igk_html_add($frm,  $target);
	$frm->Script->Content = new IGKFrameScript($frm, "confirm");
	return $frm;
}

function igk_frame_confirm($ctrl, $id, $title=null, $closeuri=".", $target=null, $reloadcallback=null)
{
	$frame = igk_getctrl(IGK_FRAME_CTRL)->createFrame($id, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = IGKApp::getInstance()->Doc->body;
	igk_html_add($frm,  $target);
	
	$frame->Title = ($title==null)? R::ngets(IGK_CONFIRM_TITLE) : $title;
	$d = $frame->Content;
	$d->ClearChilds();
	
	$igk = $ctrl->App;
	$frame->Form = $d->addForm();
	$frame->Form["action"] = $frame->closeUri;
	$frame->Form["igk-confirmframe-response-target"] = $ctrl->TargetNode["id"];
	$frame->Form->Div = $frame->Form->addDiv();
	$frame->Form->addHSep();	
	$frame->Form->addInput("confirm", "hidden",1);
	$frame->Form->addInput("frame-id", "hidden",$id);
	$frame->Form->addInput("frame-close-uri", "hidden", igk_getctrl(IGK_FRAME_CTRL)->getUri("closeFrame_ajx&navigate=false&id=".$id));
	$frame->Form->addScript()->Content ="igk.winui.framebox.init_confirm_frame(igk.getlastscript(), '".$frame->closeUri."&cancel=1"."', ".
	($igk->Session->URI_AJX_CONTEXT?'true':'false')
	.")";
	
	$canceluri = $frame->closeUri."&cancel=1";
	switch($buttonmodel){
	case 0:
		$btn = $frame->Form->addBtn("btn_yes", R::ngets("btn.yes"), "submit");			
		$btn["onclick"] = $igk->Session->URI_AJX_CONTEXT?"javascript: return IGK.winui.framebBox.btn.yes(this);":null;		
		IGKHtmlUtils::addBtnLnk($frame->Form, R::ngets("btn.no"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close(); ");
	break;
	case 1:
		$frame->Form->addBtn("btn_ok", R::ngets("btn.ok"), "submit", array("onclick"=>$igk->Session->URI_AJX_CONTEXT?"javascript:return IGK.winui.frameBox.btn.yes(this);":null) );			
		IGKHtmlUtils::addBtnLnk($frame->Form, R::ngets("btn.cancel"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close()" );
		break;
	}
	
	$frm->Script->Content = new IGKFrameScript($frm, "c");	
	return $frm;
}

function igk_frame_js_postform_ref($ctrl){
	return  "javascript: return (function(q,s){ IGK.winui.frameBox.postForm(q.form, q.form.action, s); return false;})(this, '".$ctrl->TargetNode["id"]."');";
}

///<summary>frame class script</summary>
final class IGKFrameScript implements IIGKHtmlGetValue {//represent a frame class script
	var $owner;
	private $m_type;
	
	public function __construct($owner, $type="f"){
		$this->owner = $owner;		
		$this->m_type = $type;
	}

	public function getValue()
	{
		$n =IGK_STR_EMPTY;
		switch($n)
		{
			case "c":
				$n = "initconfirm";
				break;
			case "f":
			default:
				$n = "init";
				break;				
		}
		return  igk_get_string_format("IGK.winui.frameBox.{$n}({0}],{1});",
		igk_getsv($this->owner->Width?'"'.$this->owner->Width.'"':null,'null'),
		igk_getsv($this->owner->Height?'"'.$this->owner->Height.'"':null,'null'));
	}
}




///<summary>get new relative html relative uri value</summary>
function igk_get_nhru($value)
{
	return new IGKHtmlRelativeUriValueAttribute($value);
}


function igk_register_balafon_db_table($tablenameinterface)
{
	IGKBalafonDBManager::getInstance()->register_db_table($tablenameinterface);	
	
}
function igk_db_getdatatableinfokey($tablename){
	$tab = igk_getctrl("IGKDBCtrl")->getDataTableDefinition($tablename);	
	return igk_array_object_refkey($tab, "clName");	
}
function igk_db_getdatatable_owner($tablename){
	return igk_getctrl("IGKDBCtrl")->getDataTableCtrl($tablename);	
}


//<summary>get table result as xml response</summary>
function igk_db_table_xmlview_response($tablename, $where=null){
		$tb = IGKHtmlItem::CreateWebNode("DataTable");
		$tb["name"] = $tablename;
		$dataentry = $tb->addDataEntry();
		$dataentry->LoadData(igk_db_table_select_where($tablename, $where));
		$e = IGKHtmlItemm::CreateWebNode("XmlViewer");
		$e->Load($dataentry);
		return $e->Render(null);
}

///<summary>return the declared table definition structure</summary>
function igk_db_get_table_def($adaptername=IGK_MYSQL_DATAADAPTER)
{
	$v_dictionary = array();
		foreach(igk_sys_getall_ctrl() as $k)
		{
			$v_name = $k->DataTableName; // primary table name
			//retrieve controller that match this adapter
			if ((($k->DataAdapterName != $adaptername) || 
			empty($v_name) ||
			(($v_info = $k->DataTableInfo) == null)))
				continue;
			//			
			$te = null;
			if (isset($v_info["data-schema"]) || is_array($v_info) && is_array(igk_getv(array_values($v_info),0)))
			{
				foreach($v_info as $table=>$rinfo){
					if ($table == "data-schema")continue;
					$info = (object)array(
					"tableName"=>$table,
					"tableInfo"=>IGKdbColumnInfo::AssocInfo($rinfo, $table),
					"Ctrl"=>$k,
					"Entries"=>$te,
					"AdapterName"=>$adaptername
					);			
					$v_dictionary[$info->tableName] = $info;
				}
			}
			else{
			$info = (object)array(
			"tableName"=>$v_name,
			"tableInfo"=>IGKdbColumnInfo::AssocInfo($v_info, $v_name),
			"Ctrl"=>$k,
			"Entries"=>$te,
			"AdapterName"=>$adaptername
			);			
			$v_dictionary[$info->tableName] = $info;
			}
		}
	return $v_dictionary;		
}

///<summary>get table that contains specified column</summary>
function igk_db_get_table_with_column($columnName, $adaptername=IGK_MYSQL_DATAADAPTER){
	$dic = igk_db_get_table_def($adaptername);
	$tab = array();
	$columnName = strtolower($columnName);
	foreach($dic as $k=>$v){
		$tb = array_keys($v->tableInfo);
		foreach($tb as $s=>$t){
			if (strtolower($t) == $columnName)
			{
				$tab[] = $v->tableName;
				break;
			}
		}
	}
	return $tab;
}

function igk_db_lastid($ctrlorName){
  $apt	= igk_get_data_adapter($ctrlorName);
	if ($apt)
		return $apt->getLastId();
	return 0;
}
function igk_db_drop_table($ctrlorName, $table, $leaveOpen)
{
	$apt = igk_get_data_adapter($ctrlorName);
	if ($apt)
	{
		$apt->connect();
		$apt->dropTable($table);
		$apt->close($leaveOpen);
	}
	
}

function igk_db_close($ctrlorName){
	$apt = igk_get_data_adapter($ctrlorName);
	if ($apt)
		$apt->close(false);
}
///<summary>load data from schema files</summary>
function igk_db_load_data_schemas($file)
{
		$tab = array();		
		if (file_exists($file))
		{			
			$d = IGKHtmlReader::LoadFile($file);
			$n = igk_getv($d->getElementsByTagName("data-schemas"),0);			
			if ($n){
			foreach($n->getElementsByTagName("DataDefinition") as $k=>$v)
			{
				$c = array();
				foreach($v->getElementsByTagName("Column") as $kk=>$vv)
				{
					$c[] = new IGKdbColumnInfo($vv->Attributes->ToArray());
				}
				$tab[$v["TableName"]] = $c;
			}		
			}			
		}
		return $tab;
}
///<summary>get default entries from data schema</summary>
///<summary>get default entries from data schema</summary>
function igk_db_load_data_entries_schemas($file)
{
		$tab = array();		
		if (file_exists($file))
		{			
			igk_debug_wln(__FUNCTION__."::: load files");
			$d = IGKHtmlReader::LoadFile($file);
			$n = igk_getv($d->getElementsByTagName("data-schemas"), 0);
			$n = $n ? igk_getv($n->getElementsByTagName("Entries"), 0) : null;			
			if ($n){
				
				foreach($n->Childs as $k=>$v)
				{
					$c = array();
					$ttb = $v->getElementsByTagName("Row");
					foreach($ttb as $kk=>$vv)
					{
						$c[] = $vv->Attributes->ToArray();
					}				
					$tab[$v->TagName] = $c;
				}		
			}			
		}
		return $tab;
}

function igk_db_getobj($tab){
	$t = array();		
	foreach($tab as $k)
	{
		$t[$k->clName] = null;
	}
	return (object)$t;
}
function igk_db_select_all($ctrl)
{
	$db = igk_get_data_adapter($ctrl);
	$r = null;
	if ($db){
		$db->connect();
		try{
		$r = $db->selectAll($ctrl->DataTableName);
		}
		catch(Exception $ex)
		{
		}
		$db->close();
	return $r;
	}
	return null;
}
function igk_db_select_wherec($ctrl, $andcondition)
{
	$db = igk_get_data_adapter($ctrl);
	$r = null;
	if ($db){
		$db->connect();
		try{
			$r = $db->selectAndWhere($ctrl->DataTableName, $andcondition);
		}
		catch(Exception $ex)
		{
			igk_log_write_i("error", $ex);
		}
		$db->close();
		return $r;
	}
	return null;
}

function igk_db_table_select_where($table, $andcondition=null, $adapter=IGK_MYSQL_DATAADAPTER, $leaveOpen = false)
{
	$db = igk_get_data_adapter($adapter);	
	$r = null;
	if ($db){
		$db->connect();
		try{
			$r = $db->selectAndWhere($table, $andcondition);
		}
		catch(Exception $ex)
		{
			igk_log_write_i("error", $ex);
		}
		$db->close($leaveOpen);
		
		return $r;
	}
	return null;
}
function igk_db_load_to_node($result, $p){// load data to node
	if ($result && $result->RowCount >0)
	{
		foreach($result->Rows as $k=>$v)
		{
			$p->add("Item")->setAttributes($v);
		}	
	}
}
function igk_db_view_result($result){
	$r =  IGKHtmlItem::CreateWebNode("table");
	$tr = $r->add("tr");
	
	foreach($result->Columns as $k=>$v){	
		$tr->add("th")->Content = $v->name;
	}
	foreach($result->Rows as $k=>$v){	
		$tr = $r->add("tr");	
		
		foreach($v as $s=>$m){
			$tr->add("td")->Content = $m;
		}
	}
	return $r;
}

//filter object entries to fit data base column info
function igk_db_objentries($ctrl, $tab)
{
			$ttab = $ctrl->getDataTableInfo();
			if( !$tab)
				return null;
			$v_otab = array ();
			$s = IGK_FD_NAME;
			foreach($ttab as $k=>$v)
			{				
				$tk = igk_getv($v,IGK_FD_NAME);
				$v_otab[$tk] = igk_getv($tab, $tk);
			}
			return $v_otab;
}

//controller of name
function igk_get_data_adapter($controllerOrAdpaterName, $throwException=false)
{
	$n = IGK_STR_EMPTY;
	if (is_string($controllerOrAdpaterName))
		$n = $controllerOrAdpaterName;
	else if (is_object($controllerOrAdpaterName))
		$n = $controllerOrAdpaterName->getDataAdapterName();	
	$r = IGKDataAdapter::CreateDataAdapter($n, $throwException);
	return $r;
}
function igk_db_get_entries($controllerOrAdpaterName, $table, $dbname=null)
{
	$adapt = igk_get_data_adapter($controllerOrAdpaterName, false);
	
	if($adapt)
	{
		$adapt->connect($dbname);
		$r =  $adapt->selectAll($table);
		$adapt->close();
		return $r;		
	}	
	return null;
}
function igk_db_insertc($ctrl,$entries){//insert db 
	
	return igk_db_insert($ctrl, $ctrl->getDataTableName(), $entries, null);
}
///<summary>select single row</summary>
function igk_db_table_select_row($table, $id, $controllerOrAdapterName=IGK_MYSQL_DATAADAPTER, $leaveopen=false)
{
	$k = null;
	if (is_array($id)) $k = $id;
	else if (is_object($id)) $k =(array)$id;
	else 
		$k = array("clId"=>$id);
	
	
	$r = igk_db_table_select_where($table, 
	$k, 
	$controllerOrAdapterName, 
	$leaveopen);
	if ($r && ($r->RowCount == 1))
		return $r->getRowAtIndex(0);
	return null;
}

function igk_db_send_query($controllerOrAdpaterName, $query,  $dbname=null, $leaveOpen=false)
{
	$adapt = igk_get_data_adapter($controllerOrAdpaterName, false);	
	if($adapt && method_exists(get_class($adapt), "sendQuery"))
	{
		$adapt->connect($dbname);
		//!!!need of a query reader	
		foreach(explode(";", $query) as $k=>$v)
		{
			$v = trim($v);
			if (!empty($v))
			{
				try{
					$r =  $adapt->sendQuery($v);
				}catch(Exception $exception){
				}
			}
		}
		$adapt->close($leaveOpen);
		return $r;		
	}	
	return null;
}
function igk_db_reload_index($controllerOrAdapterName, $table, $dbname=null, $leaveOpen=false){//used to reload index on database
$adapt = igk_get_data_adapter($controllerOrAdapterName, false);	
	if($adapt)
	{
		$adapt->connect($dbname);
		$r =  $adapt->selectAll($table);
		$adapt->ClearTable($table);
		$i=1;
		foreach($r->Rows as $k=>$v){
			$v->clId = $i;
			$adapt->insert($table, $v);
			$i++;
		}
		$adapt->close($leaveOpen);
		return $r;		
	}	
	return null;
}
function igk_db_error($message){
	IGKApp::getInstance()->Session->setParam("db_error_msg", $message);
}
function igk_db_get_error(){
	return IGKApp::getInstance()->Session->getParam("db_error_msg");
}
///<summary></summary>
///<remark>if entrie is a std class the reponds will have a clid updated </remark>
function igk_db_insert($controllerOrAdpaterName, $table, $entries,  $dbname=null, $leaveOpen= false)
{
	$adapt = igk_get_data_adapter($controllerOrAdpaterName, false);	
	if($adapt)
	{
		$adapt->connect($dbname);
		$r =  $adapt->insert($table, $entries);		
		$adapt->close($leaveOpen);
		return $r;		
	}	
	else{
		igk_db_error("adapter is null");
	}
	return null;
}
function igk_db_update($controllerOrAdpaterName, $table,$entry, $where=null,  $dbname=null, $leaveOpen=false){//update entries
	$adapt = igk_get_data_adapter($controllerOrAdpaterName, false, $leaveOpen);	
	if($adapt)
	{
		$adapt->connect($dbname);
		$r =  $adapt->update($table, $entry, $where==null? array("clId"=>$entry->clId): $where );		
		$adapt->close($leaveOpen);
		return $r;		
	}	
	return null;
}
function igk_db_deletec($ctrl, $where){
	return igk_db_delete($ctrl, $ctrl->getDataTableName(), $where, null);
}
function igk_db_delete($controllerOrAdpaterName, $table, $where,  $dbname=null, $leaveOpen=false)
{
	$adapt = igk_get_data_adapter($controllerOrAdpaterName, false);	
	if($adapt)
	{
		$adapt->connect($dbname);
		$r =  $adapt->delete($table, $where );
		
		$adapt->close($leaveOpen);
		return $r;		
	}	
	return null;
}

///<summary>get notification controller</summary>
function igk_notifyctrl($name =null){
	$ctrl = igk_getctrl(IGK_NOTIFICATION_CTRL,true);
	if ($name == null)
		return $ctrl;	
	$c =  $ctrl->getNotification($name, true);
	return $c;
}
function igk_notify_sethost($node, $notificationName=null){
	
	igk_notifyctrl()->setNotifyHost($node,$notificationName );
}

function igk_notification_response($name)
{
	$v_notification = igk_notifyctrl()->getNotification($name, false);
	if ($v_notification){		
		$s = $v_notification->Render();
		return $s;
	}
	return null;
}
///<summary>get default web page controller.</summary>
function igk_get_defaultwebpagectrl(){
	$igk = IGKApp::getInstance();	
	return igk_getctrl($igk->Configs->web_pagectrl);
}
///<summary>get the current page controller.</summary>
function igk_get_currentpagectrl(){
	$igk = IGKApp::getInstance();
	$tab = igk_get_default_pagesctrl();
	$page = $igk->getCurrentPage();	
	if ($tab && (count($tab)>0))
		{
			foreach($tab as $k=>$v)
			{
				if (igk_getv($v->Configs,"clDefaultPage") == $page)
				{
					return $v;
				}
			}
		}
	return null;
}
function igk_get_webpagecontent(){
	if (IGKApp::getInstance()->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER)
	{
		return igk_getctrl(IGK_CONF_CTRL)->ConfigNode;
	}
	else{
	 $c = igk_get_defaultwebpagectrl();
	 if ($c)
		return $c->page_content;
	else{
		$igk = IGKApp::getInstance();	
		return $igk->Doc->bodycontent;
	}
	}
	return null;
}
//return t he default config page ctrl
function igk_getconfigwebpagectrl(){
	$igk = IGKApp::getInstance();
	return igk_getctrl(IGK_CONF_CTRL);
}
//sort functions
function igk_key_sort($k, $v)
{
	return strcmp($k,$v);	
}

function igk_array_value_exist($tab , $obj)
{
	foreach($tab as $k=>$v){
		if ($v === $obj)
			return true;
	}
	return false;
}
function igk_array_sortkey(& $tab)
{
	if (!is_array($tab))
		return false;
	$ckey = array_keys($tab);
	igk_usort($ckey, "igk_key_sort");
	$t = array();
	foreach($ckey as $k)
	{
		$t[$k] = $tab[$k];
	}
	$tab = $t;
	return true;
}
function igk_array_first($c)
{
	if (is_array($c) && (igk_count($c)>0))
	{
		return $c[0];
	}
	return null;
}
function igk_array_last($c)
{
	if (is_array($c) && (igk_count($c)>0))
	{
		return $c[igk_count($c)-1];
	}
	return null;
}
function igk_array_copy($c, $from = 0, $to = -1)
{
	$tab = array();
	$t = ($to==-1)?count(c):$to;
	if ($t<= igk_count($c))
	{
		foreach($c as $k=>$v)
		{
			$tab[$k] = $v;
			$t--;
			if ($t<=0)
				break;
		}
	}
	return $tab;
	
}

function igk_array_sort_bykey(& $tab, $key){
	$sorter = new IGKSorter();
	$sorter->key = $key;
	usort($tab, array($sorter, "SortValue"));
}
//used to convert array to values to value=> value
function igk_array_tokeys($d)
{
	$b = array();
	foreach($d as $k=>$v)
	{
		$b[$v] = $v;
	}
	return $b;
}
function igk_array_object_refkey($d, $key)
{//used in getDataTableInfo () conversion
	$b = array();
	foreach($d as $k=>$v)
	{
		$b[$v->$key] = $v;
	}
	return $b;
}
///<summary>used to get array of toggled value . keys=>keys </summary>
function igk_array_key_value_toggle($d){
	
	$b = array();
	foreach($d as $k=>$v)
		{	if (isset($b[$v]))continue;
			$b[$v] = $k;
		}
	return $b;
}

function igk_save_config()
{
	IGKAppConfig::getInstance()->saveConfig();	
}

function igk_fileIsNotincluded($file)
{
$tab = get_included_files();
return $tab[0] == $file;
}


function igk_navtobase($path=null)
{
	$s = null;
	
	if ($path==null)
	{
		$s = igk_io_currentRelativePath(IGK_STR_EMPTY,"/");
	}
	else {
		$s = igk_io_currentRelativePath($path,"/");
	}
	
	if (empty($s))
	{
		header("Location: ./");
	}
	else{
		header("Location: ".igk_html_uri($s));
	}
	igk_exit();
}
function igk_navto($uri){
	header("Location: ".$uri);
	igk_exit();
}
//navigate to current uri
function igk_navtocurrent($uri=null)
{
		$page = IGKApp::getInstance()->CurrentPageFolder;
		$t = IGK_STR_EMPTY;	
		if (strtolower($page)!=IGK_HOME_PAGEFOLDER)
		{			
			$t = ($uri)? IGK_STR_EMPTY.($page)."/".$uri : $page;
		}
		else{
			if ($uri !== null)
				$t = $uri;	
		}	
		igk_navtobase($t);
		igk_exit();	
}

function igk_navtobaseuri(){
	$uri = igk_getv (explode("?", igk_getv($_SERVER, "REQUEST_URI")), 0);
	header("Location: ".igk_html_uri($uri));
	igk_exit();
}
function igk_js_load_found_script($doc, $dirname)	
{
	$dirname = IGKIO::GetDir($dirname);
	if (($doc == null) || !is_dir($dirname) || isset(IGKApp::$ScriptFolders[$dirname]) )
	{		
		return;
	}
	$hdir = @opendir($dirname);
	if (!$hdir)
	{
		igk_debug_wln("scripts dirname can not be opened [".$dirname."]");
		return false;
	}
	while($fd = readdir($hdir))
	{
	
		if (($fd==".") || ($fd==".."))
			continue;
			$f = $dirname."/".$fd;
		if (is_dir($f))
		{
			if (($fd == IGK_SCRIPT_FOLDER))
			{
				igk_js_load_script($doc, $f);
			}
			else{
				igk_js_load_found_script($doc, $f);
			}
		}
	}	
	closedir($hdir);
	return true;
}
//load javascript documenet from directory
function igk_js_load_script($doc, $dirname)
{	
	$dirname = IGKIO::GetDir($dirname);
	if (($doc == null) || !is_dir($dirname) || isset(IGKApp::$ScriptFolders[$dirname]) )
	{		
		return;
	}
	if (IGKApp::$ScriptFolders==null)
		IGKApp::$ScriptFolders = array($dirname=>$dirname);
	else
		IGKApp::$ScriptFolders[$dirname] = $dirname;
		
	$hdir = @opendir($dirname);
	if (!$hdir)
	{
		igk_debug_wln("scripts dirname can not be opened [".$dirname."]");
		return false;
	}

	$f = null;
	$fd = null;
	$scriptFolder = array();
	while($fd = readdir($hdir))
	{
	
		if (($fd==".") || ($fd==".."))
			continue;
			
		$f = $dirname."/".$fd;
		if (is_dir($f)){
			$scriptFolder[] = $f;
			
		}
		else {
			if (IGKString::EndWith($f,".js"))
			{
				//add script with full path
				$doc->addScript(realpath($f));
			}
		}
	}
	foreach($scriptFolder as $f)
	{
		igk_js_load_script($doc, $f);
	}
	closedir($hdir);
	return true;
}

function igk_js_bind_script_folder($folder)
{
	$folder = IGKIO::GetDir($folder);
	if (!is_dir($folder))
		return;
	$tab = IGKApp::$ScriptFolders;
	if ($tab == null)
		$tab = array();
	if (!isset($tab[$folder]))
		$tab[$folder] =$folder;
	IGKApp::$ScriptFolders = $tab;
}
function igk_getctrls(){
	return IGKApp::getInstance()->getControllerManager()->getControllers();
}
//controller function
function igk_getctrl($ctrlname, $throwex = false)
{
	if (!IGKApp::IsInit())
		return null;
	if (is_string($ctrlname))
	{
		$cc = IGKApp::getInstance()->getControllerManager();			
		if ($cc==null)
			return null;			
		$v = $cc->$ctrlname;
		if ($throwex && ($v==null))
		 {
			throw new Exception("controller [".$ctrlname."] not found");
		 }
		return $v;	
	}
	else{
		if (is_object($ctrlname) && igk_is_ctrl($ctrlname))
		{
			return $ctrlname;
		}
	}
	return null;
}

function igk_getregctrl($name){
	if (IGKApp::IsInit())
		return null;
	return IGKApp::getInstance()->getControllerManager()->getRegCtrl($name);
}

function igk_ctrl_isactive($ctrlname){//get non active controller from "Data/igk_nonactive.csv";
	return true;
}

///<summary>call View function of this controller. if this controller is not a child or call the parent view</summary>
function igk_ctrl_viewparent($ctrl)
{
	if ($ctrl->Configs->clParentCtrl && ($p = igk_getctrl($ctrl->Configs->clParentCtrl ))){
		igk_ctrl_viewparent($p);
	}
	else{
		$ctrl->View();
	}
}
///<summary></summary>
function igk_ctrl_view($ctrl, $targetnode, $requestedview='default'){
	if ($ctrl==null)return;
	
	$bck = $ctrl->getCurrentView();	
	$newnode =  IGKHtmlItem::CreateWebNode("div");	
	$ctrl->setCurrentView($requestedview, true, null);
	$targetnode->Load($ctrl->TargetNode->Render());
	$ctrl->setCurrentView($bck, false);	
}

function igk_is_ctrl($ctrl)
{
	if (igk_reflection_class_extends(get_class($ctrl), IGK_CTRLBASECLASS))
	{
	return true;
	}
	return false;
}
//-------------------------
// init igk environement
//-------------------------
function igk_initenv($dirname){
	IGKApp::$BASEDIR = $dirname;
	
	$confFILE = $dirname."/Data/configure"; //configure file	
	$Rfile = $dirname."/R/R.class.php"; //resources class 
	
	if (file_exists($confFILE))
	{
		if (file_exists($Rfile))
			include_once($Rfile);
			
		if (!IGKApp::LoadCacheLibFiles(null))
		{	
			$t_files = igk_loadcontroller($dirname."/Inc");
			$t_c = igk_loadcontroller($dirname."/Mods");
			$t_files = ($t_c==null)? $t_files :  array_merge($t_files, $t_c);		
			igk_reglib($t_files);
			IGKApp::CacheLibFiles(true);			
		}
		return;
	}

	$hdir = null;
	if (is_dir($dirname))	
		$hdir = opendir($dirname);
	if (!$hdir)
		return;	
	$v_access = $dirname."/.htaccess";
	$access = "deny from all";//default htacess
	$old = umask(0);	
	IGKIO::CreateDir($dirname."/Configs");	
	//----------------------------------------------------------------------------------------------
	//create and init framework environment
	//----------------------------------------------------------------------------------------------
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Configs/index.php",igk_get_configIndex(), true);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Configs/.htaccess",igk_getconfig-access(), true);
	//write default access
	IGKIO::WriteToFileAsUtf8WBOM($v_access, igk_getbase_access(), true);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Lib/.htaccess", $access, true);
	IGKIO::CreateDir($dirname."/R");
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/.htaccess", "allow from localhost",true);
	IGKIO::CreateDir($dirname."/R/Img"); //folder that will contain image folder
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/.htaccess", "allow from all",true);
	IGKIO::CreateDir($dirname."/R/Layouts");//folder that will contain layout
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/.htaccess", "allow from all",true);
	IGKIO::CreateDir($dirname."/R/Styles"); //folder that will contain primary styles
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/.htaccess", "allow from all",true);
	
	IGKIO::CreateDir($dirname."/R/Fonts"); //folders that will contain fonts	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Fonts/.htaccess", "allow from all", false); //folders that will contain fonts	
	
	
	IGKIO::CreateDir($dirname."/R/Videos"); //folders that will contain fonts
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/ie.css", "@import url(\"base.css\");", true);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/mod.css", "@import url(\"base.css\");", true);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/base.css", igk_css_getdefaultstyle(), true);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/base.php", igk_get_basestyle(), true);
	
	IGKIO::CreateDir($dirname."/R/Themes");
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Themes/default.phtml", IGKIO::ReadAllText(igk_io_syspath(IGK_DEFAULT_THEME_FOLDER."/default.themes")), true);
	
	//create mod folder	
	IGKIO::CreateDir($dirname."/".IGK_MODS_FOLDER, 0777);	
	IGKIO::CreateDir($dirname."/".IGK_PLUGINS_FOLDER, 0777);	
	IGKIO::CreateDir($dirname."/".IGK_PAGE_FOLDER, 0722);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_PAGE_FOLDER."/.htaccess", $access,true);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Mods/.htaccess", $access,true);
	IGKIO::CreateDir($dirname."/Data");
	IGKIO::CreateDir($dirname."/Data/Lang");
	//copy file to 
	//IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/Lang/lang.fr.resources", IGKIO::ReadAllText(dirname(__FILE__)."/Default/Lang/lang.fr.resources"), true);
	
	//init default data. by copying data to output folder
	
	IGKIO::CopyFiles(dirname(__FILE__)."/Default/Data",	$dirname."/Data", true);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/.htaccess", $access,false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_CONF_DATA, igk_get_defaultconfigData(),false);
	IGKIO::CreateDir($dirname."/".IGK_SCRIPT_FOLDER);
	IGKIO::CreateDir($dirname."/Inc");
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Inc/.htaccess", "deny from all");
	//caches folder
	IGKIO::CreateDir($dirname."/".IGK_CACHE_FOLDER);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_CACHE_FOLDER."/.htaccess", "deny from all");
	
	
	igk_loadcontroller($dirname."/Inc");	
	igk_loadcontroller($dirname."/Mods");	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Mods/.htaccess", "deny from all");
	
	IGKIO::WriteToFileAsUtf8WBOM($confFILE,"1", false);
	//require db configuration	
	closedir($hdir);	
	umask($old);
}
function igk_getconfig_access(){
$root_dir = igk_io_rootBaseDir();
$error_404 = "\"".$root_dir."/Lib/igk/igk_redirection.php?code=404\"";
	$out =<<<EIO
SetEnv PHP_VER 5_3
Options -Indexes
ErrorDocument 404 {$error_404}

#no mod rewrite
<IfModule rewrite_module>
RewriteEngine Off
</IfModule>
EIO;

return $out;
}
function igk_getbase_access()
{
$root_dir = igk_io_rootBaseDir();
$error_404 = "\"".$root_dir."/Lib/igk/igk_redirection.php?code=404\"";
$error_901 = "\"".$root_dir."/Lib/igk/igk_redirection.php?code=901\"";
	$out = <<<EOF
#rootdir {$root_dir}
SetEnv PHP_VER 5_3
Options -Indexes
ErrorDocument 404 {$error_404}

# Use UTF-8 encoding for anything served as text/plain or text/html
AddDefaultCharset utf-8
<IfModule mod_mime.c>
    # Force UTF-8 for certain file types
    AddCharset utf-8 .css .js .json .vtt .nex .webapp .xml
</IfModule>

#if web server support RewriteEngine the redirect file to igk_redirection.php?code=901. this code will support
#post value redirection
<IfModule rewrite_module>
RewriteEngine On
RewriteCond "%{REQUEST_FILENAME}" !-f
RewriteRule ^(/)?(.+)(/)?$  {$error_901} [QSA,L]
</IfModule>
EOF;
return $out;

}

//-------------------------------------------------------
///retrieve base.css file
//--------------------------------------------------------


function igk_css_getbgcl($v)
{
	if (empty($v))
		return null;
	return "background-color: ".$v.";";
}
function igk_css_getbordercl($v){
	if (empty($v))
		return null;
	return "border-color: ".$v.";";
}
function igk_css_getfcl($v)
{
	if (empty($v))
		return null;
	$theme = IGKApp::getInstance()->Doc->Theme;
	$h = igk_css_treat($theme, $v);
	if ($h){
		return "color: ".$h.";";
	}
	else{
		return "color: ".$v.";";
	}
}
function igk_css_getfont($v)
{
	if (empty($v))
		return null;
	return "font-family: \"".$v."\";";
}
/*


<return> the value of the key if found in the current theme</return>
*/
function igk_css_get_cl($key){
	$theme = IGKApp::getInstance()->Doc->SysTheme;
	return igk_getv($theme->cl, $key);
}
//return all style definition
function igk_css_getbasedef($minfile=false, $themeexport=false)
{
$igk = IGKApp::getInstance();
$theme = $igk->Doc->Theme;
$el = $minfile ? IGK_STR_EMPTY: "\n";
$o = IGK_STR_EMPTY;
$o .= "/* IGKDEV-WebFramework ( BALAFON ) GLOBAL APP APP THEME */".$el;
$o .= $igk->Doc->SysTheme->get_css_def($minfile,$themeexport) .$el;

//-------------------------------------------------------------------
// BASE SCRIPT FILE
//-------------------------------------------------------------------
$f = IGKIO::GetDir(dirname(__FILE__)."/Styles/base.pcss");
if (file_exists($f)){
	igkOb::Start();
	include($f);
	$o.= igk_css_treat($igk->Doc->SysTheme, igkOb::Content()).$el;
	igkOb::Clear();
	$o .= "/* CUSTOM THEME FROM  {$f} */\n";
	$o .= $theme->get_css_def($minfile,$themeexport);
}

//eval script files
foreach($theme->Files as $k=>$v){
	$f = $v;
	if (file_exists($f)){
		igkOb::Start();
		include($f);
		$o.= igk_css_treat($igk->Doc->SysTheme, igkOb::Content()).$el;
		igkOb::Clear();
		$o .= "/* CUSTOM THEME FROM  {$f} */".$el;
		$o .= $theme->get_css_def($minfile,$themeexport);
	}
}

$c = igk_getctrl(IGK_THEME_CTRL);
if ($c)
{
	$h = $c->themeGetCss();
	if ($h)
	{
		$o .= "/* APPICATION THEME STYLES */".$el;
		$o .= $h;
	}
	else{
		$o .= "/* THEME FOR IGK_THEME_CTRL->themeGetCss() is empty */".$el;
	}
}
else{
	$o .= "/* NO THEME CTRL */";
}
return $o;
}


function igk_get_basestyle()
{
$v = <<<EOF
<?php
define("IGK_FORCSS", 1);
define("IGK_NO_WEB", 1);
include("../../index.php");
header('content-type: text/css');

\$f = igk_io_currentRelativePath("Caches/cssstyle.cache");
\$t = IGKApp::getInstance()->Configs->UseCssCache;
if (\$t && file_exists(\$f))
{
	\$o = IGKIO::ReadAllText(\$f);
}
else{
	\$o = igk_css_getbasedef();
	if (\$t){
		IGKIO::WriteToFile(\$f, \$o);
	}	
}
igk_wl(\$o);
igk_exit();
?>
EOF;
return $v;
}

function igk_css_getdefaultstyle()
{
	$v = <<<ETF
*{ margin : 0px; padding: 0px; }
ETF;
return $v;
}
function igk_get_configIndex()
{
$cfavicon= "Lib/igk/Default/R/Img/cfavicon.ico";
$v = <<<ETF
<?php
require_once(dirname(__FILE__)."/../index.php");
\$igk = IGKApp::getInstance();
if (\$igk){
\$doc = \$igk->Doc;
\$doc->Title = R::gets("title.igkwebconfig");
\$doc->Favicon = new IGKHtmlRelativeUriValueAttribute("$cfavicon");
igk_wl( \$doc->Render());
}
?>
ETF;
return $v;
}


function igk_get_defaultconfigData()
{
$v = <<<EOF
admin_login,admin
admin_pwd,21232f297a57a5a743894a0e4a801fc3
app_default_controller_tag_name,div
show_powered,1
show_debug,0
menu_defaultPage,default
allow_article_config,0
allow_auto_cache_page,0
cache_loaded_file,0
website_domain,igkdev.be
website_title, igkdev.be
mail_server,relay.skynet.be
mail_port,25
mail_admin,contact@igkdev.be
mail_contact,contact@igkdev.be
db_server,localhost
db_user,igkdev
db_name,igkdev
web_pagectrl,defaultpagectrl
db_pwd,test
meta_description,default page description
meta_copyright,igkdev@copyright.com
meta_enctype,text/html; charset=utf-8
meta_keysword,"igkdev, .NET Developper"
meta_title, igkdev.be
website_prefix, igk
EOF;
return $v;
}

function igk_setheader($status=200, $info=null ){
	header("Status: ".$status);
	header("IGKDEV-WFM: BALAFON ".IGK_VERSION);	
	if ($info){
		header($info);
	}
}
function igk_reglib_once($file)
{
	$f = realpath($file);
	
	if (!empty($f) && file_exists($f))
	{	
		require_once($f);
		igk_reglib(array($f=>$f));
	}
}
function igk_reglib($files)
{
	if (($files==null)  || (igk_count($files)==0))
		return;
	if (IGKApp::$LibFiles == null)
		IGKApp::$LibFiles = array();
	
	foreach($files as $k=>$v)
	{
		if (!isset(IGKApp::$LibFiles[$v]))
			IGKApp::$LibFiles[$v] = $v;
	}
}
function igk_loadlib($dir, $ext="php")
{
	$hdir = @opendir($dir);
	if (!$hdir)return;
	
	$file = IGK_STR_EMPTY;
	$dirs = array();
	$files = array();
	while($fdir = readdir($hdir))
	{
		if (($fdir == ".") || ($fdir==".."))
			continue;
		$file  = $dir.DIRECTORY_SEPARATOR.$fdir;
		
		if (is_dir($file)){
			$dirs[] = $file;
		}
		else {
			if (strstr($file, ".phtml") || !IGKString::EndWith($file,$ext))
				continue;						
			include_once($file);			
			$files[] = igk_html_uri($file);
		}
	}	
	closedir($hdir);
	if (count($dirs>0))
	{
		//order table 
		sort($dirs);
		foreach($dirs as $k)
		{
			$t = igk_loadlib($k, $ext);
			$files = array_merge($files, $t);
		}
	}	
	return $files;
}

//--------------------------------------------------------------------------------------------------------
// AGENT FUNCTIONS
//--------------------------------------------------------------------------------------------------------

//get if client user agent is microsoft internet explorer
function igk_agent_isIE(){
	return IGKUserAgent::IsIE();
}
function igk_agent_ieVersion()
{
	if (igk_agent_isIE())
	{
		$tab = array();
		preg_match_all("/MSIE\s*(?P<version>[0-9\.]+)/i", $_SERVER["HTTP_USER_AGENT"], $tab);
		return $tab["version"][0];
	}
	return null;
}
function igk_agent_isAndroid(){//get if the gent is an android device
	return IGKUserAgent::IsAndroid();
}
function igk_agent_androidVersion(){//get the android device version
	return IGKUserAgent::GetAndroidVersion();
}



//--------------------------------------------------------------------------------------------------------
// GLOBAL VARIABLE
//--------------------------------------------------------------------------------------------------------

//defining system variable
$igk_App =null; //

//--------------------------------------------------------------------------------------------------------
// INTERFACES
//--------------------------------------------------------------------------------------------------------

interface IIGKFrameController
{
	function ContainFrame($id,$frame, $remove=true);
}

interface IIGKDataTable{//basic interface

}
interface IIGKSystemUser
{
	function getLogin();	
}
interface IIGKConfigController
{
	function showConfig();
}
interface IIGKWebController extends IIGKController
{
	//return an array of childs controller 
	function getChilds(); //get childs		
	function regChildController($ctrl);//reg child controller
	function unregChildController($ctrl);//unreg child controller
}
interface IIGKWebPageController extends IIGKWebController
{

	function manageErrorUriRequest($uri);//manage error request	
	function getpage_content(); //get page content
	function getheader_content();//get header content
	function getfooter_content();//get footer content
	function getmenu_content();//get menu base container
	
	
	function getheaderNode();
	function getbodyNode();
	function getfooterNode();
	
	function loadWebTheme($file);//load web structure
}
interface IIGKWebPageChildCtrontroller{
	function getWebParentCtrl();
	
}
interface IIGKWebAdministrativeCtrl
{
	function getConfigNode();	
}

//--------------------------------------------------------------------
// R Class clas 
//--------------------------------------------------------------------
final class R extends IGKObject
{
	
	var $m_lang;
	var $langRes;
	var $LangChangedEvent;//used to inform that keys changed. or updated
	var $KeysAdded;	
	var $PageLangChangedEvent;
	
	static $sm_instance;
	static $sm_keyVAR;	
	
	private $m_langChangedDate;
	
	/// get the current language file
	public function GetCurrentLangPath(){	
		return dirname(__FILE__)."/Default/Lang/lang.".$this->m_lang.".resources";
	}
	public static function getInstance(){ 
			if (self::$sm_instance === null)
			{
				if (isset($_SESSION["R"] )){
					self::$sm_instance = $_SESSION["R"];
				}
				else{
					self::$sm_instance = new R();
					$_SESSION["R"]= self::$sm_instance;
					self::LoadLang();
				}
			}
			return self::$sm_instance;
	}
	private function __construct()
	{
			$this->m_lang = "fr";
			$this->LangChangedEvent = new IGKEvents($this, "LangChangedEvent");
			$this->PageLangChangedEvent = new IGKEvents($this, "PageLangChangedEvent");
			$this->KeysAdded = new IGKEvents($this,"KeysAdded");
	}
	public  static function LoadLang()
	{			
		$v = self::getInstance();
		//Clear lang
		$v->langRes = array();;
		$f = $v->GetCurrentLangPath();
		if (!file_exists($f))
		{		
			//get system default file
			$f = $v->GetCurrentLangPath();
		}
		if (file_exists($f))
		{
			include($f);							
		}
		else{
			igk_debug_wln("language file not found");
		}
	}
	public static function LoadLangFiles($file){
		if (file_exists($file)){
			include($file);
		}
	}
	public static function AddLang($key, $value){	
		if (!empty($key))
			self::getInstance()->langRes[strtolower(trim($key))]=$value;
	}
	protected function OnKeyAdded($key)
	{//raise event
		$this->KeysAdded->Call($this, $key);
	}
	protected function OnLangChangedEvent($key)
	{
		if ($this->LangChangedEvent !=null)
			$this->LangChangedEvent->Call($this, null);
	}
	///<summary>get string expression </summary>
	public static function gets($key)
	{
		$i = self::getInstance();
		
			$key = strtolower($key);
			if (isset($i->langRes[$key]))
			{
			    $s = $i->langRes[$key];
				$match = array();
				$c = 0;			
				//get include key in string  exemple : title.error ==> the [info] error
				// [info] will be replaced by its real value if found in keys
				$c = preg_match_all("/\[(?P<value>[a-zA-Z0-9_\.]+)\]/i",$s, $match);
				if ($c > 0)
				{
					for($i = 0; $i < $c ; $i++)
					{
					
						$ckey = $match["value"][$i];
						if (strtolower($ckey) == strtolower($key))
							continue;
						
						$s = str_replace( $match[0][$i],R::gets($ckey),$s);
						
					}		
				}		
			
				return $s;
			}
			else{
				if (!empty($key))
				{
					$i->langRes[$key] = $key;
					$i->OnKeyAdded($key);
				}
			}
			return $key;
	}
	
	public static function ngets($key)
	{
		if ($key==null)
			return null;
		if (!is_string($key))
		{
			//throw new Exception("not a valid keys");
			return $key;
		}
		if (self::$sm_keyVAR == null)
			self::$sm_keyVAR = array();
		$T = strtolower($key);
		$default = self::gets($key);
		$args = array();
		if (func_num_args() > 1)
		{
			$t = func_get_args();
			for($i=1; $i< count($t) ; $i++)
			{
				$args[] = $t[$i];
			}		
			return new IGKLangKey($key, $default, $args);					
		}
		else{
			if (isset(self::$sm_keyVAR[$T]))
			{
				return self::$sm_keyVAR[$T];
			}
			else{
				self::$sm_keyVAR[$T] = new IGKLangKey($key, $default, $args);			
				return self::$sm_keyVAR[$T];
			}
		}
		/*if (isset(self::$sm_keyVAR[$T]))
		{
			return self::$sm_keyVAR[$T];
		}
		//register
		$default = self::gets($key);
		$args = array();
		if (func_num_args() > 1)
		{
			$t = func_get_args();
			for($i=1; $i< count($t) ; $i++)
			{
				$args[] = $t[$i];
			}
		}
		self::$sm_keyVAR[$T] = new IGKLangKey($key, $default, $args);			
		return self::$sm_keyVAR[$T];*/
	}
	public static function ChangeLang($lang = "fr"){
		$v = self::getInstance();
		
		if ($lang=="Img")
			throw new Exception("change lang changed by unknown");
		if ($v->m_lang != $lang)
		{
			$v->m_lang = $lang;
			self::LoadLang();
			$v->onPageLangChangedEvent();
		}		
	}	
	public function onPageLangChangedEvent()
	{
		if ($this->PageLangChangedEvent !=null)
			$this->PageLangChangedEvent->Call($this,null);
	}
	public static function GetLangInfo(){
		return self::getInstance()->langRes;	
	}

	public static function SaveLang()
	{	
		$v = self::getInstance();		
		$out = "<?php 
";	
		$tab = $v->langRes;
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		foreach($ktab as $k)
		{
			$v = $tab[$k];
			$v = str_replace("\'", "'", str_replace("\"", "&quot;",$v));
			if (!empty($k))
				$out .= "R::AddLang(\"$k\", \"".$v."\");\n " ;
		}
		$out .= "?>";
		$v = self::getInstance();
		$file = $v->GetCurrentLangPath();

		if (IGKIO::WriteToFileAsUtf8WBOM($file, $out, true))
		{
			//reload lang files
			self::LoadLang();			
			igk_sys_regchange("LangChanged", $v->m_langChangedDate);
			$v->OnLangChangedEvent(null);	
			return true;
		}
		else{
			igk_notify_error("can't save lang file");
		}
		return false;
	}
	//
	//get the current lang
	//
	public static function GetCurrentLang(){
		$v = self::getInstance();
		return $v->m_lang;
	}
	public static function GetImgUri($name)
	{
		$v = igk_getctrl(IGK_PIC_RES_CTRL);
		if ($v)
		{
			return $v->getImgUri($name);		
		}
		return IGK_STR_EMPTY;
	}
	
	public static function GetImgResUri($name)
	{
		$v = igk_getctrl(IGK_PIC_RES_CTRL);
		if ($v)
		{
			return $v->getImgUri($name, true);		
		}
		return IGK_STR_EMPTY;
	}
	
	public static function RemoveKey($name){
		$name = strtolower($name);
		$v = self::getInstance();
		if(isset($v->langRes[$name]))
		{
			unset($v->langRes[$name]);
			return true;
		}
		return false;
	}
	public static function ClearLang(){
		$v = self::getInstance();		
		$v->langRes = array();
		self::SaveLang(null);
	}
}


//--------------------------------------------------------------------------------------------------------
//DATA DESCRIPTION
//--------------------------------------------------------------------------------------------------------
final class Vector2f extends IGKObject
{
	private $m_x;
	private $m_y;
	
	public function getX(){return $this->m_x;}
	public function getY(){return $this->m_y;}
	
	public function setX($value){ $this->m_x = $value;}
	public function setY($value){ $this->m_y = $value;}
	
	public function __construct($x=0,$y=0)
	{
		$this->m_x = $x;
		$this->m_y = $y;
	}
	public function __toString(){
		return "Vector2f [x:".$this->X." y:".$this->Y."]";
	}
	public static function FromString($data){		
		$b = explode(";", $data);
		list($X,$Y) = count($b) == 2? $b : array($data,$data);
		return new Vector2f($X,$Y);
	}
}

final class IGKRectanglef extends IGKObject
{
	private $m_x;
	private $m_y;
	private $m_w;
	private $m_h;
	
	public function getX(){return $this->m_x;}
	public function getY(){return $this->m_y;}
	
	public function setX($value){ $this->m_x = $value;}
	public function setY($value){ $this->m_y = $value;}
		
	public function getWidth(){return $this->m_w;}
	public function getHeight(){return $this->m_h;}
	
	public function setWidth($value){ $this->m_w = $value;}
	public function setHeight($value){ $this->m_h = $value;}
	
	
	public function __construct($x=0,$y=0, $width=0, $height=0 )
	{
		$this->m_x = $x;
		$this->m_y = $y;
		$this->m_w = $width;
		$this->m_h = $height;
	}
	public function __toString(){
		return "IGKRectanglef [x:".$this->X." y:".$this->Y."; width: ".$this->Width." ;height: ".$this->Height."]";
	}
}

///<summary>represent the core json string convertor</summary>
final class IGKCoreJSon extends IGKObject
{
	const ExpressionRegex = "\\{(?<expression>(.)+)\\}";
	
	public function ToDictionary($expression){
		$t = array();
		$m = array();
		$c = preg_match_all("/".self::ExpressionRegex."/i", $expression, $m);
		$v_data = array();
		for($j = 0; $j < $c ; $j++)
		{
				$s = $m["expression"][$j];	
				
				$s = preg_replace_callback("/:\s*\[(?<value>([^\]])+)\]/i", function($tmatch) use (&$v_data){
						$data = "@data". count($v_data);						
                        $v_data[$data] =  $tmatch["value"];
                        return ":".$data;
				}, $s);

				
                // $s = Regex.Replace(s, @":\s*\[(?<value>([^\]])+)\]", (tmatch)=>{ 
                        // string data = "@data"+ v_data.Count ;
                        // v_data.Add($data, tmatch.Groups["value"].Value);
                        // return ":"+$data;
                // });
				
				
                $tab = igk_str_explode(array( ',', '=', ':' ),  $s);
				
				
                for ($i = 0; $i < count($tab); $i += 2)
                {
                    $n = trim($tab[$i]);
					
                    $v = trim($tab[$i + 1]);
                    if (isset($v_data[$v]))
                    {
                        //data is array
                        $t[$n] = explode(',',$v_data[$v]);
                    }
                    else
                    {
                        $t[$n] = $v;
                    }
                }
			
            }
            
		return $t;
	}
}

//--------------------------------------------------------------------------------------------------------
//igk Application class
//--------------------------------------------------------------------------------------------------------
final class IGKApp extends IGKObject
{
	public static $BASEDIR;//base directory
	public static $DEBUG;//for debuging purpose
	public static $LibFiles;
	public static $ScriptFolders; //represent script folder
	public static $controllerdir;
	
	public $InitEvent;				//init event
	private $m_CurrentPageFolderEvent;		//current page event
	private $m_DocCreatedEvent; //event raised when a new web document is created on the system. used to initalize a document
	
	private static $sm_instance;	
	private $m_Doc; //html document	
	private $m_Validator; //get html the validator object
	
	private $m_ControllerManager; //controller manager objects
	private $m_firstUse; //is first used
	private $m_invokedUriController ; //invoked uri controller
	private $m_selectedController ; //selected controller
	//private $m_cPage ;
	private $m_autorisations;
	private $m_session; //igk session parameters.
	private $sm_isInit;
	private $sm_isConfig;
	private $m_configMenuConf; //configuration menu array
	
	private $m_queryError;
	private $m_queryErrorUri;	
	private $m_pageFolderInitMethod;
	
	private $m_ViewMode;
	
	public function OnNewDocumentCreated($doc)
	{
		if ($this->m_DocCreatedEvent!=null)
			$this->m_DocCreatedEvent->Call($this, $doc);
	}
	public function addNewDocumentCreatedEvent($target, $func){
		$this->m_DocCreatedEvent->add($target, $func);
	}
	public function RemoveDocumentCreatedEvent($taget, $func)
	{
		$this->m_DocCreatedEvent->remove($target, $func);
	}

	public function getConfigMenuConfiguration()
	{
		return $this->m_configMenuConf;
	}
	
	public static function GetAppDir(){
		global $IGK_APP_DIR;		
		return $IGK_APP_DIR;
	}
	public static function GetLibFolder(){		
		return dirname(__FILE__);
	}
	
	public static function CacheLibFiles($force=false){//cache library files	
		
		$f =  igk_io_baseDir(IGK_FILE_LIB_CACHE);		
		$t = 3600;
		$expire = time()-$t;
		$el = "\n";
		if (!$force && file_exists($f) && (filemtime($f) > $expire))
		{	//no cache
			return;
		}		
		$data  =IGK_STR_EMPTY;
		$dir = dirname(__FILE__);
		$mdir = igk_html_uri(dirname(__FILE__));
		foreach(self::$LibFiles as $k=>$v)
		{
			$o = igk_io_getrelativepath($dir, realpath($v));
			$data .= 'require_once(\''.IGKIO::GetDir(realpath($v)).'\');'.$el;
			// $data .= 'require_once(\''.
			// IGKIO::GetDir(
			// IGKIO::GetRelativePath(dirname(realpath($v)), $dir )."/".basename($v)
			// ).'\');'.$el;
		}		
		
		$out = <<<EOF
<?php
\$bck = getcwd();
chdir(dirname(__FILE__));
\$d = '{$dir}';
chdir(\$d);
{$data}

// \$t_files = igk_loadcontroller(\$dirname."/Inc");
// \$t_c = igk_loadcontroller(\$dirname."/Mods");
// \$t_files = (\$t_c==null)? \$t_files :  array_merge(\$t_files, \$t_c);		
// igk_reglib(\$t_files);	
chdir(\$bck);
unset(\$bck);
?>
EOF;
		
		
		igk_io_save_file_as_utf8($f, $out);
	}
	public static function LoadCacheLibFiles(){
	//load cached files. igk instance not created yet. the only wait to do that 
	//is to check if a cached files exists.
	//if ture then load it otherwise return no cached dir file.		
		$f = igk_io_currentRelativePath(IGK_FILE_LIB_CACHE);	
		$v = false;	
		if (file_exists($f))
		{
			try{
				include($f);
				$v = true;
			}
			catch(Exception $ex){
					igk_wln("can't load files...");
			}
		}
		return $v;
	}
	public static function SetIsInit($value){
		self::getInstance()->sm_isInit = $value;
	}
	public static function IsInit(){
		return self::getInstance()->sm_isInit;
	}
	public static function setConfig($v)
	{
		throw new Exception( __CLASS__."::".__FUNCTION__." is Not Defined Impletement ");
		self::getInstance()->sm_isConfig = $v;
	}
	public function getSelectedController(){return $this->m_SelectedController; }
	public function getInvokedUriController(){return $this->m_invokedUriController; }
	public function getAutorisations(){return $this->m_autorisations;}	
	public function getControllerManager(){return $this->m_ControllerManager;}
	public function setControllerManager($value) {$this->m_ControllerManager = $value;}
	public function getDoc(){return $this->m_Doc;}
	public function getFirstUse(){ return $this->m_firstUse; }
	//used to check if this is in configuration mode
	public function getConfigMode(){ return igk_getv(igk_getctrl(IGK_CONF_CTRL), 'IsConnected'); }
	public function getViewMode(){
		return $this->m_ViewMode;
	}
	function setViewMode($mode){
		if ($mode != $this->m_ViewMode){
			$this->m_ViewMode = $mode;
			//view controller
			$this->ViewControllers();
		}
	}
	public function IsSupportViewMode($view){
		return (($this->getViewMode() & $view) == $view);
	}
	 //get current page folder
	public function getCurrentPageFolder(){
		
		if (IGKIO::GetCurrentDir() == IGKIO::GetBaseDir())
			return IGK_HOME_PAGEFOLDER;
		 else{
			 return IGKIO::GetChildRelativePath(self::$BASEDIR, IGKIO::GetCurrentDir());
		}
	}

	//class::igk system current page return a menu current page
	public function getCurrentPage(){ return igk_getv(igk_getctrl(IGK_MENU_CTRL), 'CurrentPage', 'home'); }
	public function getCurrentPageIndex(){return igk_getv(igk_getctrl(IGK_MENU_CTRL),'CurrentPageIndex', 0); }
	//set the current page
	public function setCurrentPage($value, $index=0)
	{  
		$p = $this->CurrentPage;
		$i = $this->CurrentPageIndex;
		$index = ($index == 0)?igk_getr("pageindex",$index):$index;	
		if (($p != $value) || ($index!= $i )){		
			igk_getctrl(IGK_MENU_CTRL)->setPage($value, $index);		
		}
	}	
	 
	public function addCurrentPageFolderEvent($obj, $method){
		$this->m_CurrentPageFolderEvent->add($obj, $method);
	}
	public function removeCurrentPageFolderEvent($obj, $method){
		$this->m_CurrentPageFolderEvent->remove($obj, $method);
	}
	public function addCurrentPageEvent($obj, $method)
	{
		igk_getctrl(IGK_MENU_CTRL)->addPageChangedEvent($obj, $method);
	}
	public function removeCurrentPageEvent($obj, $method)
	{
		igk_getctrl(IGK_MENU_CTRL)->removePageChangedEvent($obj, $method);
	}
	public function getValidator(){return $this->m_Validator;}
	//is configurating
	public function getIsConfigurating(){return $this->getCurrentPage() == IGK_CONFIG_MODE; }
	public function getConfigs(){return IGKAppConfig::getInstance()->Data; }
	public function getSession(){return $this->m_session;}
	public function getUser(){return $this->getSession()->User; }
	
	
	//reset
	public function reset(){
		$this->m_firstUse = true;
		//$this->m_cPage = null;
		$this->Doc->body->ClearChilds();
	}
	public function __toString(){
		return "igk framework[Version:". IGK_VERSION."]";
	}
	private function __construct(){//init framework app constructr
		//magic function		
		$this->m_ViewMode = IGKViewMode::VISITOR;
	}
	//private to call function
	public function __call($name, $arguments)
	{
		if (function_exists("igk_".$name))
		{			
			return call_user_func_array("igk_".$name, $arguments);
		}
		
	}
	//private function get igk m
	public function __get($name)
	{
		if (function_exists("igk_".$name))
		{		
			return call_user_func_array("igk_".$name, $tb);
		}
		return parent::__get($name);
	}
	public function registerPageFolderChangedMethod($pageFolderName, $array_ctrl_method)
	{
		if ($this->m_pageFolderInitMethod== null)
			$this->m_pageFolderInitMethod = array();
		if (!isset($this->m_pageFolderInitMethod[$pageFolderName]))
		{
			$this->m_pageFolderInitMethod[$pageFolderName] = $array_ctrl_method;
		}
		else 
			igk_debug_wln("method already register". $pageFolderName);
	}
	public function unregisterPageFolderChangedMethod($pageFolderName)
	{
		unset($this->m_pageFolderInitMethod[$pageFolderName]);
	}
	public function onCurrentPageFolderEvent($oldpage)
	{
		//call primary method register
		$f = $this->CurrentPageFolder;	
		if (isset($this->m_pageFolderInitMethod[$f]))
		{
			$t = $this->m_pageFolderInitMethod[$f];			
			$t[0]->Invoke($t[1], array($this));			
		}		
		//call page folder event
		if ($this->m_CurrentPageFolderEvent!=null)
				$this->m_CurrentPageFolderEvent->Call($this, array("currentPage"=>$f, "oldPage"=>$oldpage));	
		
	}
	private static function RegViewPicture()
	{	
		//for getting web resource
		if (igk_getr("c")== IGK_PIC_RES_CTRL)
		{
			if (igk_getr("css")==1)
			{
				$f = igk_getr("f","viewpic");
				if ($f=="viewpic")
				{
					igk_getctrl(IGK_PIC_RES_CTRL)->$f();		
					igk_exit();
				}
			}
		}
		if (igk_getr("vimg", null)!=null)
		{ 
			//priority to image request
			igk_getctrl(IGK_PIC_RES_CTRL)->viewpic(igk_getr("vimg")); 
			igk_exit();
		}
		
	}
	
	public static function setErrorQuery($error, $uri=null)
	{
		IGKApp::getInstance()->m_queryError = $error;
		IGKApp::getInstance()->m_queryErrorUri = $uri;
	}
	public static function Init($file, $raisePageFolderChanged=false)
	{	
		if (defined("IGK_NO_WEB"))
		{
			//no web rendering
			return;
		}	
		//continue for page loading
		$v_igk = self::getInstance();	
		
		if ($v_igk->sm_isInit)
		{
			
			$c = $v_igk->getControllerManager()->InvokeUri();			
			//if CSS DEFINED exit 
			if (defined("IGK_FORCSS"))
				return;	
			$v_igk->maintainPageFolderView(false);
			$v_igk->__init_updateSession(false);
			self::Render($v_igk, $file);
			return;
		}
		
		//continue for page loading
		$v_igk->sm_isInit = true;
		//check if picture demand. if found Init exit
		self::RegViewPicture();
		$v_igk->Session->RedirectionContext = 0;
		$v_spagef = $v_igk->Session->PageFolder;			
		$v_ctrlm = IGKControllerManagerObject::getInstance(); 
		$v_raise = $raisePageFolderChanged; //raise page folder changed
		$v_initFrom1stUse = false;
		$c = null;
		//for single domain operation
		$domain = $v_igk->Session->Domain;
		
		if ($domain !== igk_io_baseUri())
		{	
			if (!empty($domain))
			{
				//change the domain
				session_destroy();
				//Clear session and reconnect
				$v_igk->Session->Domain = igk_io_baseUri();				
				igk_notifyctrl()->addMsgr("Domain changed");
				igk_getctrl(IGK_CONF_CTRL)->reconnect();				
				igk_exit();
			}
			$v_igk->Session->Domain = igk_io_baseUri();			
		}
		//-------------------------------------------------------------
		//init for the first used
		//-------------------------------------------------------------
		if ($v_igk->FirstUse)
		{
			//call initialize event to initialize system
			$v_igk->InitEvent->Call($v_igk, null);			
			//call the user init default page
			if(function_exists("InitDefaultPage"))
			{
				InitDefaultPage($v_igk);
			}
			else{
				$v_igk->__initDefaultPage();
			}	
			//init the default document. init view
			self::__initDocument($v_igk);
			//change the first use
			$v_igk->m_firstUse = false;
			$v_raise  = false; //don't raise the page folder changed event 
			$v_initFrom1stUse = true;
		}			
		
		igk_debug_wln("IGKApp::Init->Invoke uri");
		//initialize event
		$v_igk->Session->initalize($v_igk);
		//TODO: INVOKE URI to update data value 
		$c = $v_igk->getControllerManager()->InvokeUri();
		//if CSS DEFINED exit 
		if (defined("IGK_FORCSS"))
			return;	
	
		//change current page instance
		$v_igk->maintainPageFolderView();
	
	
		//for debugging purspose maintain the lasted invoked controller
		if ($c && ($c  != $v_igk->m_invokedUriController ))
		{
			$v_igk->m_invokedUriController = $c;
		}
		//init system data base 
		if ($v_igk->sm_isConfig){	
			igk_getctrl("igkdbCtrl")->initSDb(false, false);
			$v_igk->sm_isConfig = false;
		}	
		
		///-------------------------------------------------------
		/// MAINTAIN THE CURRENT PAGE VISIBILITY VIEW
		///-------------------------------------------------------		
		if ($v_igk->CurrentPage != igk_web_defaultpage())
		{
			$s = igk_io_baserequestUri();
			if ((empty($s)) && preg_match("/\?p=".$v_igk->CurrentPage."/i", igk_getv($_SERVER, "REQUEST_URI"))==false)
			{
				$uri = igk_io_baseUri()."?p=".$v_igk->CurrentPage;				
				header("Location: ".$uri);
				igk_exit();
			}
		}	
		$v_igk->__init_updateSession($v_raise);	
		//$p = microtime(); // measure render time		
		self::Render($v_igk, $file);
		
	}	
	private function __init_updateSession($v_raise){
		//-------------------------------------------------------
		//update session control value
		//-------------------------------------------------------
		$this->Session->update();
		//igk_wln($_SERVER);
		//	igk_wln("refreshing ...?".igk_getv($_SERVER, "HTTP_CACHE_CONTROL"));
		//-------------------------------------------------------		
		//Render file manager
		//-------------------------------------------------------
		// if (igk_getv($_SERVER, "HTTP_CACHE_CONTROL") == "max-age=0"){//hits refresh 
			// refresh the visible controller
			// if (!$v_raise){
				$this->ViewControllers();
			// }
		// }
	}
	private function maintainPageFolderView($v_initFrom1stUse=true){	
		$v_cpage = $this->CurrentPageFolder;
		$v_opage = $this->Session->PageFolder;
		if ($v_opage != $v_cpage)
		{
			//store current page to setting
			$this->Session->PageFolder = $v_cpage;							
			//raise page folder change only if (page is not home or not on )
			if (!$v_initFrom1stUse || ($v_initFrom1stUse && ($v_cpage != "home")))				
				$this->onCurrentPageFolderEvent($v_opage);						
		}
	}
	/// init default page rendering system
	private function __initDefaultPage()
	{
		$doc = $this->Doc;		
		//define user entry				
		$doc->bodypage = $doc->body->add("div", array("id"=>"bodypage", "class"=>"igk-web-bodypage"));
		
	}
	
	private static function __initDocument($igk){//init document		
		$igk->ViewControllers();		
	}

	private static function Render($v_igk, $file=null){//render document in inclusion
		if (igk_fileIsNotincluded($file))
		{			
			self::RenderDocument();
		}
	}
	public static function RenderDocument(){//force to render document			
			$igk = self::$sm_instance;
			if (!$igk->ConfigMode && $igk->Configs->allow_auto_cache_page)
			{				
				$ctrl = igk_getctrl("cache");
				if ($ctrl)
				{
					$ctrl->loadCache($App->CurrentPage.".html",IGKApp::getInstance());
				}
			}
			else{
				
				$o = $igk->Doc->Render();				
				echo $o;
			}
	}
	//call document view
	public function View(){
		//do nothing
	}
	public function getTargetNode(){
		return $this->Doc;
	}
	var $createAt;
	///<summary>get the igk instance value</summary>
	public static function getInstance(){ //instance of this igk
		if (self::$sm_instance === null)
		{
			if (isset($_SESSION["igk"]))
			{
				self::$sm_instance = $_SESSION["igk"];
			}
			else {
				$t =date("y-m-d h:i:s");
				self::$sm_instance = new IGKApp();
				self::$sm_instance->createAt  = $t;
				$_SESSION["igk"] = self::$sm_instance;
				$_SESSION["igk-createat"] = $t;
				self::$sm_instance->_load();
			}
		}
		return self::$sm_instance;
	}

	private function _load()
	{
	
		$this->m_autorisations = new IGKAutorisation($this);
		$this->m_session = new IGKSession($this);
		$this->InitEvent = new IGKEvents($this,"InitEvent");
		$this->m_CurrentPageFolderEvent = new IGKEvents($this,"CurrentPageEvent");
		$this->m_DocCreatedEvent = new IGKEvents($this,"DocCreatedEvent");
		//create web document
		$this->m_Doc = new IGKHtmlDoc($this);
		$this->m_Doc->setup_document();
		
		$this->m_Validator = new IGKHtmlValidatorItem();		
		$t = $this->m_Doc->addStyle("R/Styles/base.php");

		
		//load all javascript from the basedir script folder
		
		IGKApp::$ScriptFolders = null;
	    igk_js_load_script($this->m_Doc, IGKIO::GetDir(dirname(__FILE__)."/".IGK_SCRIPT_FOLDER));		
		igk_js_load_script($this->m_Doc, IGKIO::GetDir(IGKApp::$BASEDIR."/".IGK_SCRIPT_FOLDER));
		//load script from dir
		igk_js_load_found_script($this->m_Doc, IGKIO::GetDir(dirname(__FILE__)."/Ext"));
		
		
		
		$this->m_configMenuConf = $this->__loadConfigMenu();// app data load config Menu
		$this->m_Doc->addScript(IGKApp::$BASEDIR."/Lib/tiny_mce/tiny_mce.js", false);
		$this->m_firstUse = true;
	}
	
	private function storeDBConfigsSettingMenu()
	{
		$tab = $this->m_configMenuConf;
		$f = dirname(__FILE__)."/Data/config.menu.xml";
		if (file_exists($f))
		{
			$d =  IGKHtmlItem::CreateWebNode("configmenu");
			foreach($tab as $k=>$v)
			{
				$s = $d->add($k);
				
				foreach($v as $c=>$cm)
				{
					$s->add($c)->Content = $cm;
				}
			}		
			igk_io_save_file_as_utf8($f, $out, true);	
		}		
		
	}
	private function __loadConfigMenu()
	{
		$tab = array();		
		$f = dirname(__FILE__)."/Data/config.menu.xml";
		if (file_exists($f))
		{
			$d =  IGKHtmlItem::CreateWebNode("div");
			$d->Load(file_get_contents($f));
			$e = igk_getv($d->getElementsByTagName("configmenu"), 0);
			$t = null;
			foreach($e->Childs as $k=>$v)
			{
				$s = array();
				foreach($v->Childs as $c=>$m)
				{
					$s[$m->TagName] = $m->innerHTML;
				}
				$tab[$v->TagName] = (object)$s;
			}		
		}		
		return (object)$tab;
	}
	
	public function ViewControllers(){
		IGKControllerManagerObject::getInstance()->ViewControllers();
	}

	public static function NavigateTo($url){
		header("Location: ".$url);
		igk_exit();
	}
	
}



final class IGKViewMode extends IGKObject
{
	 const VISITOR = 1;
	 const WEBMASTER = 2;
	 const ADMINISTRATOR=6;
	
	public static function GetSystemViewMode(){
		$m = IGKApp::getInstance()->getViewMode();
		$t = array();
		foreach(igk_get_class_constants(__CLASS__) as $k=>$v)
		{
			if (($m & $v) == $v)
				$t[] = $k;
		}	
		return IGKString::Join($t, ',', false);
	}
}

class IGKUserInfo extends IGKObject
{
	var $authtable ;
	var $grouptable;
	var $groupauthtable ;
	var $usertable;
	var $usergrouptable;
	
	var $clId;
	var $clLogin;
	var $clPwd;
	
	public function __construct(){
	}
	public function IsAuthorize($authname){
	
		$s = $this;
		 if ($s == null)
                return false;
            if (igk_getv($s,"clLevel", 0) == -1)
                return true;//administrator have all access
            
            $r = igk_db_table_select_where($s->authtable, array("clName"=>$authname ));
            
            $v_r = true;
            if ($r && ($r->RowCount == 1))
            {
                //get autorisation id
                $v_authid = $r->getRowAtIndex(0)->clId;
                //find group that user is member of
                $v_usergroup = igk_db_table_select_where($s->usergrouptable, array("clUserId"=>$s->clId));
                if ($v_usergroup)
				{
					foreach ($v_usergroup->Rows as $item)
					{
						
						$q = igk_db_table_select_where($s->groupauthtable, array ("clGroupId"=>$item->clGroupId,
										   "clAuthId"=>$v_authid));

						//igk_wln("check for ".$item->clGroupId .";".$v_authid. ":::".$q->RowCount);
						if ($q && ($q->RowCount == 1))
						{	
							igk_show_prev($q->getRowAtIndex(0));
							$v_r = $v_r && ($q->getRowAtIndex(0)->clGrant == 1);
							if (!$v_r)
								break;
						}
					}
				}
                return $v_r;
            }
            else
            {
				igk_db_insert(IGK_MYSQL_DATAADAPTER, $s->authtable, array("clName"=>$authname));
            }
		return false;
	}
	public function loadData($userTableData)
	{
		foreach($userTableData as $k=>$v){
			$this->$k  = $v;
		}
	}
	public function toString(){
		return get_class($this);
	}
	public function __set($name, $value){//set user user info	
		if (!$this->_setIn($name, $value))
			$this->$name = $value;
	}
	public function __get($name)
	{
		return parent::__get($name);
	}
	
	public function getGroups(){
		if ($this->clId){
			$tab = array();
			$db = igk_db_table_select_where($this->usergrouptable, array("clUserId"=>$this->clId));
			foreach($db->Rows as $k=>$v){
				$rdb = igk_db_table_select_where($this->grouptable, array("clId"=>$v->clGroupId))->getRowAtIndex(0);
				if ($rdb){
					$tab[$rdb->clName] = $rdb;
				}
			}
			return $tab;
		}
		return null;
	}
	///get all available authorisation for this user
	public function getAuths(){
		if ($this->clId){
			$tab = array();
			//get all groups that match user
			$db = igk_db_table_select_where($this->usergrouptable, array("clUserId"=>$this->clId));
			foreach($db->Rows as $k=>$v){
			
				$rdb = igk_db_table_select_where($this->groupauthtable, array("clGroupId"=>$v->clGroupId));					
				if ($rdb){
					foreach($rdb->Rows as $a=>$b){						
						if (!isset($tab[$b->clAuthId]))
						{
							$authinfo = igk_db_table_select_row($this->authtable, array("clId"=>$b->clAuthId));
							$authinfo->clGrant = $b->clGrant;
							
							$tab[$b->clAuthId] = $authinfo;
						}
						else 
							$tab[$b->clAuthId]->clGrant = $tab[$b->clAuthId]->clGrant  && $b->clGrant;
					}
				}
			}
			return $tab;
		}
		return null;
	}
}
//ob management utility class
final class IGKOb
{
	public static function Start()
	{
		ob_start();
	}
	public static function Clear()
	{
		ob_end_clean();
	}
	public static function Content()
	{
		return ob_get_contents();
	}
}

final class IGKException 
{
	public static function GetCallingFunction()
	{
		$e = new Exception();
		$trace = $e->getTrace();
		//position 0 would be the line that called this function so we ignore it
		$last_call = $trace[1];
		print_r($last_call);
	}
}


final class IGKBalafonDBManager 
{//context before session start
	static $sm_instance;
	private $m_regTables;
	public static function getInstance(){
		if (self::$sm_instance == null)
		{
			self::$sm_instance = new IGKBalafonDBManager();
		}
		return self::$sm_instance;
	}	
	public function __toString(){
		return __CLASS__;
	}
	private function __construct(){
		$this->m_regTables = array();
	}
	public function register_db_table($tablenameinterface)
	{
		if (igk_reflection_interface_exists($tablenameinterface))
		{
			$this->m_regTables[$tablenameinterface] = $tablenameinterface;
		}
	}
	public function getCount(){
		return igk_count($this->m_regTables);
	}
}
abstract class IGKQueryResult extends IGKObject
{
	//create an empty entry for this query result
	public function createEmptyEntry(){ return null; }
	//
	public function getRows(){return null;}
	//return the number of columns in the result
	public function getColumns(){return null;}
	//return the number of rows in the result
	public function getRowCount(){return 0;}
	public function getHasRow(){ return ($this->getRowCount()>0); }
	///<summary>return the itarator that can be used to iterate shift onto an element</summary>
	public function getIterator(){
		 $t = new IGKIterator($this->getRows());
		 return $t;
	}
	public function SortBy($key){
		$t = new IGKSorter();
		$t->key = $key;
		$t->Sort($this);
		return $this;
	}
}

///<summary>used to iterate thru an array
final class IGKIterator extends IGKObject implements ArrayAccess, Iterator, Countable
{
	private $m_target;
	private $m_index;
	private $m_viewCount;
	private $m_it_key;
	private $it_vtab;
	private $it_index;
	private $m_count;
	
	public function __construct($ob){	
		$this->m_target = $ob;
		$this->m_count = igk_count($ob);
		$this->m_index = 0;
	}
	public function count(){
		return igk_count($this->m_target);
	}
	public function Shift($index, $count= null){
		$this->m_index = $index;
		if ($count && is_numeric($count)){
			$this->m_count = min( $index + $count,  igk_count($this->m_target));
		}
	}
	
	function current(){ return $this->m_target[$this->m_it_key];}
	function next(){
		$this->it_index++;
		if ( $this->it_index < $this->m_count)
		{		
			$this->m_it_key  = $this->it_vtab[$this->it_index]; 
		}
	}
	function key(){ return $this->m_it_key;}
	
	function valid(){
	
		$v = ($this->it_index >= 0) && ($this->it_index < $this->m_count);			
		return $v;
	
	}
	function rewind(){ 
		
		$this->it_vtab = array_keys($this->m_target);
		$this->it_index = $this->m_index;
		$c = count($this->it_vtab);
		if (( $c>0 )&& ($this->m_index <= $c))
		{
			$this->m_it_key = $this->it_vtab[$this->m_index];		
		}
		else{
			$this->m_it_key  = null;		
		}
	}
	
	//arrayaccess
	function offsetExists($key){
	return isset($this->m_target[$key]);
	}
	function offsetGet($key){
	if (isset($this->m_target[$key]))
		return $this->m_target[$key];
	}
	function offsetSet($key, $value){//nothing		
	}
	function offsetUnset($key){//nothing
	}	
}

final class IGKValidator
{
	private $sm_enode;
	private $sm_cibling;
	
	static $sm_instance;
	private function __construct()
	{	
		$this->sm_enode =  IGKHtmlItem::CreateWebNode("error");
		$this->sm_cibling = array();
	}
	public static function getInstance()
	{
		if (self::$sm_instance == null)
			self::$sm_instance = new IGKValidator();
		return self::$sm_instance;
		
	}
	public static function Cibling()
	{
		return self::getInstance()->sm_cibling;
	}
	public static function ContainCibling($name)
	{
		$e = self::getInstance();
		return isset($e->sm_cibling[$name]);
	}
	public static function AddCibling($name)
	{		
		$e = self::getInstance();
		$t =explode(",",$name) ;
		
		foreach($t as $k=>$v){
			$e->sm_cibling[$v]=1;
		}
	}
	public static function Error(){
		$e = self::getInstance();
		return $e->sm_enode;
	}
	public static function Init(){
		$e = self::getInstance();
		$e->sm_enode->ClearChilds();
		$e->sm_cibling = array();		
	}
	public static function Assert($condition, & $error, $node = null, $errormsg=IGK_STR_EMPTY)
	{
		if ($condition)
		{
			$error = $error || true;				
			if ($node!=null)
			{
				$node->add("li")->Content = $errormsg;
			}
		}
	}
	///<summary>check is null or empty.</summary>
	public static function IsStringNullOrEmpty($v, $cibling=null, $msg="error...")
	{
		$v =  (($v==null) || (is_string($v) && (strlen($v)==0)));
		if ($v && $cibling){
			$cibling->addError($msg);
		}		
		return $v;
	}
	public static function IsEmail($mail)
	{
		if(self::IsStringNullOrEmpty($mail))
			return false;
		
		return preg_match('/[a-z0-9\.\-_]+@[a-z0-9\.\-_]+\.[a-z]{2,6}$/i',  $mail);  
      
	}
	public static function IsInt($v){
		return is_numeric($v);
	}
	public static function IsDate($v){
	}
	public static function IsFloat($v){
		return is_float($v);
	}
	public static function IsDouble($v){
		return is_Double($v);
	}
	public static function IsString($v)
	{
		return is_string($v);
	}
	public static function IsUri($v){
		
		if (empty($v))
			return false;		
		
		$r = preg_match('/^((http(s){0,1}):\/\/([\w\.0-9]+)|(\?))/i',  $v);  
		//igk_wln("check is uri : ". $r . " ".$v);
		return $r;
		
	}
	
}

/// igkServerInfo: Represent the server utility method
final class IGKServerInfo
{
	/// get if this server runing on the loal server
	public static function IsLocal()
	{			
		$v_saddr = self::ServerAddress();
		$v_srddr = self::RemoteIp();
		
		$v = ($v_srddr == "::1") || ($v_saddr == $v_srddr ) || IGKString::StartWith($v_srddr, "192.168");
		return $v;
	}
	public static function ServerAddress(){return  igk_gettv( igk_getv($_SERVER,"SERVER_ADDR"), null); }
	public static function RemoteIp(){return igk_gettv(igk_getv($_SERVER, "REMOTE_ADDR"),null); }
	
	public static function IsIGKDEVSERVER(){
		$r = igk_getv($_SERVER, "HTTP_USER_AGENT");
		if (strstr($r, IGK_SERVERNAME))
		{
			return true;
		}
		return false;
	}
}

class IGKUserAgent{
	const REGEX_ANDROID = "android";
	const REGEX_ANDROID_VERSION = "android\s+(?P<version>[0-9\.]+);";
	const REGEX_ANDROID_MODELNUMBER = "android\s+(?P<version>[0-9\.]+);\s*(?P<model>[\w0-9\.]+)\s*";
	const REGEX_ANDROID_BUILDNUMBER = "android\s+(?P<version>[0-9\.]+);\s*(?P<model>[\w0-9\.]+)\s+build\/(?P<buildnumber>[a-z0-9\.]+)";
	
	public static function Agent(){ return igk_getv($_SERVER, "HTTP_USER_AGENT"); }
	public static function IsAndroid(){
		$regex = "/".self::REGEX_ANDROID."/i";
		return preg_match( $regex,  self::Agent());
	}	
	public static function IsMobileDevice(){
		return self::IsAndroid();
	}	
	public static function GetAndroidVersion(){
		if (self::IsAndroid()){
		
			$regex = "/".self::REGEX_ANDROID_VERSION."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);
				
			return $tab["version"][0];
		}
		return null;
	}
	public static function GetAndroidModel(){
		if (self::IsAndroid()){
			$regex = "/".self::REGEX_ANDROID_MODELNUMBER."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);	
			return $tab["model"][0];
		}
		return null;
	}
	public  static function GetAndroidBuildNumber(){
		if (self::IsAndroid()){
			$regex = "/".self::REGEX_ANDROID_BUILDNUMBER."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);	
			return $tab["buildnumber"][0];
		}
		return null;
	}
	public static function GetDefaultLang(){
		$regex = "/^(?P<name>\w+),*/i";
			$tab = array();
			preg_match_all( $regex,  $_SERVER["HTTP_ACCEPT_LANGUAGE"] ,$tab);	
			return $tab["name"][0];
	}
	
	public static function IsIE()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
		{
			if (strstr($_SERVER["HTTP_USER_AGENT"],"MSIE"))
				return true;
			return false;		
		}
		return false;
	}
	public static function IsIOS(){		
		return false;
	}
	public static function IsChrome()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
		{
			if (strstr($_SERVER["HTTP_USER_AGENT"],"Chrome"))
				return true;
			return false;		
		}
		return false;
	}
	public static function GetChromeVersion()
	{
		if (self::IsChrome())
		{
			$v_r= "/Chrome\/\s*(?P<version>[0-9\.]+)\s/i";			
			$tab = array();
			preg_match_all( $v_r,  self::Agent() ,$tab);							
			return $tab["version"][0];
		}
		return null;
	}
	public static function IsSafari()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
			{
				if (strstr($_SERVER["HTTP_USER_AGENT"],"Safari"))
					return true;
				return false;		
			}
			return false;
	}
	public static function GetSafariVersion()
	{
		if (self::IsSafari())
		{
			$v_r= "/Safari\/\s*(?P<version>[0-9\.]+)\s*/i";			
			$tab = array();
			preg_match_all( $v_r,  self::Agent() ,$tab);							
			return $tab["version"][0];
		}
		return null;
	}
	public static function IsMod()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
			{
				if (strstr($_SERVER["HTTP_USER_AGENT"],"Firefox"))
					return true;
				return false;		
			}
			return false;
	}
	
}

///represent a event method pointer
class IGKEvents extends IGKObject
{
	private $m_methods;
	private $m_singlemethod;
	private $m_owner;
	private $m_name;
	
	var $DEBUG ;
	public function getOwner(){return $this->m_owner;}
	public function getName(){return $this->m_name; }
	
	public function getInfo(){
		return $this->__toString() . " count # ".igk_count($this->m_methods);
	}
	public function __toString(){
		return "Events ".$this->m_name." for [". get_class($this->m_owner)."]";
	}
	///get the number of method in this events
	public function getCount()
	{
		return count($this->m_methods);
	}
	public function __construct($owner, $name, $single=false)
	{
		$this->DEBUG = false;
		$this->m_owner = $owner;
		$this->m_methods =  array();
		$this->m_singlemethod = $single;
		$this->m_name = $name;
	}
	public function Clear()
	{
		unset($this->m_methods);
		$this->m_methods = array();
	}
	public function add($class, $method)
	{
		if ($this->m_singlemethod)
		{
			if ($this->Count() >= 1)
			{
				$this->Clear();
			}
		}
		$_info  = IGKAppMethod::Create($class, $method);
		if ($_info)
		{
			if (!$_info->IsRegistered($this->m_methods))
			{
				$this->m_methods[]= $_info;
				$_info->setParentEvent($this);
				return $_info;		
			}
		}
		
	}
	//remove menthod
	public function remove($class, $method)
	{
		for($i = 0 ; $i<count($this->m_methods) ; $i++)
		{
			$k = $this->m_methods[$i];
			if ($k->match($class, $method))
			{
				$meth = $this->m_methods[$i];
				unset($this->m_methods[$i]);
				$this->m_methods = array_values($this->m_methods);
				$k->setParentEvent(null);
				break;
			}
		}
	}
	public function Call($sender, $args)
	{
		
		if ($this->m_methods)
		{
			foreach($this->m_methods as $k=>$v)
			{
				//igk_debug_wln("call method for ".$v);				
				$v->Invoke($sender, $args);
			}
		}
	}
		
	
}
///<summary>
///represent a language key entries. it support IIGKHtmlGetValue for getting and setting the values
///<summary>
final class IGKLangKey implements IIGKHtmlGetValue
{
	var $key;
	var $default;
	var $args;
	
	public function __construct($key,$default, $args=null)
	{
		$this->key = $key;
		$this->default = $default;
		$this->args = $args;
	}
	public function __toString(){
		return $this->key;
	}
	public function getValue(){//get lang key value
		
		$s = R::gets($this->key);
		$c = 0;		
		if ($this->args != null)
		{
			$macth = array();
			//match 
			$c = preg_match_all("/\{(?P<value>[0-9]+)\}/i",$s, $match);			
			
			for($i = 0; $i < $c ; $i++)
			{
				$index = $match["value"][$i];
				if (is_numeric($index))
				{
					if (isset($this->args[$index]))
					{						
						$s = str_replace( $match[0][$i], IGKHtmlUtils::GetValue($this->args[$index]),$s);
					}
				}
			}
		}
		if ($s == $this->key ){
			$s = "<span class=\"igk-new-lang-key\" >".$s."</span>";
		}
		return html_entity_decode($s);
	}	
}

final class IGKFormatString implements IIGKHtmlGetValue 
{
	private $m_args;
	private $m_value;
	private function __construct()
	{		
	}
	public static function Create($string)
	{		
			$args = array();
			if (func_num_args() > 1)
			{
				$t = func_get_args();
				for($i=1; $i< count($t) ; $i++)
				{
					$args[] = $t[$i];
				}
			}
			$cfrm = new  IGKFormatString();
			$cfrm->m_args = $args;
			$cfrm->m_value = $string;			
			
			return $cfrm;
	}
	public function getValue()
	{
		$s = $this->m_value;
		if ($this->m_args != null)
		{
			$macth = array();
			$c = preg_match_all("/\{(?P<value>[0-9]+)\}/i",$s, $match);			
			for($i = 0; $i < $c ; $i++)
			{
				$index = $match["value"][$i];
				if (is_numeric($index))
				{
					if (isset($this->m_args[$index]))
					{
						$m = $this->m_args[$index];
						if (is_string($m))
						{
							$s = str_replace( $match[0][$i], $m ,$s);
						}
						else if (is_object($m) && method_exists(get_class($m), "getValue"))
						{
							$s = str_replace( $match[0][$i], $m->getValue() ,$s);
						}
						else {
							$s = str_replace( $match[0][$i], '' ,$s);
						}
					}
					else{
						$s = str_replace( $match[0][$i], '' ,$s);
					}
				}
			}
			
		}		
		return $s;
	}
	
	public function __toString(){
		return $this->getValue();
	}
}

final class IGKFormatGetValueString extends IGKObject implements IIGKHtmlGetValue
{
	private $m_obj;
	private $m_member;
	private function __construct(){
	}
	public static function Create($obj, $property)
	{
		if (!is_object($obj))
			return null;
		
		$out = new IGKFormatGetValueString();
		$out->m_obj = $obj;
		$out->m_member = $property;
		return $out;
	}
	public function getValue()
	{
		$c = $this->m_member;
		$v = $this->m_obj->$c;
		return IGKHtmlUtils::GetValue($v);
	}
	public function __toString(){
		return "IGKFormatGetValueString::"+$this->getValue();
	}
}

//--------------------------------------------------------------------
//### Represent a APP METHOD.
//--------------------------------------------------------------------
final class IGKAppMethod
{
	private $_class;
	private $_object;
	private $_methodname;
	private $_index;
	private $_type;
	private $_parentEvent;
	private $_func; // for closure function
	
	const OBJECT_METHOD =  1;
	const CLASS_METHOD = 2;
	const FUNCTION_METHOD = 3;
	const OBJECT_METHOD_CLOSURE = 4;
	public function getParentEvent(){return $this->_parentEvent; }
	public function setParentEvent($event){ $this->_parentEvent = $event; }
	
	private function _typeToString()
	{
		switch($this->_type)
		{
			case self::OBJECT_METHOD:
					return "OBJECT_METHOD";
			break;
			case self::CLASS_METHOD:
					return "CLASS_METHOD";
			break;
			case self::FUNCTION_METHOD:
					return "FUNCTION_METHOD";
			break;
			case self::OBJECT_METHOD_CLOSURE:
				return "CLOSURE_METHOD";
				break;
				
		}
	}
	public function __toString(){
		$v_pattern = IGK_STR_EMPTY;
		switch($this->_type)
		{
			case self::OBJECT_METHOD:
					return "IGKAppMethod[FOR OBJECT METHOD]";//.$this->_type."::".$this->_object."::".$this->_methodname."]";
			break;
			case self::CLASS_METHOD:
					return "IGKAppMethod[".$this->_type."::".$this->_class."::".$this->_methodname."]";
			break;
			case self::FUNCTION_METHOD:
					return "IGKAppMethod[".$this->_type."::".$this->_methodname."]";
					break;
			case self::OBJECT_METHOD_CLOSURE:
					$v_pattern = "CLUSURE =&gt; ".$this->_type;
					break;
		}
		return "IGKAppMethod[".$v_pattern ."]";
	}
	private  function __construct()
	{
		$this->_class =null;
		$this->_methodname= null;
	}
	public function match($class_or_object, $method)
	{
			switch($this->_type)
		{
			case self::OBJECT_METHOD:
				return (($class_or_object === $this->_object) &&  ($this->_methodname == $method));
			break;
			case self::CLASS_METHOD:
				//return call_user_func(array($this->_class, $this->_methodname), $sender, $args);
			break;
			case self::FUNCTION_METHOD:
				return ($this->_methodname == $method);
			break;
			case self::OBJECT_METHOD_CLOSURE:
						
					break;
		}
		return (($class_or_object === $this->_class) &&  ($this->_methodname == $method));
	}
	public static function Create($class_or_object,& $method)
	{
	
		$c = $class_or_object;
		$out = null;
		if (is_object($c))
		{
		
			if (is_string($method))
			{
				if (method_exists($c, $method))
				{
					//create a objet IGKAppMethod
					$out = new IGKAppMethod();
					$out->_type = self::OBJECT_METHOD;
					$out->_methodname = $method;
					$out->_class = get_class($c);
					$out->_object = $c;
				}
			 }
			
		}
		else {
			if (class_exists($c))
			{
				
				if (method_exists($c, $method))
				{
				
					$out = new IGKAppMethod();
					$out->_type = self::CLASS_METHOD;
					$out->_methodname = $method;
					$out->_class = $c;
				}
			
			}
			else if (function_exists($c))
			{
					$out = new IGKAppMethod();
					$out->_type = self::FUNCTION_METHOD;
					$out->_methodname = $method;
					
			}
		}
			
		return $out;
	}
	public function Invoke($sender, $args)
	{
		
		//----------------------------------------------------------------------------
			try{
				switch($this->_type)
				{
					case self::OBJECT_METHOD:		
						if (method_exists(get_class($this->_object), "call_incontext"))
						{
							return $this->_object->call_incontext($this->_methodname, array($sender, $args));
						}
						else
							return call_user_func_array(array($this->_object, $this->_methodname), array($sender, $args));						
					break;
					case self::CLASS_METHOD:
						return call_user_func_array(array($this->_class, $this->_methodname), array($sender, $args));
					break;
					case self::FUNCTION_METHOD:
						return call_user_func($this->_methodname, $sender, $args);
					break;
				}
		}
		catch(Exception $ex){
			igk_show_exception($ex);
			igk_wln("IGKAppMethod::Invoke exception raised Method:[".$this->_typeToString()." ; ".$this->_methodname."]" . $this->__toString());			
			igk_exit();
		}
	}
	public function IsRegistered($tab)
	{
	if ($tab==null)return false;
		foreach($tab as $k=>$v)
		{
			if ($v === $this)
			{
				return true;
			}
		}
		return false;
	}
}

class IGKSetting extends IGKObject
{
	public $m_setting;
	
	public static function IsConfigured(){
		return true;
	}
	public static function LoadSetting(){
		
	}
	public function initSetting(){
		
	}
}

//--------------------------------------------------------------------------------------------------------
//IO utils class
//--------------------------------------------------------------------------------------------------------
final class IGKIO{


	///<summary> get relative path according to the IGKApp::$BASEDIR</summary>
	///<param name="dir">must be a full path to file or directory </param>
	public static function GetBaseDirRelativePath($dir, $separator = DIRECTORY_SEPARATOR)
	{
		$doc_root = IGKIO::GetBaseDir();
		return self::GetSysRelativePath($dir, $doc_root,$separator	);		
	}
	public static function GetSysRelativePath($dir, $doc_root,$separator = DIRECTORY_SEPARATOR)
	{		
		if (empty($dir) || empty($doc_root))
			return null;
			
		$i = IGKString::IndexOf($dir, $doc_root);			
		if ($i != -1)
		{
			//// remove the base dir
			$dir = igk_str_rm_start(substr($dir, $i + strlen($doc_root)), $separator);
			return $dir;
		}
		//find base dir of the path
		$p = "../";
		$found = false;
		while( !empty($doc_root))
		{
			$doc = dirname($doc_root);
			if ($doc==$doc_root)
			{
				break;
			}
			$doc_root= $doc;
			$i = IGKString::IndexOf($dir, $doc_root);
			if ($i == -1){
				$p .= "../";
			}
			else {
				$found = true;
				break;
			}			
			
		}
		if ($found){		
			$dir = igk_str_rm_start(substr($dir, $i + strlen($doc_root)), $separator);
			return IGKIO::GetDir($p.$dir);			
		}				
		return null;
	}

	public static function CopyFiles($inputDir, $outputDir , $recursive=false, $overwrite=false)
	{
		$hdir = opendir($inputDir);
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;	
				$f = self::GetDir($inputDir . DIRECTORY_SEPARATOR . $r);
				$p  = self::GetDir($outputDir .DIRECTORY_SEPARATOR . $r);
				
				if (file_exists($p) ==false)
					copy($f, $p);
				
			}
			closedir($hdir);
		}
	}
	public static function GetFiles($dir, $match, $recursive=false)
	{
		if (is_dir($dir) === false)
			return null;
		
		$v_out = array();
		
		$hdir = @opendir($dir);
		
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;
				$f = $dir . DIRECTORY_SEPARATOR . $r;
				if (is_file($f) && (($match==null) || (($match!=null) && ( preg_match($match, $f)))))
				{
						$v_out[] = $f;				
				}
				else if(is_dir($f) && $recursive)
				{
					foreach(IGKIO::GetFiles($f, $match, $recursive) as $k)
					{
						$v_out[] = $k;				
					}
				}
			}
			closedir($hdir);
		}	
		
		return $v_out;
		
	}
	//utility fonction get picture files
	public static function  GetPictureFile($dir, $recursive=true)
	{
		if (is_dir($dir) === false)
			return null;
		$tab = array();
		$tdir = array();
		$hdir = opendir($dir);
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;
				$f = $dir . DIRECTORY_SEPARATOR . $r;
				if (is_file($f) )
				{
					$ext = strtolower(IGKIO::GetFileExt($f));
					
					switch($ext)
					{
						case "png":
						case "jpeg":
						case "jpg":
						case "ico":
							$tab[] = $f;
							break;
						
					}
				}
				else if(is_dir($f))
				{
					$tdir[] = $f;
				}
			}
			closedir($hdir);
		}
		if ($recursive){
			foreach($tdir as $k)
			{
				$m= self::GetPictureFile($k);
				if ($m!=null){
					$tab = array_merge($tab, $m);
				}				
			}
		}		
		return $tab;
	}
	public static function GetFileSize($size)
	{
		if ($size == 0)
			return "0 Bytes";
		$sizes = array('Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
		return (round($size/pow(1024, ($i = floor(log($size, 1024)))), 2) . ' ' . $sizes[$i]);

	}
	public static function IsDirEmpty($dir)
	{
		if (!is_dir($dir))
			return true;
		
		$hdir = @opendir($dir);
		if ($hdir)
		{
			$empty = true;
			while( $s = readdir($hdir))
			{
				if (($s==".") || ($s==".."))
					continue;
				$empty = false;
				break;
			}
			closedir($hdir);
			return $empty;
		}
		else{
			igk_debug_wln("warning:impossible d'ouvir le repertoire : ".$dir);
		}
		return true;
	}
	//return a directory list
	public static function GetDirList($folder)
	{
		if (!is_dir($folder))
			return false;
		$dirs = array();
			$hdir = opendir($folder);
			if ($hdir)
			{
				while( ($cdir=readdir($hdir)))
				{
					if (($cdir== ".") || ($cdir==".."))
						continue;
					$f = self::GetDir($folder."/".$cdir);
					if (is_dir($f))
					{
						$dirs[] = $f;
					}
				}
				closedir($hdir);
			}
		return $dirs;
	}
	
	//return a directory file list
	public static function GetDirFileList($folder)
	{
		if (!is_dir($folder))
			return false;
		$dirs = array();
			$hdir = opendir($folder);
			if ($hdir)
			{
				while( ($cdir=readdir($hdir)))
				{
					if (($cdir== ".") || ($cdir==".."))
						continue;
					$f = self::GetDir($folder."/".$cdir);
					if (is_file($f))
					{
						$dirs[] = $f;
					}
				}
				closedir($hdir);
			}
		return $dirs;
	}
	public static function GetCurrentDir()
	{
		// $tb = get_included_files();
		// return dirname($tb[0] );
		return getcwd();
	}
	public static function RemoveFirstDirectorySeparator($dir)
	{
		while((!empty($dir) && ($dir[0] == DIRECTORY_SEPARATOR)))
		{
			$dir = substr($dir, 1);
		}
		return $dir;
	}
	public static function CreateDir($dirname, $mode=0777){
		if (is_dir($dirname) === true)
			return true;
		//try to create the directory
		if (@mkdir($dirname, $mode))
		{
			//try to chane chmod dir to creation mask
			@chmod($dirname, IGK_DEFAULT_FOLDER_MASK);
			return true;
		}
		else{
			$d = dirname($dirname);
			if (is_dir($d)){
				//parent create can't create on directory
				return false;
			}
			else{
				if (self::CreateDir($d, $mode))
				{
					//create the current directory
					if (@mkdir($dirname, $mode))
					{
						//try to chane chmod dir to creation mask
						@chmod($dirname, IGK_DEFAULT_FOLDER_MASK);
						return true;
					}
				}
			}
			
		}
		igk_notifyctrl()->addError( R::ngets("ERR.CANTCREATEDIR",$dirname));
		throw new Exception("error when creating directory:CreateDir failed : ".$dirname);
		igk_exit();
		
	}
	///<summary> Create a directory recursivily</summary>
	///<dir>directory to create</dir>
	///<root>mus add a as directory separator </root>
	///<return>-1 if dir is empty, </return>
	public static function CreateRDir($dir, $root=false)
	{
		if (empty($dir))
		{
			return -1;
		}
		if (is_dir($dir))
			return 1;
		$d = explode(DIRECTORY_SEPARATOR, igk_io_getdir($dir));
		$s = IGK_STR_EMPTY;
		for($i=0 ; $i<count($d);$i++)
		{
			if ($root || ($i>0))
			{
				$s .= DIRECTORY_SEPARATOR;
			}
			$s.=$d[$i];
			//igk_wln($s);
			if ( empty($s)  || is_dir($s))
				continue;				
			if(!@mkdir($s))
				return false;
		}
		return true;
	}
	public static function WriteToFileAsUtf8WBOM($filename, $content, $overwrite = true, $chmod = IGK_DEFAULT_FILE_MASK)
	{
		return self::WriteToFile($filename, $content, $overwrite, $chmod);
	}
	///<summary>write text to a file</summary>
	///<remarks>return true if success. or throw exception</remarks>
	public static function WriteToFile($filename, $content, $overwrite = true, $chmod = IGK_DEFAULT_FILE_MASK)
	{	
		if (empty($filename))
			throw new Exception("filename is empty or null");
	
		$filename = igk_io_getdir($filename);		
		if (!is_dir (dirname($filename)))
		{
			if (!IGKIO::CreateDir(dirname($filename)))
				return false;
		}
		
		
		if (is_file($filename) && !$overwrite){
			return false;
		}
		$hf = @fopen($filename, "w+");
		if (!$hf)
		{
			return false;
		}
		
		//write content as utf-8
		fwrite($hf, $content);
		fflush($hf);
		fclose($hf);	
		if ($chmod)	{	
			if (!@chmod($filename, $chmod))			
			{
				igk_notify_error("chmodfailed: " . $filename. " : ".$chmod);
			}
			
		}
		return true;
	}
	public static function ReadAllText($filename)
	{
		if (file_exists($filename) == false)
			return null;
		//file size all error
		$fsize = @filesize($filename);
		$str = @file_get_contents($filename);
		return $str;
		
	}
	

	public static function GetFileName($filename)
	{
		$pathinfo = pathinfo($filename);
		$b = $pathinfo["basename"];
		return $b;
	}

	public static function GetFileExt($filename)
	{
		$pathinfo = pathinfo($filename);
		

		try{
		if (isset($pathinfo["extension"]))
			return $pathinfo["extension"];
		}
		catch(Exception $exception)
		{
			die ($filename);
		}
		return null;
	}	
	
	///<summary>tranforme le repertoire passer en paramà¨tre en une chemin compatible celon le systeme d'exploitation serveur</summary>	
	public static function GetDir($dir)
	{
		$d = DIRECTORY_SEPARATOR;
		$r = '/';
		$out = IGK_STR_EMPTY;
		
		if (ord($d) == 92)
		{
			$out =preg_replace("/\//", '\\', $dir);
			$out = str_replace("\\\\", "\\", $out);
		}
		else{
			$out =preg_replace('/[\\\]/', '/', $dir);
			$out = str_replace("//", "/", $out);
		}
		return $out;
	}
	
	//----------------------------------------------------------
	//return the formatted base directory according to base path
	//----------------------------------------------------------
	///<summary>DIRECTORY FUNCTION </summary>
	public static function GetBaseDir($dir=null)
	{
		if ($dir)
		{
			if (igk_io_is_fullpath($dir))
			{
				return self::GetDir(IGKApp::$BASEDIR.DIRECTORY_SEPARATOR.igk_io_basePath($dir));
			}
			else 
				return self::GetDir(IGKApp::$BASEDIR.DIRECTORY_SEPARATOR.$dir);
		}
		return self::GetDir(IGKApp::$BASEDIR);
	}
	//get the base uri according to local specification
	public static function GetBaseUri($dir=null, $secured=false)
	{
		$out = IGK_STR_EMPTY;
		$v_dir = self::GetBaseDir($dir);
		$root = $_SERVER["DOCUMENT_ROOT"];
		$t = substr($v_dir, strlen($root));
		
		if ($secured){
			$out = 'https://';
		}
		else{
			$out = 'http://';
		}
		
		$out .= igk_str_join(igk_str_rm_last($_SERVER["SERVER_NAME"],'/').self::GetPort(),igk_str_rm_start(igk_html_uri($t), '/'),'/');
		
		//sample		
		$out = str_replace('\\','/', $out);
		return $out;
	}
	private static function GetPort(){
	
		$port = IGK_STR_EMPTY;
		$p = igk_getv($_SERVER, "SERVER_PORT");
		if (!empty($p) && ($p!== "80"))
			$port = ":".$p;
			
		return $port;
	}
	//get root uri
	public static function GetRootUri($uri=IGK_STR_EMPTY, $secured=false )
	{		
		$root = $_SERVER["DOCUMENT_ROOT"];
		if ($secured){
		$out = 'https://';
		}
		else{
		$out = 'http://';
		}
		$out .= igk_str_join(igk_str_rm_last($_SERVER["SERVER_NAME"],'/').self::GetPort(),igk_str_rm_start($uri, '/'),'/');
		//sample
		
		$out = str_replace('\\','/', $out);
		return $out;
	
	}
	//return relative uri from server requested URI
	/*
	Exemple : GetCurrentRelativeUri("test") will return 	
	*/
	public static function GetCurrentRelativeUri($dir= IGK_STR_EMPTY)
	{
		
		//event from uri		
		$r_uri = igk_getv(explode("?",$_SERVER["REQUEST_URI"]),0);
		
		$v_isdir = IGKString::EndWith($r_uri, '/');
		$cdir = IGKIO::GetDir(IGKIO::GetRootUri(igk_str_rm_last($r_uri,'/')));
		$bdir = IGKIO::GetDir(igk_io_baseUri());
		$dir = IGKIO::GetDir($dir);
		$i = -1;
		
		if ($bdir == $cdir)
		{
			
			return self::GetRootRelativePath($dir);
		}
		//get the current directory according to BASEDIR
		$i = IGKString::IndexOf($cdir, $bdir);
		if ($i != -1){
			$cdir = substr($cdir, $i + strlen($bdir));
		}
		//build dir according to path
		$i = IGKString::IndexOf($dir, $bdir);
		if ($i!= -1){
			$dir = substr($dir, $i + strlen($bdir));
		}		
		//remove the first directory separator
		$dir = IGKIO::RemoveFirstDirectorySeparator($dir);
		$cdir = IGKIO::RemoveFirstDirectorySeparator($cdir);
		
		$t = count(explode(DIRECTORY_SEPARATOR, $cdir));
		if (($t>0 ) && (!$v_isdir))
		{
			$t--;
		}
		for($i = 0; $i< $t; $i++)
		{			
			$dir= "..".DIRECTORY_SEPARATOR.$dir;			
		}	
		return igk_html_uri($dir);
	}
	//@get the root dir according to document root. uses for css script file
	/// dir : dir according to
	//<exemple>(test) == SERVER["Document_ROOT"]-/+ test</exemple>
	public static function GetRootBaseDir($dir=null)
	{
		//get the current base directory
		$s = self::GetBaseDir();
		$s  = str_replace("\\","/", $s);
		$doc = str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);		
		$dir =  str_replace("\\","/", $dir);		
		if (strlen($s) >0)
		{
			if ($s[0] == "/")
			{
				//linux implementation
				$s = strstr($s, $doc);
				$s  = trim(substr($s, strlen($doc)));
				if((strlen($s) > 0) && ($s[0] != "/"))
					$s = "/".$s;							
			}
			else{		
				$s  = substr($s, strlen($doc));	
				if ((strlen($s)>0) && $s["0"]!="/")
					$s .="/";
			}
		}
		if ($dir)
		{
			if ($s == "/")
				$s = IGK_STR_EMPTY;
		
			if (IGKString::StartWith("/",$dir))
				$s .= $dir;					
			else
				$s .= "/".$dir;								
		}
		return $s;
	}
	//retrieve the relative path according the directory
	public static function GetChildRelativePath($source, $destination, $separator  = DIRECTORY_SEPARATOR)
	{
		$doc_root = $source;
		$dir = $destination;
		$i = IGKString::IndexOf($dir,$doc_root);
		if ($i!= -1)
		{
			//root document found in dir path 
			$dir = substr($dir, $i + strlen($doc_root));
		}	
		//not found 
		$dir = str_replace(self::GetRootBaseDir(),IGK_STR_EMPTY, $dir);		
		while( (strlen($dir)>0) && ($dir[0] == DIRECTORY_SEPARATOR))
		{
			$dir = substr($dir, 1);
		}
		return empty($dir)?null:self::__fixPath($dir);
	}
	private static function __fixPath($path, $separator = DIRECTORY_SEPARATOR)
	{
		if ($separator == "/")
		{
			$path = preg_replace('/([\/]+)/i', '/', $path);
			
		}
		else 
			$path = preg_replace('/([\\'.$separator.']+)/i', ''.$separator.'', $path);
		return $path;
	}
	/// get relative path according to the DOCUMENT_ROOT
	/// dir = must be a full path to an existing file or directory 
	public static function GetRootRelativePath($dir, $separator = DIRECTORY_SEPARATOR)
	{
		$doc_root = self::GetDir( $_SERVER["DOCUMENT_ROOT"]);	
		$i = IGKString::IndexOf($dir,$doc_root);
		$c = IGK_STR_EMPTY;
		if ($i!= -1)
		{
			//root document found in dir path 
			$dir = substr($dir, $i + strlen($doc_root));
			$bdir = IGKIO::GetDir($doc_root."/".self::GetRootBaseDir());			
			$c = igk_io_getrelativepath($bdir, $doc_root);			
		}		
		//not found 
		$dir = str_replace(self::GetRootBaseDir(),IGK_STR_EMPTY, $dir);	
		while( (strlen($dir)>0) && ($dir[0] == DIRECTORY_SEPARATOR))
		{
			$dir = substr($dir, 1);
		}
		if ($c)
			$dir = $c.DIRECTORY_SEPARATOR.$dir;		
		return igk_html_uri(empty($dir)?null:self::__fixPath($dir));
	}
	private static function GetRelativePathToDir($dir, $cdir, $bdir){
		
			//get the current directory according to BASEDIR
			$i = IGKString::IndexOf($cdir, $bdir);//$doc);
			if ($i!= -1){
				$cdir = substr($cdir, $i + strlen($bdir));			
			}	
			//build dir according to path
			$i = IGKString::IndexOf($dir, $bdir);
			if ($i!= -1){
				$dir = substr($dir, $i + strlen($bdir));
			}		
	
			//remove the first directory separator
			$dir = IGKIO::RemoveFirstDirectorySeparator($dir);
			$cdir = IGKIO::RemoveFirstDirectorySeparator($cdir);
			
			$t = count(explode(DIRECTORY_SEPARATOR, $cdir));
			
			for($i = 0; $i< $t; $i++)
			{			
				$dir= "..".DIRECTORY_SEPARATOR.$dir;			
			}	
			//remove dual separator		
			return empty($dir)?null:IGKIO::__fixPath($dir);
	}
	/// <summary>get relative path according to IGKApp::$BASEDIR base dir</summary>
	/// @dir: absolute path or basedir relative path
	public static function GetCurrentDirRelativePath($dir, $separator = DIRECTORY_SEPARATOR)
	{
		$doc = IGKIO::GetDir( $_SERVER["DOCUMENT_ROOT"]);
		$cdir = IGKIO::GetCurrentDir();
		$bdir = IGKIO::GetBaseDir();
		$dir = IGKIO::GetDir($dir);
		$i = -1;
		$v_iscurrent = ($bdir == $cdir);
		if ($v_iscurrent)
		{	//base dir is current
			//TODO::
			//igk_wln("is current ? $bdir == $cdir ? $dir ? ".igk_io_is_fullpath($dir) . " ::: ");
			//realpath($dir));
			return self::GetBaseDirRelativePath($dir);
			
		}		
		if (empty($dir))
		{
			return self::GetRelativePathToDir($dir, $cdir, $bdir);			
		}
		//TODO::
		$r = realpath($dir);
		if ($r!= null)
			$r = self::GetSysRelativePath($r, $cdir);		
		else{
			$r = self::GetSysRelativePath(igk_io_baseDir($dir), $cdir);					
		}
		return $r; 
		
	}

	//retrieve the relative page
	public static function GetRelativePath($sourcepath, $targetdir, $separator = DIRECTORY_SEPARATOR)
	{
	
		$i = IGKString::IndexOf($targetdir, $sourcepath);		
		if ($i != -1)
		{	
			$s = self::__fixpath(substr($targetdir, strlen($sourcepath)));							
			while(!empty($s) && IGKString::StartWith($s, DIRECTORY_SEPARATOR))
			{
				$s = substr($s, 1);
			}
			return $s;
		}
	
	
		$dir = $sourcepath;
		$cdir = $sourcepath;
		$bdir = $targetdir;
		$i = -1;		
		$c = 0;
		$tsdir = explode(DIRECTORY_SEPARATOR, $cdir);
		$tbdir = explode(DIRECTORY_SEPARATOR, $bdir);
		$rstep = false;
		while(($c< count($tbdir)) && ($c< count($tsdir)))
		{
			if ($tbdir[$c]!=$tsdir[$c])
			{
				$rstep = true;
				break;
			}
			$c++;
		}
		$s = IGK_STR_EMPTY;
		if ($rstep)
		{	
			for($h = $c; $h< count($tbdir) ; $h++)
			{
				$s .= "..".DIRECTORY_SEPARATOR;
			}
			
		}
		for($h = $c; $h< count($tsdir) ; $h++)
			{
				if ($h>$c)
					$s .= DIRECTORY_SEPARATOR;
				$s .= $tsdir[$h];
			}			
		return $s;
		
	}
	
	/*
	GET BASE FOLDER FULLPATH
	Exemple: GetBaseFolderFullpath("test") == BASEDIR+"/test"
	*/
	public static function GetBaseFolderFullpath($dir)
	{
		$d = IGKApp::getInstance()->CurrentPageFolder;
		if (!empty($d) && ($d!=IGK_HOME_PAGEFOLDER))
			return igk_io_getdir(igk_io_currentRelativePath(IGKApp::$BASEDIR ."/".$d."/".$dir));
		return igk_io_getdir(igk_io_currentRelativePath(IGKApp::$BASEDIR ."/".$dir));
	}


	/*
	REMOVE FOLDER
	*/
	public static function RmDir($dir, $recursive=true)
	{
		if (!is_dir($dir))
			return false;
		if (@rmdir($dir))
			return true;
		if (!$recursive)
			return false;
		$hdir = opendir($dir);
		if (!$hdir)
			return false;
		while( ($f =  readdir($hdir)))
		{
			if (($f=="." ) || ($f==".."))
				continue;
			$v = igk_io_getdir($dir."/".$f);
			if (is_dir($v))
			{
				if (self::RmDir($v,$recursive) == false)
				{				
					return false;
				}
			}
			else if (is_file($v))
			{
				unlink($v); //remove file
			}	
		}
		closedir($hdir);
		return @rmdir($dir);
	}
	public static function RmFiles($dir, $pattern=null){
		if (!is_dir($dir))
			return false;
		$hdir = opendir($dir);
		if (!$hdir)
			return false;
		while( ($f =  readdir($hdir)))
		{
			if (($f=="." ) || ($f==".."))
				continue;
			$v = igk_io_getdir($dir."/".$f);
			if (is_file($v))
			{
				if (($pattern ==null) || preg_match($pattern,$v))
				{
					unlink($v); //remove file
				}
			}		
			
		}
		closedir($hdir);
		return true;
	}


}
//-----------------------------------------------------------------------
//represent a string utility class
//-----------------------------------------------------------------------
class IGKString{
	//@chaine : string where to operate
	public static function IndexOf($chaine, $research, $offset=0)
	{
		if (empty($chaine) || empty($research))
			return -1;	
		$i = strpos($chaine, $research, $offset);
		if ($i === false)
		return -1;
		return $i;
	}
	//@personal sub
	public static function Sub($chaine, $start, $length=null)
	{
		if ($length)
		{
			return substr($chaine, $start, $length);
		}
		else 
			return substr($chaine, $start);
	}
	public static function StartWith($chaine, $pattern)
	{
		return (self::IndexOf($chaine, $pattern) == 0);
	}
	public static function EndWith($chaine, $pattern)
	{
		$chaine=trim($chaine);
		$c = strlen($chaine);
		$p = strlen($pattern);
		$i = strripos($chaine, $pattern);
		if ($i === false)
		{
			return false;
		}
		if (($i != -1) && ( ($i+$p)=== $c))
			return true;
		return false;
	}
	public static function Trim($chaine)
	{
		return trim($chaine);
	}
	public static function Contains($text, $pattern){
		if (!empty($pattern))
			return (strstr($text, $pattern) != null);
		return true;
	}
	public static function Format($s){
		
			$c = preg_match_all("/\{(?P<value>[0-9]+)\}/i",$s, $match);			
			if ($c>0)
			{
			$args = array_slice(func_get_args(), 1);
			for($i = 0; $i < $c ; $i++)
			{
				$index = $match["value"][$i];
				if (is_numeric($index))
				{
					if (isset($args[$index]))
					{
						///TODO: replace with value
						$s = str_replace( $match[0][$i], IGKHtmlUtils::GetValue($args[$index]),$s);
					}
				}
			}
			}
			return $s;
	}

	public static function Join($tab, $separator=",", $key=true)
	{
		$s = "";
		$t = 0;
		if ($tab){
		foreach($tab as $k=>$v){
			if ($t==1)
			$s.= $separator;
			if ($key)
				$s .=$k;
			else 
				$s .= "".$v;
			$t = 1;	
		}
		}
		return $s;
	}
}


///<summary> Number operator class </summary>
final class IGKNumber 
{
        private static function HexP($r)
        {
            $g = ($r >= 10) ?chr(ord("A")+($r-10)): $r;
            return $g;
        }
        public static function ToBase($d, $base, $length = -1)
        {
			if (is_numeric($d) ==false)
				return "0";
            $o = IGK_STR_EMPTY;
            if ($base > 0)
            {
                $p = (int)($d / $base);
                $r = $d % $base;
                if ($p < $base)
                {
					if ($p!=0)
						$o = self::HexP($p) . IGK_STR_EMPTY . self::HexP($r);
					else
						$o = self::HexP($r);
                }
                else
                {
                    $o = self::HexP($r) . $o;
                    $o = self::ToBase($p, $base) . $o;
                }
                if ($length != -1)
                {
                    for ($i = strlen($o); $i < $length; $i++)
                    {
                        $o = "0" . $o;
                    }
                }
            }
			return $o;
		
        }

		//<summary>convert number form base x to base</summary>
		public static function FromBase($d, $base){
		
			$o  = 0;
			$v = strtoupper(IGK_STR_EMPTY.$d);
			$ln = strlen($v);
			for($i = 0; $i < $ln;$i++)
			{
				$h = self::__GetValue($v[$ln - $i-1]);			
				$o += pow( $base, $i) * $h;
			}			
			return $o;
		}
		private  static function __GetValue($d){
			//igk_wln("d = ".is_int($d));
			if (is_int($d) || preg_match("/[0-9]/i",$d))
			{
				return $d;
			}
			else 
				return 10+ ( ord($d) - ord('A'));
		}
}
//------------------------------------------------------------------------------------------
//IGK Object Definition
//------------------------------------------------------------------------------------------
///
///<summary>Represent the base IGK object class </summary>
///
class IGKObject
{
	private $m_cmpObj;
	
	//used to dispose and release element
	public function Dispose(){
		
	}
	public function CompareTo($obj)
	{
		$this->m_cmpObj = igk_new_id();
		$r  = ($this->m_cmpObj == $obj->m_cmpObj);
		$this->m_cmpObj = null;
		return $r;
	}
	
	//override this method to filter call of global method
	//used to call internal function 
	public function Invoke($method, $args=null)
	{
		if (method_exists($this, $method))
		{
			if (($args == null) || (is_array($args )))
			{
				$this->$method($args);
			}
			else{
				call_user_func_array(array($this, $method), array($args));
			}
		}
	}
	
	protected function _setIn($name, & $value)
	{
		if (method_exists($this, "set".$name) )
		{					
			call_user_func(array($this, "set".$name), $value);
			return true;
		}
		return false;
	}
	public function __set($name,$value){//set for igk object
		$this->_setIn($name, $value);
	}
	
	public function __get($key)
	{
		if (method_exists($this, "get".$key) )
		{					
			return call_user_func(array($this, "get".$key), null);
		}
		return null;
	}
	public function __toString(){
		return get_class($this);
	}
	public function regEvent($name, $value)
	{
		//add event
		if (AppString::IndexOf($name, "add") == 0)
		{
			$event = substr($name,3)."Event";					
			if ($this->ContainVars($event))
			{
				if ($this->$event == null)
				{
					$this->$event = new IGKEvents($this, $event);
				}
				$this->$event->add($value[0],$value[1]); 
				return true;
			}				
		}
		//remove event
		if (AppString::IndexOf($name, "remove") == 0)
		{
			$event = substr($name,6)."Event";					
			if ($this->ContainVars($event))
			{
				if ($this->$event != null)
				{
				$this->$event->remove($value[0],$value[1]); 	
				}						
				return true;
			}				
		}
	}

	public function callEvent($event, $method)
	{
		if (($event!=null) && ($event->Owner==$this))
		{
			$this->$method();
		}
	}
}


final class IGKDynamicObject extends IGKObject
{
	private $m_properties;
	
	public function __construct(){
		$this->m_properties= array();		
	}
	// public function __wakeup(){	
	//	igk_wln("wake up");
		// igk_show_prev(array_keys(func_get_args()));
	//	igk_exit();
	// }
	// public function __sleep(){
		//don't seriable properties		
		//free array
		// $this->m_properties = array();
		// return array();
	// }
	public function __toString(){
		return __CLASS__."#";
	}
	public function initProperties($data){
		if ($data)
		foreach($data as $k=>$v){
			$this->m_properties[$k] = $v;
		}
	}
	public function __get($name){//IGKDynamicObject
		if (isset($this->m_properties[$name]))
			return $this->m_properties[$name];
		return parent::__get($name);
	}
	public function __set($name, $v){//IGKDynamicObject
		if (!_setIn($name,$v)){
			$this->m_properties[$name] = $v;
		}
	}
	public function __call($name, $arguments)
	{
		if (isset($this->m_properties[$name]))
		{
			return call_user_func_array($this->m_properties[$name], $arguments);
		}
	}
}
class IGKDateTime extends IGKObject
{
	private $m_day;
	private $m_month;
	private $m_year;
	private $m_min;
	private $m_hour;
	private $m_sec;
	public function getmonth(){return $this->m_month; }
	public function getday(){return $this->m_day; }
	public function getyear(){return $this->m_year; }
	public function getmin(){return $this->m_min; }
	public function getsec(){return $this->m_sec; }
	public function gethour(){return $this->m_hour; }
	
	private function __construct(){
	}
	public static function CreateFrom($format,  $value)
	{
		$tab = (object)date_parse_from_format($format, $value);
		
		if ($tab->error_count == 0)
		{
			$d = new IGKDateTime();
			$d->m_day = $tab->day;
			$d->m_month = $tab->month;
			$d->m_year = $tab->year;
			$d->m_min = $tab->minute;
			$d->m_sec = $tab->second;
			$d->m_hour = $tab->hour;
			return $d;
		}
		else{
		if (IGKApp::$DEBUG)
			igk_show_prev($tab);
		}
		return null;
	}
	public function __toString(){
		return "IGKDateTime:[".$this->day."-".$this->month."-".$this->year."]";
	}
	public function getDate($format)
	{
		$s = $format;
		$s =str_replace("Y", $this->year, $s);
		$s =str_replace("m", $this->month, $s);
		$s =str_replace("d", $this->day, $s);
		$s =str_replace("H", $this->hour, $s);
		$s =str_replace("i", $this->min, $s);
		$s =str_replace("s", $this->sec, $s);
		
		return $s;
	}
	public static function compareDate($date1, $date2)
	{
		if (!$date1 || !$date2)
			return -2;
		$s1 = $date1->getDate("Ymd");
		$s2 = $date2->getDate("Ymd");
		return strcmp($s1,$s2);
	}
	public static function isDateEqual($date1, $date2)
	{
		return self::compareDate($date1, $date2)==0;
	}
	public static function isDateYearEqual($date1, $date2)
	{
			if (!$date1 || !$date2)
			return -2;
		return $date1->year == $date2->year;
	}
	public static function isDateMonthEqual($date1, $date2)
	{
		return (self::IsDateYearEqual($date1, $date2)===true) && ($date1->month == $date2->month);
	}
}
class IGKAttribute extends IGKObject
{
	static $classAttributes = array();
	
	public function __construct(){
	}
	public static function GetAttributes($classOrObject)
	{
		$n = null;
		if (is_string($classOrObject))
		{
			$n = $classOrObject;
		}
		else 
			$n = get_class($classOrObject);
		return igk_getv(self::$classAttributes,$n);
	}
	public static function Register($classname, $attribute,$allowmultiple=true, $inherits=false)
	{
		$n = get_class($attribute);
		if (class_exists($classname))
		{
			if (igk_reflection_class_extends($n, __CLASS__))
			{
				if (($tab = igk_getv(self::$classAttributes, $classname)) == null)
				{
					$tab = array();
				}
				$tab[] = $attribute;
				self::$classAttributes[$classname] = $tab;
			}
		}
	}
}

//color float
class IGKColorf extends IGKObject
{
	private $m_R;
	private $m_G;
	private $m_B;
	private $m_A;
	
	
	public function getR(){ return $this->m_R; }
	public function getG(){ return $this->m_G; }
	public function getB(){ return $this->m_B; }
	public function getA(){ return $this->m_A; }
	
	public function setR($value){ if (($value>=0) && ($value<=1.0)) $this->m_R = $value; }
	public function setG($value){ if (($value>=0) && ($value<=1.0)) $this->m_G = $value; }
	public function setB($value){ if (($value>=0) && ($value<=1.0)) $this->m_B = $value; }
	public function setA($value){ if (($value>=0) && ($value<=1.0)) $this->m_A = $value; }
	private static function __bindStringData($cl, $v)
	{
	 $v = trim (strtoupper($v));
            if (IGKString::StartWith($v, "#") || IGKString::StartWith($v, "0x"))
            {
                $v = str_replace("#", IGK_STR_EMPTY, $v);
				$v = str_replace("0x", IGK_STR_EMPTY, $v);
                $i = 0;
                switch (strlen($v))
                {
                    case 8:
                        break;
                    case 4:
                        $v = IGK_STR_EMPTY . $v[0] . $v[0] .
                            $v[1] . $v[1] .
                            $v[2] . $v[2] .
                            $v[3] . $v[3];
                        break;
                    case 6:
                        $v = "FF" . $v;
                        break;
                    case 3:
                        $v = "FF" .$v[0] . $v[0] .
                            $v[1] . $v[1] .
                            $v[2] . $v[2];
                        break;
                    default :
                        break;
                }
                try
                {
                    $i = IGKNumber::FromBase($v, 16);// (uint)System.Convert.ToInt32(txt, 16);
					// igk_wln("v : ".$v);
					// igk_wln("i : ".$i);					
				
					
                    // Colorf c = new Colorf();
                   //$a = (int)((i >> 24) & 0x00FF);
                    $r = (($i >> 16) & 0x00FF);
                    $g = (($i >> 8) & 0x00FF);
                    $b = (($i) & 0x00FF);
                    $cl->m_R = $r / 255.0;
                    $cl->m_G = $g / 255.0;
                    $cl->m_B = $b / 255.0;  
					// igk_wln("v : ".$r);
					// igk_wln("i : ".$g);		
					// igk_wln("i : ".$b);		
										
                }
                catch(Exception $ex) {                    
                }
            }
	}
	public static function FromString($v){
	
		$t = igk_css_get_color_value($v);
		if (empty($t))
		{
		$cl = new IGKColorf();
		$cl->m_A = 1.0;
		self::__bindStringData($cl, $v);		
		return $cl;
		}
		$cl = new IGKColorf();
		$cl->m_A = 1.0;
		self::__bindStringData($cl, $t);		
		return $cl;
	}
	public function loadw($v){
		self::__bindStringData($this, $v);
	}
	public function toByte(){
		return IGKColor::FromFloat($this->R, $this->G, $this->B, $this->A);
	}
}
//color byte
class IGKColor extends IGKObject
{
	private $m_R;
	private $m_G;
	private $m_B;
	private $m_A;
	
	public static function Black(){ return self::FromFloat(0.0);}
	public static function White(){ return self::FromFloat(1.0);}
	
	public function getR(){ return $this->m_R; }
	public function getG(){ return $this->m_G; }
	public function getB(){ return $this->m_B; }
	public function getA(){ return $this->m_A; }
	
	public function setR($value){ if (($value>=0) && ($value<=255)) $this->m_R = $value; }
	public function setG($value){ if (($value>=0) && ($value<=255)) $this->m_G = $value; }
	public function setB($value){ if (($value>=0) && ($value<=255)) $this->m_B = $value;}
	public function setA($value){ if (($value>=0) && ($value<=255)) $this->m_A = $value; }
	public function __construct($r, $g, $b, $a)
	{
		$this->m_R = $r;
		$this->m_G = $g;
		$this->m_B = $b;
		$this->m_A = $a;
	}
	public static function FromFloat($rgb, $g=null, $b=null,$a=null)
	{
		
		if ($g===null)
			return new IGKColor($rgb * 255,$rgb*255, $rgb*255, 255);

		return new IGKColor($rgb * 255,$g*255, $b*255, $a*255);
	}
	public static function FromString($s)
	{
		$c = IGKColorf::FromString($s);
		return self::FromFloat($c->R, $c->G, $c->B, 255);
	}
}


//------------------------------------------------------------------------------------------
//HTML DEFINITION
//------------------------------------------------------------------------------------------

//represent a html options
class IGKHtmlOptions
{
	//indicate that the tag must be closed with  "/>"
	static $MustCloseTag = array(
	"br"=>"br",
	"link"=>"link",
	"input"=>"input",
	"meta"=>"meta",	
	"img"=>"img",
	//"script"=>"script"	
	"source"=>"source",
	"embed"=>"embed"
	);
	static $DualCloseTag = array("option"=>"option", "object");
	
	static $closeWithCloseTags =array(
		"div"=>"div",
		"form"=>"form",
		"script"=>"script",
		"noscript"=>"noscript",
		"html"=>"html",
		"body"=>"body",
		"head"=>"head"
	);
	
}
class IGKHtmlAttributeCollections 
extends IGKObject
implements ArrayAccess, Iterator
{
	private $m_attributes;
	private $m_owner;
	// get the total number of attributes
	
	public function Dispose()
	{
		//dispose elements 
		igk_debug_wln("dispose attributes");
	}
	public function getCount(){return igk_count($this->m_attributes);}
	public function __construct($owner){
		if (($owner === null) || !is_object($owner) || (is_object($owner) && !igk_reflection_class_extends(get_class($owner), IGK_HTML_ITEMBASE_CLASS)))
			throw new Exception("owner must be a HTML Item Base");
		$this->m_owner = $owner;
		$this->m_attributes = array();
	}
	public function ToArray(){		
			return $this->m_attributes;		
	}
	//Clear attribute
	public function Clear(){//clear attributes
		$this->m_attributes = array();
	}
	//iterator
	public function __toString(){
		return "HtmlAttributeCollections [".$this->getcount()."] ";
	}
	private $it_index;//value tab index
	private $it_key; //key index
	private $it_vtab;//keys value tab
	function current(){ return $this->m_attributes[$this->it_key];}
	function next(){
		$this->it_index++;
		if ( $this->it_index < count($this->it_vtab))
		{		
			$this->it_key  = $this->it_vtab[$this->it_index]; 
		}
	}
	function key(){ return $this->it_key;}
	
	function valid(){
	
		$v = (($this->it_index >= 0) && ($this->it_index < count($this->it_vtab)));	
		
		return $v;
	
	}
	function rewind(){ 
		
		$this->it_vtab = array_keys($this->m_attributes);
		$this->it_index = 0;
		if (count($this->it_vtab)>0)
			$this->it_key = $this->it_vtab[0];		
		else
			$this->it_key  = null;
		
	}
	
	//arrayaccess
	function offsetExists($key){
		if (is_object($key))
			throw new Exception("offsetExists :: keys is object ");		
		return isset($this->m_attributes[$key]);
	}
	function offsetGet($key){
	if (isset($this->m_attributes[$key]))
		return $this->m_attributes[$key];
	}
	function offsetSet($key, $value){//htmlitem
		switch(strtolower($key))
			{
			case "class":
			{
				if ($value ===null)
				{
						unset($this->m_attributes[$key]);
				}
				else{
					if (!isset($this->m_attributes[$key]) || !is_object($this->m_attributes[$key]))
					{
						 $this->m_attributes[$key] = new IGKHtmlClassValueAttribute($this);
					}					
					$this->m_attributes[$key]->add($value);
				}
			}
			break;
			case "rmclass":				
				$tb = explode(" ",$value);
				foreach($tb as $k=>$v){
					$v = trim($v);
					if (empty($v))
						continue;
					$this->offsetSet("class","-".$v);										
				}
				break;
	default:
		if (IGKString::StartWith($key, 'igk:'))
		{
			//sending attribute to owner
			$this->m_owner->setSysAttribute(substr($key,4), $value);
			
		}else{
	
		if (isset($this->m_attributes[$key]))
		{
			if ($value ===null)
				unset($this->m_attributes[$key]);
			else
				$this->m_attributes[$key] = $value;
		}
		else if ($value !== null)
		{
			$this->m_attributes[$key] = $value;
		}
		}
		break;
		}
	}
	function offsetUnset($key){
	unset($this->m_attributes[$key]);
	}	
	
	
}

abstract class IGKHtmlItemBase extends IGKObject implements ArrayAccess
{
	private $m_tagName;
	private $m_content;	
	private $m_parent; //igk hierarchie parent
	private $m_previousCiblingParent; //real cibling parent
	private $m_parentHost; //parentHost
	private $m_index;	
	protected $m_IsVisible;
	private $m_params;
	
	public function SaveToFile($file)
	{
		if (!empty($file))
			IGKIO::WriteToFileAsUtf8WBOM($file, $this->Render(null), true);
	}
	//
	public function __call($name, $arguments)
	{
		if (IGKString::StartWith($name, "add"))
		{
			$k = substr($name, 3);
			if (!empty($k))
			{				
			
				$tab = array($k, null,null);				
				$tab = array_merge($tab, $arguments);					
				return call_user_func_array(array($this,"add") , $tab);	
			}
		}		
	}

	public function getNodeType(){return IGKXMLNodeType::ELEMENT; }
	public function getIsVisible(){return $this->m_IsVisible;}
	public function setIsVisible($value){$this->m_IsVisible = $value;}
	
	public function getIndex(){return $this->m_index; }
	public function setIndex($value){ $this->m_index = $value; }
	
	public function getTagName(){return $this->m_tagName;}
	public function getContent(){return $this->m_content;}
	public function setContent($value){$this->m_content = $value; return $this;}
	
	
	///<summary>get ParentNode. attention to referrence model. & is removed to allow setting the value</summary>
	public function getParentNode(){ return  $this->m_parent;}
	
	///<summary>get the parent document </summary>
	public function getParentDocument(){
		if ($this->m_parent )
		{
			$cl = get_class($this->m_parent) ;		
			if ($cl == "IGKHtmlDoc"){			
				return $this->m_parent;
			}
			return $this->m_parent->getParentDocument();
		}
		return null;
	}
	
	public function isCloseTag($tag)
	{
		if (IGKString::StartWith($tag, "igk:"))
			$tag = substr($tag, 4);
		if (strtolower($this->tagName) == strtolower($tag))
			return true;
		return $this->_p_isClosedTag($tag);
	}
	protected function _p_isClosedTag($tag)
	{
		return false;
	}
	//set parent of this node
	protected function setParentNode($value, $context=null)
	{
		if (($value == null) && ($context=="ClearChilds"))
		{
			$this->ClearChilds();
		}
		$this->m_parent = $value;
	}
	protected function setPreviousCiblingParent($value)
	{
		$this->m_previousCiblingParent = $value;
	}
	public function getParentHost(){		
		return $this->m_parentHost;		
	}
	public function setParentHost($host){
		if (($host == null) || igk_reflection_class_extends($host, __CLASS__))
		{
			$this->m_parentHost = $host;
		}
		
	}
	public function __construct($tagname=null)
	{
			$this->m_tagName = $tagname;
			$this->m_IsVisible = true;
			$this->m_content = null;
			$this->m_index = null;
			$this->m_params = array();
	}
	public function getParam($key){
		return igk_getv($this->m_params, $key);
	}
	public function setParam($key, $value){
		$this->m_params[$key] = $value;
	}
	public function unsetParam($key){
		if (isset($this->m_params[$key]))
			unset($this->m_params[$key]);
	}
	protected function indentLine($option=null){
		if (($option==null) || (!$option->Indent))
			return null;		
		return "\n";
	}
	protected function getDepthIndent(& $options)
	{
		if (($options==null) || (!$options->Indent))
			return null;
		$q = $this;
		$s = IGK_STR_EMPTY;		
		if (isset($options->ParentDepth)){			
			while(($q = $q->m_parent) && !($options->ParentDepth->CompareTo($q)))
			{				
				$s .= "\t";
			}						
		}
		else{		
			while($q = $q->m_parent)
			{
				$s .= "\t";
			}
		}
		return $s;
	}
	///<summary>indicate that the element must be closed with close tag. <i></i> not  if empty</summary>
	protected function closeWithCloseTag()
	{
		return isset(IGKHtmlOptions::$closeWithCloseTags[$this->getTagName]);		
	}
	/// must be overrided
	public function Render($options=null){ //render IGKHtmlItemBase must be overrided in child to render the node or item
	}
	public function RenderAJX($options =null){//render in ajx context. directly to client side.
		igk_wl($this->Render($options));
	}
	public function RenderXML(){//render for global item
		header("Content-Type: application/xml");
		$this->RenderAJX(new IGKXmlRenderOptions());
	}
	public function getinnerHTML($options=null){return $this->innerHTML($options);}
	//override this for inner settings
	protected function innerHTML(& $options=null){return null;}
	public function addBr($style=null){
		$br =  $this->add("br", $style);		
		return $br;
	}
	/// add horizontal separator
	public function addHSep(){
		return $this->add(new IGKHtmlSeparatorItem());
	}
	/// add vertical separator
	public function addVSep(){
		return $this->add(new IGKHtmlSeparatorItem("vertical"));
	}
	public function addSpace(){
		$this->add(new IGKHtmlText("&nbsp;"));
		return $this;
	}
	public function addForm($attributes = null, $index=null){
		return $this->add("form", $attributes, $index);
	}
	public function addSelect($id, $attributes=null, $index=null){
		$s =  $this->add("select", $attributes, $index);
		$s["name"] = $s["id"] = $id;
		return $s;
	}
	public function addTable($attributes = null, $index=null){		
		return $this->add("table", $attributes, $index)->setClass("igk-table");
	}
	public function addDiv($attributes=null, $index= null){
		return $this->add("div", $attributes, $index);
	}
	public function addElement($tagname, $attributes=null, $index=null)
	{
		$s = new IGKHtmlItem($tagname);
		if ($this->add($s)){
			$this->AppendAttributes($attributes);
			return $s;
		}
		unset($s);
		return null;
	}
	public function addImgLnk($href, $img){
		return IGKHtmlUtils::AddImgLnk($this, $href, $img);
	}
	public function addA($href, $attributes = null, $index=null)
	{
		$a = $this->add("a", array("href"=>$href), $index);
		if ($a){
			$a->AppendAttributes($attributes);
		}
		return $a;
	}
	
	public function addIFrame($id,$uri,  $attributes = null, $index=null){
		$frm = $this->add("iframe", null, $index);
		if ($frm == null) return null;
		
		$frm["id"] = $id;
		$frm["src"] = $uri;		
		$frm["class"] = "cliframe";
		$frm->AppendAttributes($attributes);
		return $frm;
	}
	public function addObject($uri, $attributes = null)
	{
		$obj = $this->add("object");
		if ($obj ==null)return null;
		
		$obj["data"] = $uri;		
		$obj->AppendAttributes($attributes);
		return $obj;
	}
	//add a label
	public function addLabel($key, $for=null, $attributes=null)
	{
		$lb = $this->add("label");
		$lb["for"] = $for;		
		$lb->Content = R::ngets($key);
		$lb->AppendAttributes($attributes);
		return $lb;
	}
	public function addInput($id, $type="text",$value=null, $attributes=null)
	{
			$i = $this->add("input");
			if ($i){
			$i["type"]=$type;
			$i["value"]= ($value==null)? igk_getr($id, null): $value; 
			$i["id"]=$i["name"]=$id;
			$i["class"] = "cl".$type;
			$i->AppendAttributes($attributes);
			}
			return $i;
	}
	public function addFile($id , $multiselect = false, $attributes=null)
	{
			$i = $this->add("input");
			if ($i){
			$i["type"]="file";
			$i["id"]=$id;
			$i["name"]= $multiselect? $id."[]": $id;
			$i["class"] = "clfile";
			$i["multiple"]="true";
			$i->AppendAttributes($attributes);
			}
			return $i;
	}
	///<summary>add inline script to node</summary>
	public function addScript($file= null, $canBeMerged = true ){//add inline script to node script
		$s = $this->add("script");
		$s["src"] = $file;
		$s->canBeMerged = $canBeMerged;
		return $s;
	}
	public function addNothing(){
		$c = new IGKHtmlNothingItem();
		$this->add($c);
		return $c;
	}
	public function addSLabelCheckbox($id, $value=false, $attributes =null, $require=false)
	{
		
		$tab = $this->addLabelInput($id, R::ngets("lb.".$id), $type="checkbox",$value, $attributes, $require);
		if ($value)
		{
			$tab->input["checked"] = true;
		}		
		return $tab;
	}
	//add system label input
	public function addSLabelInput($id, $type="text",$value=null, $attributes=null, $require=false, $description=null){	
		return $this->addLabelInput($id, R::ngets("lb.".$id), $type, $value, $attributes, $require, $description);
	}
	public function addSLabelSelect($id, $values, $valuekey = false, $defaultCallback=null, $required=false)
	{
			$i = $this->add("label");
			$i["for"]=$id;
			if ($required)
			$i->add("span", array("class"=>"clrequired"))->Content = "*";
			$i->Content =  R::ngets("lb.".$id);
			$h = $this->add("select");
			$h->setId($id);
			if (is_array($values))
			{
				
				foreach($values as $k=>$v)
				{
					$opt = $h->add("option");
					$opt["value"] = IGK_STR_EMPTY.$k;
					$opt->Content = $valuekey? R::ngets("option.".$v) :$v;
					if (($defaultCallback ) && $defaultCallback($k,$v))
						$opt["selected"] = true;
				}
			}
			return (object)array("label"=>$i, "input"=>$h);
	}
	public function addLabelInput($id, $text, $type="text",$value=null, $attributes=null, $require=false, $description=null){
			$i = $this->add("label");
			$i["for"]=$id;
			
			if ($require)
			{
				$i->Content = $text;
				$i->add("span", array("class"=>"clrequired"))->Content = "*";
			}
			else 
				$i->Content = $text;
			switch($type)
			{
				case "checkbox":
				case "radio":
					$h = $this->addInput($id, $type,$value, $attributes);
					if ($value)
					{
						$h["checked"] = "true";
					}
				break;
			default:
					$h = $this->addInput($id, $type,$value, $attributes);					
				break;
			}
			
			$desc = null;
			if ($description){
				$desc = $this->add("span");
				$desc->Content = $description;
			}
			return (object)array("label"=>$i, "input"=>$h, "desc"=>$desc);
	}
	
	public function addSLabelTextarea($id, $text, $attributes=null, $require=false, $description=null)
	{
			$i = $this->add("label");
			$i["for"]=$id;
			
			$i->Content = R::ngets($text);
			if ($require)
			{
				$i->add("span", array("class"=>"clrequired"))->Content = "*";
			}			
			$h = $this->addTextArea($id);
			$h->AppendAttributes($attributes);
			$desc = null;
			if ($description){
				$desc = $this->add("span");
				$desc->Content = $description;
			}
			return (object)array("label"=>$i, "textarea"=>$h, "desc"=>$desc);
	}
	
	public function addBtn($name, $value, $type="submit", $attributes=null){
		$btn = self::CreateWebNode("input");
		$btn["id"] = $btn["name"] = $name;
		$btn["value"] = $value;
		$btn["type"]=$type;
		$btn["class"]="cl".$type;		
		$this->add($btn, $attributes);
		return $btn;
	}
	public function addTextArea($name, $content =null, $attributes =null){
		$tx = self::CreateWebNode("textarea");		
		$tx["id"] = $tx["name"] = $name;
		$tx["class"] ="cltextarea";
		$this->add($tx, $attributes);
		if ($content == null)
			$tx->Content = igk_getr($name);
		else 
			$tx->Content = $content;
		return $tx;
	}

	public function addText($string)
	{
		$this->add(new IGKHtmlText($string));
	}
	
	//create a web node with is value
	public static function CreateWebNode($name, $attributes=null, $index=null)
	{
		$c = null;
		if (!empty($name))
		{
			switch(strtolower($name))
			{
				case "a":
					$c = new IGKHtmlA();
					break;
				case "table":
					$c = new IGKHtmlTable();
					break;
				case "textarea":
					$c = new IGKHtmlTextarea();
					break;
				case "script":
					$c = new IGKHtmlScript();
					break;
				case "meta":	
					$c=  new IGKHtmlMeta();
					break;
				case "input":
					$c =  new IGKHtmlInput();
					break;
				case "igk-html-image":
				case "igk-img":
				case "img":
				case "image":
					$c =  new IGKHtmlImg();
					break;
				case "ul":
					$c = new IGKHtmlUl();
					break;
				case "form":
					$c = new IGKHtmlForm();
					break;
				case "label":
					$c =  new IGKHtmlItem($name);
					$c["class"]="cllabel";
					break;
				case "div":
					$c = new IGKHtmlDiv();
					break;
				default:
					$f = IGKString::Format(IGK_HTML_NODE_FORMAT, $name);
					if(class_exists($f) && !igk_reflection_class_isabstract($f) && igk_reflection_class_extends($f, __CLASS__) )
					{	
						$p = new ReflectionClass($f);	
						$tb = array_slice(func_get_args() , 3);						
						$o = call_user_func_array(array($p, "newInstance"), $tb);
						if ($o )
							$c =  $o;
						else 
							$c = new $f();
					}
					else					
						$c = new IGKHtmlItem($name);
					break;
			}			
		}
		else 
			$c = new IGKHtmlText();	
		if ($c && $attributes)
		{
			$c->AppendAttributes($attributes);
		}
		
		return $c;
	}
	
	public static function CreateElement($name){
		if (!empty($name))
		{
			if (IGKString::StartWith($name, 'igk:'))
			{
				$n = substr($name, 4);
				$f = self::CreateWebNode(substr($name, 4));
				if ($f)
					return $f;
			}		
			return new IGKHtmlItem($name);
		}
		return null;
	}
	///Load node a single node if found 
	public static function LoadNode($text)
	{
		if(empty($text))
			return null;
			
		$v_dummy =  IGKHtmlItem::CreateWebNode("dummy");
		$v_dummy->Load($text);
		if ($v_dummy->HasChilds)
		{
			return $v_dummy->Childs[0];
		}
		return null;
	}
	//return attribute that match the html requirement for rendering
	public static function GetStringAttribute($v, $options)
	{
		if (empty($v))
			return null;
		if (is_object( $v)&& method_exists(get_class($v), "getValue"))
		{
			return self::GetStringAttribute($v->getValue($options), $options);
		}
		else if (is_string($v))
		{	
			if (IGKString::StartWith($v, "\""))
			{			
				return $v;
			}
			if (IGKString::StartWith($v, "\'"))
				return $v;		
		}
		$v = str_replace("\"", "&quot;", $v);
		if (is_array($v))
		{
			igk_show_prev($v);
			igk_exit();
		}
		return "\"".$v."\"";
	}
	
	public function & getElementsByTagName($name){$tab = array(); return $tab;
	}
	public function getElementById($name){return null;
	}
	public function __toString(){
		return "HtmlItemBase [".$this->Render()."]";
	}
	///public load content
	public function Load($content){
		$d = IGKHtmlReader::Load($content);
		if ($d){
			$d->CopyTo($this);
			return true;			
		}
		return false;
	}
	/// load file content
	public function LoadFile($file)
	{
		if (file_exists($file))
		{
			return $this->Load(IGKIO::ReadAllText($file));
		}
		return false;
	}
	public function setSysAttribute($key, $value){//override this to setup your custom attribute
		$t = array("style"=>"class");
		
		$m = igk_getv($t, strtolower($key));		
		if ($m){
			$this[$m] = strtolower("+igk-".$this->getItemType()."-". $value);
		}
		else{
			$k = "set".$key;
			if (method_exists( $this, $k))
			{
				$this->$k($value);
			}
			else{
			igk_wln("not define " .$key. " ::: ".$value . " ::: ".get_class($this));
			throw new Exception("d");
			}
		}
		return $this;
	}
	public function setSysAttributes($attributes)
	{
		if (is_array($attributes))
		{
			foreach($attributes as $k=>$v)
			{
				$this->setAttribute($k,$v);
			}
		}
		return $this;
	}
	public function getItemType(){
		$exp = "/^(IGKHtml)(?P<name>[\w_-]+)Item$/i";
		$v = get_class($this);
		$t = array();
		if (igk_reflection_class_extends( $v,  __CLASS__) && !igk_reflection_class_isabstract($v) && preg_match($exp, $v) )
		{
			preg_match_all($exp, $v, $t);
			return $t["name"][0];
		}
		return "unknow";
		
		
	}
	public function __set($key, $value){ //HtmlItemBase
		if (IGKString::StartWith($key, "igk:"))		
		{
			$this->setSysAttribute(substr($key, 4), $value);
			return;
		}
		if (!$this->_setIn($key, $value))
		{
			$this->$key = $value;
		}
	}	
	function offsetExists($key){
	}
	function offsetGet($key){
	}
	function offsetSet($key, $value){//nothing	
	}
	function offsetUnset($key){//nothing
	}	
}

class IGKHtmlChildElementCollections 
extends IGKObject
implements ArrayAccess, Iterator
{
	private $m_owner;  //owner of the childs
	private $m_childs; //array of childs
	private $it_index;  //referet inde
	public function ToArray(){
		$t = array_values($this->m_childs); 
		return $t;
	}
	public function getCount(){return count($this->m_childs); }
	public function getKeys(){ return array_keys($this->m_childs); }
	
	//</summary>Clear array</summary>
	public function Clear()	{//Clear child collection
		$this->m_childs = array();
	}
	public function Sort($params)
	{
		igk_usort($this->m_childs, $params);
	}
	public function __construct($owner)
	{
		$this->m_owner = $owner;
		$this->m_childs = array();
		$this->it_index = 0;
	}
	public function & __get($key)
	{
		if (is_numeric($key))
		{
			return $this->m_childs[$key];
		}
		return $this->m_owner->getElementById($key);
	}
	//iterator
	function current(){ 
		return $this->m_childs[$this->it_index];
	}
	function next(){	
		$this->it_index++;
	}
	function key(){ return $this->it_index;}
	
	function valid(){
		return ($this->it_index>=0) && ($this->it_index< count($this->m_childs)) && isset($this->m_childs[$this->it_index]);
	}
	function rewind(){ 
		$this->it_index = 0;		
	}
	
		//arrayaccess
	function offsetExists($key){	
			$v= ($key>=0) && ($key< count($this->m_childs)) && isset($this->m_childs[$key]);		
			return $v;
	}
	function offsetGet($key){					
		if (isset($this->m_childs[$key]))
			return $this->m_childs[$key];
		return null;
	}
	function offsetSet($key, $value){//IGKHtmlChildElementCollections		
		
		if (empty($key))
		{			
			$c = $value;
			if ($c == null)
			{
				throw new Exception("setting null");
			}			
			$this->m_childs[] = $c;
		}
		
	}
	function offsetUnset($key){ 
		
		$tab = $this->m_childs;
		if (count($tab)<=0)
			return;
			
		$p = igk_getv($tab, $key, null);
		if($p !=null)
		{
			unset($tab[$key]);	
			if (count($tab)==0)
			{
				$this->m_childs =array();
			}
			else{ 
				$this->m_childs = array_values($tab);		
			}
			if ((count($tab) >0) &&  (igk_getv($this->m_childs, 0, null) == null))
			{
				//igk_wln("value 0 is null ==== [0]/ ".count($this->m_childs) ." ::: ". ($p == null));
				igk_show_prev(array_keys($this->m_childs ));
			}
		}
		
	}
	public function __toString() {
		return "HtmlChilds [ ".count($this->m_childs)." ]";
	}
	
	public function Dispose()
	{//dispose elements 
		$t = $this->ToArray();
		$ti = 0;
		foreach($t as $k)
		{
			if ($k)
				$k->Dispose();
			else{
				throw new Exception("was disposed?");
			}
			$ti++;
		}
	}
}



/// represent a html item
class IGKHtmlItem extends IGKHtmlItemBase
implements ArrayAccess
{
	private $m_childs;
	private $m_attachChilds;
	private $m_attributes;
	private $m_sortRequired;
	
	public function getAttributesKeys(){
		$tab = array();
		foreach($this->m_attributes as $k=>$v){
			$tab[] = $k;
		}
		return $tab;
	}
	
	public function setId($name)
	{
		$this["id"]=$this["name"] = $name;
		return $this;
	}
	public function setClass($value){
		$this["class"]=$value;
		return $this;
	}
	public function setStyle($value){
		$s = "";
		if (IGKString::StartWith($value,'+/'))
		{
			$s = $this["style"];
			$value = substr($value, 2);
		}
		$this["style"]= igk_css_treatstyle($value);
		return $this;
	}
	public function setAttribute($key, $value){
		$this[$key]=$value;
		return $this;
	}
	public function setAttribute_assert($assert, $key, $value){
		if ($assert){
			$this[$key]=$value;
		}
		return $this;		
	}
	public function setAttributeç($assert, $key, $value){
		return $this->setAttribute_assert($assert, $key, $value);		
	}
	public function setAttributes($item){
		foreach($item as $k=>$v)
		{
			
			$this[$k]=$v;
		}
		return $this;
	}
	
	public function attachChild($node)
	{
		if ($this->m_attachChilds == null)
		{
			$this->m_attachChilds  = array();
		}
		$this->add($node);
		$this->m_attachChilds[] = $node;
		return $this;
	}
	public function detachChild($node)
	{
		$tab = $this->m_attachChilds;
		$i = 0;
		while($i<count($tab))
		{
			if ($tab[$i] == $node)
			{
				unset($tab[$i]);
			}
			$i++;			
		}
		$this->m_attachChilds = array_values($tab);
		igk_html_rm($node);
	}
	
	public function getHasAttachedChild()
	{
		return (($this->m_attachChilds) && (igk_count($this->m_attachChilds) > 0));
	}
	public function Dispose()
	{
		//dispose childs
		if ($this->m_childs)
			$this->m_childs->Dispose();
		//dispose attribute
		if ($this->m_attributes)
			$this->m_attributes->Dispose();
	}
	public function getHasAttributes(){return ($this->m_attributes->getCount()>0); }
	///<summary>get the childs collection</summary>
	public function getChilds(){return $this->m_childs;}
	
	public function copyAttributes($node, $erase=true)
	{
		if ($node->HasAttributes)
		{
			foreach($node->m_attributes as $k=>$v)
			{
				if ($erase)
				{
					if (is_object($v ))
					{
						if (get_class($v ) == "IGKHtmlClassValueAttribute")
						{							
							$this[$k]= $v->getValue();
							continue;
							
						}						
					}
					$this[$k]=$v;
				}
				else{
					if (igk_getv($this->m_attributes, $k)==null)
					{
						$this[$k] = $v;
					}
				}
			}
		}
	}
	///<summary>get attributes collection</summary>
	public function getAttributes(){return $this->m_attributes;}
	
	public function getChildAtIndex($index){
		$e = igk_getv($this->m_childs, $index);		
		return $e;
	}
	
	public function getChildCount(){return igk_count($this->m_childs); }
	public function getHasChilds(){return ($this->ChildCount > 0);}
	public function getSortRequired(){return $this->m_sortRequired;}
	
	public function __toString(){
		return  get_class($this)."[ ".$this->TagName." ] ; Attributes : [".($this->m_attributes?$this->m_attributes->getCount():0)."] ; Childs : [ ".$this->ChildCount." ]";
	}
	//---------------------------------------------------------------------------------------------
	//IGKHtmlItem child functions 
	//---------------------------------------------------------------------------------------------
	public function ClearChilds(){ //IGKHtmlItem	
		$this->__rm_childs(__FUNCTION__);	
	}
	public function RemoveChilds(){//Same as ClearChidld but context is RemoveChild
		$this->__rm_childs(__FUNCTION__);	
	}
	protected function __rm_childs($context)
	{
			if ($this->ChildCount >0)
		{
			foreach($this->Childs as $k=>$v)
			{
				if ($v === $this){
					continue;
				}
				else{					
					$v->setParentNode(null, $context);
				}
			}		
			$this->Childs->Clear();
		}
		if ($this->m_attachChilds)
		{
			//maintain attached childs
			foreach($this->m_attachChilds as $v)
			{
				$this->add($v);
			}
		}
	}
	
	
	//<summary>Clear all in current node</summary>
	public function Clear()	{//Clear current node
		$this->Content = null;
		$this->ClearChilds();
	}
	protected function _AddChild($child, $index=null)
	{ 
		if (isset(IGKHtmlOptions::$MustCloseTag[$this->TagName]))
		       return false;
		//push childs
		$this->m_childs[] = $child;  
		$this->setupChild($child, $index, __FUNCTION__);
		$this->m_sortRequired = true;
		return true;
	}
	protected function setupChild($child, $index, $context){		
		$child->setParentNode($this, $context);
		$child->setPreviousCiblingParent($this, $context);
		$this->_setUpChildIndex($child, $index);
	}
	private function _setUpChildIndex(
		$childs, 
		$index=null)
	{				
		if ($index === null)
		{
			$i = $childs->Index;
			if (!is_numeric($i))
			{				
				$childs->setIndex($this->ChildCount-1);
			}
		}
		 else if(is_numeric($index)){ 		
			$childs->setIndex($index);
		}		
	
	}
	public function AddRange($arrayChilds)
	{
		if (is_array($arrayChilds))
		{
		foreach($arrayChilds as $k){
			$this->add($k);
		}
		return true;
		}
		return false;
	}
	public function addTo($target)
	{
		if ($target){
			$target->add($this);
		}
	}
	
	public function addPrev($itemorarray)
	{		
		$p = $this->add("pre");
		igkOb::Start();		
		print_r($itemorarray);
		$c = igkOb::Content();
		igkOb::Clear();
		$p->Content = $c;
		return $p;
	}
	
	public function addTableBuild($itemorarray, $filter = null)
	{		
		$p = $this->addDiv();
		if (is_array($itemorarray) || is_object($itemorarray))
		{
			$tab = $p->addTable();
			$tr = $tab->add("tr");			
			$tr->add("th")->Content = "Key";
			$tr->add("th")->Content = "Value";		
			foreach($itemorarray as $k=>$v)
			{
				$tr = $tab->add("tr");			
				$tr->add("td")->Content = $k;
				$tr->add("td")->Content = $v;
			}
		}		
		else{
			$p->Content = $itemorarray;
		}
		return $p;
	}
	///<summary>
	///add child to this node.
	///</summary>
	///<param name="nameorchilds">tagname or HtmlItem element</param>
	///<param>array of attribute</param>
	///<param>Required index</param>	
	public function add($nameorchilds, $attributes =null, $index = null)
	{
		$node = null;
		
		if ($nameorchilds === null)
			return null;
		if (is_string($nameorchilds))
		{
			$node =  call_user_func_array(array(get_class($this), 'CreateWebNode'), func_get_args());
			if (!$this->_AddChild($node))
			{
				$node = null;
			}
			
		}
		else if(is_object($nameorchilds) && igk_reflection_class_extends(get_class($nameorchilds), IGK_HTML_ITEMBASE_CLASS))
		{			
		    $b = $nameorchilds->parent;
			if (($b !== $this) &&
			    $this->_AddChild($nameorchilds))
			{
				$node = $nameorchilds;
				if ($b!=null){
					$b->remove($node);
				}
			}
		}
		else 
		{			
			igk_wln("Something wrong forchild = ". $nameorchilds);
			throw new Exception("Exception:::Tag not valid");
			igk_exit();
		}
		if($node)
		{
			if ($attributes)
			{
				$node->AppendAttributes($attributes);
			}
			if ($index)
			{
				$node->setIndex($index);
			}
			else{
				//gk_wln("auto index");
				$node->setIndex($this->ChildCount);
			}
		}
		return $node;
	}
	///add attribute array
	public function AppendAttributes($attributes =null)
	{	
		if (is_array($attributes)){
			foreach($attributes as $k=>$v)
			{
				$this[$k]=$v;
			}
		}
		return $this;
	}
	protected function __sortChild()
	{
		if ($this->SortRequired)
		{		
			igk_usort($this->m_childs, array("IGKHtmlItem", "SortChild" ));
			$this->m_sortRequired = false;
		}
	}
	public static function SortChildCallBack($item, $callback){
		$item->m_sortRequired = false;
		igk_usort($item->m_childs, $callback);	
		
	}
	public static function SortChild($a, $b){
		
		if ($a->Index == $b->Index)
			return 0;
		return ($a->Index < $b->Index)? -1 : 1;
	}
	public function __construct($tagname)
	{
		parent::__construct($tagname);
		$this->m_childs = new IGKHtmlChildElementCollections($this);
		$this->m_IsVisible = true;
		$this->m_attributes = new IGKHtmlAttributeCollections($this);		
	}
	protected function innerHTML(& $options=null){//html item itnner html
		
		$out = IGK_STR_EMPTY;
		$c = $this->Content;
		if (empty($c) && isset(IGKHtmlOptions::$MustCloseTag[$this->TagName]) &&($this->ChildCount == 0))
		{	
			return null;
		}
		else {
			
			$s =IGKHtmlUtils::GetContentValue($c);
			if ($s == "0")
			{
				$out .= "&#48;";
			}			
			else{
				if (!empty($s))
				{
					$v_depth = $this->getDepthIndent($options);
					$v_iline = $this->indentLine($options);
					$out .= $v_iline.($v_depth?$v_depth."\t":null).$s;
				}
			}
			
			$out .= $this->__renderChild($options);		
		}
		return $out;
	}
	private function __renderChild(& $options = null)
	{
			
			$out = IGK_STR_EMPTY;
			$this->__sortChild();		
			$ch = $this->Childs->ToArray();		
			$v_depth = $this->getDepthIndent($options);		
			$v_iline = $this->indentLine($options);
			$k = 0;
			foreach($ch as $k=>$v)
			{
				if ($v->getIsVisible()){
					
					$out .=$v_iline.$v_depth;					
					$out .= $v->Render($options);
					$k = 1;
				}
			}	
			return $out;
	}
	public function getAttributeString($options=null)
	{
	
	if ($this->HasAttributes)
		{
			$out = IGK_STR_EMPTY;
			foreach($this->Attributes as $k=>$v)
			{
				if (IGKHtmlNoValueAttribute::IsNoValue($v))
				{
					$out .= $k." ";
					continue;
				}
				$c = self::GetStringAttribute($v, $options);
				if (!empty($c)){
					if (!empty($out))
						$out .= " ";
					if ($options && igk_getv($options, "UseInXml")){
						//treat for xml
						$c = str_replace('&','&amp;', $c);
					}	
						
					$out .= $k."=".$c;
				}
			}
			return $out;
		}
		return null;
	}
	public function RenderInNode($nodename){
		$n =  IGKHtmlItem::CreateWebNode($nodename);
		$n->setContent($this->Render());
		$n->RenderAJX();
	}
	
	public function Render($options=null){//render IGKHtmlItem			
		$v_depth = $this->getDepthIndent($options);		
		$v_iline = $this->indentLine($options);
		$v_indent = igk_getv($options, "Indent", false);
		$out = IGK_STR_EMPTY;
		$v_tagname = $this->getTagName();
		if  ($v_indent ) 
		{	//$out.= $v_iline;
			//$out.= "::/".$v_depth;
		}
		$out.= "<".$v_tagname;
		if ($this->HasAttributes)
		{
			$s = trim($this->getAttributeString($options));
			if (!empty($s))
				$out.= " ".$s;
		}	
		if (empty($c) && !$this->closeWithCloseTag()  && igk_html_mustclosetag($v_tagname) &&($this->getChildCount() == 0) )
		{
			$out .=" />".$v_iline;			
		}
		else {
			$out .= ">";			
			$h = $this->innerHTML($options);
			$s = trim($h);
			if (!empty($s))
			{
				$out .= $h;//."%".$v_iline."-".$v_depth;			
				if ($v_iline){
					$out.=$v_iline;
				}
			}
			$out .= "</".$v_tagname.">";	
		}
		return $out;
	}
	public function & getElementsByTagName($name){//get elements by tags name
			$tab = array();
			$s = strtolower($name);
			if( $this->m_childs )
			{
				
				if ($name == "*")
				{
					$tab = array_merge ($tab , $this->m_childs->ToArray());
					foreach($this->m_childs as $k)
					{
						$c = $k->getElementsByTagName($s);						
						if (is_array($c) && (count($c)>0))
							$tab = array_merge($tab, $c);
					}
				}
				else{
				foreach($this->m_childs as $k)
				{
					if (strtolower($k->TagName) == $s){						
						$tab[] = $k;
					}
					$c = $k->getElementsByTagName($s);						
					if (is_array($c) && (count($c)>0))
						$tab = array_merge($tab, $c);
				}
				}
			}
			return $tab;
	}
	//retrieve all element that match the current attribute value
	public function getElementByAttribute($name, $value)
	{
		if ($this->m_childs==null)
			{
				return null;
			}
			$tab = array();
			$s = strtolower($value);
			foreach($this->m_childs as $k)
			{
				if (strtolower($k[$name]) == $s)
					$tab[] = $k;
				$r = $k->getElementById($s);
				if (is_array($r))
					$tab = array_merge($tab, $r);
				else if ($r)
					$tab[] = $r;
			}
			if (count($tab)== 1)
				return $tab[0];
			return $tab;
	}
	//get element by id
	public function getElementById($id)
	{	
		if ($this->m_childs==null)
		{
			return null;
		}
				$tab = array();
				$s = strtolower($id);
			foreach($this->m_childs as $k)
			{
				if (strtolower($k["id"]) == $s)
					$tab[] = $k;
				$r = $k->getElementById($s);
				if (is_array($r))
					$tab = array_merge($tab, $r);
				else if ($r)
					$tab[] = $r;
			}
			if (count($tab)== 1)
				return $tab[0];
			return $tab;
	}
	//Remove childs
	public function remove($child)
	{
		
		$v_deleted = false;
		
		if (($this->m_childs ==null) ||($child == null))
			return $v_delete;
		
			for	($i = 0; $i< igk_count($this->m_childs); $i++)
			{				
				if (isset($this->m_childs[$i]) )
				{
					if ( ($this->m_childs[$i] === $child) )
					{
						unset($this->m_childs[$i]);				
						$child->setParentNode(null, __FUNCTION__);
						$v_deleted = true;	
						break;
					}
				}
				else{
					igk_wln(" index ".$i." not found ". $child["id"]);
				}
			}
			if ($v_deleted)
			{
				//remove all reference
				$v_deleted |= $this->remove($child);				
			}
			return $v_deleted;
	}
	
	public function removeChildAt($index)
	{
		$p  = igk_getv($this->m_childs, $index , null);
		if ($p)
		{			
			unset($this->m_childs[$index]);				
			$p->setParentNode(null);
			return true;
		}				
		return false;
	}	
	//arrayaccess
	function offsetExists($key){
		return $this->m_attributes->offsetExists($key);
	}
	function offsetGet($key){
		if ($this->m_attributes==null)
		{
			igk_wln("try to get an attribute of null .... ".$key." [".$this."]");
			igk_exit();
		}
	return $this->m_attributes->offsetGet($key);
	}
	function offsetSet($key, $value){$this->m_attributes[$key] = $value;}
	function offsetUnset($key){$this->m_attributes->offsetUnset($key);}
}

class IGKXmlRenderOptions extends IGKObject{
	var $Indent;
	var $UseInXml;
	var $Depth;
	
	public function __construct(){
		$this->Indent = true;
		$this->UseInXml = true;
		$this->Depth = 0;
	}
}

class IGKHtmlStylableItem extends IGKHtmlItem
{
	private $m_style;
	public function __construct($tagname){
		parent::__construct($tagname);
		$this->m_style =  new IGKHtmlStyleValueAttribute($this);
		$this["style"] = $this->m_style ;
	}
	public function clear(){
		parent::clear();
		$this["style"] = $this->m_style;
	}
}

//-------------------------------------------------------
//used to render a block node 
//-------------------------------------------------------
final class IGKHtmlBlockNodeItem extends IGKHtmlStylableItem
{
	public function __construct()
	{
		parent::__construct("blockViewItem");		
		
	}
	public function getIsVisible(){
		return $this->HasChilds;
	}
	//<summary>Clear block node</summary>
	public function Clear(){
		igk_debug_wln("blocknodeitem: Clear childs");
	}
	public function ClearChilds(){//override clear content child blocknodeitem
		igk_debug_wln("blocknodeitem: Clear childs");
	}
		
	public function Render($options=null){//render block node item
		$out = $this->getinnerHTML($options);		
		return $out;
	}
}
//------------------------------------------------------------
//only used to render item once
//------------------------------------------------------------
final class IGKHtmlSingleViewItem extends IGKHtmlItemBase
{
	var $targetNode;
	
	public function __construct($node)
	{
		parent::__construct("singleViewItem");
		$this->targetNode = $node;
	}
	public function Render($options=null){//render single view item
		$out = $this->targetNode->Render($options);
		//remove item after rendering
		$p = $this->ParentNode;
		igk_html_rm($this);
		$this->targetNode->ClearChilds();
		return $out;
	}
	protected function _AddChild($item, $index=null){ return false;}
}
//using only to clone the content node 
final class IGKHtmlCloneNodeItem extends IGKHtmlItemBase
{
	var $targetNode;
	public function __construct($node){
		if($node == null)
			throw new Exception("HtmlCloneNodeItem ''node'' not valid");
		parent::__construct("cloneNode");
		$this->targetNode = $node;
	}
	public function Render($options=null){
		$out = $this->targetNode->Render($options);
		return $out;
	}
	protected function _AddChild($item, $index=null){ return false;}
}
interface IIGKHtmlGetValue
{
	function getValue();
}

class IGKHtmlItemAttribute extends IGKObject
implements IIGKHtmlGetValue {
	
	public function getValue(){
		
	}
}
///uri relative value
//@@ used to get the current relative link value according to BASEDIR
final class IGKHtmlRelativeUriValueAttribute extends IGKHtmlItemAttribute
{
	private $m_lnk; //relative path according to base dir
	
	public function __construct($uri = null)
	{
		$this->m_lnk = $uri;
	}	
	public function getValue(){			
		$v = igk_html_uri(igk_io_currentRelativeUri($this->m_lnk));
		return IGKHtmlItem::GetStringAttribute("./".$v, "/");
	}
	public function __toString(){return get_class($this); }
}
final class IGKHtmlValidatorItem extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("validator");
	}
	public function add($text,$attributes =null, $index=null)
	{
		parent::Add("div")->Content = $text;
	}
}
final class IGKHtmlTinyMceScript extends IGKHtmlItem
{
	private static $m_instance = null;	
	private  $m_tinyScript;
	private  $m_rendered ;
	
	function __construct(){
		parent::__construct(IGK_STR_EMPTY);
		$this->m_tinyScript = igk_js_enable_tinymce($this);
		$this->m_rendered = false;
	}
	
	public static function getInstance(){
		if (self::$m_instance == null)
			self::$m_instance = new IGKHtmlTinyMceScript();
		return self::$m_instance;
	}
	protected function innerHTML(& $option=null){
		return $this->m_tinyScript->innerHTML($option);
	}
	public function Render($option=null){
		if (!$this->m_rendered)
			$this->m_rendered = true;
		else 
			return null;
		return $this->m_tinyScript->Render($option);
	}
}

final class IGKHtmlA extends IGKHtmlStylableItem
{
	
	public function __construct(){
		parent::__construct("a");
		$this->m_node = new IGKHtmlItem("a");
	}
	public function Render($option=null)
	{		
		$bck = $this["href"];
		if ($this["onclick"] == null)
		{
			if (IGKString::StartWith(trim($this["href"]), "javascript"))
			{	
				$this["onclick"] = $bck." return false;";
				$this["href"] = "javascript:void();";				
			}
		}
		$o =  parent::Render($option);
		//restore
		$this["href"] = $bck;
		return $o;
	}
}

final class IGKHtmlTable extends IGKHtmlStylableItem
{
	private $m_headers;
	public function __construct(){
		parent::__construct("table");
		$this["class"] = "igk-table";
	}
	public function setHeader(){
		if ($this->m_headers ){
			$this->m_headers->ClearChilds();
		}
		else
			$this->m_headers = $this->add("tr");
		foreach(func_get_args() as $k=>$v){
			$this->m_headers->add("th")->Content = $v;
		}
	}
	public function addRow(){
		return $this->add("tr");
	}
}
final class IGKHtmlTextarea extends IGKHtmlStylableItem
{
	private  $m_must_escapeChar;
	private  $m_useTinyMce;
	public function getuseTinyMce(){return $this->m_useTinyMce; }
	public function setuseTinyMce($value){ $this->m_useTinyMce = $value; }
	
	public function __construct(){
		parent::__construct("textarea");
		$this->m_useTinyMce = false;
		$this->m_must_escapeChar = false;
	}
	public function getContent(){ return parent::getContent();}
	public function setContent($value){ return parent::setContent( htmlentities($value)); }
	
	public function Render($option=null)
	{
		$out = parent::Render($option);
		if ($this->m_useTinyMce)
		{
			$out.= IGKHtmlTinyMceScript::getInstance()->Render($option);
		}
		return $out;
		
	}
}
//current session class event
final class IGKHtmlClassSessionOpt extends IGKObject{
	var $regClass; //registered class
	var $regEvent; //used set that property added
	var $regParentClass; //used to store parent of class
	public function __construct(& $tab)
	{
		$this->regClass = & $tab;
		$this->regParentClass = array();
		$this->regEvent = new IGKEvents($this, "regEvent");
	}
	public function onPropertyAdded()
	{
		$this->regEvent->Call($this,null);
	}
}

/// represent classe used to register platform css class definition
final class IGKHtmlClassValueAttribute extends IGKHtmlItemAttribute{
	private $m_classes ; 
	private $m_expressions; //used to store in expression
	private $m_owner;
	private static $sm_regClass = null;
	
	
	
	public function __construct($owner){
		$this->m_classes = array();
		$this->m_expressions = array();
		$this->m_owner =$owner;
	}
	public function getKeys(){
		return array_keys($this->m_classes);
	}
	//register current class 
	private static function _RegClass($name)
	{	
		$v = & self::_GetRegClass();
		$App = IGKApp::getInstance();
		

		if (($App->Doc == null) || 
			isset($App->Doc->SysTheme->def[$name])||
			(isset($App->Doc->Theme->def[$name])))
			{				
				return;
			}
		
		if (!isset($v[$name]))
		{
			$v[$name] = $name;
			$App->Session->RegClasses->onPropertyAdded();
		}
		
	}
	/// get if this instance contain classe name
	public function contain($name)
	{
		return isset($this->m_classes[$name]);
	}
	private static function _UnRegClass($name)
	{
	
		$v = & self::_GetRegClass();
		if (isset($v[$name]))
		{
			unset($v[$name]);
			IGKApp::getInstance()->Session->RegClasses->onPropertyAdded();
		}
		
	}
	//unregister css class 
	public static function UnRegClass($key){
		self::_UnRegClass($key);
	}	
	//get all registrated css class
	public static function GetRegClass(){
		return self::_GetRegClass();
	}
	//return the reference of this object
	private static function & _GetRegClass(){ 
		if (self::$sm_regClass === null)
		{
			if (IGKApp::getInstance()->Session->RegClasses !==null)
			{
				self::$sm_regClass = & IGKApp::getInstance()->Session->RegClasses->regClass;
			}		
			else{
				self::$sm_regClass = array();	
				IGKApp::getInstance()->Session->RegClasses = new IGKHtmlClassSessionOpt( self::$sm_regClass);
			}
		}		
		return  self::$sm_regClass;
	}
	public function Clear(){
		$this->m_expression = array();
		$this->m_classes = array();
	}
	//add class with the add value
	public function add($class)
	{
		if (empty($class))
			return;
		$tab = explode(" ", $class);
		if (count($tab) == 1)
		{	 
			$this->_add($class);
		}
		else{
			foreach($tab as $v)
			{
			 $this->_add($v);
			}
		}
	}
	private function _add($v)
	{
	
				$v = trim($v);
				if (strlen( $v) > 0)
				{
					switch($v[0])
					{
						case '-'://remove the class
							$v = substr($v,1);
							$this->remove($v);	
						
						break;
						case '+'://add a new class
							$v = substr($v, 1);					
							if (!isset($this->m_classes[$v]))
							{
								$this->m_classes[$v] = $v;	
							}
							self::_RegClass(".".$v);
						break;
						case "{"://bind with expression
							$this->m_expressions[] = $v;
							igk_exit();
						break;
						 default:
						if (!isset($this->m_classes[$v]))
						{
							$this->m_classes[$v] = $v;				
						}
						self::_RegClass(".".$v);
						break;
					}
				}
				
	}
	public function remove($class)
	{
		if (empty($class))
			return;
		if (isset($this->m_classes[$class]))
		{
			unset($this->m_classes[$class]);
		}						
	}
	
	///<summary>get html css class presentation value</summary>
	public function getValue($options=null){
		
		$out = IGK_STR_EMPTY;
		if ($options && $options->ForMailTransport)
			return $out;
		$i = 0;
		foreach($this->m_classes as $k=>$v)
		{
			if ($i == 0)
					$i= 1;
			else 
				$out .=" ";
			//replacing parent item
			if (self::IsCssChild($v))
			{
				$out .= self::GetParentClass(IGKApp::getInstance()->Doc->Theme, $v);
			}
			else 
				$out.= $v;			
		}		
		return IGKHtmlUtils::GetValue($out);
	}
	public static function IsCssChild($v)
	{
		$c = IGKApp::getInstance();
		if ($c)
		{
			$s = $c->Doc->Theme[$v];
			if (!empty($s))
			{				
				//check matrix match				
				$r= preg_match(IGK_CSS_CHILD_EXPRESSION_REGEX, trim($s));				
				return $r;
			}			
		}
		return false;
	}
	private static function GetParentClass($theme, $v)
	{
		$s = $theme[$v];
		if (!empty($s))
		{	
				$t = array();
				if (preg_match_all(IGK_CSS_CHILD_EXPRESSION_REGEX, $s, $t))
			    {
					 $vv = $t["name"][0];
					if (self::IsCssChild($vv))
					 {
						return self::GetParentClass($theme, $vv);
					}
					return $vv;
				}
		}
		return $v;
	}
	public function EvalClassStyle(){
		$out = IGK_STR_EMPTY;
		$i = 0;
		foreach($this->m_classes as $k=>$v)
		{
			if ($i == 0)
					$i= 1;
			else 
				$out .=" ";
			$out .= igk_css_get_style($v);			
		}			
		return $out;
	}
}

///<summary>style presentation value used only to store additional style for an item</summary>
final class IGKHtmlStyleValueAttribute extends IGKHtmlItemAttribute{
	private $m_value;
	private $m_target;
	public function __construct($target){
		$this->m_target = $target;
	}
	public function setValue($value){
		$this->m_value = $value;
	}
	public function getValue($options =null){//get style value			
		$opt = IGK_STR_EMPTY;
		if ($options && isset($options->ForMailTransport)  && $options->ForMailTransport){
			$p = $this->m_target["class"];			
			$opt .= $p ? $p->EvalClassStyle() : IGK_STR_EMPTY;
		}			
		if (!empty($opt) && !empty($this->m_value))
			$opt .= " ";
		$opt = $opt.$this->m_value;
		return empty($opt) ? null: $opt;
	}
}

class IGKHtmlSeparatorItem extends IGKHtmlStylableItem
{
	private $m_orientation;
	public function __construct($orientation="horizontal")
	{
		parent::__construct("div");
		switch($orientation)
		{
			case "horizontal":
			$this["class"]="igk-horizontal-separator";
			break;
			case "vertical":
			$this["class"]="igk-vertical-separator";
			break;
		}
	}
}
final class IGKHtmlSearchItem extends IGKHtmlStylableItem
{
	private $m_link;
	private $m_input;
	private $m_ctrl; //controller
	private $m_ajxfunc ;
	public function __construct($uri, $search=null, $prop = "q")
	{	
		parent::__construct("div");
		$this["class"]="clsearch search_fcl";
		$frm = $this->addForm();
		$tab = igk_getquery_args($uri);
		if (isset($tab["c"]))
		{
			$this->m_ctrl = igk_getctrl($tab["c"]);
			$f = igk_getv($tab, "f");
			if ($f && !IGKString::EndWith($f, "_ajx"))
			{
				$this->m_ajxfunc = $f."_ajx";
				if (!method_exists($this->m_ctrl, $this->m_ajxfunc))
				{
					$this->m_ajxfunc  = null;
				}
				else{
					$this->m_ajxfunc =	$this->m_ctrl->getUri($this->m_ajxfunc);
				}
			}	
		}
		$frm["action"] = $uri;
		$frm["id"]="search_item";
		$frm->addDiv()->setClass("igk-underline-div");
		
		$frm->NoTitle = true;
		$frm->NoFoot = true;
		$d  = $frm->addDiv();
		$d["class"] = "disptable fitw";
		$this->m_link = IGKHtmlUtils::AddImgLnk($d, $uri, "btn_search", "24px", "24px");
		$this->m_link->a["class"]="alignm disptabc";
		$this->m_link->a["onclick"]=<<<EOF
return (function(i){var q = window.igk.getParentByTagName(i, 'form'); if (q){ q.submit(); return false;} return true;})(this);
EOF;
		$this->m_input = $d->addInput($prop, "text", igk_getr($prop, $search));
		
		$this->m_input["class"] = "no-border disptabc fitw";
		$script =<<<SCR
javascript: return (function(i, event){ var frm = null; if (event.keyCode==13){frm = window.igk.getParentByTagName(i, 'form'); if (frm){ frm.submit(); return false; }}  return true;} )(this, event);
SCR;
		$this->m_input["onkeypress"]=$script;
	}
	
}
//text element
class IGKHtmlText extends IGKHtmlItemBase
{
	public function getTagName(){return "HTMLText"; }
	public function getType(){return "HtmlText"; }
	public function __construct($content = null){
		parent::__construct();
		$this->Content = $content;
	}
	public function Render($options=null)
	{			
		$s = IGKHtmlUtils::GetValue($this->Content);
		if (empty($s))return;
		
		return $this->getDepthIndent($options).$s;//.$this->indentLine($options);		
	}
	protected function innerHTML(& $option=null){
		return IGKHtmlUtils::GetValue($this->Content);		
	}
	protected function _AddChild($item, $index=null){return false;}
	public function add(){return null;}
	public function getIsVisible(){return true;}
	public function getNodeType(){return IGKXMLNodeType::TEXT; }
	public function __toString(){ return "HtmlText[".$this->Content."]";}
}
class IGKHtmlProcessInstruction extends IGKHtmlItemBase
{
	private $m_content;
	public function getContent(){return $this->m_content;}
	public function __construct($content)
	{
		parent::__construct();
		$this->m_content = $content;
	}
	public function Render($options=null){
		$out = "<?";
		$out .= $this->Content;
		$out .= "?>";
		return $out ;
	}
	protected function _AddChild($item, $index=null){return false;}
	public function add($item, $attributes =null, $index= null){return null;}
}
final class IGKHtmlBodyDebuggerNode extends IGKHtmlItem
{
	private $m_owner;
	public function __construct($owner)
	{
		parent::__construct("div");
		$this->m_owner = $owner;
	}
	public function Render($options = null){		
		$o = null;
		$c = igk_debuggerview();
		if ($c->HasChilds)
		{
			if(igkServerInfo::IsLocal() || IGKApp::$DEBUG)
			{
			$c["class"] = "igk-debuggernode";
			$c->setStyle("max-height: 100%; overflow:scroll;");
			$o = $c->Render($options);
			}
			$c->ClearChilds();
		}	
		return $o;
	}
	public function innerHTML(& $options =null)
	{
		return null;
	}
}
//body class
final class IGKHtmlBody extends IGKHtmlStylableItem
{
	private $m_script;//basic script on body
	private $m_bodyScripts;//body script list 
	private $m_bodyDiv;
	private $m_bodyDebugHeader;
	
	public function __toString()
	{
		return "HtmlBody";
	}
	public function getDebuggerHeader(){
		return 	$this->m_bodyDebugHeader;
	}
	public function __construct()
	{
		parent::__construct("body");
		
		$this->m_script =  IGKHtmlItem::CreateWebNode("script");
		$this->m_script->Content = new IGKHtmlBodyMainScript("(function(){if (window.igk)window.igk.init_document(); })();");		
		$this->m_bodyScripts = new IGKHtmlBodyAppendScript($this);
		$this->m_bodyDebugHeader = new IGKHtmlBodyDebuggerNode($this);
	}	
	public function getBodyBox(){
		return $this->m_bodyDiv;
	}
	public function addBodyBox(){
		if ($this->m_bodyDiv == null)
		{
			$this->m_bodyDiv = IGKHtmlItem::CreateWebNode("div");
			$this->m_bodyDiv["class"]= "igk-body-box fitw fith overflow-y-a igk-powered-viewer igk-parentscroll";
			parent::add($this->m_bodyDiv);
		}
		return $this->m_bodyDiv;
	}
	
	///load addition script content when page request loaded.
	public function addScriptContent($key, $script){//add script function to body main script
		return $this->m_script->Content->addScript($key, $script);
	}
	public function innerHTML(& $options=null){
		$s = '';
		$s = $this->m_bodyDebugHeader->Render($options);
		$s .= parent::innerHTML($options);
		$s .= $this->m_script->Render($options);
		if (!($options && $options->ForMailTransport))
		$s .= $this->m_bodyScripts->Render($options);
		
		$d = igk_sys_powered_node();
		if ($d){
			$s .= $d->Render($options);
		}		
		return $s;
	}
	public function appendScript($scriptfile, $canbeMerged=false,  $index=0){	
		$this->m_bodyScripts->addScript($scriptfile,$canbeMerged, $index);
	}
	public function removeScript($scriptfile){
		$this->m_bodyScripts->removeScript($scriptfile);
	}	
}
final class IGKHtmlBodyAppendScript extends IGKHtmlItem
{
	private $m_scripts;	
	public function __construct(){
		parent::__construct("bodyscript");
		$this->m_scripts = array();
	}
	public function add($name, $attributes=null, $index=null){
		return null;
	}
	public function addScript($file = NULL, $canBeMerged = false, $index=0){		
		$c = new  IGKHtmlScript($file);	
		// igk_wln("add script ".$file);
				
		if ($index!=0){
			$c->Index = $index;
		}
		else{
			$c->Index = 0;
		}
		$this->m_scripts[$file] = $c;
		$tab = array_values($this->m_scripts);
		igk_usort($tab, array(get_class($this), "__sortScript"));
		//initialize the scripts
		$this->m_scripts = array();
		foreach($tab as $k=>$v){
			$this->m_scripts[$v->link] = $v;
		}
		
	}
	public static function __sortScript($a, $b){
	
		$aa = $a->Index;
		$bb = $b->Index;
		if ($aa==$bb)return 0;
		return ($aa<$bb)?-1:1;
	}
	public function removeScript($scriptFile){
		if (isset($this->m_scripts[$scriptFile]))
		{
				unset($this->m_scripts[$scriptFile]);
		}
	}
	public function innerHTML(& $options=null){
		$s = IGK_STR_EMPTY;
		foreach($this->m_scripts as $k=>$v)
		{
			$s .= $v->Render($options);
		}
		return $s;
	}
	public function Render($options=null){
		return $this->innerHTML($options);
	}
}
final class IGKHtmlBodyMainScript implements IIGKHtmlGetValue
{
	private $m_scripts;
	private $m_value;
	
	public function __construct($value)
	{
		$this->m_value = $value;
		$this->m_scripts = array();
	}
	public function getScriptAt($index)
	{
		return igk_getv($this->m_scripts, $index, null);
	}
	///<summary>add inline script to bodymain  script</summary>
	///<return>index of this script</return>
	public function addScript($key,  $script){//addscript to body main script
		$this->m_value .= $script;
		$this->m_scripts[$key] = $script;
		return igk_count($this->m_scripts);
	}
	public function removeScript($index )
	{
		$str = igk_getv($this->m_script, $index);
		if ($str)
		{			
			unset($this->m_script[$index]);
			$this->m_value = implode('',$this->m_scripts);
		}
	}
	public function __toString(){
		return "HtmlBodyMainScript:".$this->getValue();
	}
	public function getValue()
	{
		return $this->m_value;
	}
	
}
//---------------------------------------------------------------------------------------------
//CLASS: HTMLDOC
//---------------------------------------------------------------------------------------------
///<summary>represent the a igk app document instance</summary>
final class IGKHtmlDoc extends IGKHtmlItem
{
	
	private $m_parent;//igk app parent
	private $m_ForMailTransport;
	private $m_metaManager;
	private $m_scriptManager;
	private $m_linkManager;
	private $m_params;
	private $m_docType = "html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\""; 
	private $m_namespase = "http://www.igkdev.com/schema";
	var $m_head;
	var $m_body;
	var $m_title;
	var $m_doctype;
	var $m_sys_theme; //système - theme utiliser pour la configuration
	var $m_theme; //custom - theme
	var $m_favicon;
	var $lang; //set or set the lang of this document default lang is fr
	
	public function getForMailTransport(){
		return $this->m_ForMailTransport;
	}
	public function setForMailTransport($value){
		$this->m_ForMailTransport = $value;
	}
	public function __toString(){
	return "IGKHtmlDoc";
	}
	public function getMetas(){return $this->m_metaManager; }
	public function getBody(){return $this->m_body; }
	public function getHead(){return $this->m_head;}
	public function getSysTheme(){return $this->m_sys_theme; }
	public function getTheme(){return $this->m_theme;}
	public function getScriptManager(){return $this->m_scriptManager; }
	public function setDocType($value){ $this->m_docType = $value;}
	public function getElementById($name){
		$tab = array();
		$r1 = $this->m_head->getElementById($name);
		$r2 = $this->m_body->getElementById($name);
		if (is_array($r1))
			array_merge($tab, $r1);
		else 
			$tab[] = $r1;
			if (is_array($r2))
			array_merge($tab, $r);
		else 
			$tab[] = $r2;
			if (count($tab) == 1)
				return $tab[0];
			return $tab;
		
	}
	
	public function & getElementsByTagName($name){
		$n  = strtolower($name);
		$tab = array();
		if ($n == "head"){ $tab [] = $this->m_head; return $tab;}
		if ($n == "body"){ $tab [] = $this->m_body; return $tab;}
		$tab1 = $this->m_head->getElementsByTagName($name);
		$tab2 = $this->m_body->getElementsByTagName($name);
		return array_merge($tab1, $tab2);
	}
	public function __construct($parent, $initSystem=false, $themeId="Document")
	{		
		if ($parent == null)
			throw new Exception("parent must be created first");
		$this->m_parent = $parent;
		$this->m_params = array();				
		$this->m_head = self::CreateWebNode("head");
		igk_html_add($this->m_head, $this);
		$this->m_body = new IGKHtmlBody();
		igk_html_add($this->m_body, $this);
		$this->m_scriptManager = new IGKHtmlScriptManager($this);
		$this->m_linkManager = new IGKHtmlLinkManager($this);		
		$this->m_metaManager = new IGKHtmlMetaManager($this);		
		$this->m_sys_theme = new IGKHtmlDocTheme($this, "System:".$themeId);
		$this->m_theme = new IGKHtmlDocTheme($this, $themeId);//private themes....
		$this->lang = "fr";
		$this->m_parent->OnNewDocumentCreated($this);
		
		if ($initSystem){
			$this->setup_document();		
			$this->addStyle("R/Styles/base.php");			
			$parent->Doc->ScriptManager->bindScriptTo($this);
	
		}
	}
	public function setup_document()
	{			
		$this->_initThemes();
		$this->m_body["class"] = "igk-web-body";		
	}
	private function _initThemes()
	{
		//init default theme
		$d = $this->m_parent->Doc;
		if ($d !== $this)
		{
			$d->_initThemes();
			return;
		}
		//global document themes
		$this->m_sys_theme->Name = "igk_system_theme";
		$this->m_theme->Name = "default"; //set the default name		
		$this->m_sys_theme->def->Attributes->Clear();
		$def = $this->m_sys_theme->def;
		$def["*"]  = "padding:0px; margin:0px; box-sizing: border-box";
		$def["html, body, ul, div, p"] = "padding:0px; margin:0px; position:relative;";
		$def["a"] = "[fcl:link_base_fcl] text-decoration:none;";
		$def["body li"] = "list-style-type:none;";
		$def["body a, body img"]= "text-decoration:none; list-style-type:none; border:none;";
		$def["html, body"] = "width:100%; height:100%;";				
		//define shortcut icon theme
		
		$def[".posab"] = "position:absolute;";		
		$def[".posfix"]="position:fixed;";		
		$def[".posr"] = "position:relative;";
		$def[".posstatic"] = "position:static;";
		$def[".floatl"] = "float:left;";
		$def[".floatr"] = "float:right;";
		$def[".floatn"] = "clear:both;";
		$def[".clearb"] = "clear:both;";
		$def[".clearl"] = "clear:left;";
		$def[".clearr"] = "clear:right;";
		$def[".overflow-x-a"] = "overflow-x:auto;";
		$def[".overflow-y-a"] = "overflow-y:auto;";
		$def[".overflow_x"] = "overflow-x:scroll;";
		$def[".overflow_y"] = "overflow-y:scroll;";
		$def[".auto_y"] = "overflow-y:scroll;";
		$def[".auto_x"] = "overflow-x:scroll;";
		
		$def[".alignl"] ="text-align:left !important;";
		$def[".alignr"] ="text-align:right !important;";
		$def[".alignc"] ="text-align:center !important;";
		
		$def[".alignm"] ="vertical-align:middle !important;";
		$def[".alignb"] ="vertical-align:bottom !important;";
		$def[".alignt"] ="vertical-align:top !important;";
		
		$def[".igk-text-c"] ="text-align:center !important; vertical-align: middle !important;";
		
		$def[".ztop"] ="z-index: 9000;";
		$def[".zback"] ="z-index: -9000;";
		$def[".fitw"] ="width:100%;";
		$def[".fit"] ="width:100%; height:100%;";
		$def[".igk-underline-div"] ="display:block; position:absolute; height:4px; width:100%; background-color:#414141; bottom :0px;";
	
		
		$def[".igk-text-ellipis"] = "text-overflow:ellipsis;";
		$def[".igk-web-pageinfo"] = "{sys:dispn}";
		$def[".igk-prev"] = "border-radius:0px; [bgcl:igk-prev-bg]";
		$def[".igk-hbox"] = "border:none; height:1px; width:1px; margin-bottom:-1px; clip:rect(0,0,0,0); overflow:hidden; position:absolute; padding:0px;";
		
		
		$def[".igk-xml-viewer"] ="{sys:clearb}";
		$def[".igk-xml-viewer span"] ="{sys:floatl}";
		$def[".igk-xml-viewer span:not(:first-child):not(:last-child)"] ="margin-left:1px; margin-right:4px;";
		$def[".igk-xml-viewer span:first-child"] = "margin-right:4px;";
		$def[".igk-xml-viewer br"] ="{sys:clearb}";
		$def[".igk-xml-viewer .t"] ="{sys:dispib} width:32px;";
		$def[".igk-xml-viewer .s"] ="[fcl:igk-xml-tag-fcl];";
		$def[".igk-xml-viewer .e"] ="[fcl:igk-xml-tag-fcl]";
		$def[".igk-xml-viewer .o"] ="margin:0px !important;";
		$def[".igk-xml-viewer .c"] ="font-style:italic; [fcl:igk-xml-comment-fcl]";
		$def[".igk-xml-viewer .attr"] ="[fcl:igk-xml-attr-fcl] margin-right:1px !important;";
		$def[".igk-xml-viewer .attrv"] ="[fcl:igk-xml-attrv-fcl]";
		
		//article options
		$def[".igk-article-options"] = "{sys:alignl,loc_l,loc_t,z_50,fitw,dark-op20}";
		$def[".igk-article-options img"] ="display:inline;";
		$def[".igk-article-options > a "] ="display:inline-block;";
		
		//
		igk_css_regclass(".".IGK_SESSION_CTRL,  "{sys:posfix, loc_r, loc_t} top:32px; right:32px;  z-index: 10000;");		
	
		$def[".capitalize"] = "text-transform:capitalize;";
		$def[".uppercase"] = "text-transform:uppercase;";
		$def[".lowercase"] = "text-transform:lowercase;";
		$def[".fith"] ="height:100%;";
		$def[".hide"] ="display:none;";		
		$def[".halfw"] ="width:50%;";
		$def[".halfh"] ="height:50%;";
	
		
		$def[".pad4"] = "padding: 4px;";
		$def[".marg4"] = "margin: 4px;";
		
		$def[".no-wrap"] = "white-space: nowrap;";
		$def[".no-border"] = "border:none !important;";
		$def[".no-margin"] = "margin:0px !important;";
		$def[".no-padding"] = "padding:0px !important;";
		$def[".no-decoration"] ="text-decoration:none !important;";
		$def[".no-repeat"] = "background-repeat:no-repeat;";
		$def[".no-overflow"] = "overflow:hidden;";
		$def[".no-style"] = "text-decoration:none; list-style-type:none; border:none;";
		$def[".no-vibility"] = "visibility: hidden;";
		
		$def[".wrapnormal"] = "white-space:normal;";
		$def[".loc_b"]="bottom:0px;";
		$def[".loc_l"]="left:0px;";
		$def[".loc_mid"]="left:50%; top: 50%;";
		$def[".loc_r"]="right:0px;";
		$def[".loc_t"] = "top:0px;";
		$def[".nomargin"] = "margin-top:0px; margin-left:0px;margin-right:0px; margin-bottom:0px;";
		$def[".nopadding"] = "padding-top:0px; padding-bottom:0px; padding-right:0px; padding-left:0px;";
		$def[".nodecoration"]="text-decoration:none;";
		$def[".block_5m"] = "margin:5px;";
		$def[".block_10m"] = "margin:10px;";
		
		for($i =0; $i<= 10; $i++){
			$def[".z-level-".$i] = "z-index:".($i*10).";";
		}
		
		
		$def[".resizable"] = "resize:both;";
		$def["*:before, *:after"]= "box-sizing: border-box";
		

		$def[".scroll_h_x"] = "overflow-x:hidden;";
		$def[".scroll_h_y"] = "overflow-y:hidden;"; 
		$def[".scroll_x"] = "overflow-x: scroll;"; 
		$def[".scroll_y"] = "overflow-y: scroll;"; 
		$def[".scroll_ay"] = "overflow-y: auto;"; 
		$def[".scroll_ax"] = "overflow-x: auto;"; 
		$def[".autoh"] = "height:auto;";
		$def[".autow"] = "width:auto;";
		
		$def[".puce_circle"]= "list-style-type:disc;";
		
		$def[".dispn"] = "display:none;";
		$def[".dispb"] = "display:block;";
		$def[".dispi"] = " display:inline;"; 
		$def[".dispib"] = "display:inline-block;";
		$def[".disptabc"] = " display: table-cell;";
		$def[".disptable"] = " display:table;";
		$def[".disptabr"] = " display: table-row;";
		
		$def[".igk-clear-cell"] = "display:table; content:' ' ; clear:both;";
		
		
		$def[".box_16x16"] = "width:16px; height:16px;";
		$def[".box_24x24"] = "width:24px; height:24px;";
		$def[".box_32x32"] = "width:24px; height:32px;";
		$def[".box_48x48"] = "width:48px; height:48px;";
		

		
		$def[".editstyle-ajx-form"] = IGK_STR_EMPTY;
		$def[".editstyle-ajx-form .cltextarea"] = "width:400px; height:300px;";
		
		$def[".igk-web-body"] = "font-size:12px;";
		$def[".igk-ctrl-options"] = "{sys:dispb} [res:light-op20] text-align:left; margin:0px;";
		$def[".igk-ctrl-options ul"] = "{sys:dispi}";
		$def[".igk-ctrl-options ul li"] = "{sys:dispib} vertical-align:middle;";
		
	
		//frame box;
		$def[".frame_textarea"] = "min-width: 500px; min-height:300px";
		$def[".igk-msbox-dialog"] = $def[".framebox-dialog"] = "background-color: white; padding: 4px;"; 
		$def[".igk-msbox-dialog-title"] = $def[".framebox-dialog-title"]="position:relative; overflow:hidden; min-height:32px; font-size:14pt; [bgcl:framebox_title_bgcl];[fcl:framebox_title_fcl]; cursor:move; padding-right: 64px;"; 
		
		$def[".hseparator"]="{sys:fitw} height: 16px; [res:hsep];"; 
		$def[".hidden"]="display:none;";
	
		$def[".transparent"] ="background-color:transparent; color:transparent;";		
		$def[".igk-web-bodyinfo"] = "display:none;";
		
		$def[".config-fileviewdir"]="[res:folder]; background-repeat: no-repeat ;text-indent: 24px; display:inline-block;"; 
		$def[".config-fileviewfile"]="[res:file] ; background-repeat: no-repeat ;text-indent: 24px; display:inline-block;"; 
		
		
	
		//---------------------------------------------------------
		//CONFIG Home page for apage editor
		//---------------------------------------------------------
		$def[".igk-page-editor .framebox-dialog .cllabel "] = "{sys:alignr, dispib} width: 200px;"; 
		$def[".igk-page-editor .framebox-dialog  input,.igk-page-editor .framebox-dialog  select"] = "{sys:dispib, igk-form-control} width: 200px"; 
		$def[".igk-page-editor .framebox-dialog  input.clsubmit"] = "(:.igk-btn)";
		
		//---------------------------------------------------------
		//CONFIG PAGE STYLE CONFIGURATION
		//---------------------------------------------------------
		
			//config button styles
		$btnstyle = "[sysbgcl:igk-cnf-btn-bgcl] [sysfcl:igk-cnf-btn-fcl] border:none; {sys:dispib} display:inline-block; margin:2px; padding-right:4px; height:32px; vertical-align: top; min-width:120px;text-align:center;".
"cursor:pointer;";
		
			
		//config page
		$def[".igk-cnf-body .framebox-dialog .clbutton,".
		".igk-cnf-body .framebox-dialog .clsubmit, ".
		".igk-cnf-body .framebox-dialog .clreset, ".
		".igk-cnf-body .framebox-dialog .igk-btn-lnk"
		] = $btnstyle;
		$def[".igk-cnf-body .framebox-dialog .cllabel"] = "{sys:dispib,alignr,alignt} font-weight:600; width: 200px; padding:4px;";
		$def[".igk-cnf-body .framebox-dialog .clselect"] = "{sys:dispib} min-width : 200px; height:24px;";
		$def[
		".igk-cnf-body .framebox-dialog .cltext, ".
		".igk-cnf-body .framebox-dialog .clemail, ".
		".igk-cnf-body .framebox-dialog .clpassword, ".
		".igk-cnf-body .framebox-dialog .clfile "
		] = "{sys:dispib} min-width : 200px; height:24px";
		
		$def[".igk-cnf-page .igk-cnf-menu-title"] = "margin-bottom: 4px; margin-top: 4px; padding:0px; margin-left:auto; margin-right:auto; color: #aaa; font-weight: 600; ";
		$def[".igk-cnf-page"] = "overflow: auto; text-align:left; [res:light-op20] color:#777;";		
		$def[".igk-cnf-page a"] = "color:black; text-decoration:none;";
		$def[".igk-cnf-page .igk-ctrl-additionnal-properties"] = "[bgcl:igk-cnf-add-prop-color] border: 1px solid dashed #7e7e7e;";		
		$def[".igk-cnf-page .igk-cnf-content_submenu li"]= $btnstyle;
		$def[".igk-cnf-page .igk-cnf-content_submenu li a"]="{sys:fitw,fith} display:block; line-height:32px; vertical-align:middle; text-align:center; color:white"; 
		$def[".igk-cnf-page .igk-cnf-content_submenu li a:hover"]="background-color: #CECECE; color: black;"; 	
		$def[".igk-cnf-page .igk-cnf-content_submenu .igk-cnf-content_submenu_selected"]="background-color:#CECEFF;";			
		$def[".igk-web-body .igk-cnf-page .config-menu-separator"] = "{sys:dispb} height:1px; line-height:1px;border:2px solid #4fbaff;";
		$def[".igk-cnf-page .font_list"] = "{sys:posr}";
		$def[".igk-cnf-page .font_list li"]="display:inline-block; text-align:center;  padding:4px; border:1px solid #a4A4A4; vertical-align:top; margin: 3px; position:relative;";
		$def[".igk-cnf-page .font_list li div"] = "font-size: 30pt; height:40pt;";
		$def[".igk-cnf-page .font_list li .tool_tip"] = "height:auto;";
		$def[".igk-cnf-page .color_view"] = "padding: 2px; border:1px solid black";
				
		$def[".framebox"]="[res:framebox_bgimg]; z-index: 1000;"; 
		$def[".framebox_close"]="display: block; position:absolute; top:4px; right:8px;"; 
		$def[".framebox-btn-close"] = "display:block; background-color:transparent !important;";
		$def[".igk-cnf-page .framebox-dialog"]= "box-shadow: 0 2px 4px black";
		
		
		$def[".igk-web-body .igk-cnf-page "] = "[sysbgcl:igk-cnf-page-bg]";
		$def[".igk-cnf-page .config-menu-title"] = "font-size:1.1em; background-color: #389AFF; color:white; padding: 8px;";
		$def[".igk-cnf-page .config-menu-description"] = "padding-left:8px;";
		$def[".igk-cnf-page .igk-nav-bar"] = "{sys:posfix,fitw,loc_t,loc_l} background-color:#ddd; border-bottom:1px solid #aaa;";
		
		
		$def[".igk-cnf-page .igk-cnf-content"]="{sys:alignt} display:table-cell; width:100%; padding-left:16px; padding-right:16px; font-family:[ftn:century_gothic], serif, sans-serif ; padding-left: 16px;padding-right:16px;[res:config-content_bgimg]; [sysbgcl:config-content_bgcl]; [sysfcl:config-content_fcl]"; 		
		$def[".igk-cnf-page .igk-cnf-menu"]	  ="{sys:alignt} display:table-cell; width:210px; background-color:#fff;"; 
		$def[".igk-cnf-page .igk-cnf-info"]   ="{sys:alignt} display:table-cell; background-color:white; min-width:160px;";
	
		
		
		$def[".igk-cnf-page .other-conf-setting"] = "position:relative; padding-left:8px; padding-right:8px;";
		$def[".igk-cnf-page .other-conf-setting .cllabel"] = "width: auto;";
		$def[".igk-cnf-page .other-conf-setting:after"] = "display:table; clear:both; content:' ';";		
		$def[".igk-cnf-page .other-conf-setting li"]=  "height : 48px;";
		$def[".igk-cnf-page .other-conf-setting li label"]="width:auto; white-space:no-wrap; text-overflow:ellipsis; overflow:hidden; padding-right: 8px;";
		//$def[".igk-cnf-page .other-conf-setting li:last-of-type:after"] ="display:table; Clear:left; content: ''";
		
		
		
		$def[".igk-cnf-page .igk-menu-item"] = "{sys:dispb} height:32px;  overflow:hidden; border-top: 1px solid [syscl:igk-cnf-menu-border]"; 		
		$def[".igk-cnf-page .igk-cnf-menu li"]="{sys:dispb} line-height:1.4325; min-width: 210px;  min-height:32px; overflow:hidden; border-top: 1px solid [syscl:igk-cnf-menu-border]"; 
		$def[".igk-cnf-page .igk-cnf-menu li:first-child"] = "margin-top: 16px; border:none;";
		$def[".igk-cnf-page .igk-cnf-menu li:last-child"] = "margin-bottom: 16px; borner:none;";
		$def[".igk-cnf-page .igk-cnf-menu li:first-child:last-child"] = "border: 1px solid [syscl:igk-cnf-menu-border];";
		
		
		//android menu options
		
		$def[".igk-cnf-page .igk-android-menu-options"] = "{sys:posfix,overflow-y-a,fith} [trans: all ease-in-out 0.2s]; z-index:100; max-width:460px;[sysfcl:igk-android-menu-option-fcl] [sysbgcl:igk-android-menu-option-bg] overflow-x:hidden;";
		$def[".igk-cnf-page .igk-android-menu-options a"] = "{sys:no-decoration} [sysfcl:igk-android-menu-option-fcl]";
		$def[".igk-cnf-page .igk-android-menu-option li.config-menu-separator"] = "height:8px; line-height:0px;";
		$def[".igk-cnf-page .igk-android-menu-options .igk-config-menu-font li"] = "{sys:dispb} line-height:32px; min-height:32px; overflow:hidden; border-top: 1px solid [syscl:igk-cnf-menu-border]";
		$def[".igk-cnf-page .igk-android-menu-options li:first-child"] = "margin-top: 16px; border:none;";
		$def[".igk-cnf-page .igk-android-menu-options li:last-child"] = "margin-bottom: 16px; borner:none;";
		
		
		$def[".igk-cnf-page .igk-cnf-menu li div"]= "padding:4px;";	
		$def[".igk-cnf-page .igk-cnf-menu li.config-menu-separator"] = "border:none;";
		$def[".menu-indent-trans"] = "-webkit-transition:text-indent .2s ease-in-out; -o-transition: text-indent .2s ease-in-out; transition: text-indent .2s ease-in-out;";
		$def[".igk-cnf-page .igk-cnf-menu li > a"]="{sys:dispb,fith,fitw, no-wrap, no-decoration,menu-indent-trans}line-height:32px; height:32px; font-size: 0.8em; text-overflow:ellipsis; vertical-align:middle; cursor:pointer;  [fcl:config-menu_fcl]"; 		
		$def[".igk-cnf-page .igk-cnf-menu li > span"]="line-height:32px; height:32px; font-size: 0.8em; vertical-align:middle; cursor:pointer;"; 		
		$def[".igk-cnf-page .igk-cnf-menu li > a:hover"]="text-indent: 16px; font-weight: 800; [bgcl:igk-cnf-menu_a_hover_bgcl]; [fcl:igk-cnf-menu_a_hover_fcl];"; 
		
		$def[".igk-cnf-page .igk-cnf-menu ul"]="margin-bottom:8px;"; 		
		$def[".igk-cnf-page .igk-cnf-menu .igk-cnf-menu_selected"]="text-indent:16px;background-repeat:no-repeat;[res:config-menu_selected_bgimg];[bgcl:config-menu_selected_bgcl];[fcl:config-menu_selected_fcl]"; 
		$def[".igk-cnf-page .igk-db-tableentries"] = "width:600px; max-height:440px; overflow: auto";		
		$def[".igk-cnf-page .igk-table"] = "border-spacing:0 0; font-size:10pt; border-collapse:collapse;";
		$def[".igk-cnf-page .igk-table td"]  = "border:1px solid #E7E7E8;";
		$def[".igk-cnf-page .igk-table th:hover"]  = "color: black;";		
		$def[".igk-cnf-page .table_lightrow"]=  "[bgcl:table_lightrow_bgcl]";
		$def[".igk-cnf-page .table_lightrow:hover"]= "[bgcl:table_row_hover_bgcl];[fcl:table_row_hover_fcl]";
		$def[".igk-cnf-page .table_darkrow"]=  "[bgcl:table_darkrow_bgcl]";
		$def[".igk-cnf-page .table_darkrow:hover"]= "[bgcl:table_row_hover_bgcl];[fcl:table_row_hover_fcl]";
		$def[".igk-cnf-page .table_lightrow a,.igk-cnf-page .table_darkrow a"] ="{sys:dispb,fitw,fith}";
		$def[".igk-cnf-page .table_darkrow a:hover"] = "[fcl:table_row_hover_fcl]";
		$def[".igk-cnf-page .table_lightrow a:hover"] = "[fcl:table_row_hover_fcl]";		
		
		$def[".igk-cnf-page .db_info"] = "{sys:dispib,alignt} padding:4px; margin:0px; overflow:hidden;";
		$def[".igk-cnf-page .row .db_info"] = "margin: 0px !important;";
		
		$def[".igk-cnf-page .igk-cnf-header-node"] = "{sys:no-overflow} font-size:1em; {sys:no-wrap, overflow-none}";
		$def[".igk-cnf-page .igk-cnf-header-node:after"] = "display:table; content:' '; {sys:clearb}";
		$def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-logo"] = "[res:config_logo] {sys:dispib,no-repeat} width : 125px; overflow:hidden; height:74px;";
		$def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-logo a"]=
		$def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-logo a:hover"] = "{sys:no-decoration}";
		$def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-title"] = "{sys:dispib} font-size:3em; vertical-align:top; text-shadow: 1px 1px 2px #2A2A2A;";
		$def[".igk-cnf-page .igk-title"] = "{sys:dispib} font-size: 2em; vertical-align:top;";
		
		$def[".igk-cnf-page .conf_ctrl_info"] = "margin-top:16px; margin-bottom:16px; border:1px solid gray; padding:4px;";
		$def[".igk-cnf-page .conf_ctrl_info table"] = "{sys:disptable,fitw}";
		
		$def[".igk-cnf-page .admin_option"] = "background-color: white;";
		$def[".igk-cnf-page .admin_option li"] = "width: 150px; min-height:85px; display:inline-block; padding-right:4px; padding-bottom:4px;"; 
		$def[".igk-cnf-page .admin_option li a"] = "display: block; height:100%; background-color: white;";
			
		$def[".igk-cnf-page .igk-table-img-action_16x16"] = "width:16px;";
		
		$def[".igk-cnf-page .igknotificationctrl"] = "border: none;";
		$notification_style = "padding:8px;";
		$def[".igk-cnf-page .igk-notify-z"] = $notification_style;
		$def[".igk-cnf-page .igk-notify-success"] =$notification_style ." [fcl:notify_g_fcl]";
		$def[".igk-cnf-page .igk-notify-danger"] = $notification_style ." [fcl:notify_b_fcl]";
		$def[".igk-cnf-page .igk-notify-info"] =   $notification_style ." [fcl:notify_i_fcl]";
		$def[".igk-cnf-page .igk-notify-warning"] =$notification_style ." [fcl:notify_w_fcl]";
		
		$def[".igk-cnf-page .igk-selectdb-row"]= "color:darkblue; background-color: #a2a2a2;";
		$def[".igk-cnf-page .clselect"] = "{sys:dispib} min-width : 200px; height:24px;";
		$def[".igk-cnf-page .connexion_frame"] = "{sys:fitw,alignc,posr} background-color:#4e4eFF; height: 10px; top: 50%;margin-top:-5px;";
		$def[".igk-cnf-page .connexion_frame .igk-cnf-connexion-div"] = "box-shadow:0px 0px 4px black;";
		$def[".igk-cnf-page .igk-language-list"]=IGK_STR_EMPTY;
		$def[".igk-cnf-page .igk-language-list li"]="{sys:dispib,alignt} width: 32px; height:24px; padding:1px; margin:1px;";
		$def[".igk-cnf-page .igk-language-list li a"]="{sys:dispb, fith}";
		$def["body .igk-cnf-connexion-div"] = "{sys:posab} left:50%; top:50%; margin-left:-150px; margin-top:-200px;background-color:white; padding:5px;";
		$def["body .igk-cnf-connexion-div input"] = "color:black;";
		
		

		
		$def[".bodyBgColor"] = "[palbgcl:color_1]";
		$def[".bodyfColor"] = "[palfcl:color_2]";
		
		$def[".dark-op20"] = "[res:dark-op20]";
		$def[".dark-op50"] = "[res:dark-op50]";
		$def[".dark-op70"] = "[res:dark-op70]";
		$def[".dark-op80"] = "[res:dark-op80]";
		$def[".dark-op90"] = "[res:dark-op90]";		
		$def[".light-op20"] = "[res:light-op20]";
		$def[".light-op50"] = "[res:light-op50]";
		$def[".light-op80"] = "[res:light-op80]";
		$def[".light-op90"] = "[res:light-op90]";


		$def[".igk-cnf-page .cltext, .igk-cnf-page .clpassword, .igk-cnf-page .clemail"] = "padding:4px; width:180px;";
		$def[".igk-cnf-page .cltextarea"] = "width:420px; height : 300px; white-space: no-wrap; ";
		$def[".igk-cnf-page .cllabel"] = "display:inline-block; width: 150px; min-height: 32px; vertical-align:top;  line-height:auto;";
		$def[".igk-cnf-page table input[type=text]"] = "width:100% !important;";
		
		
		
		
		
		$def[".igk-cnf-page .clreset"]=
		$def[".igk-cnf-page .clsubmit"]= 
		$def[".igk-cnf-page .igk-btn-lnk"] = 
		$def[".igk-cnf-page .clbutton"] = $btnstyle;
		$def[".igk-cnf-framebox .clbutton, .igk-cnf-framebox .clsubmit, .igk-cnf-framebox .clreset, .igk-cnf-framebox clbutton"] = $btnstyle;
		
		$def[".igk-cnf-page .clreset:hover"]=
		$def[".igk-cnf-page .clsubmit:hover"]= 
		$def[".igk-cnf-page .igk-btn-lnk:hover"] = 
		$def[".igk-cnf-page .clbutton:hover"] = "background-color: #CECECE; color:black;";

		
		$def["body.igk-cnf-body .framebox-dialog .cltext, body.igk-cnf-body .framebox-dialog .clpassword"] = "padding:4px; margin-bottom:4px;";
		
		
		

		$def[".igk-cnf-page .clsearch"] = "display:inline-block; border: none;  width:auto; min-width:auto;";		
		$def[".igk-cnf-page .clsearch div"] = "padding:0px; margin:0px; background-color:transparent;";
		$def[".igk-cnf-page .clsearch .igk-underline-div"] = $def[".igk-underline-div"];
		$def[".igk-cnf-page .clsearch input"] = "{sys:disptabc} border:none; background-color:transparent; vertical-align:top; font-size: 1.5em;";
		$def[".igk-cnf-page .igk-horizontal-separator"]="height:16px; [res:hsep]; background-repeat:repeat-x; {sys:dispib, fitw}";
		$def[".igk-cnf-page .igk-vertical-separator"]= "width:16px; [res:vsep]; background-repeat:repeat-y";
		
		
		$def[".igk-horizontal-separator"]="height:16px; [res:hsep]; background-repeat:repeat-x; {sys:dispib, fitw}";
		
		
		$def[".config-page"]="display:table;";// border:1px dotted #8C9191;"; 
		$def[".config-title"]="font-size:1.3em; font-weight:600;padding-top:8px; margin-bottom:8px;";
		$def[".igk-powered"] = "display:block; position:fixed; bottom:0px; z-index: 10000; font-size:0.68em; right:0px;";
		//init colors
		$cl = $this->m_sys_theme->cl;
		$cl["igk-cnf-menu-border"] = "#ddd";
		$cl["igk-cnf-btn-bgcl"] = "#88f";
		$cl["igk-cnf-btn-fcl"] = "white";	
		$cl["igk-cnf-page-bg"] = "#dedede";
		$cl["igk-android-menu-option-bg"] = "#3699FF";
		$cl["igk-android-menu-option-fcl"] = "white";
		
		$d = $this->m_sys_theme->reg_media("(max-width:700px)");
		$d->def[".igk-cnf-page .igk-cnf-menu"] = "display:none !important;";
		$d->def[".igk-cnf-page .igk-cnf-info"] = "display:none;";
		$d->def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-logo"] = "{sys:dispn}";
		$d->def[".igk-cnf-page .igk-cnf-header-node .igk-cnf-title"] = "font-size:2em;";
		$d->def[".igk-android  .igk-cnf-page input[type=text],.igk-android  .igk-cnf-page input[type=password]"] = "{sys:dispb,fitw}";
		$d->def[".igk-cnf-page .igk-cnf-frame"] = "{sys:fitw} overflow:hidden;";
		$d->def[".igk-cnf-page .igk-cnf-frame .cltext, .igk-cnf-page .igk-cnf-frame select"] =
		$d->def[".igk-cnf-page .igk-cnf-frame .clpassword"]=
		$d->def[".igk-cnf-page .igk-cnf-frame .igk-btn-lnk"]=
		$d->def[".igk-cnf-page .igk-cnf-frame .clsubmit"]=
		$d->def[".igk-cnf-page .igk-cnf-frame .clbutton"]=
		$d->def[".igk-cnf-page .igk-cnf-frame .clreset"]=
		"{sys:fitw,dispb} min-width:auto; max-with:auto;";
		
		
		$d->def[".igk-cnf-page .clsearch"] = "width:100%;";
		
		//igk platform theme definition
		
		include(dirname(__FILE__)."/igk_css_colors.phtml");			
		$d = dirname(__FILE__)."/igk_css_template.phtml";
		if (file_exists($d))
			include($d);
	}
	public function getSystemCssContent($min=false)
	{
		$o = IGK_STR_EMPTY;
		foreach($def->Attributes as $k=>$v)
		{
			if (!$min)
			{
				$o.="\r\n";
			}
			$o .= $k."{".igk_css_treat($this->m_sys_theme, $v)."}";
		}
		return $o;
	}
	public function initSysTheme()
	{		
		//init configurable variables 
		igk_get_uvar("CONFIG_SCHEMA_FONT", "R/Fonts/PDFFont.TTF", true);
		igk_get_uvar(IGK_CSV_SEPARATOR, ",", true);
		igk_get_uvar("CONFIG_DB_MAX_VISIBLEITEM", "50", true);
		
	}
	public function toString()
	{
		return "HtmlDocument";
	}
	public function getDocType(){
		return "<!DOCTYPE ".$this->m_docType.">";
	}
	///<summary>shortcut to add script</script>
	public function addScript($file=null, $canbeMerged=true ){//document addScript
		return $this->m_scriptManager->addScript($file, $canbeMerged);
	}
	public function addLink($name){
		return $this->m_linkManager->addLink($name);
	}
	public function addStyle($file){
		$ln = new IGKHtmlCssLink($file);
		$this->m_head->add($ln);
		return $ln;
	}
	public function removeStyle($file)
	{		
		$tab = $this->m_head->Childs->ToArray();
		foreach( $tab as $k=>$v)
		{
			if (get_class($v) == "IGKHtmlCssLink")
			{				
				if ($v->link == $file)
				{					
					$b = igk_html_rm($v);		
				}				
			}
		}
	}
	public function ClearStyle()
	{
		$v_childs = array();
		//remove all style added to head
		foreach( $this->m_head->Childs as $k=>$v)
		{
			if ( get_class($v) == "IGKHtmlCssLink")
			{
				$v_childs[] = $v;
			}
		}
		foreach($v_childs as $k)
		{
			$this->m_head->remove($k);
		}
	}

	public function getStylesList(){
		$v_childs = array();
		//remove all style added to head
		foreach( $this->m_head->Childs as $k=>$v)
		{
			if ( get_class($v) == "IGKHtmlCssLink")
			{
				$v_childs[] = $v;
			}
		}
		return $v_childs;
	}
	public function Render( $options=null){
		//init document setting
		if ($options){
			$options->Document == $this;			
			$options->ForMailTransport = $this->ForMailTransport;
		}
		else{
			$options = (object)
			array(
			"Document"=>$this, 
			"ForMailTransport"=>$this->ForMailTransport,
			"Indent"=>false);
		}
		$out =IGK_STR_EMPTY;
		
		$out .= $this->getDocType();
		$out .= "<html lang=\"".$this->lang."\" xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:igk=\"".$this->m_namespase."\" ";
		//build additional property
		if (file_exists(igk_io_currentRelativePath("manisfest.appcache")))
			$out .= "manifest=\"manifest.appcache\" ";
		$out .= "class=\"igk-web-page\" ";		
		$out .= ">";		
		$out .= $this->innerHTML($options);
		$out .= "</html>";
		return $out;
	}
	protected function innerHTML(& $options=null){//get inner html document
		$out =IGK_STR_EMPTY;
		if ($this->m_head->getIsVisible())
		$out .= $this->m_head->Render($options);
		if ($this->m_body->getIsVisible())
		{
			$out .= $this->m_body->Render($options);	
		}
		return $out;
	}
	//get the saved params
	public function getParams()
	{
		return $this->m_params;
	}
	public function getbodypage(){
		
		$i =  igk_getv($this->m_params, "bodypage");
		if ($i == null)
		{
			igk_debug_wln("notice: the system bodypage is null");
		}
		return $i;
	}
	public function setTitle($value){
		if (($value) ==null) {igk_html_rm($this->m_title); return; }
		
		
		if ($this->m_title === null)
		{
			$this->m_title = $this->m_head->add("title");			
			$this->m_title->Index = -9999;
		}
		$this->m_title->Content = $value;
	}
	public function getTitle(){
		if ($this->m_title !== null)
		{
		return $this->m_title->Content;
		}
	}
	public function __get($key){
		if (method_exists($this, "get".$key) )
		{					
				return call_user_func(array($this, "get".$key), null);
		}	
		else{			
			return igk_getv($this->m_params, $key);			
		}
	}
	public function __set($key, $value){	//style	
		if (!$this->_setIn($key, $value))
		{ 
			if ($value==null)
				unset($this->m_params[$key]);
			else 
				$this->m_params[$key] = $value;			
		}
	}
	public function setFavicon($icon)
	{
		if ($icon)
		{			
			if ($this->m_favicon == null)
			{
				$this->m_favicon = IGKHtmlItem::CreateWebNode("link");
				$this->m_favicon["title"] = R::ngets("title.favicon");
				$this->m_head->add($this->m_favicon);			
			}
			
			$this->m_favicon["rel"]="shortcut icon";
			$this->m_favicon["type"]="image/x-icon";
			$this->m_favicon["href"]=$icon;
		}
		else {
			igk_html_rm($this->m_favicon);
			$this->m_favicon = null;
			igk_exit();
		}
		
	}

	public function ClearParams()
	{
		$this->m_params = array();
	}
}

final class IGKHtmlMetaItem extends IGKHtmlItem
{
	public function __construct()
	{
		parent::__construct("metas");
	}
	
	public function Render($options=null)
	{
		$o = $this->innerHTML($options);		
		return $o;
	}
	public function getIsVisible(){ return $this->HasChilds; }
}


final class IGKHtmlMetaManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_managerItem ;
	private $m_node;
	private $m_metas;
	public function RenderNode(){ return $this->m_node->Render(); }
	public function getNode(){return $this->m_node; }
	public function getAuthor(){ return $this->m_metas["author"]["content"];}
	public function getCopyright(){ return $this->m_metas["copyright"]["content"];}
	public function getDescription(){ return $this->m_metas["description"]["content"];}
	public function getKeywords(){ return $this->m_metas["keywords"]["content"];}
	public function getContentType(){ return $this->m_metas["contenttype"]["content"];}
	
	
	public function setAuthor($value){  $this->m_metas["author"]["content"] = $value;}
	public function setCopyright($value){ $this->m_metas["copyright"]["content"]= $value;}
	public function setDescription($value){  $this->m_metas["description"]["content"]= $value;}
	public function setKeywords($value){ $this->m_metas["keywords"]["content"]= $value;}
	public function setContentType($value){  $this->m_metas["contenttype"]["content"]= $value;}
	
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_node = new IGKHtmlMetaItem();
		igk_html_add($this->m_node , $this->m_htmlDoc->head);	
		$this->m_metas = array();
		$this->m_metas["author"]  = $this->m_node->add("meta", array("name"=>"author", "content"=>IGK_AUTHOR));
		$this->m_metas["copyright"]  = $this->m_node->add("meta", array("name"=>"copyright", "content"=>IGK_COPYRIGHT));
		$this->m_metas["description"]  = $this->m_node->add("meta", array("name"=>"Description", "content"=>IGK_STR_EMPTY));
		$this->m_metas["keywords"]  = $this->m_node->add("meta", array("name"=>"keywords", "content"=>IGK_STR_EMPTY));
		$this->m_metas["contenttype"]  = $this->m_node->add("meta", array("http-equiv"=>"Content-Type", "content"=>"text/html; charset=utf-8"));		
	}
	public function addMeta($name, $meta)
	{		
		if ($meta && !isset($this->m_metas[$name])){
			$this->m_node->add($meta);
			$this->m_metas[$name] = $meta;
		}	
	}
	public function rmMeta($name)
	{
		if (isset($this->m_metas[$name]))
		{
			unset($this->m_metas[$name]);
		}
	}
	public function getMetaById($name){
		if (isset($this->m_metas[$name]))
		{
			return $this->m_metas[$name];
		}
		return null;
	}
	public function __toString(){ return "HtmlMetaManager";}
}



final class IGKHtmlScriptManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_assocTable; //store the link assoc table for script unicity
	private $m_node;
	private $m_managerItem ; 
	
	public function getDoc(){return $this->m_htmlDoc; }
	public function getNode(){return $this->m_node;}
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_assocTable = array();
		$this->m_node = null;
		$this->m_managerItem = new IGKHtmlScriptManagerItem($this);
	}
	public function __toString(){ return "HtmlScriptManager"; }
	
	public function getScript($file)
	{
		if (isset($this->m_assocTable[$file]))
			return $this->m_assocTable[$file];
		return null;
	}
	///<summary>register script do manager button</summary>
	public function addScript($file, $canbeMerged=true){//htmlscript Manager addscript
			
		
		$local = false;
		$fname = true;
		$f = $file;
		if (!IGKValidator::IsUri($file)){
			$fname =false;
			$f = igk_io_getdir($file);
			if (file_exists($f))
			{
				$file = $f;
				$local = true;
			}
			else{
				$local = false;
			}
		}
		
		if (isset($this->m_assocTable[$file]))
			return $this->m_assocTable[$file];
		if ($this->m_node == null){
			$this->m_node = new IGKHtmlBlockNodeItem();			
			igk_html_add($this->m_node, $this->m_managerItem);
			
		}
		$s = new IGKHtmlScript($f);
		if (!$fname && !$local)
		{
			$s->link =null;
			$s->canBeMerged = $canbeMerged;
		}
		else{
			$s = new IGKHtmlScript($file);
			$s->canBeMerged = $canbeMerged;
		}
		igk_html_add($this->m_managerItem, $this->m_htmlDoc->head);		
		$this->m_node->add($s);				
		$this->m_assocTable[$file] = $s;
		return $s;
	}
	///<summary>get the merged content data</summary>
	///<return>array of data: the data, append: string to append</return>
	public function getMergedContent(){//represent a merged containt script block
		//merge all files in a single script item
			$txt = IGK_STR_EMPTY;
			$Append = IGK_STR_EMPTY;
			$n = $this->Node;
			$nonMerged = array();
			if ($n)
			{
			$links = "/* ";
			foreach($n->Childs as $k)
			{
				if (!$k->canBeMerged){
					$nonMerged[] = $k;
					continue;
				}
				
				$c = $k->link;
				
				if(empty($c))
					continue;
				
				
				$f = igk_io_baseUri($c);
				
				$links .= $f."\n";
				if (($k->canBeMerged == true) && !IGKValidator::IsUri($c) )
				{
					if (empty($txt))
					{
						$txt.="var script_src_lnk = '';";
					}
					if (file_exists($c))
					{
						$txt .= "/* FILE :  ". $f."*/\n";
						//transform to ansi text
						$txt .= "script_src_lnk = '".$f."';";
						$txt .= utf8_decode(file_get_contents($c))."\n";
					}
					else{
						$txt .="/* FILE NOT EXISTS: ".$c."*/\n";
					}
				}
				else {
					$Append.= $k->Render(null);
				}
				
			}
			$links .="*/\n";
			$txt = $links.$txt;
			}
			return (object)array("data"=>$txt, "append"=>$Append, "notMerged"=>$nonMerged);
	}
	public function getNonMergedContent($tab=null){
		$nonMerged = $tab == null ? $this->getMergedContent()->notMerged: $tab->notMerged;
		$o = "";
		foreach($nonMerged as $k=>$v){
			$o .= $v->Render(null);
		}
		return $o;
	}
	
	///<summary>current script to new document 
	public function bindScriptTo($document){
		if ($document ==null)
			return;
		//igk_wln(array_keys($this->m_assocTable));
		foreach($this->m_assocTable as $k=>$v)
		{
			$document->addScript($k, $v->canBeMerged);
		}
	}
}
///<summary></summary>
final class IGKHtmlScriptManagerItem extends IGKHtmlItem{//used to manage script on document
	private $m_scriptManager;
	
	public function __construct($scriptManager)
	{
		parent::__construct("HtmlScriptManagerItem");
		$this->m_scriptManager = $scriptManager;
	}
	public function Render($options=null)
	{
		return $this->innerHTML($options);
	}
	
	protected function innerHTML(& $options = null)	{//IGKHtmlScriptManagerItem innerHtml
		//MERGE ALL SCRIPT
		$merge_all_script = true;
		if (igkServerInfo::IsIGKDEVSERVER())
		{
			$merge_all_script = true;
		}
		if ($merge_all_script && igk_is_debuging())
		{
			return $this->m_scriptManager->Node->Render($options);
		}
		else{
			$tab = $this->m_scriptManager->getMergedContent();			
			$o = "<!-- non merged script -->";
			$o .= $this->m_scriptManager->getNonMergedContent($tab);			
			$o .= "<!-- merged scripts -->";
			$o .= "<script language=\"javascript\" type=\"text/javascript\" src=\"".igk_getctrl("IGKScriptController")->getUri("getScript")."\" ></script>"
			.$tab->append;
			return $o;
		}
	}
}


final class IGKHtmlLinkManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_links;
	private $m_node;
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_links = array();
		$this->m_node = null;
	}
	
	public function addLink($name){
		if (isset($this->m_links[$name]))
			return $this->m_links[$name];
		if ($this->m_node == null)
		{
			$this->m_node = new IGKHtmlBlockNodeItem();
			IGKHtmlUtils::AddItem($this->m_node, $this->m_htmlDoc->head);
		}
		$c = new IGKHtmlLink();
		$this->m_node->add($c);		
		$this->m_links[$name] = $c;		
		return $c;
	}
}

final class IGKCssDefaultStyle extends IGKHtmlItem
{
	private $m_declaredRule;
	
	public function getHasRules(){
		return igk_count($this->m_declaredRule) > 0;
	}
	public function getRulesString(){
		$o = "";
		foreach($this->m_declaredRule as $k=>$v)
		{
			$o .= $k."{".$v."}";
		}		
		return $o;
	}
	public function __construct()
	{	parent::__construct("Default");
		$this->m_declaredRule = array();		
	}
	public function __toString(){
		return get_class($this)."#items";
	}
	public function addRule($name, $expression)
	{
		$this->m_declaredRule[$name] = $expression;
	}
	public function rmRule($name)
	{
		if (isset ($this->m_declaredRule[$name]))
			unset($this->m_declaredRule[$name]);
	}
	public function Render($o=null){
		return null;
	}
	public function innerHTML(& $o = null){
		return null;
	}
}

final class IGKHtmlDocThemeMediaType extends IGKObject
{
	const XSM_MEDIA = 0;
	const SM_MEDIA = 1;
	const LG_MEDIA = 2;
	const XLG_MEDIA = 3;
	const XXLG_MEDIA = 4;
}
//represent a document themes
final class IGKHtmlDocTheme extends IGKHtmlItem
{
	var $def; // default system	
	var $cl;//custom color
	var $ft; //font 
	var $res;//resources - not currently used
	var $properties; //somme properties
	var $Append; //Append to all
	var $rules;//
	private $m_medias; //media array	
	private $m_mediasid;//media id keys
	private $m_type;
	private $m_document;
	private $m_lastchanged; //store last theme changed
	private $m_files;
	private $m_id; //for debugging
	
	public function getFiles(){
		return $this->m_files;
	}
	
	const REGKEY = "HtmlDocTheme";
	
	public function ClearChilds(){//noting
		//do nothing
	}
	public function __toString(){
		return "HtmlDocTheme : [id:".$this->m_id.", type: {$this->m_type} ]";
	}
	public function getDoc(){ return $this->m_document; }
	public function getFont(){
		return $this->ft;
	}
	///<summary>register a media </summary>
	///<param name="$name">name or condition</param>
	public  function reg_media($name = "print", $id= null)
	{	
		$n = null;
		if (!isset($this->m_medias[$name]))		
		{
			$n = new IGKHtmlDocTheme($this->m_document,"media:".$name);
			$this->m_medias[$name] = $n;
			if ($id!==null)
				$this->m_mediasid[$id] = $n;
	
		}
		else 
			$n = $this->m_medias[$name] ;
		return $n;
	}
	public  function get_media($id)
	{	
		return igk_getv($this->m_mediasid, $id);
	}
	///<summary>get print media</summary>
	public function getPrintMedia(){
		return $this->reg_media("print");
	}
	
	public function reg_keyFrames($def , $name, $expression)
	{
		$def->addRule("@-webkit-keyframes ".$name, $expression);
		$def->addRule("@-moz-keyframes ".$name,$expression);
		$def->addRule("@-ms-keyframes ".$name, $expression);
		$def->addRule("@-o-keyframes ".$name,$expression);
		$def->addRule("@keyframes ".$name, $expression);
	}

	public function __construct($document, $id,  $type="global"){
		parent::__construct("themes");
		$this->m_id = $id;
		$this->m_document = $document;
		$this->m_files = array();
		$this->def = $this->add(new IGKCssDefaultStyle());		
		$this->cl = $this->add("Colors");		
		$this->res = $this->add("Resources");
		$this->ft = $this->add("Fonts");
		$this->properties = $this->add("properties");
		$this->rules = $this->add("rules");
		$this->m_type =$type;
		$this->m_medias = array();
		$this->m_mediasid = array();
		//--------------------------------------------
		//cutom theme definitions
		//--------------------------------------------
		$this->Append = $this->add("AppendCss");
	}
	
	public function getRegChangedKey(){
		return self::REGKEY."_".$this->Name;
	}
	
	public function addColor($cl, $value)
	{
		$changed = false;
		if (isset($this->cl[$cl]))
		{
			if ($this->cl[$cl] != $value)
			{
				$this->cl[$cl] = $value;
				$changed = true;
			}
		}
		else{
			$this->cl[$cl] = $value;
			$changed = true;
		}
		if ($changed)
		{
			$this->save();
		}
	}
	public function removeColor($cl)
	{
		if (isset($this->cl[$cl]))
		{
			$this->cl[$cl] = null;
			$this->save();
		}
	}
	public function ClearFont()
	{
		$tab=  $this->ft->Attributes;
		if (count($tab)> 0)
		{
			foreach($tab as $k=>$v)
			{
				$f = igk_io_currentRelativePath($v);
				if (file_exists($f))
					unlink($f);
				
			}
			$this->ft->Attributes->Clear();
			$this->save();
		}
	}
	public function addFont($name, $path)
	{
		$changed = false;
		if (isset($this->ft[$name]))
		{
			$changed = $this->ft[$name] != $path;
			$this->ft[$name] = $path;
		}
		else{
			$this->ft[$name] = $path;
			$changed = true;
		}
		if ($changed)
		{
			$this->save();
		}
	}
	///remove a specific font
	public function removeFont($name)
	{
		$f = $this->ft[$name];
		if ($f )
		{
			if (is_object($f))
			{
			
				$this->ft[$name] = null;
				unset($this->ft[$name]);
				$this->save();
				return true;			
			}
			
			if (is_string(f))
			{
			$f = igk_io_currentRelativePath($f);
			
			if (file_exists($f) && (unlink($f)))
			{
				igk_notifyctrl()->addMsg(R::gets("msg.fontfile.removed"));
				
			}
				$this->ft[$name] = null;
					$this->save();
					return true;
			}
		}
		return false;
	}
	public function load($file)
	{	
		include($file);
	}
	public function getAttributes(){
		throw new Exception("getAttributes not avaiable for theme");
	}
	public function getDeclaration($key = null)
	{
		$out = IGK_STR_EMPTY;
		$key = $key == null ? "\$this" : $key;
		foreach($this->def->Attributes as $k=>$v){
	
			$out .= $key."[\"$k\"]=\"".$v."\";\n";
		}
		foreach($this->getChilds() as $k)
		{
			if ($k->TagName == "Default") 
				continue;
			
			$out .= "\$$k->TagName = igk_getv({$key}->getElementsByTagName(\"$k->TagName\"), 0);\n";
			foreach($k->Attributes as $r=>$s)
			{
				if (is_object($s)){
					switch($k->TagName)
					{
						case "Fonts":
						$out .= "\$$k->TagName[\"$r\"]=\"".str_replace("\\", "\\\\", str_replace("\"","'", igk_css_get_fontdef($s)))."\";\n";
						break;
					}
					continue;
				}
				$out .= "\$$k->TagName[\"$r\"]=\"".str_replace("\\", "\\\\", str_replace("\"","'", $s))."\";\n";
			}
		}
		return $out;
	}
	public function save($file =null){//save theme properties
		$f = ($file==null) ? igk_io_syspath("R/Themes/".$this->Name.".phtml") : $file;
		$out =IGK_STR_EMPTY;
		$out .="<?php\n";
		$out .= $this->getDeclaration();
		$out .="//media properties\n";
		foreach($this->m_medias as $k=>$v)
		{
			$out .= "\$media = \$this->m_medias['$k'];\n";
			$out .= $v->getDeclaration("\$media");
		}
		$out .="?>";		
		$result =  IGKIO::WriteToFileAsUtf8WBOM($f, $out, true);
		igk_sys_regchange(self::REGKEY."_".$this->Name, $this->m_lastchanged);			
		return $result ;
	}
	public function getMedias(){
	
		return $this->m_medias;
	}
	
	public function get_css_def($minfile=false, $themeexport=false)
	{
		$out = $this->_get_css_def(!$minfile, $themeexport );	
		$el = $minfile ? IGK_STR_EMPTY : "\n";
		//write media and media query expression
		foreach($this->m_medias as $k=>$v)
		{
				$out .="@media ".$k."{".$el;
				$out .= $v->_get_css_def(!$minfile, $themeexport );
				$out .="}".$el;
		}		
		return $out;
	}
	private function _get_css_def($indent=true, $themeexport=false)
	{		
	//igk_wln("get css definition from .... ".$this."\n");
$lineseparator = $indent ? "\r\n" : IGK_STR_EMPTY;	
$out =IGK_STR_EMPTY;
$def = $this->def;
$colors = $this->cl;
$fonts = $this->getFont();
$res = $this->res; 
$rules = $this->rules;

//write fonts
if (!$themeexport){
foreach($fonts->Attributes as $k=>$v)
{
	$out .= igk_css_get_fontdef($v, $lineseparator);
}
}

//set default property
if ($def->getHasRules())
{
	$out .= $def->getRulesString($lineseparator).$lineseparator;;	
}
foreach($def->Attributes as $k=>$v)
{	
	$kv = trim(igk_css_treat($this, $v, $themeexport));
	if (!empty($kv))
	{
		$out .= $k."{".$kv."}".$lineseparator;
	}
}

foreach($rules->Attributes as $k=>$v)
{	
	$v=trim($v);
	if (!empty($v))
	{
		$out .= $k." { ".$v."}".$lineseparator;		
	}
}

//add global attribute
/*$tab = $this->def->Attributes->ToArray();
$keys = array_keys($tab);
igk_usort($keys, "igk_key_sort");
foreach($keys as $k)
{
	$cc = $def->Attributes[$k];
	//already define in definition context continue;
	if (!empty($cc))continue;
	
	$v = $tab[$k];
	$kv = trim(igk_css_treat($this, $v));
	if (!empty($kv))
	{
		if (IGKString::StartWith($k, "#"))
			$out .= $k."{".$kv."}".$lineseparator;
		else
			$out .= $k."{".$kv."}".$lineseparator;		
	}
}*/

$res = $this->res; 
if (!$themeexport){
foreach($res->Attributes as $k=>$v)
{
	$out .= ".".$k."{background-image: url('../Img/".$v."');}".$lineseparator;	
}
}
//render Append theme
$tab = $this->Append->Attributes->ToArray();
if (count($tab)>0)
{
	$keys = array_keys($tab);
	$out .= "/* APPEND THEME */\n";
	igk_usort($keys, "igk_key_sort");
	foreach($keys as $k)
	{	
		$v = $tab[$k];
		$kv = trim(igk_css_treat($this, $v,  $themeexport));
		if (!empty($kv))
		{
			if (IGKString::StartWith($k, "#"))
				$out .= $k."{".$kv."}".$lineseparator;
			else
				$out .= ".".$k."{".$kv."}".$lineseparator;
		}
	}
}
return $out;
	}

	public function getAllClassExpression(){
		$out = IGK_STR_EMPTY;
		$def = $this->def;
		$tab =  IGKHtmlItem::CreateWebNode("table");
		foreach($def->Attributes as $k=>$v){
			$r = $tab->addRow();
			$r->add("td")->Content =  $k;
			$r->add("td")->Content =  $v;
		}
		$out .= $tab->Render();
		return $out;
	}


	public function OffsetGet($key){
		return $this->def[$key];
	}
	public function OffsetSet($key, $value){
		$this->def[$key] = $value;
	}
}
///<summary>igk framework form</summary>
final class IGKHtmlForm extends IGKHtmlStylableItem
{
	private $m_encType;
	private $topdiv;
	private $bodydiv;
	private $footdiv;
	private $m_notitle;
	private $m_nofoot;
	
	const URLEncoded = "application/x-www-form-urlencoded";
	
	public function getNoTitle(){return $this->m_notitle;}
	public function getNoFoot(){return $this->m_nofoot;}
	public function setNoTitle($value){ $this->m_notitle = $value;}
	public function setNoFoot($value){ $this->m_nofoot = $value;}
	public function getAction(){return $this["action"];}
	public function setAction($value){return $this["action"]=$value;}
	public function getMethod(){return $this["method"];}
	public function setMethod($value){return $this["method"] = $value;}
	public function getEncType(){return $this->m_encType;}
	public function setEncType($value){$this->m_encType=$value;}
	public function setTitle($value){$this->topdiv->Content = $value;}
	public function getTitle(){return $this->topdiv->Content;}
	public function getContent(){return $this->bodydiv; }
	
	public function __construct($notitle=false, $nofoot = true){
		parent::__construct("form");
		$this->Method = "POST";
		$this->Action= ".";
		$this->m_encType =true;
		$this->m_notitle = $notitle;
		$this->m_nofoot = $nofoot;
		$this["class"]="clbasicform";
		$this["enctype"]=IGK_HTML_ENCTYPE;
		$this->topdiv =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>"title"));		
		$this->bodydiv =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>"content"));
		$this->footdiv =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>"foot"));
		
		parent::_AddChild($this->topdiv);
		parent::_AddChild($this->bodydiv);
		parent::_AddChild($this->footdiv);
	}
	public function ClearChilds(){//Clear only the body childs
		$this->bodydiv->ClearChilds();
	}
	protected function _AddChild($item, $index=null)
	{		
		return $this->bodydiv->_AddChild($item);		
	}
	public function add($nameoritem, $attributes=null, $index= null)
	{
		$t = null;
		$t = $this->bodydiv->add($nameoritem, $attributes, $index);				
		return $t;
	}
	public function Render($options=null)
	{
		// if ($this->m_encType)
			// $this["enctype"]=$this->m_encType;
		// else 
			// $this["enctype"]=IGK_HTML_ENCTYPE;	
		$e = $this->topdiv->Content;		
		$this->topdiv->setIsVisible(!empty($e) && !$this->m_notitle);
		$this->footdiv->setIsVisible(!$this->m_nofoot);
		
		return parent::Render($options);		
	}
}


class IGKHtmlCssLink extends IGKHtmlItem
{
	var $link;
	private $ln;
	public function getType(){return $this->ln["type"];}
	public function getRel(){return $this->ln["rel"];}
	public function setType($value){$this->ln["type"]= $value;}
	public function setRel($value){ $this->ln["rel"] = $value;}
	public function __construct($link){
		$this->setIsVisible(true);
		$this->link = $link;
		$this->ln = self::CreateWebNode("link");
		$this->ln["type"]="text/css";
		$this->ln["rel"]="stylesheet";
	}
	protected function innerHTML(& $option = null){//CSS innerHTML render nothing
		return null;
	}
	public function Render($options=null){
		if (IGKValidator::IsUri($this->link))
		{
			$this->ln["href"] = $this->link;
		}
		else{
			$s = IGKIO::GetCurrentRelativeUri($this->link);
			// if (!file_exists(realpath($s))){	
			// igk_wln(" not exists ".getcwd() . " :: ".realpath($s). ";; ".$this->link);
				// return null;
			// }
			$this->ln["href"] = igk_html_uri($s);
		}			
		return $this->ln->Render($options);
	}
}
final class IGKHtmlLink extends IGKHtmlItem
{
	var $i;
	public function __construct(){
		parent::__construct("link");
		$this->i = 1;
	}
	
	public function Render($options=null){				
		return parent::Render($options);
	}
}
class IGKHtmlScript extends IGKHtmlItem
{
	var $link;
	var $canBeMerged;
	///private $ln;
	public function __construct($link=null){
		parent::__construct("script");
		$this->link = $link;
		$this["type"]="text/javascript";
		$this["language"]="javascript";
		$this->canBeMerged = true;
		
	}
	public function offsetSet($name, $value)
	{
		if (strtolower($name)=="src")
		{
			$this->link = $value;
		}
		else {
			parent::offsetSet($name, $value);
		}
	}
	
	public function Render($options=null){		
		if ($options && $options->ForMailTransport){
			return IGK_STR_EMPTY;
		}
		$src = IGK_STR_EMPTY;
		if ($this->link !=null)
		{
			if (!IGKValidator::IsUri($this->link) && file_exists($this->link))
			{
				$s = igk_io_basePath($this->link);
				if ($s == $this->link) //not evaluated
				{
					$src = igk_html_uri(igk_io_currentRelativePath($s));
				}
				else{
					$src = igk_io_currentRelativeUri($s);
				}				
			}
			else{
				$src = igk_html_uri( $this->link);
			}
		}		
		parent::offsetSet("src", $src);
		return parent::Render($options);
	}
}
class IGKHtmlDiv extends IGKHtmlStylableItem
{
	protected  function closeWithCloseTag(){
		return true;
	}
	public function __construct(){
		parent::__construct("div");
		
	}
	
}
class IGKHtmlImg extends IGKHtmlStylableItem
{
	private $m_lnk;
	private $m_img;
	
	public function getSrc(){
		return $this->m_lnk; 
	}
	public function setSrc($value){
		$this->m_lnk=$value;
	}
	public function offsetGet($key){
		if (strtolower($key)=="src")
			return $this->m_lnk;
		return $this->m_img->offsetGet($key);
	}
	// var $intc = 0;
	public function offsetSet($key,$value) {		
		if (strtolower($key) =="src")
		{			
			$s = igk_io_baseUri();			
			$rg = "/((".str_replace("/","\\/", $s)."\/)+)/i";
			if (preg_match($rg, $value))
			{
				//remove domain name
				$value = preg_replace($rg, IGK_STR_EMPTY, $value);
			}
			$this->m_lnk = $value;
		}
		$this->m_img->offsetSet($key,$value);
	}
	public function __construct(){
		$this->m_img = new IGKHtmlItem("igk-img");
		$this->m_img["alt"]=null;//R::ngets("tip.picture");	
		parent::__construct("igk-html-image");
	}

	protected function _p_isClosedTag($tag)
	{
		switch(strtolower($tag))
			{
				case "igk-html-image":
				case "igk-img":
				case "img":
				case "image":			
					return true;
			}
			return false;
	}
	public function IsLoadedClosedTag($loadedTag){//override if this is a loaded closed tag
		switch(strtolower($loadedTag))
		{
			case "igk-html-image":
			case "igk-img":
			case "img":
			case "image":			
				return true;
		}
		return false;
	}
	public function Render($options=null)
	{

		if (strstr($this->m_lnk, ".."))
		{
			$this->m_lnk = str_replace("../",IGK_STR_EMPTY,  $this->m_lnk);
		}
		$s = IGK_STR_EMPTY;
		$k = igk_html_uri($this->m_lnk);
		if (!empty($k))
		{
			if (IGKValidator::IsUri($k) || (preg_match("#^file://#i", $k)))
			{				
				$s = $k;
			}
			else{
				$f = $this->m_lnk;
				if (file_exists($f))
				{
					$s = igk_io_fullpath2Uri(realpath($f));
				}
				else {
					$s = igk_html_uri(igk_io_currentRelativePath($f));		
				}
			}
		}
		else
			$s =null;
		$this->m_img["src"] = $s;
		return $this->m_img->Render($options);
	}
	public function __toString()
	{
		return "HtmlImg[".$this->TagName."] Attributes : [".$this->Attributes->Count."] ; Childs : [ ".$this->ChildCount." ]";
	}
}

//
final class IGKHtmlImageNodeItem extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("img");
	}
}
final class IGKHtmlNothingItem extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("nothingitem");
	}
	//unable to add child to this item
	protected function _AddChild($item, $index=null){return false;}
	public function Render($options=null){//render htmlNothing Item
		return null;
	}
}
class IGKHtmlDoctype extends IGKHtmlItem
{
	public function __construct($value){
		$this->Content = $value;
	}
	public function Render($options=null){//render doc type
		$out = "<!DOCTYPE ".$this->Content . " >".$this->indentLine($options);
		return $out;
	}
	protected function _AddChild($item, $index=null){return false;}
}
final class IGKHtmlCommentItem extends IGKHtmlItem
{
	public function getNodeType(){
		return IGKXMLNodeType::COMMENT;
	}
	public function getHasAttributes(){return false;}
	public function __construct($value=null){
		parent::__construct("igk-comment");
		$this->Content = $value;		
	}
	public function Render($options=null){//render comment
		$out = $this->getIndentDepth($options)."<!-- ".$this->Content . " -->".$this->indentLine($options);		
		return $out;
	}
	public function __toString(){
		return "HtmlComment[".$this->Content."]";
	}
	protected function _AddChild($item, $index=null){return false;}
}
class IGKHtmlMeta extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("meta");
	}
	public function setContent($v){/*no set content*/ return $this;}
	protected function _AddChild($item, $index=null){return false;}
}
class IGKHtmlUl extends IGKHtmlStylableItem
{
	public function __construct(){
		parent::__construct("ul");
	}
	public function addLi($attributes=null){
		return $this->add("li", $attributes);
	}
	public function addLiA($url, $attributes=null)
	{
		return $this->addLi($attributes)->addA($url);
	}
}
class IGKHtmlInput extends IGKHtmlStylableItem
{
	public function __construct(){
		parent::__construct("input");
	}
	
	protected function _AddChild($item, $index=null){return false;}
}
///<summary>represent a server response item. used to send name, value, description data to client</summary>
final class IGKHtmlResponse extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("response");
	}
	public function addItem($name, $value, $description = null)
	{
		$i = $this->add("item");
		$i["name"] = $name;
		$i->Content =  $value;
		$i["description"] = $description;
		return $i;
	}
}

///<summary>represent html utility </summary>
final class IGKHtmlUtils
{
	public static function GetContentValue($c){
		if (is_array($c))
		{
			$r =  IGKHtmlItem::CreateWebNode("content");
			$i = 0;
			foreach($c as $k=>$v)
			{		
				if (ord($k)==0)
				$r->add("item")
				->setAttribute("key", $k)			
				->setContent($v);
				$i++;
			}
			return $r->getinnerHTML(null);
		}
		return self::GetValue($c);
	}
	public static function AddToggleAllCheckboxTh($tr, $targetid=null)
	{
		if ($targetid !=null)
			$targetid = ",'#$targetid'";
		return $tr->add("th",array("class"=>"box_16x16"))->add("li")->add("input", 
			array("type"=>"checkbox","onchange"=>"ns_igk.html.ctrl.checkbox.toggle(this, ns_igk.getParentByTagName(this, 'table'), this.checked, true $targetid);"));
	}
	
	public static function GetTableFromSingleArray($array)
	{
		$tab =  IGKHtmlItem::CreateWebNode("table");
		foreach($array as $k=>$v)
		{
			$tr = $tab->add("tr");
			$tr->add("td")->Content  = $k;
			$tr->add("td")->Content  = $v;
		}
		return $tab;
	}
	///get all element childs
	public static function GetAllChilds($t)
	{
		$d = array();
		if (method_exists(get_class($t), "getChilds"))
		{
			$s = $t->getChilds();
			if (is_array($s))
			{
				$d = array_merge($d, $s);
				
				foreach($s as $k){
					$d = array_merge($d, igk_getAllChilds($k));
				}
			}
		}		
		return $d;
	}
	
	///used to create sub menu in category 
	public static function CreateConfigSubMenu($target, $items, $selected =null)
	{
		
		$ul = $target->add("ul", array("class"=>"igk-cnf-content_submenu"));
		foreach($items as $k=>$v)
		{
			$li = $ul->add("li");
			$li->add("a", array("href"=>$v))->Content = R::ngets("cl".$k);
			if ($selected == $k)
			{
				$li["class"] = "+igk-cnf-content_submenu_selected";
			}
			else{
				$li["class"] = "-igk-cnf-content_submenu_selected";
			}
		}
		return $ul;
	}
	public static function ToggleTableClassColor($target, $type="tr",  $startAt=0, $class1="table_darkrow", $class2="table_lightrow")
	{
		if ($target == null)return;
		$k = 0;
		$tab = $target->getElementsByTagName($type);
		
		for	($i = $startAt; $i< count($tab); $i++)
		{
			if (isset($tab[$i])){
			$tr = $tab[$i];
			if ($k == 0)
			{
				$tr["class"] =$class1;
				$k=1;
			}
			else 
			{
				$tr["class"] = $class2;
				$k = 0;
			}
			}
		}
	}
	public static function BuildForm($array)
	{
		$frm =  IGKHtmlItem::CreateWebNode("form");
		foreach($array as $k=>$v)
		{
			switch(strtolower($k))
			{
				case "label":
					$lb = $frm->add("label");
					$lb->Content = R::ngets(IGK_STR_EMPTY);
				break;
				case "radio":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "radio");
				break;
				case "checkbox":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "checkbox");
				break;
				case "hidden":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "hidden");
				break;
				
				case "button":
				case "submit":
				case "reset":
					$frm->addInput($v["id"],strtolower($k),igk_getv($v ,"text", "r") );
				break;
				case "textarea":
					$frm->addTextArea($v["id"]);
				break;
				case "br":
					$frm->addBr();
				break;
			}
		}
		return $frm;
	}
	public static function ShowHierarchi($var){

	$out = IGK_STR_EMPTY;
	if ($var->HasChilds){
		$out .="<ul>";
	foreach($var->Childs as $k)
	{
		$out .= "<li>".$k->TagName;
		if ($k->TagName == "a")
			$out.= " : ".$k->Content;
		if ($k->TagName == "input")
			$out.= " : ".$k["value"];
		$out .= self::ShowHierarchi($k);
		
		$out .="</li>";
	}
	$out.="</ul>";
	}
	return $out;
}
	//new input
	public static function nInput($id, $value=null, $type="text")
	{
		$btn =  IGKHtmlItem::CreateWebNode("input")->AppendAttributes(array("id"=>$id, "name"=>$id, "type"=>$type, "value"=>$value));
		switch(strtolower($btn["type"]))
		{
			case "button":
			case "submit":
			case "reset":
				$btn["class"]="clbutton";
			break;
		}
		return $btn;
	}
	//
	public static function nTextArea($id, $value){
		return IGKHtmlItem::CreateWebNode("textarea")->AppendAttributes( array("id"=>$id, "name"=>$id, "value"=>$value));
	}
	public static function nBtn($owner, $uri, $img, $width=16, $height=16)
	{	
		$n = new IGKHtmlLinkBtnItem();	
		
		$n->Href = $uri;
		$n->Width = $width."px";
		$n->Height = $height."px";
		$n->ImgSrc = $img;		
		$owner->add($n);
		return $n;
	}
	public static function RemoveItem($item, $dispose=false)
	{		
		$p = null;
		if (($item!=null)&&	(($p= $item->getParentNode()) !=null ))
		{			
			if ($p->remove($item) == false)
			{
				igk_wln("false to remove item");
			}
			igk_debug_wln("item removed");			
			return true;
		}
		igk_debug_wln("item not removed");		
		return false;
	}
	
	//add items	
	public static function AddItem($item, $target, $index=null)
	{
		if (($item==null) || ($target==null))
			return false; //cant not add
		if ($item->ParentNode === $target)
			return true;//already a item child
		self::RemoveItem($item, false);
		return $target->add($item, null, $index);					
	}
	//copy item child to target
	public static function CopyChilds($item, $target)
	{
		if (($item==null)||($target==null)|| !$item->HasChilds)
			return false;
			foreach($item->getChilds() as $k)
			{
				$target->Load($k->Render());
			}
			return true;
	}
	//move instance
	public static function MoveChilds($item, $target)
	{
		if (($item==null)||($target==null)|| !$item->HasChilds)
			return false;
			foreach($item->getChilds() as $k)
			{
				IGKHtmlUtils::AddItem($k, $target);
			}
			return true;
	}
	//return value according to string
	public static function GetValue($c)
	{
		$out = IGK_STR_EMPTY;
		if (is_numeric($c) && ($c == 0))
			return "0"; 
			if (is_numeric($c) || (is_string($c) &&  !empty($c)))
			{
				$out.=$c;
			}
			else if (is_object($c) && (method_exists(get_class($c),"getValue")) )//&& get_class($c) == "IGKLangKey")
			{
				$out .= $c->getValue();
			}
			
		return $out;
	}
	public static function GetAttributeValue($c)
	{
		$s = self::GetValue($c);
		
		$q = trim($s);
		$v_h = "\"";
		if (preg_match("/^\'/", $q) && preg_match("/\'$/", $q))
		{			
			$v_h ="'";
		}	
		
		if (IGKString::StartWith($q, $v_h))
		{
			$q = substr($q,1);
		}
		if (IGKString::EndWith($q, $v_h))
		{
			$q = substr($q,0, strlen($q) - 1);
		}
		
		if ($v_h == "\"")		
		{			
			$q = str_replace("\"", "&quot;", $q);
		}
		return $q;
	}
	/// add button link
	public static function AddBtnLnk($target, $langkey,  $uri, $attributes = null)
	{	
		if ($target==null)return;
		$a  = $target->add("a" ,array("class"=>"igk-btn-lnk", 
			  "href"=>$uri));
			  $a->Content = is_string($langkey) ?  R::ngets($langkey) : $langkey;
		if (is_array($attributes))
		{
			$a->AppendAttributes($attributes);
		}
		return $a;
	}
	/// AddImgLnk add image link
	public static function AddImgLnk($target, $uri, $imgname, $width="16px", $height="16px", $desc=null, $attribs=null)
	{
		if (is_object($target))
		{
			$a  = $target->add("a", array("href"=>$uri, "class"=>"img_lnk"));
			$t = array();
			$t["a"] = $a;
			$t["img"] = $a->add("img", 
							array(
							"width"=>$width,
							"height"=>$height, 
							"src"=>R::GetImgUri($imgname),
							"alt"=>R::ngets($desc)));			
			$a->AppendAttributes($attribs);
			return (object)$t;
		}
		return null;
	}
	/// AddImgLnk add image link
	public static function AddAnimImgLnk($target, $uri, $imgname, $width="16px", $height="16px", $desc=null, $attribs=null)
	{
		if (is_object($target))
		{
			$a  = $target->add("a", array("href"=>$uri, "class"=>"img_lnk"));
			$t = array();
			$t["a"] = $a;
			$t["img"] = $a->add("igk-anim-img", 
							array(
							"width"=>$width,
							"height"=>$height, 
							"src"=>R::GetImgUri($imgname),
							"alt"=>R::ngets($desc)));
			$a->AppendAttributes($attribs);
			return (object)$t;
		}
		return null;
	}
}

///<summary>represnet xml node type</summary>
final class IGKXMLNodeType{//enum type 
	const NONE = -1;
	const ELEMENT = 1;
	const PROCESSOR = 2;
	const COMMENT = 3;
	const ENDELEMENT = 4;
	const CDATA = 5;
	const TEXT = 6;
	const DOCTYPE = 7;
	
	public function GetString($i){///represent nod type
		switch($i)
		{
			case self::NONE: return "NONE";
			case self::ELEMENT : return "ELEMENT";
			case self::PROCESSOR : return "PROCESSOR";
			case self::COMMENT : return "COMMENT";
			case self::ENDELEMENT : return "ENDELEMENT";
			case self::CDATA : return "CDATA";
			case self::TEXT : return "TEXT";
			case self::DOCTYPE : return "DOCTYPE";
		}
		return "UNKNOWN";
	}
}

///<summary> xml render document</summary>
class IGKHtmlReaderDocument extends IGKHtmlItem{
	public function __construct()
	{
		parent::__construct("DocumentToRender");
	}
	public function Render($options = null)
	{
		$out = IGK_STR_EMPTY;
		foreach($this->Childs as $k)
		{
			$out .= $k->Render($options);
		}
		return $out;
	}
	///<summary> copy the current node to destination</summary>
	public function CopyTo($target)
	{	
		$t = $this->Childs->ToArray();
		$this->__rm_childs(__FUNCTION__);
		foreach($t as $k)
		{
			if ($k == null)
				continue;
			$target->add($k);
		}
	}	
}

///<summary> represent a html/xml reader info</summary>
class IGKHtmlReader{
	private $m_hfile;
	private $m_text;
	private $m_mmodel;
	private $m_offset;
	private $m_name;
	private $m_value;
	private $m_nodetype;
	private $m_isEmpty;
	private $m_hasAttrib;
	private $m_attribs;
	
	public function NodeType()
	{
		return $this->m_nodetype;
	}
	private function __construct($text)
	{
		$this->m_text= $text;
		$this->m_offset =0;
		$this->m_nodetype= IGKXMLNodeType::NONE;
		$this->m_attribs = null;
	}
	public function Name(){ return $this->m_name;}
	public function Value(){ return $this->m_value;}
	public function IsEmpty(){return $this->m_isEmpty;}
	public function HasAttrib(){return $this->m_hasAttrib;}
	public function Attribs(){return $this->m_attribs; }
	public function Read()
	{
		if (!$this->CanRead())
		{//default setting
			$this->m_nodeType  = IGKXMLNodeType::NONE;
			$this->m_value = null;
			$this->m_name = null;
			$this->m_isEmpty = true;
			$this->m_hasAttrib = false;
			$this->m_attribs = null;
			return false;
		}
		
		$v_enter = false;
		$this->m_isEmpty = false;
		$this->m_hasAttrib  = false;
		$v = IGK_STR_EMPTY; //value
	
		
		while($this->CanRead())
		{
			$c =$this->m_text[$this->m_offset];
		
			switch($c)
			{
			case "<":
				$v_enter = true;								
			break;
			case "?": //preprocessor instruction
				if ($v_enter)
				{
						//reading process
						$this->m_offset ++;
						$v =IGK_STR_EMPTY;
						while( $this->CanRead())
						{
							$v .= $this->m_text[$this->m_offset];							
							$this->m_offset++;
							//end comment
							if (substr($v, -2, 2) == "?>")
							{
								$v = substr($v, 0, strlen($v)-3);
								
								$this->m_name = null;
								$this->m_value = $v;
								$this->m_nodetype = IGKXMLNodeType::PROCESSOR;
								return true;								
							}
						}
						
				}
				else{
				//not entered a prepropecessor instruction
					return $this->__readTextValue($v);
				}
				return false;				
			break;
			case "!": 			
				if ($v_enter)
				{
					if (substr($this->m_text, $this->m_offset+1,2) == "--")
					{
						//reading comment
						$this->m_offset +=3;
						$v =IGK_STR_EMPTY;
						while( $this->CanRead())
						{
							$v .= $this->m_text[$this->m_offset];							
							$this->m_offset++;
							//end comment
							if (substr($v, -3, 3) == "-->")
							{
								$v = substr($v, 0, strlen($v)-3);								
								$this->m_name = null;
								$this->m_value = $v;
								$this->m_nodetype = IGKXMLNodeType::COMMENT;								
								return true;								
							}
						}						
					}
					else if (strtoupper(substr($this->m_text, $this->m_offset+1,7)) == "[CDATA[")
						{//reading CDATA
							$this->m_offset +=8;
							$v =IGK_STR_EMPTY;
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//end comment
								if (substr($v, -3, 3) == "]]>")
								{
									$v = substr($v, 0, strlen($v)-3);								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = IGKXMLNodeType::CDATA;								
									return true;								
								}
							}						
					}
					else if (strtoupper(substr($this->m_text, $this->m_offset+1,7)) == "DOCTYPE")
					{//reading DOC TYPE
							$this->m_offset +=8;
							$v =IGK_STR_EMPTY;
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//end doctype
								if (substr($v, -1, 1) == ">")
								{
									$v = substr($v, 0, strlen($v)-1);								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = IGKXMLNodeType::DOCTYPE;								
									return true;								
								}
							}					
					}
					return false;
				}
			break;			
			case "/": //end element	
				if ($v_enter)
				{		
					$this->m_offset+=1;				
					$this->m_nodetype =  IGKXMLNodeType::ENDELEMENT;
					$this->m_name = $this->ReadName();
					$this->m_value= null;
					$v_enter = false;
					return true;
				}
				$v .= $c;
				break;
			default:	//read default case			
				if (!$v_enter)
				{
					if ($this->m_nodetype ==  IGKXMLNodeType::ELEMENT)
					{
						
						$match = array();
						if (strtolower($this->m_name) == "script")
						{//special script node
						
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								
								if (preg_match("/\<\/([\s]*)script([\s]*)\>$/i",$v, $match))
								{
									$this->m_offset-= strlen($match[0]);
									$v = substr($v, 0, strlen($v)-strlen($match[0]));	
									break;
								}
							}
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = IGKXMLNodeType::TEXT;	
									return true;
						}
						else if (strtolower($this->m_name) == "style")
						{//for style
						
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								
								if (preg_match("/(\<\/([\s]*)style([\s]*)>)$/i",$v, $match))
								{
									$this->m_offset-= strlen($match[0]);
									$v = substr($v, 0, strlen($v)-strlen($match[0]));	
									break;
								}
							}
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = IGKXMLNodeType::TEXT;	
									return true;
						}
						else {
						    //
							//read text value	
							//
							return $this->__readTextValue($v);
						}
					}
					else{
							//read text elements
							$v=IGK_STR_EMPTY;
							if ($this->m_nodetype ==  IGKXMLNodeType::ENDELEMENT)
								$this->m_offset++;
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//e
								if (substr($v, -1, 1) == "<")
								{
									$v = substr($v, 0, strlen($v)-1);		
									$this->m_offset--;								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = IGKXMLNodeType::TEXT;										
									return true;								
								}
							}
					}
				}
				else
				{//element requested
				
					$this->m_name = $this->ReadName();
					$this->m_value= null;
					$this->m_nodetype =  IGKXMLNodeType::ELEMENT;		
					$this->m_isEmpty = false;
					$this->m_hasAttrib = false;
					//get attribute
					$v_end = false;
					$v = IGK_STR_EMPTY;//for xml read attribute contains
					$v_readname =false;
					$v_readvalue=false;
					//$v_assoc = array();
					$v_attribname = null;
					$v_ch = null;//character
					$v_startattribvalue = false;
					$v_attribmatch =IGK_STR_EMPTY;
						while( $this->CanRead())
						{
							$v_ch =  $this->m_text[$this->m_offset];													      	
							$v .= $v_ch;
							$this->m_offset++;					
							if (preg_match("('|\")", $v_ch))
							{
								if ($v_startattribvalue )
								{
									if($v_attribmatch == $v_ch)
										$v_startattribvalue = false;
								}
								else{
									$v_startattribvalue = true;
									$v_attribmatch = $v_ch;//save the attrib value start match
								}
							}
							if ($v_startattribvalue)continue;
							if (substr($v, -2, 2) == "/>")
							{
								//empty element
								$v = trim(substr($v,0, strlen($v)-2));
								$this->m_isEmpty = true;
								break;
							}
							else if (substr($v, -1, 1) == ">")
							{
								$v = trim(substr($v,0, strlen($v)-1));
								$this->m_isEmpty = false;
								break;
							}
							//for reading the name
							if ($v_readname ==false)
							{
								if (preg_match("/([\s])/",$v_ch))
								{
									$v_attribname=$v_ch;
									$v_readname = true;
									$v_readvalue = false;
								}
							}
							else{
								if (preg_match("/[\s]/", $v_ch))
									$v_attribname .= $v_ch;
								else{
									$v_readname = false;
									//$v_assoc[] = $v_attribname;
								}
							}
						}
						
						if (!empty($v))
						{
								
								//get all matching attributes
								$this->m_hasAttrib =true;								
								$m = null;		
								//def: "/(\w+)[\s]*=[\s]*(\"|')(?P<value>(([^\"']*(')?)+))(\"|')/"								
								$machv = "(?P<value>";
								$machv .= "([\"](([^\"]*(')?(\"\")?)+)[\"])";
								$machv .= "|([\'](([^']*(\")?('')?)+)[\'])";
								$machv .= "|(([^\s]*)+)";
								$machv .= ")";
								
								//$acount = preg_match_all("/(\w+)[\s]*=[\s]*(".$machv.")/",$v, $m);			
								$acount = preg_match_all("/(?P<name>(".IGK_TAGNAME_CHAR_REGEX."+))[\s]*=[\s]*(".$machv.")/i",$v, $m);										
								$this->m_attribs = array();
								for($cc =0;$cc< $acount; $cc++)
								{
									$this->m_attribs[$m["name"][$cc]] =IGKHtmlUtils::GetAttributeValue($m["value"][$cc]);							
								}
						}					
						return true;
				}
				break;
				
		}
			$this->m_offset+=1;		
		}
		if (!$v_enter && !empty($v))
		{
			$this->m_name = null;
			$this->m_value = $v;
			$this->m_nodetype = IGKXMLNodeType::TEXT;		
			return true;	
		}
		return false;
	}
	private function __readTextValue($v=IGK_STR_EMPTY)
	{
	
		while( $this->CanRead())
		{
			$v .= $this->m_text[$this->m_offset];							
			$this->m_offset++;
			
			if (substr($v, -1, 1) == "<")
			{
				$v = substr($v, 0, strlen($v)-1);		
				$this->m_offset--;								
				$this->m_name = null;
				$this->m_value = $v;
				$this->m_nodetype = IGKXMLNodeType::TEXT;		
				return true;								
			}
		}
		return false;
	}
	//check if can read
	private function CanRead()
	{
		
		return (($this->m_offset>=0) && ($this->m_offset < strlen($this->m_text)));
	}
	/// read tag name
	private function ReadName()
	{
		$v = IGK_STR_EMPTY;
		//check reaed cararacter
		while( $this->CanRead() && preg_match("/".IGK_TAGNAME_CHAR_REGEX."/i",$this->m_text[$this->m_offset]))
		{
			$v .= $this->m_text[$this->m_offset];
			$this->m_offset++;
		}		
	
		return $v;
	}
	
	public static function Create($file)
	{
		if (is_file)
		{
			$f = fopen($file,"r");
			if ($f)
			{
				$reader = new IGKHtmlReader();
				$reader->m_hfile = $f;
				return $reader;
				
			}
		}
		return null;
	}	
	public function Close(){
		fclose($this->hfile);
	}
	
	/// return a array of xml node
	//------------------------------
	public static function Load($text)
	{
		$opentag = false;		
		$tab = null; 
		$cnode = null;
		$pnode = null;
		
		if (is_string($text))
		{
		
			$tab =  new IGKHtmlReaderDocument();			
			$reader = new IGKHtmlReader($text);
			//$resolved = array();
			
			//get elements
			while($reader->Read())
			{
			  	switch($reader->NodeType())
				{
					case IGKXMLNodeType::ELEMENT :							
						$name = $reader->Name();
						if(empty($name))
						{
							continue;
						}	
					
						$v = IGKHtmlItem::CreateElement($name);						
						if ($reader->HasAttrib())
						{
							//build attribs
							$cattr = $reader->Attribs();
							foreach($cattr as $k=>$c)
							{											
								$v[$k] = $c;
							}
						}
						if (!$cnode)
						{					
							$tab->add($v);
							$cnode = $v;
						}
						else 
						{
							$cnode = self::_addItem($v, $tab, $cnode);						
						}		
						if ($reader->IsEmpty())
						{
							//move to parent
							$cnode = $cnode->getParentNode();
							if ($cnode == $tab)
								$cnode = null;
						}
						break;
					case IGKXMLNodeType::TEXT:
						//add only text to current node element		
						$v_sr= $reader->Value();						
						$v_c=IGK_STR_EMPTY;
						if (!empty($v_sr) && (strlen(trim($v_sr))>0))
						{
							$v_c = $v_sr;
						}
						if (!empty($v_c))
						{
							if ($cnode)
							{
								$cnode->addText($v_sr);									
							}	
							else{
								$v = new IGKHtmlText($v_sr);
								$tab->add($v);
								$cnode = $v;
							}
						}						
						break;
					case IGKXMLNodeType::COMMENT:
						$v_v = $reader->Value();					
						$v = new IGKHTMLCommentItem($v_v);	
							
						if (!$cnode)
						{
							$cnode = $v;
							$tab->add($v);
						}
						else{								
							$cnode = self::_addItem($v, $tab, $cnode);
						}						
						break;
					case IGKXMLNodeType::CDATA:
					case IGKXMLNodeType::DOCTYPE;
						$v = self::CreateElement($reader->NodeType()); 
						$v->Content = $reader->Value();
						if (!$cnode)
						{
							$cnode = $v;
							$tab->add($v);
						}
						else{
							$cnode = self::_addItem($v, $tab, $cnode);
						}					
						break;
					case IGKXMLNodeType::ENDELEMENT :
						if ($cnode)
						{
							$t = $cnode->TagName;
							$n = $reader->Name();
							if (($n == $t) || $cnode->isCloseTag($n)  || self::IsResolved($cnode, $n))
							{
								//igk_wln("goto parent ");
								//go to parent
								$cnode = $cnode->getParentNode();	
							}
							else{
								$rsv = false;
								while( $cnode && ($cnode->TagName != $reader->Name()) && !($rsv && self::IsResolved($cnode, $n)))
								{
									$cnode = $cnode->getParentNode();
									$rsv =true;
								}
								if ($cnode)
									$cnode = $cnode->getParentNode();
								else{
									throw new Exception("Bad Html structure can't get parent, cnode is null, name : $n  , tagName : $t  ?  <br/>\nLine : ".
									__LINE__."\n"
									.$text
									."\n".
									" : ".get_class($cnode)
									);
								}
							}
							if ($cnode == $tab)
								$cnode = null;
						}
						else 
							$cnode = null;
					break;
					case IGKXMLNodeType::PROCESSOR:	
							$v = $reader->Value();
							$v_cnode = new IGKHtmlProcessInstruction($v);
						if (!$cnode)
						{
							$cnode = $v_cnode;
							$tab[] = $cnode;							
						}	
						else{
							$cnode->add($v_cnode);
						}							
						break;
				}
			}
		}
		else if (is_resource($text))
		{//loading resources files
			
		}		
		return $tab;
		
	}
	private static function IsResolved(&$node, $tagName){// igk::
		if (!$node)
			return false;
		if (IGKString::StartWith($tagName, "igk:"))
		{
			$f = IGKString::Format(IGK_HTML_NODE_FORMAT, substr($tagName, 4));
			
			if (strtolower($f) == strtolower(get_class($node)))
			{	
				return class_exists($f) && !igk_reflection_class_isabstract($f) && igk_reflection_class_extends($f, 'IGKHtmlItem');		
			}
			else{							
				if ($node->getParentHost()!=null){
					$node = $node->getParentHost();
					return self::IsResolved($node, $tagName);
				}
			}
		}
		return false;
		
	}
	private  static function _addItem($v, $tab, $cnode)
	{
		
		if ($cnode->add($v))
		{
			$cnode = $v;
			
		}
		else if (!self::_AddToParent($tab, $cnode, $v))
		{
			$tab->add($v);
			$cnode = $v;
		}
		else {
			$cnode = $v;
		}
		return $cnode;
	}
	public static function CreateElement($nodetype,$value=IGK_STR_EMPTY)
	{
		$v = null;
		switch($nodetype)
		{
			case IGKXMLNodeType::CDATA:
				$v = new HTMLCData($value);
				break;
			case IGKXMLNodeType::DOCTYPE:
				$v = new IGKHtmlDoctype($value);
				break;
		}
		return $v;
	}
	//@load the  files
	public static function LoadFile($file)
	{
		if (is_file($file))
		{
			$size  = @filesize($file);
			if ($size > 0)
			{
				try{
				$hfile = fopen($file, "r");
				}
				catch(Exception $ex)
				{
				}
				if ($hfile)
				{
				$text  = fread($hfile, $size);
				fclose($hfile);			
				return self::Load($text);
				}
			}
			return null;
		}
		throw new Exception("file : ".$file." doesn't exist");
	}
	
	static function _AddToParent($topnode, $cnode, $node)
	{	
		$p = $cnode->getParentNode();
		if ($topnode === $p)
			return false;
		if ($p)
		{
			if ($p->add($node)==false)
			{
				return self::_AddToParent($topnode, $p, $node);
			}
			else 
				return true;
		}
		return false;
	}


}

//------------------------------------------------------------------------------------------
//DATABASE MANAGEMENT
//------------------------------------------------------------------------------------------

///<summary>db manager interface</summary>
interface IIGKdbManager
{
	function connect();
	function dropTable($tableName);
	function close($leaveopen=false);
}
interface IIGKQueryConditionalExpression extends IIGKHtmlGetValue
{
	//add an expression
	function add($expression, $operator="AND");
	//remove an expression
	function remove($expression);
	//get number of expression
	function getCount();
}
///<summary> represent </summary>
interface IIGKQueryResult{//represent a queryr result....
	
}

///<summary> represent IGKDbEntiry object </summary>
class IGKDbEntity extends IGKObject
{
	private $m_propertyChangedEvent;
	private $m_db_origin;
	private $m_table_origin;
	
	public function __construct(){
			$this->m_propertyChangedEvent = new IGKEvents($this, "propertyChangedEvent");
	}
	public function __toString(){return "IGKDbEntity";}
	
	public function __set($name, $value){//set in for db entity		
		parent::__set($name, $value);
		$this->onPropertyChanged($name, $value);
	}
	protected function onPropertyChanged()
	{
		$this->m_propertyChangedEvent->Call($this, null);
	}
}
final class  IGKdbColumnDataType
{
	const VARCHAR = "VarChar";
	const INT32 = "Int";
	const TEXT = "Text";
	const SINGLE = "Float";
	const DOUBLE_SINGLE = "Double";
	const DATE_TIME = "Datetime";
	
	public static function GetDbTypes()
	{
		$t = array(
			self::VARCHAR=>self::VARCHAR,
			self::INT32=>self::INT32,
			self::TEXT=>self::TEXT,
			self::SINGLE=>self::SINGLE,
			self::DOUBLE_SINGLE=>self::DOUBLE_SINGLE,
			self::DATE_TIME=>self::DATE_TIME
			);
		return $t;
		
		
	}
}
//represent column info
final class IGKDbColumnInfo extends IGKObject
{
	var $clName;
	var $clType;
	var $clTypeLength;
	var $clAutoIncrement;
	var $clNotNull;
	var $clIsPrimary;
	var $clIsUnique;
	var $clIsIndex;
	var $clIsUniqueColumnMember;
	var $clDefault;	
	var $clDescription;
	
	var $clIsNotInQueryInsert; //not in insertion query
	
	//for table relation
	var $clLink; //data table relations // array of link relation in a column
	var $clFromTable; //target table
	var $clFromTableDisplay;//array used to display the property
	var $clLinkType;
	
	var $clInsertFunction;
	var $clUpdateFunction;
	var $clInputType;
	
	public function __toString(){
		return "IGKdbColumnInfo[".$this->clName."]";
	}
	///get association info array
	public static function AssocInfo($array, $tablename=null)
	{
		if (!is_array($array))
			throw new Exception("array is not an array");
	
		$t = array();
		foreach($array as $k=>$v)
		{
			if (is_object($v)){			
				if ($k !== $v->clName)
				{
					$t[$v->clName] = $v;
				}			
				else{
					$t[$k] = $v;
				}
			}
			else{
				igk_wln("v is not an object");
				igk_wln(igk_count($array));
			}
		}
		return $t;
	}
	
	public function __construct($array=null)
	{
		$this->clTypeLength = 11;
		$this->clNotNull = false;
		$this->clInputType="text";
		if (is_array($array))
		{
			$t = get_class_vars(get_class($this));			
			foreach($array as $k=>$v)
			{	
				if (!array_key_exists($k, $t))
				{
					continue;
				}
				$this->$k = $v;
			}
		}
		switch(strtolower($this->clType))
		{
			case "text":
			case "datetime":
			case "date":
				$this->clTypeLength=null;
				break;
		}
	}	
	public function __get($key){ 
		$d = get_class_vars(get_class($this)) ; 	
		if (array_key_exists ( $key, $d)){		
			return $this->$key;
		}
		throw new Exception("Not implements : ".$key);
	}
	public function __set($key, $value){throw new Exception("variable : [". $key ."] Not Implements");}
	
	public static function GetColumnInfo()
	{
		return get_class_vars("IGKDbColumnInfo");
	}
	public static function NewEntryInfo()
	{
		return new IGKDbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true));
	}
}


//------------------------------------------------------------------------------------------
//INTERFACE: IIGKContolller
//------------------------------------------------------------------------------------------
interface IIGKController{
	
	
	//get the name of the controller
	function getName();
	//init de data menu
	function initMenu();
	//view method that will be call to render the view of this controller
	function View();
	//primary target node
	function getTargetNode();
	function getTargetNodeId();
}
interface IIGKDataController extends IIGKController
{
	//init the data base model
	function initDb();
	function getDataTableName();
	function getDataTableInfo();//return the primary data table info
	function getDataAdapterName();	
}

interface IIGKUserController{
	function connect();
	function register();
}


final class IGKControllerOptionsItem extends IGKHtmlItem
implements IIGKHtmlGetValue
{
	private $m_ctrl;
	public function getCtrl(){return $this->m_ctrl; }
	
	public function getValue(){
		return IGK_STR_EMPTY;//options for : ".$this->Ctrl->Name;
	}
	public function __construct($ctrl){
		parent::__construct("div");
		$this->m_ctrl = $ctrl;
		$this["class"] = "igk-ctrl-options";
		$this["igk-type"] = "igk-ctrl-options";
		$this->Content = $this;
		//force top most
		$this->Index = -1000;
		//link this options
		$this->ctrl->TargetNode->attachChild($this);	
		
	}
	public function getIsVisible(){
		return  parent::getIsVisible() && $this->m_ctrl->App->IsSupportViewMode(IGKViewMode::WEBMASTER)
		&& $this->Ctrl->CurrentPageFolder!= IGK_CONFIG_PAGEFOLDER;
	}
	public function Render($xmloptions = null){	//Render IGKControllerOptionsItem			
		$this->ClearChilds();
		$d = $this->addDiv();//Content = $this;
		$v_opts = $this->ctrl->getControllerConfigOptions();
		$v_opts->Index = -1000;
		$this->add($v_opts);
		return parent::Render($xmloptions);
	}
}

//------------------------------------------------------------------------------------------
//CLASS: IGKCONTROLLERBASE
//------------------------------------------------------------------------------------------
abstract class IGKControllerBase extends IGKObject
 implements IIGKController , IIGKWebController , IIGKDataController
{
	private $_visiblePage;
	private $m_targetNode;
	private $m_webParentCtrl;	
	private $m_childsctrl;
	private $m_regviewChilds;
	private $m_configs;	

	private $m_params;   // the params view
	private $m_pageview; // the page view
	private $m_view;     // the current view of this controller. "default" is the default value -> default.phtml
	private $m_visibility; 
	private $m_showChildFlag; //flag to call _showChild method automatically. default is true. this flag must be changed by the viewer
	
	//IGKControllerBase events :
	private $m_viewCompleteEvent;	
	private $m_mainArticle;// the current view of this controller. "default" is the default value -> default.[lang].phtml in Article dir
	static $sm_regComplete;
	
	//used to initialze a controller
	public static function InitControllerSystem(){
		
	}
	
	public function getMainArticle(){
		if (!isset($this->m_mainArticle))
			$this->m_mainArticle = "default";
		return $this->m_mainArticle;
	}
	protected function setMainArticle($article){
		$this->m_mainArticle = $value;
	}
	
	
	public static function  RegisterInitComplete($ctrl)
	{
		if ($ctrl == null)
			return;		
		if (self::$sm_regComplete ==null)
			self::$sm_regComplete = array();
		self::$sm_regComplete[] = $ctrl;
	}
	public static function InvokeRegisterComplete(){	
		if (self::$sm_regComplete)
		{
			foreach(self::$sm_regComplete as $k=>$v){
				$v->InitComplete();
			}
		}
		self::$sm_regComplete =null;
	}
	
	
	public function addViewCompleteEvent($obj, $methodName){//add method event
		if ($this->m_viewCompleteEvent)
		{
			$this->m_viewCompleteEvent->add($obj, $methodName);
		}
	}
	public function removeViewCompleteEvent($obj, $methodName){//remlove method event
		if ($this->m_viewCompleteEvent)
		{
			$this->m_viewCompleteEvent->remove($obj, $methodName);
		}
	}
	public function call_incontext($funcname, $params){//grant access to private function
		if (get_called_class() == get_class($this)){
			call_user_func_array(array($this, $funcname), $params);
		}
	}
	public function getVisibility(){return $this->m_visibility; }
	protected function setVisibility($visibility) { $this->m_visibility = $visibility; }
	public function getCurrentView (){ return $this->m_view; } 
	public function setCurrentView($view, $reload=true, $targetNode= null){ 
			if ( $this->m_view != $view ) 
			{
				$this->m_view = $view; 
				$reload = true;
			}
			if ($reload)
			{
				$bck = $targetNode ? $this->TargetNode : null;
				if ($bck)//set target node
					$this->TargetNode = $targetNode;
				$this->View(); 
				if ($bck)
					$this->TargetNode = $bck;
			}
			
	}
	
	
	///<summary>get controller config options</summary>
	public function getControllerConfigOptions(){//get the controller configs options
		$node =  IGKHtmlItem::CreateWebNode("ul");
		$node["class"] = "igk-ctrl-config-options";
		//cn : cibling name
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_THEME_CTRL)->getUri("theme_editStyle_ajx&n=".$this->Name."&cibling=1&cn".$this->Name)), "editstyle");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_ajx&n=".$this->Name)), "edit");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_properties_ajx&n=".$this->Name)), "setting");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_atricles_ajx&n=".$this->Name)), "article");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_views_ajx&n=".$this->Name)), "views_16x16");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_force_view_ajx&n=".$this->Name)), "foreceviews_16x16");
		IGKHtmlUtils::AddImgLnk($node->add("li"), igk_js_post_frame(igk_getctrl(IGK_CA_CTRL)->getUri("ca_drop_controller_ajx&forceview=1&n=".$this->Name)), "drop");
		return $node;
	}
	//retrieve the global application uri
	public static function CurrentUri(){
		return igk_getv($_SERVER, "REQUEST_URI");
	}
	public static function CurrentQueryString()
	{
		return igk_getv($_SERVER, "QUERY_STRING");
	}
	
	
	///<summary>get system variables in this controller. call extract method get var</summary>
	public function getSystemVars(){
		$t = array();
		$t["t"] = $this->TargetNode;
		if (igk_count($_REQUEST)> 0)
			$t= array_merge($t, $_REQUEST);
		$tab  = $this->App->getControllerManager()->getControllers();		
		if (is_array($tab))
		{
			$t["igk_controllers"] = $tab;			
		}
		if ($this->getParam("func_get_args") !=null)
		{
			$t["func_get_args"] = $this->getParam("func_get_args") ;
		}
		return $t;
	}
	///<summary>get or set if this items can't add child</summary>
	public function getCanAddChild(){
		return true;
	}
	
	public function getPageView(){ return $this->m_pageview;}
	//is system controller
	public function getIsSystemController(){ return false; }
	
	private static $sm_sysController;
	
	public static function RegSysController($className)
	{
		if (self::$sm_sysController == null)
			self::$sm_sysController = array();
		if (class_exists($className))
		{
			self::$sm_sysController[$className] = $className;
		}
	}
	public static function IsSysController($className)
	{
		return (igk_getv(self::$sm_sysController, $className)!=null);
	}	
	//get the current parent controller
	public function getWebParentCtrl(){return $this->m_webParentCtrl;	}
	//set the current parent controller
	//---------------------------------
	public function setWebParentCtrl($value, $store=false)
	{

		if ($this->m_webParentCtrl!=$value)
		{
			if ($this->m_webParentCtrl!=null)
				$this->m_webParentCtrl->unregChildController($this);
			
			$this->m_webParentCtrl = $value;	
			$this->Configs->clParentCtrl = $value? $value->getName() : null;
			if ($store)
			$this->storeDBConfigsSetting();
		}
		
	}
	//get childs of this controller
	public function getChilds(){return $this->m_childsctrl;}	
	
	///<summary>register a controller with a view callback function</summary>
	public function regView($ctrl, $callback){//register controller view
		if ($ctrl === $this)
			return;
		if ($this->m_regviewChilds == null){
			$this->m_regviewChilds = array();
		}
		$this->m_regviewChilds[$ctrl->Name] =(object) array("ctrl"=>$ctrl,"func"=> $callback);
		
	}
	///<summary>remove controller registered view</summary>
	public function unregView($ctrl){//unregister the view controller
		if ($ctrl!=null)			
			unset($this->m_regviewChilds[$ctrl->Name]);
	}
	//controller params
	public function setParam($key, $value)
	{
		if ($this->m_params == null)
		{
			$this->m_params = array();
			
		}
		$this->m_params[$key] = $value;
	}
	public function  getParam($key, $default=null, $register=false)		
	{
		$c =  igk_getv($this->m_params, $key);
		
		
		if($c ==null)
		{
			if (($default!=null) && $register)
				$this->setParam($key, $default);
			$c = $default;
		}		
		return $c;
	}
	
	//drop the controller used internally to drop and release controller resources
	public function dropController(){
		$this->App->removeCurrentPageFolderEvent($this, "pageFolderChanged");
		$this->App->removeCurrentPageEvent($this, "pageChanged");
		igk_html_rm($this->TargetNode);
		if ($this->hasChilds)
		{
			foreach($this->getChilds() as $k=>$v)
			{
				$v->setWebParentCtrl(null, true);
				$v->View();
			}
			//Clear childs
			$this->m_childsctrl = array();
		}
	}
	public function getcanModify(){return true;}
	public function getcanDelete(){return true;}
	
	///<summary>"get if this funciton is available in output query context</summary>	
	public function IsFunctionExposed($function){
		if (method_exists(get_class($this) , $function))
			return true;
		return false;
	}
	///<summary>get exposed list of the exposed function 
	///<return>exposed function list</return>
	public function getExposedfunctions(){
		return array();
	}
	///<summary>register childs controllers</summary>
	public function regChildController($controller)	
	{
		if (!$this->CanAddChild)return;
		if ($controller == null)return;
		if ($controller->WebParentCtrl === $this)return;
		if ($controller == $this)return;
		
		$n = strtolower($controller->getName());
		if (!isset($this->m_childsctrl[$n] ))
		{
			$this->m_childsctrl[$n] = $controller;
			$controller->setWebParentCtrl($this);
		}
	}
	public function unregChildController($controller)
	{	
		if ($controller == null)return;		
		if ($controller->WebParentCtrl === $this)return;
		if ($controller == $this)return;
		
		$n = strtolower($controller->getName());
		if (isset($this->m_childsctrl[$n]))
		{
			$p = $this->m_childsctrl[$n];
			$p->setWebParentCtrl(null, true);
			unset($this->m_childsctrl[$n]);
		}
		else{
			igk_debug_wln("unreg controller not removed");
		}
		
	}
	protected function _showChild($targetNode=null)
	{
		$t= $targetNode == null? $this->TargetNode : $targetNode;
		if ($this->hasChild)
		{
			foreach($this->getChilds() as $k=>$v)
			{			
				if ($v->getIsVisible())
				{
					//bind the node to this controller
					igk_html_add($v->TargetNode, $t);					
					$v->View();
				}
				else {
					igk_html_rm($v->TargetNode);
				}
			}
		}
	}
	///<summary>view complete.</summary>
	protected function _onViewComplete(){//called to raise the method when View complete on the current Controller. must be called on the view Method.
		if (($this->m_regviewChilds!=null) && is_array($this->m_regviewChilds))
		{
			//here v is is STDCLASS of "cltr","func" param
			foreach($this->m_regviewChilds as $k=>$v)
			{				
				$m = $v->func;
				$v->ctrl->Invoke($m, $this);				
			}		
		}
		if ($this->m_viewCompleteEvent!=null)
		{
			$this->m_viewCompleteEvent->Call($this, null);
		}
	}
	
	public function gethasChild(){return (is_array($this->m_childsctrl) && count($this->m_childsctrl)>0); }
	
	//used to identity the controller into the controller index
	public function getName(){return strtolower(get_class($this));}
	public function getConfigs(){//get the controller configs
		return $this->m_configs; 
	}
	//display name of the controller
	public function getDisplayName(){return get_class($this); }
	public function getIsVisible(){
		return $this->PageView->getIsVisible($this->CurrentPage);
	}
	public function getisAvailable(){return true;}
	public function initMenu(){ return null;}
	public function initConfigMenu(){return null;}
	public function getCurrentPageFolder(){ return $this->App->CurrentPageFolder;}
	public function getCurrentPage(){ return $this->App->CurrentPage;}
	
	protected function getCanInitDb()
	{
		return !igk_is_conf_connected();		
	}
	public function initDb(){//igk controller base init  db
	//TODO:
	if (!$this->getCanInitDb())
		return;
	
	// for child controller that can support multiple table name declaration
	// public function initDb(){
		// $this->initDbFromSchemas();	
		// $this->initConstantFiles();		
	// }
	if ($this->IsSystemController || !igk_getv($this->getConfigs(), "clDataSchema"))
	{
		$v_tab = $this->getDataTableInfo();
		$v_tablename= $this->getDataTableName();
		if (($v_tab == null)|| ($v_tablename==null))return;
		
		$db = igk_get_data_adapter($this, true);
		if ($db){
			if ($db->connect()){
				$db->selectdb($this->App->Configs->db_name);
				$db->createTable($v_tablename, $v_tab, null);
				// {
					// igk_debuggerview()->addDiv()->setContent("failed to create table .".$v_tablename);
				// }
			}
		$db->close();
		}	
	}
	else{
		$this->initDbFromSchemas();	
		$this->initConstantFiles();	
	}
		
	}
	
	protected function initDbFromSchemas()
	{	
		$tb = $this->loadDataFromSchemas();
		$etb = $this->loadDataNewEntriesFromSchemas();
		$db = igk_get_data_adapter($this, true);
		if ($db){
			if ($db->connect()){
				$db->selectdb($this->App->Configs->db_name);
				foreach($tb as $k=>$v)
				{
					$r = $db->createTable($k, $v, igk_getv($etb, $k));				
				}		
				$db->close();
				
		}}	
		return $tb;
	}
	protected function __init_entries($ctrl, $tablename, $etb, $db){		
		if ($db->initSystableRequired($tablename))
		{	
			//igk_wln("table require init of some data ".$tablename);
			//igk_show_prev($db->getStoredRequired());
			//recreation creation of some table before insert data
			$e = $this;
			//push data to reserved							
			$db->initSystablePushInitItem($tablename, function() use ($e, $ctrl, $tablename, $etb , $db, $ctrl){
				//igk_wln("cakkbackk  : " .$tablename);		
				//igk_show_prev(igk_getv($db->getStoredRequired(),'Data'));
				$e->__init_entries($ctrl, $tablename, $etb, $db);
			});
		}
		else{
		
			if (($etb !=null) && array_key_exists($tablename, $etb))
			{
				igk_wln("insert ....".$tablename);
				foreach($etb[$tablename] as $e=>$ee)
				{
					if (!$db->insert($tablename, (object)$ee))
					{
						igk_wln("insert failed ".$db->getError());
						igk_wln($ee);
						return false;
					}
				}
			}
			else{				
				$ctrl->initDataEntry($db, $tablename);
			}
		}
		return true;
	}
	
	///<summary>load data base from data schemas</summary>
	protected  function loadDataFromSchemas(){
		return igk_db_load_data_schemas($this->getDataDir()."/data.schema.xml");		
	}
	///<summary>load data new entries froms schemas</summary>
	protected  function loadDataNewEntriesFromSchemas(){
		return igk_db_load_data_entries_schemas($this->getDataDir()."/data.schema.xml");		
	}
	
	protected function initDataEntry($dbman){//initialize data entries
		//init default data entry
	}	
	public function getCanEditDataBase(){//get for editionon table info
		return !(igk_getv($this->getConfigs(),"clDataSchema"));
	}
	public function getCanEditDataTableInfo(){//indicate that 
		$p = $this->getConfigs();		
		$p = igk_getbool(igk_getv($p, "clDataSchema" ,false));				
		return !($p == true);
	}
	public function getDataTableInfo(){//load data from db configs files 		
		$tb  = $this->loadDataFromSchemas();
		if ($tb){
			return $tb;
		}
		if (file_exists($this->DBConfigFile ))
		{
			$e =  IGKHtmlItem::CreateWebNode("__loadData");
			$e->Load(IGKIO::ReadAllText($this->DBConfigFile));			
			$t = array();
			foreach($e->getElementsByTagName("Column") as $k)
			{
				$t[] = new IGKDbColumnInfo($k->Attributes->ToArray());
			}
			return $t;
		}
		return null;
	}	
	
	public function getDataTableName(){
		if (file_exists($this->DBConfigFile ))
		{
			$e =  IGKHtmlItem::CreateWebNode("__loadData");
			$e->Load(IGKIO::ReadAllText($this->DBConfigFile));
			$t = igk_getv($e->getElementsByTagName("DataDefinition")	,0);
			if ($t)
			{
				$s = $t["TableName"] ;
				if (!empty($s))
					return $s;
			}
		}
		return IGK_TABLE_PREFIX.$this->Name;		
	}
	
	//-----------------------------------------------------------------------------------------
	//DB FUNCTION
	//-----------------------------------------------------------------------------------------
	///<summary>select equal property</summary>
	///<param name="equal"></param>
	public function select($equals){ 
		return $this->getDbEntries()->searchEqual($equals);
	}
	public function selectAndWhere($whereTab)
	{	
		$v = $this->invokeDbFunction(array($this, "__dbselect_andwhere"), $whereTab);	
		return $v;
	}
	
	public function update($entries=null){ 		
		return  $this->invokeDbFunction(array($this, "__dbupdate_entries"), $entries);	
	
	}
	public function delete($entries){ 
	return $this->invokeDbFunction(array($this, "__dbdelete"), $entries);	
	}
	public function selectLastId(){
		$v = $this->invokeDbFunction(array($this, "__dbselectlastid"));			
		return $v;
	}
	//insert to entries
	public function insert($entry){ 		
		$v = $this->invokeDbFunction(array($this, "__dbinsert"), $entry);			
		return $v;
	}
		
	
	public function invokeDbFunction($param)
	{
		$adapt = igk_get_data_adapter($this, true);	
		
		if ($adapt == null)
			return null;
		$d = null;
		if ($adapt->connect()){			
			try{
				$p  = array($adapt);
				if (func_num_args()>1)
					$p = array_merge($p, array_slice( func_get_args(), 1));			
				
				$d = call_user_func_array($param, $p);
				
			}
			catch(Exception $ex)
			{
				$d = null;
				igk_debug_wln("error Append ".$ex);
			}
		}
		$adapt->close();
		return $d;
	}
	
	///retrieve all controller db entries
	public function getDbEntries(){
		return $this->invokeDbFunction(array($this, "__dbselectAll"));	
	}
	private function __dbselect_andwhere($adapt, $properties)
	{	
		return $adapt->selectAndWhere($this->getDataTableName(), $properties);		
	}
	private function __dbselectAll($adapt){
		return $adapt->selectAll($this->getDataTableName());		
	}
	private function __dbinsert($adapt,$entry){				
		return $adapt->insert($this->getDataTableName(), $entry);				
	}
	private function __dbselectlastid($adapt){
		return $adapt->getLastId();
	}
	private function __dbupdate_entries($adapt, $entries=null)
	{
		if ($entries==null)return;
		if (is_array($entries))
		{
			foreach($entries as $k=>$v)
			{
				$this->__dbupdate_entries($adapt, $v);
			}
			return;
		}
		return $adapt->update($this->DataTableName, $entries);
	}
	///delete entries in database
	///@adapt : adapter
	///@entries : array or object of entries to delete
	private function __dbdelete($adapt, $entries)
	{
		if ($entries==null)return;
		if (is_array($entries))
		{
			if (igk_count($entries)> 0)
			{
				foreach($entries as $k=>$v)
				{
					$this->__dbdelete($adapt, $v);
				}
				
			}
			return;
		}
		return $adapt->delete($this->DataTableName, $entries);
	}
	
	//get the target node
	public function getTargetNode(){return $this->m_targetNode;}
	protected function getHandleShowChild(){return $this->m_showChildFlag; }
	protected function setHandleShowChild($value){ $this->m_showChildFlag = $value; }
	//get the id of the target node
	public function getTargetNodeId() { return $this->TargetNode["id"]; }
	//protected set the method
	protected function setTargetNode($node) {				
		$this->m_targetNode = $node; 
	}
	

	//public function get the page document
	public function getdoc(){
		return IGKApp::getInstance()->Doc;
	}
	protected function _getViewfile($view){
		return $this->getCtrlFile(IGK_VIEW_FOLDER."/".$view.".phtml");
	}
	public function getCtrlFile($path)
	{
		return igk_io_getdir(dirname($this->getDeclaredFileName()).DIRECTORY_SEPARATOR.$path);
	}
	protected function _incViewfile($view){
			
		$v_file = $this->_getViewfile($view);
		if (file_exists($v_file)===true)
		{	
			$this->_includefile_oncontext($v_file);
		}
	}
	//copy this fonction to allow file inclusion on the current context controller
	protected function _includefile_oncontext($v_file){		
		$f = $this->getConstantFile();
		if (file_exists($f)) include_once($f);
		extract($this->getSystemVars());		
		include($v_file);
	}
	//get the view without changing the current view
	public function getView($view=null, $forcecreation=false){
		extract($this->getSystemVars());	
		$v = $view !=null? $view: igk_getr("v", $view);		
		$f = $this->_getViewfile($v);
		$t->ClearChilds();
		if (file_exists($f) || ($forcecreation && igk_io_save_file_as_utf8($f,IGK_STR_EMPTY)))
		{
			$this->_includefile_oncontext($v_file);
			//include($f);
		}
	}
	///<summary> call init view file </summary>
	protected function _initPage(){
		$f = $this->_getViewfile("init");
		if (file_exists($f))
		{
			include($f);			
		}
		
	}
	///<summary>override this method to show the controller view.</summary>
	public function View(){	// basic controller view  
		extract($this->getSystemVars());		
		if ($t)
		{
			$this->m_showChildFlag = true;
			//$t->ClearChilds();
			if ($this->getIsVisible())
			{
				$this->_initCssStyle();
				$this->_showViewFile();	
				if ($this->m_showChildFlag)
					$this->_showChild(null);
				$this->_onViewComplete();
			}
			else 
				igk_html_rm($t);
		}		
	}

	///<summary>render the target node in ajx context</summary>
	public function ViewAJX(){//render the target node on ajx view context
		$t = $this->getTargetNode();
		if ($t!=null){
			$t->RenderAJX();
		}
		igk_exit();
	}
	
	protected function _initCssStyle(){//used to initialize your custom style 
		$f = $this->getStylesDir()."/default.pcss";
		if (file_exists($f))
		{
			include($f);
		}
	}
	protected function _showViewFile()
	{
		extract($this->getSystemVars());	
		$v = $this->m_view ? $this->m_view : "default";
		$c = strtolower(igk_getr("c",null));			
		if ($c ==  strtolower($this->Name))
		{
			$v = igk_getr("v", $v);
		}		
		$f = $this->_getViewfile($v);				
		if (!file_exists($f))
		{
		
			if (igkServerInfo::IsLocal())
			{
			
			//IGKIO::WriteToFileAsUtf8WBOM
				if (!igk_io_save_file_as_utf8($f, "<?php \n?>", true))
				{
					igk_debug_wln("can't create the file ".$f . " AT ".__LINE__);
					igk_exit();
				}
			}
		}
		if (file_exists($f))
		{			
			//include in this context
			$this->_includefile_oncontext($f);
			//include($f);
		}
	}
	/// ask for a view in ajx context
	public function view_ajx(){
		$v = igk_getr("v", "default");
		$this->CurrentView = $v;
		$this->TargetNode->RenderAJX();
	}
	///used to reload a view in ajx context
	public function reload_view_ajx()
	{
		if (igk_sys_isAJX()==1)
		{		
			$this->View();						
			$c =  IGKHtmlItem::CreateWebNode("script");
			$c->Content = "if(IGK) window.igk.ajx.post( '".$this->getUri("view_ajx")."',null,  new window.igk.ajx.responseNode('".$this->getTargetNodeId()."').response )";
			$m = new IGKHtmlSingleViewItem($c);
			$m->RenderAJX();		
		}
	}
	
	///<summary> override to manage the view when page folder changed.</summary>	
	protected function pageFolderChanged()
	{		
		if (($this->getWebParentCtrl() ==  null)&&($this->getIsVisible()))
		{	
			$this->View();
		}
	}
	///<summary> override this when page change on a spécific page</summary>
	protected function pageChanged(){
	}
	///<summary> override to init controller according to other created controller.</summary>	
	protected function InitComplete(){	//base Init complete method
		$this->_initPage();
		$f1 = $this->getDeclaredFileName();
		$f2 = __FILE__;
		if (($f1!== $f2)&&(dirname($f1)!== dirname($f2)))
		{
			//load private script
			igk_js_load_script($this->App->Doc, IGKIO::GetDir(dirname($this->getDeclaredFileName())."/".IGK_SCRIPT_FOLDER));
		}
		if ($this->Configs!=null)
		{
			$this->_conf_regToParent();
		}
		else {
			igk_debug_wln("error ". $this->Name);
		}
		if ($this->PageView == null){
			throw new Exception("No PageView DEFINED FOR ". $this->Name);
		}
		$this->PageView->registerPages();		
		//register page changed event
		$this->App->addCurrentPageFolderEvent($this, "pageFolderChanged");	
		$this->App->addCurrentPageEvent($this, "pageChanged");	
		
		//load custom language
		$langdir = $this->getDataDir()."/R/Lang";
		if (is_dir($langdir)){
			R::getInstance()->PageLangChangedEvent->add($this, "planguageChanged");
			$this->planguageChanged();
		}		
		
	}	
	protected function planguageChanged(){
		$d =  R::getInstance()->GetCurrentLangPath();
		if (file_exists($d))
		{
			R::LoadLangFiles($d);
		}
	}
	///override this method to show the controller view.
	public function getDeclaredFileName()
	{	
		$h = new ReflectionClass ($this);
		return $h->getFileName();
	}
	public function getDeclaredDir(){
		return dirname($this->getDeclaredFileName());
	}
	///<summary>get the constant file </summary>
	public function getConstantFile(){
		return $this->getDeclaredDir()."/.constants.php"; 
	}
	protected function initConstantFiles(){
		 $f = $this->getConstantFile();
		 $tb = $this->getDataTableInfo();
		 $s = "<?php\n";
		 //build constant file 
		 if ($tb !=null){
			 foreach($tb as $k=>$v)
			 {
				$s .= "define(\"". strtoupper($k)."\", \"".$k."\");\n";
			 }
		 }
		 $s .= "?>";
		 IGKIO::WriteToFile($f, $s, true);
	}
	//get the current article path
	public function getArticle($name)
	{
		return $this->getArticleInDir($name, $this->getArticlesDir());
		// $f = $this->getArticlesDir()."/".$name;
		// if (file_exists($f))
			// return $f;
		// return IGKIO::GetDir($this->getArticlesDir()."/".$name.igk_get_article_ext());
	}
	public function getArticleInDir($name, $dir){
		$f = $dir."/".$name;
		if (file_exists($f))
			return $f;
		return IGKIO::GetDir($dir."/".$name.igk_get_article_ext());

	}
	public function getAllArticles()
	{
		return IGKIO::GetFiles($this->getArticlesDir(), "/\.phtml$/i",false);
	}
	public function getAllArticlesByCurrentLang()
	{
		$dir = $this->getArticlesDir();
		$t = IGKIO::GetDirFileList($dir);
		$lang_search = null;	
		$lang_search = R::GetCurrentLang();
		$out = array();
		if ($t && count($t)>0)
		{
			sort($t);
			foreach($t as $k)
			{
				$n =  basename($k);
				if ($lang_search && !IGKString::EndWith(strtolower($n), igk_get_article_ext($lang_search)))
					continue;
				if($this->m_search_article && !strstr(strtolower($n), strtolower($this->m_search_article)))
					continue;
				$out[] = $k;
			}
		}
		
		return $out;
	}
	
	
	public function getArticleFull($fullname)
	{
		return $this->getArticlesDir()."/".$fullname;
	}
	public function getArticlesDir()
	{
		return $this->getDeclaredDir()."/".IGK_ARTICLES_FOLDER;
	}
	public function getViewDir()
	{
		return $this->getDeclaredDir()."/".IGK_VIEW_FOLDER;
	}
	public function getDataDir()
	{
		return $this->getDeclaredDir()."/".IGK_DATA_FOLDER;
	}
	public function getScriptDir(){
		return $this->getDeclaredDir()."/".IGK_SCRIPT_FOLDER;
	}
	public function getStylesDir(){
		return $this->getDeclaredDir()."/".IGK_STYLE_FOLDER;
	}
	public function getApp(){		return IGKApp::getInstance();	}
	public function getmsbox(){//return the base message box frame
		return $this->App->getControllerManager()->msbox;
	}
	//return validator object
	public function getval(){
		return $this->App->Validator;
	}
	
	public function getBody(){
		return $this->App->Doc->Body;
	}
	public function getHeader(){
		return $this->App->Doc->Header;
	}
	//get function uri
	public function getUri($function=null)
	{
		$out = "c=".strtolower($this->getName());
		if ($function){
			$t = explode("&", $function);
			$t[0] = "&f=".str_replace ('_', '-', $t[0]);
			$out .= implode('&', $t);
		}
		return "?".$out;
	}
	
	///<summary>getfull uri</summary>
	public function getAppUri($function =null)
	{
		return igk_io_baseUri().$this->getUri($function);
	}
	///<summary>get article content</summary>
	///<param name="name" > name of the article</param>
	///<param name="evalExpression">demant for eval expression .default is true</param>
	///<param name="row">row used info to eval expression</param>
	public function getArticleContent($name, $evalExpression=true, $row =null){//data rows
		$f = $this->getArticle($name);
		if (file_exists($f))
		{
			$out = IGK_STR_EMPTY;
			$out = file_get_contents($f);			
			if ($evalExpression)
			{
				$out = igk_html_eval_script($out, $this,$row);
			}
			return $out;
		}
		return null;		
	}
	///<summary>get the article binding content</summary>
	public function getArticleBindingContent($name, $entries, $prebuild=true){		
		 if (is_object($entries) && ($entries->RowCount > 0))
		 {		
			$d =  IGKHtmlItem::CreateWebNode("div");
			igk_html_binddata($this, $d, $name, $entries);
			return $d->Render();
		}		
		return IGK_STR_EMPTY;
	}
	///<summary>get the article binding content with name. of the target controller</summary>
	public function getArticleBindingContentW($name, $targetCtrlName){//used for binding article width name
		return $this->getArticleBindingContent($name, igk_db_select_all(igk_getctrl($targetCtrlName)));
	}
	//get value uri
	public function getUriv($page)
	{
		$out = "?c=".strtolower($this->getName());
		if ($page)
			$out .="&v=".$page;
		return $out;
	}
	//get uri link
	public function getUril($uri)
	{
		$out = "?c=".strtolower($this->getName());
		if ($uri)
			$out .="&".$uri;
		return $out;
	}
	//init uri post
	public function initUriPost($form, $uri)
	{
		$uri = $this->getUri($uri);
		$form->addInput("c", "hidden", strtolower($this->getName()));
		
		//explode uri
		$tab = igk_getquery_args($uri);
		foreach($tab as $k=>$v){
			$form->addInput($k, "hidden", sv);
		}
	}
	//-----------------------------------------------------
	//represent a target node
	//-----------------------------------------------------
	protected function initTargetNode(){
		$tagName = igk_sys_getconfig("app_default_controller_tag_name", "div");
		$div =  new IGKHtmlCtrlViewNodeItem($tagName);
		$div["class"] = $div["id"] = strtolower($this->Name);						
		return $div;
	}
	
	//Get data ADAPTER NAME
	public function getDataAdapterName(){
		if ($this->Configs)
			return $this->Configs->clDataAdapterName;
		igk_wln("no adapter name defined for ".$this->Name);
	}
	protected function __loadCtrlConfig()
	{
			//default property value
			$t = igk_sys_getdefaultCtrlConf();			
			//add additional properties			
			if (method_exists(get_class($this), "GetAdditionalConfigInfo"))
			{
				$s = get_class($this);
				$c = call_user_func( array($s, "GetAdditionalConfigInfo"));
				if (is_array($c))
				{				
					foreach($c as $k=>$v)
					{
						if (is_object($v))
						{
							$t[$k] = null;
						}
						else if( is_string($v) && isset($t[$v]))
						{
							$t[$v] = null;
						}
					}
				}
			}
			
			$f = $this->getConfigFile();
			if (file_exists($f) == false)
				return (object)$t;
			
			$div =  IGKHtmlItem::CreateWebNode("div");
			$s = file_get_contents($f);
			$div->Load($s);
			$d = igk_getv($div->getElementsByTagName("config"), 0);
			if ($d)
			{
				foreach($d->Childs as $k)
				{
					
					if ($k->Type == "HtmlText")
					continue;
					$t[$k->TagName] = $k->innerHTML;
				}
			}	
			if ($this->getIsSystemController())
			{
				$t["clRegisterName"] = "igkdev.com.".$this->getName();
			}
			else{
				if (!isset($t["clRegisterName"]))
				$t["clRegisterName"] = igk_sys_getconfig("website_prefix","igk").".".$this->getName();
				
			}			
			return (object)$t;
	}
	
	
	protected function getConfigFile()
	{
		return igk_io_getdir($this->getDataDir()."/".IGK_CTRL_CONF_FILE);
	}
	protected function getDBConfigFile()
	{
		return igk_io_getdir($this->getDataDir()."/".IGK_CTRL_DBCONF_FILE);
	}
	public function storeDBConfigsSetting(){//store configuration data
		$d =  IGKHtmlItem::CreateWebNode("config");
		//store
		foreach($this->m_configs as $k=>$v)
		{
			$d->add($k)->Content = $v;
		}	
		$s = $d->Render();
		
		if( IGKIO::WriteToFileAsUtf8WBOM($this->ConfigFile, $s))
		{
			//reload config setting
			$this->loadCtrlConfigSettings();			
			return true;
		}
		return false;
	}
	
	protected function loadCtrlConfigSettings(){//load configuration setting
		
		if ($this->m_configs ==null)
			return;
		if ($this->TargetNode !=null)
		{
			$this->TargetNode["igk-type-id"] =  $this->Name;
			$this->TargetNode->setIndex($this->m_configs->clTargetNodeIndex);
		}	
		$this->_conf_regToParent();		
		if (isset($this->m_configs->clVisiblePages))
		{			
			$this->PageView->register($this->m_configs->clVisiblePages);
		}
		
	}	
	function __toString()
	{
		return "IGKCONTROLLER::".get_class($this);	
	}
	///<summary>.ctr IGKControllerBase</summary>
	function __construct()
	{
		$this->m_pageview = new IGKPageView();//manage the current view system.
		$this->m_pageview->register("default");		
		$this->m_childsctrl = array();
		$this->m_methods = array();
		$this->m_viewCompleteEvent = new IGKEvents($this, "ViewCompleteEvent");
		
		 $t = $this->initTargetNode();		
		if ($t)
		{			
			$this->setTargetNode($t);
			if (IGKControllerManagerObject::IsSystemController($this) == false)
			{				
				new IGKControllerOptionsItem($this);
			}		
		}
		//load configurations 
		$this->m_configs = $this->__loadCtrlConfig();		
		$this->m_visibility = false; 
		$this->reloadConfiguration();
	}
	
	///<summary>reload configuration setting</summary>
	public function reloadConfiguration()
	{	
		if ($this->TargetNode==null)
			return;	
		$this->TargetNode["igk-type"] = "controller";		
		$this->loadCtrlConfigSettings();
	}
	
	///<summary>load and init from configuration setting</summary>
	protected function _conf_regToParent()
	{		
		$h = igk_getctrl($this->Configs->clParentCtrl, false);
		if ($h)
		{
			if ($this->WebParentCtrl!=null)
			{
				$this->WebParentCtrl->unregChildController($this);
			}
			if ($h->CanAddChild)
			{
					$h->regChildController($this);
			}
			else {
				$this->Configs->clParentCtrl = null;
			}	
		}
	}
	
	
}


abstract class IGKNonVisibleControllerBase extends IGKControllerBase
{
	protected function initTargetNode(){
		return null;
	}
	public function getIsVisible(){
		return false;
	}
	public function View()
	{
		//do nothing
	}
	public function getCanAddChild(){
		return false;
	}
}


final class IGKApi extends IGKNonVisibleControllerBase
{
	public function getName(){ return "igkapi"; }
	
	public function invokeUri(){
		IGKApp::$DEBUG = igk_getr("DEBUG",false);	
	
	}
}


final class IGKAdditionCtrlInfo extends IGKObject
{
	private $m_Type;
	private $m_DefaultValue;
	private $m_Values; //used when type == select
	
	///<summary>.ctr</summary> 
	///<param name="type">type of the parameter. select|text|textarea|bool|radio</summary>
	///<param name="def">array of value in case of "select" or default value</summary>
	///<param name="def1">default value in case of type "select" </summary>
	public function __construct($type, $def, $def1=null)
	{
		$this->m_Type = $type;
		if (strtolower($type) == "select")
		{
			$this->m_Values = $def;
			$this->m_DefaultValue = $def1;
		}
		else{
			$this->m_DefaultValue = $def;
			$this->m_Values=null;
		}
	}
	public function getclType(){return $this->m_Type; }
	public function getclDefaultValue(){return $this->m_DefaultValue; }
	public function getclValues(){return $this->m_Values; }
	
	public function __toString(){
		return "IGKAdditionalCtrlInfo";
	}
}
//save session parameters
//<remarq> this is uses to free $_SESSION array value</remarq>
final class IGKSession extends IGKObject
{
	private $m_igk;
	private $m_sessionParams;
	private $m_User;
	//Events
	private $m_initializeSessionEvent;//call just before global invoke uri function of the controll manager
	private $m_updateSessionEvent; //update setting changed. call just before rendering default document
	private $m_UserChangedEvent; //global user changed event
	
	public function getApp(){return $this->m_igk;}
	public function getUser(){	return $this->m_User;}
	public function setUser($user){ if ( $this->m_User !== $user){$this->m_User = $user; $this->_onUserChanged();} }
	
	public function getUserChangedEvent(){return $this->m_UserChangedEvent; }
	
	//event getter an setter
	public function addUpdateSessionEvent($obj, $method){		$this->m_updateSessionEvent->add($obj, $method);	}
	public function removeUpdateSessionEvent($obj, $method)	{		$this->m_updateSessionEvent->remove($obj, $method);	}
	
	public function addInitializeSessionEvent($obj, $method){		$this->m_initializeSessionEvent->add($obj, $method);	}
	public function removeInitializeSessionEvent($obj, $method)	{		$this->m_initializeSessionEvent->remove($obj, $method);	}
	
	public function addUserChangedEvent($obj , $method){
		$this->m_UserChangedEvent->add($obj, $method);
	}
	
	public function __construct($App)
	{	
		$this->m_igk = $App;
		$this->m_sessionParams = array();
		$this->m_initializeSessionEvent = new IGKEvents($this, "initializeSessionEvent");
		$this->m_updateSessionEvent = new IGKEvents($this, "UpdateSessionEvent");
		$this->m_UserChangedEvent = new IGKEvents($this, "UserChangedEvent");
	}
	private function _onUserChanged()
	{
		$this->m_UserChangedEvent->Call($this, null);
	}
	//unset a session key
	public function Clear($key)
	{
		if (isset($this->m_sessionParams[$key]))
			unset($this->m_sessionParams[$key]);
	}
	public function __get($key){ 
		if (method_exists($this, "get".$key) )
		{					
			return call_user_func(array($this, "get".$key), null);
		}
		else if(isset($this->m_sessionParams[$key])){
			
			return $this->m_sessionParams[$key];
		}
		return null;
	}
	public function __set($key, $value)
	{		
		if (!$this->_setIn($key, $value))
		{
			$this->m_sessionParams[$key] = $value;
		}		
	}
	public function __toString(){ return "SessionParameters"; }
	
	/// raise the session UpdateEVent 
	public function update(){//invoke update session. before render the document
		$this->m_updateSessionEvent->Call($this,null);
	}
	public function initalize($app){//raise the initialize event. allowing some ctrl to init them self before invoking uril 
		if ($app == $this->m_igk){
			$this->m_initializeSessionEvent->Call($this,null);
		}
	}
	public function setParam($key, $value)
	{
		if (empty($key))
			return;
		
		if (isset($this->m_sessionParams[$key]))
		{
			if ($value == null)
				unset($this->m_sessionParams[$key]);
			else
				$this->m_sessionParams[$key] = $value;
		}
		else{
			if ($value !=null)
			{
				$this->m_sessionParams[$key] = $value;
			}
		}
	}
	public function & getParam($key)
	{
		$k = null;
		if (isset($this->m_sessionParams[$key]))
		{
			return $this->m_sessionParams[$key];
		}
		return $k;
	}
}


final class IGKAutorisation extends IGKObject
{
	private $App ;
	private $autorisation;
	//internal constructor
	public function __construct($igk)
	{
		$this->App = $igk;
	}
	private function loadAutorisation(){
		$this->autorisation = array();
	}
	public function __toString(){return "IGKAutorisation"; }
	public function __get($key){
		if ($this->App->User)
		{
			if (isset($this->autorisation[$key]))
			{
				return $this->autorisation[$key];
			}
		}
		return false;
	}
	public function __set($key, $value){}
}
//----------------------------------------------------------------------
//@ System Controllers Managers. 
//@ add controller
//@ drop controller by Name
//----------------------------------------------------------------------
final class IGKControllerManagerObject extends IGKObject
{
	private static $sm_instance;
	private $m_tbcontrollers;
	private $m_registeredCtrl;
	
	//register controller for specific fonctionnality
	public function register($name, $ctrl)
	{	
		if (empty($name) || ($ctrl == null))
			return false;
		if ($this->m_registeredCtrl == null)
			$this->m_registeredCtrl = array();
		if(isset($this->m_registeredCtrl[$name]))
		{
			return false;
		}
		$this->m_registeredCtrl[$name] = $ctrl;
	}
	public function getRegCtrl($name)
	{		
		if(($this->m_registeredCtrl != null) && isset($this->m_registeredCtrl[$name]))
			return $this->m_registeredCtrl[$name];
		return null;
	}
	
	
	private function __construct(){
		
		$this->m_tbcontrollers = array();
	}
	///<summary>raise init complete event</summary>
	private function _onInitComplete()
	{
		IGKControllerBase::InvokeRegisterComplete();
	}
	///<summary>true if controller is a system controller otherwise false</summary>
	///<param name="controller">controller name or controller instance </param>
	public static function IsSystemController($controller)
	{
		//igk_wln("is SysController ".$controller);
		$instance = self::getInstance();
		if (is_string($controller))
		{
			$controller = strtolower($controller);
			$v = $instance->$controller;
			if ($v->getDeclaredFileName() == __FILE__)
				return true;
		}
		//igk_wln("---".$controller);
		if (is_object($controller) && igk_reflection_class_extends(get_class($controller),  IGK_CTRLBASECLASS))
		{
			$r  =  ($controller->getDeclaredFileName() == __FILE__) || $controller->getIsSystemController() || IGKControllerBase::IsSysController(get_class($controller));
			//igk_wln("response = ".igk_parsebool($r));
			return $r;
		}
		return false;
		
	}
	public static function IsIncludedController($controller)
	{
		$instance = self::getInstance();
		$dir = null;
		if (is_string($controller))
		{
			$controller = strtolower($controller);
			$v = $instance->$controller;
			$dir = dirname($v->getDeclaredFileName());
			
		}
		else if (is_object($controller) && igk_reflection_class_extends(get_class($controller),  IGK_CTRLBASECLASS)){
			$dir = dirname($controller->getDeclaredFileName());
		}
		//
		//get parent folder
		//
		$o = igk_io_basePath(igk_io_currentRelativePath(IGK_INC_FOLDER));
		$dir = igk_io_basePath($dir);
		
		while( ($dir != '.') && (strlen($dir) > 0))
		{
			if ($dir === $o){
				return true;
			}
			$dir = dirname($dir);
			
		}	
		return false;
	}
	///<summary>get the current instance manager</summary>	
	public static function getInstance()
	{
		if (self::$sm_instance===null)
		{
			if (IGKApp::getInstance()->getControllerManager() == null){
				self::$sm_instance = new IGKControllerManagerObject();					
				IGKApp::getInstance()->setControllerManager(self::$sm_instance);
				//init controllers
				self::$sm_instance->InitControllers();
			}
			else {
				self::$sm_instance = IGKApp::getInstance()->ControllerManager;
			}			
		}
		return self::$sm_instance;
	}
	
	public static function ClearCache(){//remove all cached files
		
		$t = null;
		$t = igk_io_getFiles(igk_io_currentRelativePath(IGK_CACHE_FOLDER));
		if ($t){
			foreach($t as $k=>$v)
			{
				unlink($v);
			}
		}
	
	}
	public function ClearCtrlCache(){//clear ctrl cache
		$fc = igk_io_currentRelativePath(IGK_FILE_CTRL_CACHE);
		if (file_exists($fc))
		{
			unlink($fc);
		}
	}
	///<summary>init all controller</summary>	
	private function InitControllers(){
	//TODI
	$fc = igk_io_baseDir(IGK_FILE_CTRL_CACHE);
	if (file_exists($fc))
	{
		$s = explode("\n", IGKIO::ReadAllText($fc));
		foreach($s as $k=>$v){
			if (empty($v) || !class_exists($v))
			continue;
			
			$t = new $v();				
			$n = $t->Name;
			$this->$n = $t;//add to controlller list
			IGKControllerBase::RegisterInitComplete($t);	
		}
	}
	else{
		$m = "";
		foreach(get_declared_classes() as $k=>$v)
		{
			if (igk_reflection_class_extends($v, IGK_CTRLNONATOMICTYPEBASECLASS))
			{
				continue;
			}
			if (igk_reflection_class_extends($v, IGK_CTRLBASECLASS) && igk_ctrl_isactive($v))
			{			
				$v_rc = new ReflectionClass($v);
				if ($v_rc->isAbstract()) 
					continue;				
				$t = new $v();				
				$n = $t->Name;
				$this->$n = $t;//add to controlller list
				IGKControllerBase::RegisterInitComplete($t);	

				$m .= $v."\n";
			}
			
		}
		IGKIO::WriteToFileAsUtf8WBOM($fc, $m, true);
	}		
		//call init complete on all controller
		$this->_onInitComplete();
		
	}
	
	//</summary>call View method for all controllers that don't have a parent web controller</summary>
	public function ViewControllers()
	{
		$ctrls = self::getInstance()->m_tbcontrollers;
		if ($ctrls){
			foreach($ctrls as $k)
			{
				if (($k->getWebParentCtrl() == null) && $k->getIsVisible())
				{
					$k->View();
				}
			}
		}
	}
	public function __toString(){
		return "Controllers [#".count($this->m_tbcontrollers)."]";
	}
	public function __get($key){
	
		$key = strtolower($key);
		if (isset($this->m_tbcontrollers[$key]))
			return $this->m_tbcontrollers[$key];
		return null;
	}
	public function __set($key, $value)
	{
		$key = strtolower($key);
		if ($value===null)
		{
			if (isset($this->m_tbcontrollers[$key]))
				unset($this->m_tbcontrollers[$key]);	
				return;
		}
		else
		{
			if (is_object($value) && igk_reflection_class_extends( get_class($value),IGK_CTRLBASECLASS))
			{
				$this->m_tbcontrollers[$key] = $value;
			}
		}
	}
	public function Count() {return count($this->m_tbcontrollers);}
	public function getControllers(){return $this->m_tbcontrollers;}
	
	//@remove controller by name
	public function dropControllerByName($name)
	{

		$k = strtolower($name);
		if (isset($this->m_tbcontrollers[$k]))
		{
			$ctrl = $this->m_tbcontrollers[$k];
			$d = dirname($ctrl->getDeclaredFileName());			
			$ctrl->dropController();
			if (is_dir($d))
			{
				if (IGKIO::RmDir($d , true))
				{
					unset($this->m_tbcontrollers[$k]);
				}			
			}	
		}
	}
	public function reload(){//reload controller
		self::ClearCache();
		$d  = igk_io_currentRelativePath("/Mods");
		igk_loadcontroller($d);	
		$this->InitControllers();
		
		/*$classes = get_declared_classes();
		foreach( $classes as $k=>$v)
		{
			if (igk_reflection_class_extends($v, IGK_CTRLBASECLASS) && igk_ctrl_isactive($v))
			{				
				$v_rc = new ReflectionClass($v);
				if ($v_rc->isAbstract()) 
					continue;
				$t = new $v();
				$n = strtolower($t->Name);
				if (!isset($this->m_tbcontrollers[$n]))
				{
					$this->$n = $t;
					IGKControllerBase::RegisterInitComplete($t);
					//$this->InitCompleteEvent->add($t, "InitComplete");
				}
				else{
					unset($t);
				}
			}
		}
		//$this->_onInitComplete();
		//$this->InitCompleteEvent->Clear();*/
		
	}
	
	///return the user controller list.
	///there is 2 controller type . framework controller and user controllers
	public function getUserControllers()
	{
		$tab = $this->getControllers();
		$out = array();
		if (count($tab) > 0)
		{		
			$tab_k = array_keys($tab);
			igk_usort($tab_k, "igk_key_sort");
			foreach($tab_k as $k)
			{
				$v = $tab[$k];
				if (IGKControllerManagerObject::IsSystemController($v) || IGKControllerManagerObject::IsIncludedController($v) || !$v->canModify)
					continue;
				$out[] = $v;
				
			}
		}
		return $out;
	}

	private function _sort_byConfigNodeIndex($a, $b)
	{
		if ($a->Configs->clTargetNodeIndex && $b->Configs->clTargetNodeIndex)
		{
			$i = $a->Configs->clTargetNodeIndex;
			$j = $b->Configs->clTargetNodeIndex;
			return ($i == $j)? 0: (($i<$j) ? -1 : 1); 
		}
		return strcmp($a->Name, $b->Name);
	}
	private function renderController($s, $v, $fname, $fsize, $x, $y, $cl, $indexpos= 0)
	{		
		$t = $s->DrawString($v->Name, $fname, $fsize, $x, $y , $cl);
		
		//$s->DrawRectangle($cl, $t);
		
		$s->DrawString($v->Configs->clTargetNodeIndex, $fname, $fsize, $indexpos, $y , $cl);
		
		if ($v->Childs){
			$y+= $t->height;
			$tab = $v->Childs;
			usort($tab, array($this, "_sort_byConfigNodeIndex"));
			$i = igk_count($tab);
			foreach($tab as $k=>$m)
			{
				$i--;
				$tt = $this->renderController($s, $m, $fname, $fsize, $x + 50, $y, $cl, $indexpos);				
				
				$t->height += $tt->height;
				$t->width = max($tt->width + 50, $t->width);
				$y+= $tt->height;				
			}
		}		
		return $t;
	}
	private  function _cm_measure($s , $tab, $fname, $fsize, $x, $y ,$cl)
	{
		$rc = (object)array(
		"x"=>0,
		"y"=>0,
		"width"=>0,
		"height"=>0);
		
		if (is_array($tab))
		{
		
			foreach($tab as $k=>$v)
			{
				if ($v->WebParentCtrl == null)
				{
					$t = $this->_cm_measure($s, $v, $fname, $fsize, $x, $y ,$cl);
					
					$rc->height += $t->height;
					$rc->width  = max($rc->width, $t->x + $t->width);
				}
			}
		}
		else{
			return $this->renderController($s, $tab, $fname, $fsize, $x, $y, $cl);					
		}
		return $rc;
	}
	public function cm_controllerschema()
	{
		//retreive all controller scheam
		if (!defined("IGK_GD_SUPPORT"))
		{
			igk_exit();
		}		
		
		
		$y = 14;
		$x = 0;
		$fname = igk_io_currentRelativePath(igk_get_uvar("CONFIG_SCHEMA_FONT"));
		if (!file_exists($fname))
		{		
			igk_exit();
		}
		$fsize = 14;
		$cl = IGKColor::FromFloat(1.0);	
		
		$tb = $this->getUserControllers();
		
		$s = IGKGD::Create(32,32);
		
		$rect =  $this->_cm_measure($s, $tb, $fname, $fsize, $x, $y ,$cl);
		
		$s->Dispose();
		if (($rect->width<=0) || ($rect->height<=0))
			igk_exit();
		$x =40;
		$y =28;
		
		$s = IGKGD::Create($rect->width  +300+ (2*$x), $rect->height + ($y));
		
		//$s = IGKGD::Create(500,600);
		$s->Clear($cl);
		if (file_exists($fname))
		{
				foreach($tb as $k=>$v)
				{
									
					if ($v->WebParentCtrl == null)
					{
						$t = $this->renderController($s, $v, $fname, $fsize, $x, $y, IGKColor::Black() , $rect->width+150);
						$y += $t->height;
					}					
				}
		}
		header("Content-type: image/png");
		$s->Render();
		$s->Dispose();
		unset($s);
		igk_exit();
		
	}
	///<summary>use to invoke system controller method</summary>
	///<return>the selected uri</return>
    public function InvokeUri($uri=null, $defaultBehaviour=true)
	{	
		$c = null; 
		$f = null;
		$igk = IGKApp::getInstance();
		$igk->Session->URI_AJX_CONTEXT = 0;
	
		if ($uri == null)
		{
			if ( ($p = igk_getr("p",null))!=null){ 
				//change the current page;
				if (igk_sys_is_page($p))
				{
					$igk->CurrentPage = $p;				
				}
			}
			if (igk_getr("l",null)!=null){ R::ChangeLang(igk_getr("l"));}
			if (igk_getr("history",0)==1){ igk_debug_wln("notice:form history"); }
			//
			//call for controller function
			//
			$c = igk_getru("c",null);
			$f = igk_getru("f", "invokeUri");
		}
		else{
			$args = igk_getquery_args($uri);
			$c =str_replace("-","_", igk_getv($args,"c"));
			$f =str_replace("-","_", igk_getv($args,"f"));
			if (igk_getv($args,"p")){  igk_getctrl(IGK_MENU_CTRL)->setPage(igk_getv($args, "p"), igk_getv($args, "pageindex",0)); }
			if (igk_getv($args,"l")){   R::ChangeLang(igk_getv($args, "l"));}
		}
		$funcinfo = null;
		$arg = null;
		if (strstr($f, "/"))
		{
			$a = explode("/", $f);
			$f = $a[0];
			$b = array_slice($a, 1);
			if (igk_count($b) == 1)
			{
				$arg = $b[0];
			}
			else 
				$arg = $b;
			
		}
		
		if ($c && $f)
		{	
			//check for requirement before call thme 	
			$ctrl  = $this->$c;
			if (!$ctrl)
				return null;
			if (!method_exists(get_class($ctrl), $f))
				return false;
			
			if ($ctrl &&  $this->$c->IsFunctionExposed($f))
			{
				$ctrl->App->Session->URI_AJX_CONTEXT = IGKString::EndWith($f, IGK_AJX_METHOD_SUFFIX) || (igk_getr("ajx") == 1);				
				if (is_array($arg))
					call_user_func_array(array($this->$c, $f), $arg);
				else{
					if ($arg)
						$ctrl->$f($arg);
					else
						$ctrl->$f();						
				}
				if($defaultBehaviour && $this->$c->App->Session->URI_AJX_CONTEXT)
				{
					igk_exit();
				}
			}
			else{
				//notify method not found
				igk_notifyctrl()->addWarning("InvokeUri for ".$c."::".$f." not defined or you don't have access to this method.");
			}
		}	
		return $c;		
		
	}
	/// used to invoke function and return response. main used in igk_api
	public function InvokeFunctionUri($uri=null)
	{
		$c = null; 
		$f = null;
		if ($uri == null)
		{			
			//
			//call for controller function
			//
			$c = igk_getru("c",null);
			$f = igk_getru("f", null);		
		}
		else{
			$args = igk_getquery_args($uri);
			$c =str_replace("-","_", igk_getv($args,"c"));
			$f =str_replace("-","_", igk_getv($args,"f"));
		}		
		if ($c && $f)
		{	
			//check for requirement before call thme 							
			if ($this->$c &&  $this->$c->IsFunctionExposed($f))
			{
				$this->$c->App->Session->URI_AJX_CONTEXT = IGKString::EndWith($f, IGK_AJX_METHOD_SUFFIX) || (igk_getr("ajx") == 1);
				return $this->$c->$f();				
			}
		}	
		return null;	
	}
}


//--------------------------------------------------------------------
//initialize
//--------------------------------------------------------------------
final class IGKSessionIdValue implements IIGKHtmlGetValue
{
	var $i ;
	public function getValue(){//session get value
	if ($this->i)
			$this->i++; else $this->i = 1;
		$s = "Session ID[" .$this->i." ]: " . session_id ();		
		return $s;
	}
}
//-----------------------------------------------------------------------
//basics controller
//-----------------------------------------------------------------------
///<summary>Session controller</summary>
final class IGKSessionController extends IGKControllerBase
{
	private $m_debugginchanged;
	public function getName(){return IGK_SESSION_CTRL;}
	public function getConfigCtrl(){
		return igk_getctrl(IGK_CONF_CTRL);
	}
	protected function InitComplete()
	{
		parent::InitComplete();		
		$this->App->Doc->SysTheme->PrintMedia->def[".".IGK_SESSION_CTRL] = "display:none;";		
		$conf = igk_getctrl(IGK_CONF_CTRL);
		
		$conf->addConfigSettingChangedEvent($this, "configPropertyChanged");		
		$conf->addConfigUserChangedEvent($this, "ConfUserChanged");		
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "changeLoaded");	
		
	}	

	public function View(){	
		
		//for debugging purpose
		if ( $this->IsVisible )
		{
			
			$this->TargetNode->ClearChilds();			
			igk_html_add($this->TargetNode, $this->doc->body);
			$this->TargetNode->setIndex(10000);
			
			$d = $this->TargetNode->add("div");
			$d->Content = R::ngets("title.DEBUGINFO");
			$d["class"]= "debug_option_title";
			$ul = $this->TargetNode->add("ul");		
			//register a color name
			
			$ul->add("li")->Content = "Referrer : " . $_SERVER["REMOTE_ADDR"];
			$ul = $this->TargetNode->add("ul");
			$ul["class"]="btn-group";
			$ul->add("li")->setClass("btn btn-default igk-btn igk-btn-default")->add("a", array("href"=>$this->getUri("forceview")))
			->Content = "ForceView";
			$ul->add("li")->setClass("btn btn-default igk-btn igk-btn-default")->add("a", array("href"=>$this->getUri("ClearS")))->Content = "ClearSession";		
			if ($this->ConfigCtrl->IsConnected){			
				$ul->add("li")->setClass("btn btn-default igk-btn igk-btn-default")->add("a",array("href"=>igk_getctrl(IGK_CONF_CTRL)->getUri("reconnect")))->Content = "Re-connect";
			}
			$this->TargetNode->addBr();
			$ul = $this->TargetNode->add("ul");
			$ul["class"]="btn-group";
			$ul->add("li")->setClass("btn btn-default igk-btn igk-btn-default")->add("a", array("href"=>new IGKHtmlRelativeUriValueAttribute("Configs")))->Content = "Configs";
			$ul->add("li")->setClass("btn btn-default igk-btn igk-btn-default")->add("a", array("href"=>new IGKHtmlRelativeUriValueAttribute(IGK_STR_EMPTY)))->Content = "Index";
			
			$ul = $this->TargetNode->add("ul");
			$ul->add("li")->Content = "CurrentPage : " . $this->App->CurrentPage;
			$ul->add("li")->Content = "CurrentFolder : " . $this->App->CurrentPageFolder;
			$ul->add("li")->Content = "ViewMode : " . IGKViewMode::GetSystemViewMode();
			$ul->add("li")->Content = new IGKSessionIdValue();	
			$bootstrap = igk_sys_getconfig("BootStrap.Enabled");
			if (!igk_is_conf_connected() && ($this->CurrentPageFolder != IGK_CONFIG_PAGEFOLDER)){
				
				$logindiv = $this->TargetNode->add("div");
				$frm = $logindiv->addForm();
				$frm["action"] = /*igk_io_baseUri("", false)."".*/igk_getctrl(IGK_CONF_CTRL)->getUri("connect");
				$v_logul = $frm->add("ul");
				$p = $v_logul ->add("li")->addSLabelInput("clLogin");
				$p->input["autocomplete"]="off";
				$p->input["placeholder"] = R::ngets("tip.login");
				
				$p->input->setClass("igk-form-control");
				$i = $v_logul->add("li")->addSLabelInput("clPwd","password");
				$i->input["placeholder"] = R::ngets("tip.password")->getValue();
				
				
				$i->input->setClass("igk-form-control");
				
				$i = $v_logul->add("li")->addInput("btn.connect", "submit",R::ngets("btn.connect"));
				if ($bootstrap){
					$i->setClass("btn btn-default igk-btn igk-btn-default");
				}
			}
			else{
				$div = $this->TargetNode->addDiv()->setClass("igk-form-group");
				
				if (igk_is_conf_connected())
				{
					$sl = $div->addSelect("clViewMode")->setClass("igk-form-control");
					$uri = $this->getUri("changeviewmode");
					$sl["onchange"] = "javascript: ns_igk.ajx.post('{$uri}&mode='+this.value,null, ns_igk.ajx.fn.replace_body); return false;";
					$mode = $this->App->getViewMode();
					foreach(igk_get_class_constants("IGKViewMode") as $k=>$v)
					{
						$opt = $sl->add("option")->setContent($k)->
						setAttribute("value", $v);
						if ($v == $mode){
							$opt["selected"] = true;
						}
					}				
				}
				$this->TargetNode->addDiv()->setClass("igk-cleartab");
			}
			$this->TargetNode->addScript()->Content  = "if (window.igk.ctrl.sessionblock)window.igk.ctrl.sessionblock.init();";
		}
		else{
			igk_html_rm($this->TargetNode);
		}
		
	}
	public function getIsVisible(){
		return !IGKUserAgent::isMobileDevice() && (igkServerInfo::IsLocal() || igk_getv($this->App->Configs,"AllowDebugging", false));
	}
	public function ConfUserChanged()
	{	
		$this->App->ViewControllers();		
		
		//igk_getctrl(IGK_CONF_CTRL)->removeConfigUserChangedEvent($this, "ConfUserChanged");
	}
	//<summary>primary</summary>
	public function PageChanged()
	{
		$this->View();
	}
	public function ClearS($navigate = true){
		
		session_destroy();
		if ($navigate)
		{
			igk_navtocurrent("/");
		}
	}
	
	public function forceview(){
		$this->App->Doc->setup_document();
		$this->App->ViewControllers();	
		//....igk_navtocurrent();
	}
	
	public function changeLoaded($ctrl){		
		if ( $ctrl->isChanged(IGKAppConfig::CHANGE_REG_KEY, $this->m_debugginchanged))
		{
			$this->View();
		}
	}
	public function configPropertyChanged()
	{
		$this->View();	
	}
	public function changeviewmode(){
		if (igk_is_conf_connected())
		{
		$m = igk_getr("mode", 1);
		$this->App->setViewMode($m);		
		}
	}
}

//Controller used to manage and add controller 
final class IGKCtrlManager extends IGKNonVisibleControllerBase
{
	public function getName(){return IGK_CTRL_MANAGER; }
	
	public function IsFunctionExposed($name){
		return true;
	}
	//add a controller
	public function add_ctrl($webpagecontent = false, $webparent=null)
	{
	
		$n = str_replace(" ","_", trim(igk_getr(IGK_FD_NAME,null))); 
		$ctrl_typename = igk_getr("clCtrlType", null);	
		$ctrl_ns = igk_getr("clCtrlNameSpace", "igk");
		$response = false;
		
		if (!igk_isidentifier($n))
		{
			igk_notifyctrl()->addWarningr("msg.identifiernotvalid",$n);			
		}		
		else if (igk_ctrl_is_reservedname($n))
		{
			igk_notifyctrl()->addWarningr("msg.addctrl.nameisreserverd_1", "[".$n."]");		
		}
		else if (class_exists($n))
		{
			igk_notifyctrl()->addWarningr("msg.classalreadyexists");
		}
		else if ( ($info = igk_ctrl_info($ctrl_typename)) && !$info->CanAddNew)
		{
			igk_notifyctrl()->addWarningr("msg.ctrl.notallowingchild_1",  $info->Created);
		}
		else{			
			$type = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $ctrl_typename );		
			if ($n && ($n !=".") && ($n!=".." ) && (igk_getctrl($n) == null) && ($type!=null)) 
			{	
				$clcontent = self::GetDefaultClassContent($n, $type, $webparent);
				$p = "";
				if (($ctrl_ns!="igk") && preg_match(IGK_NAME_SPACE_REGEX, $ctrl_ns))
				{
					$m = explode(".", $ctrl_ns);
					foreach($m as $k=>$v){
						if (empty($v))
							continue;
						$p .= $v."/";
					}
				}
		
				$folder = IGKApp::$BASEDIR."/".IGK_MODS_FOLDER."/".$p.$n;
		
				
				IGKIO::CreateDir($folder);
				IGKIO::CreateDir($folder."/".IGK_VIEW_FOLDER); //view folder
				IGKIO::CreateDir($folder."/".IGK_ARTICLES_FOLDER);//article folder
				IGKIO::CreateDir($folder."/".IGK_DATA_FOLDER);//data folder 
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_DATA_FOLDER."/.htaccess", "allow from all");
				IGKIO::CreateDir($folder."/".IGK_SCRIPT_FOLDER);//script folder
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_SCRIPT_FOLDER."/.htaccess", "allow from all");
			
				IGKIO::CreateDir($folder."/".IGK_STYLE_FOLDER);//styles folder
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_STYLE_FOLDER."/.htaccess", "allow from all");
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_STYLE_FOLDER."/default.pcss", "<?php\n ?>");
				//configuration section
				$t = igk_sys_getdefaultCtrlConf();//configs section 
				$t["clDataAdapterName"] = igk_getr("clDataAdapterName", "CSV");
				$t["clDisplayName"] = igk_getr("clDisplayName",null);
				$t["clRegisterName"] = igk_getr("clRegisterName", igk_web_prefix().".".$n);
				$t["clParentCtrl"] = $webparent==null? $webparent : igk_getr("clParentCtrl");
				$t["clTargetNodeIndex"] = igk_getr("clTargetNodeIndex");
				$t["clVisiblePages"] =igk_getr("clVisiblePages");
				$t["clDescription"] =igk_getr("clDescription");
				$t["clDataSchema"] = igk_getr("clDataSchema");
				
				//call set additionnal info
				call_user_func_array( array($type,"SetAdditionalConfigInfo"), array(&$t) );
				
				if ($type == "IGKDefaultPageCtrl")
				{					
					IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_SCRIPT_FOLDER."/default.js", self::GetDefaultScript($n));
				}
				$file_name = $folder."/class.".$n.".php";
				IGKIO::WriteToFileAsUtf8WBOM($file_name, 	$clcontent );
				//write view
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_VIEW_FOLDER."/".IGK_DEFAULT_VIEW_FILE, call_user_func(array($type,"GetAdditionalDefaultViewContent")));
				
				//store_config data
				include($file_name);
				$cl = new $n();
				$conf =  IGKHtmlItem::CreateWebNode("config");
				foreach($t as $k=>$v)
				{
					$conf->add($k)->Content = $v;
				}
				//store configs
				IGKIO::CreateDir(dirname($cl->getConfigFile()));
				IGKIO::WriteToFileAsUtf8WBOM($cl->getConfigFile(), $conf->Render());
				
				//call InitEnvironment method if exists . on child controller.
				//first call 
				$fn = "InitEnvironment";
				if (method_exists($cl, $fn))
				{
					call_user_func_array(array($n, $fn), array($cl));
				}
				//dispose 
				unset($cl);
				//reaload all ctrl
				IGKControllerManagerObject::getInstance()->reload();
				
				$ctrl = igk_getctrl($n);
				$nodefaultarticle = igk_getr("nodefaultarticle", 0);
				//save default articles
				if ($ctrl && !$nodefaultarticle)
				{					
					IGKIO::WriteToFileAsUtf8WBOM($ctrl->getArticle("default"), "text for [".$n."]");
				}				
				$response = true;
			}	
			else {
				igk_notifyctrl()->addError(R::ngets("err.cannotaddnewctrl_2", $type , $n));
			}
		}
		return $response;		
	}
	//request remove controller by name
	public function removeController($n)
	{		
		$n = ($n == null)?igk_getr("n"): $n;
		if ($n)
		{
			IGKControllerManagerObject::getInstance()->dropControllerByName($n);
			IGKControllerManagerObject::getInstance()->reload();		
		}
	}
	private static function GetDefaultScript($n)
	{
	$o = <<<OEF
/*
default script for {$n}
*/
OEF;
	return $o;
	}
	public static function GetDefaultClassContent($name, $extends, $webparent=null)
	{
	
		if (igk_ctrl_is_reservedname($name))
			return null;
	
		$param = array();
		$param["extend"] =  $extends; // $webpagecontent? IGK_CTRLWEBPAGEBASECLASS :  IGK_CTRLBASECLASS;
		$s = IGK_STR_EMPTY;
		$s .= !$webparent || (igk_getctrl($webparent) == null) ?null :<<<EOF
igk_getctrl("{$webparent}")->regChildController(\$this);
EOF;
		$out = <<<EOF
<?php
//controller code class declaration
//file is a part of the controller tab list
class $name extends {$param["extend"]} {
	public function getName(){return get_class(\$this);}
	/*
	protected function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}*/
	/// init target node
	protected function initTargetNode(){
		\$node =  parent::initTargetNode();
		return \$node;
	}	
	//----------------------------------------
	//Please Enter your code declaration here
	//----------------------------------------
	/// parent view control
	public function View(){
		parent::View();
	}
	
}
?>
EOF;
return $out;
	}
}

// Page Controller
final class IGKPageCtrl extends IGKNonVisibleControllerBase
{
	private $m_oldPage;
	private $m_newPage;
	private $m_state;
	private $m_currentUri;
	
	var $PageLoadEvent;
	//navigation state
	const REFRESHING = 5;
	const NAVIGATE = 1;
	const GOTOPREVIOUS = -1;

	public function __construct()
	{
		parent::__construct();
		$this->PageLoadEvent = new IGKEvents($this, "PageLoadEvent");
	}
	public function getName(){return "igkpagectrl";}
	public function getState(){return $this->m_state;}
	
	public function checkState(){
		$v_rUri = $_SERVER["REQUEST_URI"];
		if ($this->m_newPage != $v_rUri)
		{
			if ($v_rUri == $this->m_oldPage)
			{			
				$this->m_oldPage = $this->m_newPage;
				$this->m_newPage = $v_rUri;			
				$this->setState(self::GOTOPREVIOUS);
			}
			else{
				$this->m_oldPage = $this->m_newPage;
				$this->m_newPage = $v_rUri;			
				$this->setState(self::NAVIGATE);
			}
		}
		else {
			if (igk_getv($_SERVER, "HTTP_CACHE_CONTROL") == "max-age=0"){
				$this->setState(self::REFRESHING);			
			}
			else
				$this->setState(0);
		}	
	}
	public function getisRefreshing(){		
		return ($this->State == self::REFRESHING);
	}
	
	///add a new page to system
	public function add(){
		$n= getr("n",null); 
		if ($n)
		{
			$dir = IGKIO::GetBaseDir($n);
			mkdir($dir);
			$text = <<<EOF
<?php
include_once(dirname(__FILE__)."/../index.php");
igk_wl( IGKApp::getInstance()->Doc->Render());
?>
EOF;
			IGKIO::WriteToFileAsUtf8WBOM($dir."/index.php", $text, false);
			igk_navtobase();
			igk_exit();
		}		
	}
	protected function InitComplete(){//IGKPageCtrl init complete event
		parent::InitComplete();
		$this->App->InitEvent->add($this, "_igk_initCalled");
		$this->App->Session->addUpdateSessionEvent($this, "_igk_session_update");
	}
	protected function _igk_session_update()
	{
		$this->_igk_initCalled();
		$this->m_currentUri = $_SERVER["REQUEST_URI"];
		if ($this->State == self::REFRESHING)
			$this->View();
	}
	private function setState($state)
	{
		if( $this->m_state != $state)
		{
			$this->m_state = $state;
			//ONSTATE CHANGED
		}
	}
	public function _igk_initCalled()
	{
		if (defined("IGK_FORCSS"))
		{
			return;
		}		
		$this->OnPageLoad();
	}
	protected function OnPageLoad(){
		$this->PageLoadEvent->Call($this, null);
	}
}
//-------------------------------------------
//dialog frame box size
//-------------------------------------------
final class  IGKMsDialogFrameSizeValue extends IGKObject
 implements IIGKHtmlGetValue {
	private  $m_owner;
	
	public function getOwner(){
		return $this->m_owner;
	}
	
	public function __construct($owner){
		$this->m_owner = $owner;		
	}

	public function getValue(){//dialog size get value
		return  igk_get_string_format("ns_igk.winui.framebox.init(ns_igk.getParentByTagName(ns_igk.getlastscript(),'div'),{0},{1});",
		igk_getsv($this->m_owner->Width?'"'.$this->m_owner->Width.'"':null,'null'),
		igk_getsv($this->m_owner->Height?'"'.$this->m_owner->Height.'"':null,'null'));
	}
}



//represent the dialog frame
final class IGKMsDialogFrame extends IGKHtmlItem
{		
		private $m_Box;
		private $m_Content;
		private $m_Title;
		private $m_closeUri;
		private $m_closeBtn;
		private $m_Width;
		private $m_Height;
		private $m_id;
		private $m_owner;
		private $m_script;
		private $m_form;
		private $m_closeMethodUri;
		private $m_callbackMethod;
		private $m_reloadcallbackMethod;
		private $m_closeCallBackEvent;
		private $m_framectrl;
	
	
		public function addCloseCallBackEvent($obj, $method)
		{
			if ($this->m_closeCallBackEvent!= null)
			{
				$this->m_closeCallBackEvent->add($obj, $method);
			}
		}
		public function removeCloseCallBackEvent($obj, $method)
		{
			if ($this->m_closeCallBackEvent!= null)
			{
				$this->m_closeCallBackEvent->remove($obj, $method);
			}
		}
		//get the id of this frame
		public function getId(){return $this->m_id;}
		//get the owner of this dialog
		public function getOwner(){return $this->m_owner; }
		public function getBox(){return $this->m_Box;} //get the box
		public function getContent(){return $this->m_Content;}//get
		public function setcloseUri($value){
			$this->m_closeBtn["href"] = $value;
		}
		public function getcloseUri(){
			return $this->m_closeBtn["href"];
		}
		public function getcloseMethodUri(){ return $this->m_closeMethod ;}
		public function setcloseMethodUri($value){$this->m_closeMethod = $value;}
		public function setWidth($value){ $this->m_Width = $value;}
		public function setHeight($value){ $this->m_Height = $value;}
		public function setTitle($value){ $this->m_Title->Content = $value;}
		public function getTitle(){ return $this->m_Title->Content;}
		public function getForm(){return $this->m_form;}
		public function setForm($value){ $this->m_form = $value; }
		public function getcallbackMethod(){return $this->m_callbackMethod;}
		public function setcallbackMethod($value){$this->m_callbackMethod = $value;}
		
		public function getWidth(){return $this->m_Width; }
		public function getHeight(){return $this->m_Height;}
		//method to call when frame closed
		public function closeMethod()
		{
			
			if ($this->m_callbackMethod)
			{
				$c = $this->m_callbackMethod;
				$c($this);
			}
			if($this->m_closeCallBackEvent!= null)
			{
				$this->m_closeCallBackEvent->Call($this, null);
			}
	
			
		}
		//<summary>get script node</summary>
		public function getScript(){return $this->m_script; }
		
		public function __construct($framectrl , $id = null, $owner=null, $reloadcallback=null){
			parent::__construct("div");
			
			if (!igk_reflection_class_implement($framectrl , "IIGKFrameController"))
			{
				throw new Exception("required IIGKFrameController");
			}
			
			$this->m_framectrl = $framectrl;
			
			
			$this->m_closeCallBackEvent = new IGKEvents($this, "closeCallBackEvent");
			$this["class"] = "framebox fitw fith posab loc_t loc_l";
			$this["id"] = "framebox_".$id;
			$this["igk-control-type"] = "frame";
			$this->setIsVisible(true);
			$this->m_id = $id;
			$this->m_owner = $owner;
			$this->m_reloadcallbackMethod = $reloadcallback;
			$this->m_Box = $this->add("div", array("class"=>"framebox-dialog posab no-overflow resizable", "id"=>"framebox-dialog"));
	
			
			$tab = $this->m_Box->add("div", array("class"=>"disptable fitw fith framebox_bgcl"));			
			$c = $this->m_Box;
			
			$this->m_Title = $tab->add("div", array("class"=>"disptabr", "id"=>"framebox_".$id."_title"))->add("div", array("class"=>"framebox-dialog-title"));
			
			$this->m_Content =  $tab->add("div", array("class"=>"disptabr fith fitw"))->add("div",array("class"=>"framebox-dialog_content disptabc alignl pad4") );
			
			
			
			$v_cdiv = $this->m_Title->addDiv()->setClass("framebox_close");
			$this->m_closeBtn = IGKHtmlUtils::nBtn($v_cdiv, IGK_STR_EMPTY , null, 48,24);	
			if ($this->m_closeBtn ==null){
				throw new Exception("no close button created");
			}
			$this->m_closeBtn["class"] = "-igk-btn-lnk framebox-btn-close";			
			$this->m_script = $this->m_Box->addScript();
			$this->m_script->setContent(new IGKMsDialogFrameSizeValue($this));
		}

		public function getIsVisible(){
			if (!parent::IsVisible() && !$this->m_framectrl || !$this->m_framectrl->ContainFrame($this->m_id, $this))
			{
				//remove frame
				return false;
			}
			return true;
		}
		
		public function Render($xmloption=null)
		{ 		
			if (!$this->m_framectrl || !$this->m_framectrl->ContainFrame($this->m_id, $this))
			{
				//remove frame
				return null;
			}
			$def = IGK_STR_EMPTY;
			if ($this->m_Width && $this->m_Height)
				$def =$def."width:".$this->m_Width."px; height:".$this->m_Height."px";
			$this->m_closeBtn->ImgSrc = R::GetImgUri("btn_close");
			$this->m_Box["style"]=$def;
			$out = parent::Render($xmloption);
			return $out;
		}
	
		public function ClearChilds(){//override clear childs
			$this->m_Content->ClearChilds();
		}
}

//used in MsBox Controller to store activities
final class IGKHtmlBoxItem extends IGKHtmlStylableItem
{
		private $m_msboxController; //represent a frame box items
		public function __construct($msboxController){
			parent::__construct("div");
			$this->m_msboxController = $msboxController;
		}
		public function Render($xmloption=null)
		{		
			$out = parent::Render($xmloption);
			//igk_wln("render wath ...<textarea>".$out."</textarea>");
			
			if ($this->m_msboxController->getIsVisible())
			{
				$this->m_msboxController->getIsVisible(false);
				$this->m_msboxController->Clear();
				return $out;
			}
			else{
				$this->m_msboxController->Clear();
				return null;
			}
		}
}
//
// Messagebox controller
/*
MESSAGEBOX CONTROLLER
show message box 
*/
final class IGKMsBoxController extends IGKControllerBase 
implements IIGKFrameController
{
	private $m_frame;
	private $m_node;
	private $m_title;	
	private $m_boxbloc;
	private $m_errormsg;
	private $m_warningmsg;
	private $m_debugmsg;
	private $m_isvisible;
	
	public function getName(){return "msbox"; }	
	public function getIsVisible(){return $this->m_isvisible;}
	public function setIsVisible($value){$this->m_isvisible =$value;}
	public function getContent(){return $this->m_frame->Content; }
	
	public function ContainFrame($id, $frame, $remove=true)
	{
		return "igk-msbox-dialogframe" == $id;
	}
	public function __construct(){
		parent::__construct();
		$id = "igk-msbox-dialogframe";
		$this->m_frame = new IGKMsDialogFrame($this, $id, $this);		
		//$this->m_frame->setCloseUri("#/closeframe?id=igk-msbox-dialogframe");
		$this->m_frame->setCloseUri($this->getUri("close"));
		$this->m_frame->Title = R::ngets("title.MessageBox");
		$this->m_node = new IGKHtmlBoxItem($this);
		$this->m_node->add($this->m_frame);
		$this->m_node["class"] = "igk-msbox-dialogframe posab fitw fith loc_t loc_l igk-zfront";
		$this->m_node->setId( $id);
		$this->m_node["igk-type"] = "igk-framectrl";
		$this->m_node->addScript()->setContent(<<<EOF
(function(q){igk.winui.framebox.reg_frame_close(function(name){ if (name=='framebox_{$id}') { q.parentNode.removeChild(q);return true;} return false;});})(window.igk.getParentScript());
EOF
);
		
		$this->m_errormsg =  IGKHtmlItem::CreateWebNode("ul");		
		$this->m_warningmsg =  IGKHtmlItem::CreateWebNode("ul");
		$this->m_debugmsg =  IGKHtmlItem::CreateWebNode("ul");
		$this->m_isvisible =false;
	}
	public function initTargetNode(){
		return null;
	}
	public function View(){
		//no views	: cause no target node but not is used for rendering message box
	}
	
	public function Clear()
	{
		$this->_freeError();
		$this->m_warningmsg->ClearChilds();
		$this->m_debugmsg->ClearChilds();
	}
	function _freeError()
	{
		igk_html_rm($this->m_errormsg);
		$this->m_errormsg->ClearChilds();			
	}
	public function close(){//"msbox controller close node			
		if ($this->m_node->ParentNode !=null)
		{
			igk_html_rm($this->m_node);
			$this->Content->ClearChilds();
			$this->_freeError();
			$this->m_isvisible = false;						
			igk_navtocurrent();
			igk_exit();
		}
	}
	private function _register()
	{
		if ($this->m_node->ParentNode === null)
		{
				$this->App->Doc->Body->add($this->m_node);
		}
		if ($this->m_errormsg->ParentNode === null)
		{
			$this->Content->add($this->m_errormsg);
		}
		$this->m_title["class"] = "msbox_error_title";
		$this->m_isvisible = true;
	}
	public function addErrorr($key)
	{
		$this->addError(R::ngets($key));
	}
	public function addError($msg){//IGKMsBoxController add Error		
			if (is_string($msg))
			{
				$this->m_errormsg->add("li")->Content = $msg;
			}
			else{
				IGKHtmlUtils::AddItem($msg, $this->m_errormsg);
			}		
			$this->_register();
			$this->m_isvisible = true;
	}
	public function addErrori($msg_code)
	{
		$c = igk_error($msg_code);
		if ($c){
			$out =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>"alignl"));
			$ul = $out->add("ul");
			$li = $ul->add("li");			
			$li->add("label")->Content = "Code : ";
			$li->add("span")->Content =  $c["Code"];
			$li = $ul->add("li");
			$li->add("label")->Content = "Message : ";
			$li->add("span")->Content = R::ngets($c["Msg"]);		
			$this->addError($out->Render(null));
		}
		$this->m_isvisible = true;
	}
	public function addInfo($msg){
		if (!$this->getIsVisible()){
			if (is_string($msg))
			{
				$this->m_errormsg->add("li")->Content = $msg;
			}
			else{
				IGKHtmlUtils::AddItem($msg, $this->m_errormsg);
			}
		}
		$this->_register();
		$this->m_isvisible = true;
	}
	public function addDebug($msg){
		
			if (is_string($msg))
			{
				$this->m_errormsg->add("li", array("class"=>"msbox_debug"))->Content = $msg;
			}
			else{
				IGKHtmlUtils::AddItem($msg, $this->m_errormsg);
			}		
		$this->_register();
		$this->m_isvisible = true;
	}

	public function copyChilds($errori){
	if ($errori == null)return;
			foreach($errori->getChilds() as $k)
			{
				$this->msbox->addError($k);
			}
	}
}
//-----------------------------------------------------------------------------
//used as base configurable controller class
//-----------------------------------------------------------------------------
abstract class IGKConfigCtrlBase extends IGKControllerBase 
implements IIGKConfigController
{
	private $m_configCtrl;
	
	
	public function  getConfigNode(){ return $this->m_configCtrl->getConfigNode(); }	
	public function  getConfigInfo(){ return $this->m_configCtrl->getConfigInfo(); }
	
	public function getConfigCtrl(){return $this->m_configCtrl;}
	public function getConfigPage(){return "default"; }	
	
	public function initConfigMenu(){//IGKConfigCtrlBase init config menu.
		$c = $this->ConfigPage;
		if (isset($this->App->ConfigMenuConfiguration->$c))
		{
			$cp = $this->App->ConfigMenuConfiguration->$c;
			if ($cp){
			//($name,$CurrentPage, $uri, $index=0, $key=null, $controller=null, $group=null, $defaulttag="li")
			return array(new IGKMenuItem(
			$cp->menuname, 
			$cp->pagename, 
			$this->getUri("showConfig"), 
			$cp->menuindex, 
			$cp->imagekey,
			null,
			$cp->group));
			}
			else{
				igk_debug_wln("----no config menu found for : ".$c . " ".$this->Name);
			}
		}
		else{			
			igk_debug_wln("no config menu found for : ".$c . " ".$this->Name);	
		}
		return null;
	}
	
	public function IsFunctionExposed($function){
		$f = ($this->ConfigCtrl->IsConnected==true);
		return $f;
	}
	protected function InitComplete(){
		parent::InitComplete();
		$this->m_configCtrl = igk_getctrl(IGK_CONF_CTRL, true);
		if($this->m_configCtrl)
		{
			$this->m_ConfigNode = $this->m_configCtrl->ConfigNode;
			$this->m_configCtrl->registerConfig($this);
		}
		
	}
	public function __construct(){
		parent::__construct();
	}
	//---------------------------------------------------
	//BASE::showConfig
	//---------------------------------------------------
	public function showConfig(){		
	
		$this->ConfigInfo->ClearChilds();
		$this->ConfigNode->Clear();
		$this->ConfigCtrl->setSelectedConfigCtrl($this, $this->Name."::showConfig");				
		
		$this->View();
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);			
		}		
		else{
			igk_html_add($this->TargetNode, $this->ConfigNode);			
			//add help 			
			igk_add_article($this, "help.".$this->Name, $this->ConfigInfo->addDiv(), null, true);		
		}
	}
	
	protected function addTitle($node, $title){
		$d = $node->addDiv();
		$d["class"] ="igk-cnf-title";
		$d->Content = R::ngets($title);
	}
	public function getIsVisible(){	
		$v = ( ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)&& ($this->ConfigCtrl!=null) &&( $this->ConfigCtrl->SelectedConfigCtrl== $this) &&($this->ConfigCtrl->IsConnected));				
		return $v;
	}	
}

///<summary>used to save page view in tab </summary>
class IGKPageView extends IGKObject 
{
	private $m_value;
	private $m_pagelist;
	
	public function getValue(){return $this->m_value; }
	public function getPageList(){return $this->m_pagelist; }
	public function __construct()
	{
	}
	
	public function registerPages()
	{
		if (!is_array($this->m_pagelist))
			return;
		$ctrl = igk_getctrl(IGK_MENU_CTRL);
		foreach($this->m_pagelist as $k=>$v)
		{
			if (!empty($k))
				$ctrl->registerPage(strtolower(trim($k)));
		}
	}
	public function register($value)
	{
		//-------------------------------
		//register pages with -
		//-------------------------------
		$this->m_value = $value;
		$t = explode(',', $value);
		if ($value == "*")
		{
			$this->m_pagelist = true;
		}
		else {
			$this->m_pagelist = array();
			foreach($t as $k=>$v)
			{
				$this->m_pagelist[strtoupper(trim($v))] = 1;					
			}
		}
	}
	public function getIsVisible($page)
	{
		if ($this->m_value == "*")
			return true;
		if ( isset($this->m_pagelist[strtoupper($page)]))
			return true;
		if ( isset($this->m_pagelist["-".strtoupper($page)]))
			return false;
		return false;
	}
}

///<summary>Represent controller type</summary>
/*
controller type is the base class of all personnalisable atomic controller. if you want to create a multiple 
inheritance controller . use IGKCtrlNonAtomicTypeBase that extends IGKCtrlTypeBase
*/
abstract class IGKCtrlTypeBase extends IGKControllerBase
{
	//return the system controller type category
	public static function GetCtrlCategory(){
		return "DEFAULT";
	}
	//must have a static method that return a info
	public static function GetAdditionalConfigInfo()
	{
		return null;
	}
	//set addition info
	public static function SetAdditionalConfigInfo(& $t)
	{
		
	}
	///<summary>get de default string content</summary>
	public static function GetAdditionalDefaultViewContent(){//default view
		return  "<?php\n \$this->TargetNode->ClearChilds();\n igk_add_article(\$this , \$this->MainArticle, \$this->TargetNode); \n?>";
	}
	public function __construct(){
		parent::__construct();
		
	}
}
///<summary>used for multiple instance</summary>
abstract class IGKCtrlNonAtomicTypeBase extends IGKCtrlTypeBase 
{

}
///<summary>respresent de fault View controller type </summary>
abstract class IGKViewCtrl extends IGKCtrlTypeBase
{
	//must have a static method that 
	public static function GetAdditionalConfigInfo()
	{
		return null;
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		//so set additionnal property setting
	}
}

abstract class IGKDefaultPageCtrl extends IGKCtrlTypeBase
implements IIGKWebPageController
{	
	private $m_page_content;	//get the page content node
	private $m_footer_content; //get the footer content node
	private $m_menu_container; //get the menu container
	private $m_header_content; //get the header content
	private $m_header_node;// get the header node
	private $m_body_node;   //get the body node
	private $m_footer_node; //get the footer node
	private $m_menuCtrl;	//get the menu controller
	private $m_Title; 		//title of the page
	private $m_currentView; //current view name for this page controller
	///get the name of the page that control this controller
	
	public static function GetAdditionalConfigInfo()
	{
		return array("clDefaultPage");
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clDefaultPage"] = igk_getr("clDefaultPage");
	}
	protected function setheaderNode($value){$this->m_header_node = $value;}
	protected function setbodyNode($value){  $this->m_body_node = $value;}
	protected function setfooterNode($value){ $this->m_footer_node = $value;}
	
	//override this to manage error uri request
	public function manageErrorUriRequest($uri){}
	
	public function __construct()
	{
		parent::__construct();
		$this->m_currentView = "default";
	}	
	public function getheaderNode(){return $this->m_header_node;}
	public function getbodyNode(){ return $this->m_body_node;}
	public function getfooterNode(){ return $this->m_footer_node;}
	public function getpage_content(){return $this->m_page_content; } //get page content
	public function getheader_content(){return $this->m_header_content; }//get header content
	public function getfooter_content(){return $this->m_footer_content; }//get footer content
	public function getmenu_content(){return $this->m_menu_container; }//get menu base container
	
	
	//load web theme structure
	public function loadWebTheme($file){
	}
	
	//get or set the page name:
	public function setPageName($value){ $this->m_pageviewName; }
	protected function setfooter_content($value){$this->m_footer_content =$value; }
	protected function setpage_content($value){$this->m_page_content = $value;}
	protected function setmenu_content($value){ $this->m_menu_container = $value;}
	protected function setheader_content($value){$this->m_header_content = $value;}
	
	
	protected function _initView(){
		if ($this->App->CurrentPageFolder != IGK_CONFIG_MODE)
		{
			IGKHtmlUtils::AddItem($this->headerNode, $this->doc->bodyheader);
			IGKHtmlUtils::AddItem($this->bodyNode, $this->doc->bodycontent,400);			
			IGKHtmlUtils::AddItem($this->footerNode, $this->doc->bodyfooter, -100);	
			
		}
		else {
			igk_html_rm($this->headerNode);
			igk_html_rm($this->bodyNode);
			igk_html_rm($this->footerNode);
			return;
		}		
		
	}
	public function getExtraTitle(){
		if (igk_web_defaultpage()!=$this->CurrentPage)
			return " - ".R::ngets("title.".$this->CurrentPage.".webpage")->getValue();
		return IGK_STR_EMPTY;
	}
	public function View(){	//default page controller view
		extract($this->getSystemVars());			
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		else {
			igk_html_add($this->TargetNode, $this->App->Doc->bodypage);
		}
		$t->ClearChilds();
		$this->doc->Title = $this->m_Title ? $this->m_Title: $this->App->Configs->website_title. $this->getExtraTitle();
		$p = igk_io_basePath($this->getDataDir()."/R/Img/favicon.ico");			
		$this->doc->Favicon = new IGKHtmlRelativeUriValueAttribute($p);
		$this->_initCssStyle();
		$this->_initView();	
		$c = strtolower(igk_getr("c",null));
		
		if ($c ==  strtolower($this->Name))
		{
			//change the current view
			$this->m_currentView = igk_getr("v", empty($this->m_currentView) ? "default": $this->m_currentView);
		}		
		//Register parent menu FOR MENU		
			if ($this->m_menuCtrl)
				$this->m_menuCtrl->setParentView($this->menu_content);
		
		$this->m_init = true;	
		$this->_showViewFile();
		if (!$this->HandleShowChild)
		{
			$this->_showChild(null);
		}
		$this->_onViewComplete();		
	}

	
	protected function _showViewFile()
	{		
			extract($this->getSystemVars());
			$f = $this->_getViewfile($this->m_currentView);
			$d = $this->page_content;
			if($d){
				$d->ClearChilds();
			}
			if (file_exists($f))
			{
				include($f);
			}		
			else{
				igk_debug_wln("Current view file does't exists : ".$f);
			}
	}
	
	
	protected function InitComplete(){	
		parent::InitComplete();
		$this->m_menuCtrl = igk_getctrl(IGK_MENU_CTRL , true);
		$this->m_menuCtrl->addPageChangedEvent($this, "View");
		$this->App->Session->UserChangedEvent->add($this, "View");
	}
	protected function OnMenuPageChanged(){//menu page changed
		$this->View();
	}
	public function getIsVisible(){
		//default page controller visible
		return ($this->CurrentPageFolder != IGK_CONFIG_MODE) && ($this->PageView->getIsVisible($this->CurrentPage) );
	}
	
	public function pageFolderChanged()
	{
		$this->View();
	}	
}

//-----------------------------------------------------------------------------------------
//REPRESENT A Menu Controller
//-----------------------------------------------------------------------------------------
final class IGKMenuCtrl extends IGKConfigCtrlBase
{
	private $m_init;
	private $m_Menus; //registrated menu
	private $m_Pages; //registrated pages
	private $m_CMenus;//Config menu
	private $m_CPages; // Configs Page
	private $m_menu_selected; //base selected menu
	private $m_menu_cselected; //config selected menu
	private $m_configTargetNode; //config target node
	private $m_menuTargetNode;//sytem target node
	private $m_customMenu;//user loaded menu
	
	private $m_CurrentPage;//current page
	private $m_configCurrentPage;// config current mage
	
	private $m_CurrentPageIndex;
	private $m_configCurrentPageIndex;
	private $m_sortby;
	private $m_osortby;
	
	const MENU_CHANGE_KEY  = "CustomMenuChanged";
	
	private $m_menuChangedState;
	private $m_menuHostCtrl; //menu host constroller
	
	
	//EVENTS
	private $m_CurrentPageChangedEvent;
	private $m_configCurrentPageChangedEvent;
	
	public function getName(){
		return IGK_MENU_CTRL;
	}
	//register menu page
	public function registerPage($pageName)
	{
		if (!isset($this->m_Pages[$pageName]))	
		{
			$this->m_Pages[$pageName] = array();
		}
	}
	public function unregisterPage($pageName)
	{
		if (!isset($this->m_Pages[$pageName]))	
		{
			unset($this->m_Pages[$pageName]);
		}
	}
	
	//GET PROPERTIES

	public function getConfigTargetNode(){ return $this->m_configTargetNode; }
	//MENU Current PAGE
	public function getCurrentPage(){return $this->m_CurrentPage;}
	public function getCurrentPageIndex(){return $this->m_CurrentPageIndex; }
	public function getConfigCurrentPage(){return $this->m_CurrentPage;}
	public function getGlobalMenu(){ if (is_array( $this->m_Menus)){$t = array(); $t = array_merge($t, $this->m_Menus); return $t;} return null;}
	public function getMenu($name){ if ($v = igk_getv($this->getGlobalMenu(),  strtoupper($name)))return $v; return null; }
	public function getRootMenu($name){ return $this->_getRootMenu($name);}
	public function getUserMenu(){return $this->m_customMenu; }
	
	
	//return the roots menus
	public function getRoots(){ 
		$t = array ();
		$h = $this->getGlobalMenu() ;
		if ($h && is_array($h)){
			foreach($h as $k)
			{
				if ($k->MenuParent == null)
					$t[] = $k;
			}
		}
		return $t;
	}
	public function addPageChangedEvent($obj, $method){
		$this->m_CurrentPageChangedEvent->add($obj, $method);
		
	}
	public function removePageChangedEvent($obj, $method){
		$this->m_CurrentPageChangedEvent->remove($obj, $method);
		
	}
	public function addConfigPageChangedEvent($obj, $method){
		$this->m_configCurrentPageChangedEvent->add($obj, $method);
		
	}
	public function removeConfigPageChangedEvent($obj, $method){
		$this->m_configCurrentPageChangedEvent->remove($obj, $method);		
	}
	//get registrated page list
	public function getPageList(){
		if ($this->m_Pages)
			return array_keys($this->m_Pages);
		return array();
	}
	private function onPageChanged(){//raise the Page changed event
		$this->m_CurrentPageChangedEvent->Call($this,null);
	}
	protected function onConfigPageChanged(){//raise the config page event
		$this->m_configCurrentPageChangedEvent->Call($this,null);
	}
	public function __construct(){
		parent::__construct();
		$this->m_init =false;
		$this->m_menu_selected = null;
		$this->m_cmenu_selected =null;
		$this->m_CurrentPage = "default";
		$this->m_CurrentPageIndex = 0;
		$this->m_CurrentPageChangedEvent = new IGKEvents($this, "CurrentPageChangedEvent");
		$this->m_configCurrentPageChangedEvent =  new IGKEvents($this, "ConfigCurrentPageChangedEvent");
		$this->m_CurrentPageChangedEvent->add($this, "View");
	}
	

	//------------------------------------------------------------
	//set the global web page
	//------------------------------------------------------------
	public function setPage($page, $index)
	{
		if (!$this->ConfigCtrl->IsConfiguring)
		{	
			$this->m_CurrentPage = $page;
			$this->m_CurrentPageIndex = $index;
			$this->onPageChanged();				
		}
		else{
			if (($this->m_configCurrentPage != $page) || ($this->m_configCurrentPageIndex != $index))
			{
				$this->m_configCurrentPage = $page;
				$this->m_configCurrentPageIndex = $index;
				$this->onConfigPageChanged();	
			}
		}
	}
	public function getConfigPage(){return "menu";}
	
	public function getDataTableInfo(){
		return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clIndex", IGK_FD_TYPE=>"Int")),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clController", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clMethod", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clPage", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clAvailable", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>1 ,"clDefault"=>1))
		);
	}
	
	public function initDb(){//init menu configuration
	$f = igk_io_syspath(IGK_MENU_CONF_DATA);
	if (file_exists($f) == false){
	$content = <<<EOF
DEFAULT,0,,,default,1
EOF;
		IGKIO::WriteToFileAsUtf8WBOM($f, $content,true);
		$this->_ReLoadMenu();
		}
	}

	public function menu_sortby()
	{
		$r = igk_getr("n");
		$m = igk_getr("m");
		$index = 0;
		if ($m==null){
			if ($r == $this->m_sortby )
				$this->m_sortby = "r_".$r;
			else 
				$this->m_sortby = $r;
		}else{
			$index = 1;
			if ($r == $this->m_sortby )
				$this->m_osortby = "r_".$r;
			else 
				$this->m_osortby = $r;
		}
		$this->View();
		igk_wl(igk_getv($this->TargetNode->getElementsByTagName("table"), $index)->Render());
		igk_exit();
	}
	public function sortmenu($a,$b)
	{
	
		if ($this->m_sortby)
		{
			$m = $this->m_sortby;
			if (IGKString::StartWith($this->m_sortby,"r_"))
			{
				switch(strtolower($m))
				{
					case "clindex":
						$i = igk_getv($a,"clIndex");
						$j = igk_getv($b,"clIndex");
						if ($i < $j)
							return -1;
						else if ($i > $j)
							return 1;
						break;
					case "clcontroller":
					default:
						return strcmp( igk_getv($b,$m), igk_getv($a,$m));
					
				}
				return strcmp( igk_getv($b, "clName"), igk_getv($a,"clName"));
			}
			else{
			switch(strtolower($m))
			{
				case "clindex":
					$i = igk_getv($a,"clIndex");
					$j = igk_getv($b,"clIndex");
					if ($i < $j)
						return -1;
					else if ($i > $j)
						return 1;
					break;
				case "clcontroller":
				default:
					return strcmp( igk_getv($a,$m), igk_getv($b,$m));
				
			}
			}
		}
		return strcmp( igk_getv($a, "clName"), igk_getv($b,"clName"));
	}
	public function changeDefaultPage($newPage =null)
	{
		
		$newPage = igk_gettv($newPage, igk_getr("defaultmenupage"));
		if ($newPage)
		{
			$this->App->Configs->menu_defaultPage = $newPage;
			igk_save_config();
			igk_notifyctrl()->addMsg("configuration update");
		}
		$this->View();
		igk_navtocurrent();
	}
	public function View()
	{		
		if (!$this->getIsVisible())
		{
			if (!$this->ConfigCtrl->IsConfiguring)
			{
				$this->selectGlobalMenu(strtolower($this->m_CurrentPage),$this->m_CurrentPageIndex);			
			}				
			igk_html_rm($this->TargetNode);			
		}
		else{
			if (igk_sys_ischanged(self::MENU_CHANGE_KEY, $this->m_menuChangedState))
			{
				$this->_LoadMenu();
			}
			$t = $this->TargetNode;
			igk_html_add($t, $this->ConfigNode);
			$t->ClearChilds();
			
			//primary menu builder
			$this->MenuConfig($t);
			//other menu builder
			$v_mdiv = $t->addDiv();
			$v_mdiv["class"]="dispib alignt marg4";
			$this->_m_otherMenuView($v_mdiv);
		}
		$this->_onViewComplete();	
	}
	public function MenuConfig($t)
	{
		
		$v_mdiv = $t->addDiv();
		$v_mdiv["class"]="dispib alignt marg4";
		$frm = $v_mdiv->addForm();
		$this->addTitle($frm, "title.MenuDefaultPage");
		$frm["action"] = $this->getUri("changeDefaultPage");
		$frm["method"] = "post";
		$frm->addLabel("lb.defaultMenuPage");
		$frm->addInput("defaultmenupage", "text", igk_gettv($this->App->Configs->menu_defaultPage, "default"));
		$frm->addBr();
		$frm->addInput("btn_d", "submit", R::gets("btn.submit"));
		$c = $v_mdiv->addForm();
		$c["id"] = "config-menu_form";
		$c["action"]="#".$c["id"];		
		$this->addTitle($c, "title.MenuManager");
		$c->addHSep();			
		igk_add_article($this,"menu.description", $c->addDiv());
		$c->addHSep();
		$c->addBr();
		$c->addBr();
		
		$tab = $c->add("table", array("class"=>"fitw"));
		
		$ct = $this->DataTableInfo;
		$this->_m_loadTableHeader($tab);
		
		$d = $this->m_customMenu;
		
		usort($d, array($this,"sortmenu"));
		
		
		foreach($d as $k=>$v)
		{		
			$tr = $tab->add("tr");
			
			$input = $tr->add("td")->addInput("menu[]", "checkbox", $v[IGK_FD_NAME]);
			
			foreach($ct as $h=>$m)
			{
				$oi = $m->clName;
				
				
				switch(strtolower($oi))
				{
					case "clindex":
						$tr->add("td")->Content = igk_parse_num($v[$oi]);
						break;
				default:
					if (isset($v[$oi]))
					{
					if ($oi==IGK_FD_NAME){
						$tr->add("td")->add("a", array("href"=>$this->getUri("menu_editmenuframe&n=".$v[IGK_FD_NAME])))->Content =$v[$oi];
					}
					else 
						$tr->add("td")->Content =$v[$oi];
					}
					else
					$tr->add("td")->Content = IGK_HTML_WHITESPACE;//$v[$oi];
				break;
				}
			}
			IGKHtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("menu_editmenuframe&n=".$v[IGK_FD_NAME]), "edit");
			IGKHtmlUtils::AddImgLnk($tr->add("td"),igk_js_post_frame($this->getUri("menu_dropmenu_ajx&n=".$v[IGK_FD_NAME])), "drop");
					
		}
		$c->addBr();
		
		$div = $c->addDiv();
		$a = IGKHtmlUtils::AddImgLnk($div,$this->getUri("menu_drop_selected_menu_ajx"), "drop");
		$a->a["onclick"] = "javascript: var q =  \$igk(this).getParentByTagName('form'); q.action = this.href; q.submit();  return false;";		
		IGKHtmlUtils::AddBtnLnk($c, "btn.add", igk_js_post_frame($this->getUri("menu_add_menu_frame_ajx")));		
		IGKHtmlUtils::AddBtnLnk($c,"btn.rmAll", $this->getUri("menu_Clearallmenu"));			
		igk_html_toggle_class($tab);		
	}
	private function _m_loadTableHeader($table, $oMenu=null)
	{
		$tr = $table->add("tr");
		IGKHtmlUtils::AddToggleAllCheckboxTh($tr);			
		$ct = $this->DataTableInfo;
		foreach($ct as $k)
		{
			$tr->add("th")->add('a', array("href"=>$this->getUri("menu_sortby&n=".$k->clName. (($oMenu==null)?null:"&m=".$oMenu) ),
			"onclick"=>igk_js_ajx_post_luri('table')))->Content = R::gets($k->clName);
		}		
		$tr->add("th",array("style"=>"width:8px; "))->Content = IGK_HTML_WHITESPACE;
		$tr->add("th", array("style"=>"width:8px; "))->Content = IGK_HTML_WHITESPACE;
	}
	private function _m_otherMenuView($target)
	{
		
		$this->addTitle($target, "title.OtherMenuManager");
		$target->addHSep();
		
		igk_add_article($this,"menu.othermenudescription", $target->addDiv(), null, true);
		$target->addHSep();
		$frm = $target->addForm();
		
		
		
		$li = $frm->add("ul")->add("li");
		$li->addLabel("lb.Menus", "clMenus");
		igk_html_build_select($li,"clMenus", array());
		
		
		$table = $frm->addTable();
		
		$this->_m_loadTableHeader($table, "d");
		
		$btndiv = $frm->addDiv();
		
		igk_html_toggle_class($table);
		
	}
	public function menu_drop_selected_menu()
	{
		$this->menu_drop_selected_menu_ajx();
		
	}
	public function menu_drop_selected_menu_ajx()
	{		
		if (!$this->ConfigCtrl->IsConnected)
			return;
		$m = igk_getr("menu");
		$c = false;
		foreach($m as $k=>$n)		
		{
			$n = strtoupper($n);
			if (isset($this->m_customMenu[$n]))
			{
				unset($this->m_customMenu[$n]);			
				$c = true;
			}
		}
		if ($c)
		{
			$this->__saveConfigMenu();
			$this->_ReLoadMenu();				
			igk_notifyctrl()->addMsg("menu ".$n. " removed");			
		}
		else {
			igk_notifyctrl()->addError("menu ".$n. " not removed");
		}				
		igk_navtocurrent();
	}
	
	public function menu_Clearallmenu()
	{		
		if (igk_qr_confirm()){
			$this->m_customMenu = array();
			$this->__saveConfigMenu();			
			$this->_ReLoadMenu();
			$this->View();			
			igk_navtocurrent();
		}
		else{
			$frame = igk_frame_add_confirm($this, "menu_Clearallmenu_confirm_frame", $this->getUri("menu_Clearallmenu"));				
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEMENU_QUESTION);						
		}
	}
	public function menu_dropmenu()
	{
		$n = igk_getr("n",IGK_STR_EMPTY);
		$n = strtoupper($n);
		if (isset($this->m_customMenu[$n]))
		{
			unset($this->m_customMenu[$n]);			
			$this->__saveConfigMenu();
			$this->_ReLoadMenu();
			igk_notifyctrl()->addMsg("menu ".$n. " removed");			
		}
		else {
			igk_notifyctrl()->addError("menu ".$n. " not removed");
		}
		$this->View();
		igk_navtocurrent();
	}
	
	public function menu_dropmenu_ajx()
	{
		if (igk_qr_confirm()){
			$this->menu_dropmenu();
		}
		else{
			$frame = igk_frame_add_confirm($this, __FUNCTION__."_frame", $this->getUri("menu_dropmenu_ajx"));			
			$frame->Form->addInput("n", "hidden", igk_getr("n"));
			$frame->Form->Div->Content = R::ngets("msg.deletemenu.question_1", igk_getr("n"));						
			$frame->RenderAJX();
		}
	}
	
	public function menu_editmenuframe($name=null)
	{
		$name = ($name==null)?igk_getr("n"):$name;		
		
		if (!isset($this->m_customMenu[$name]))
				return ;
				
		$v_menu = $this->m_customMenu[$name];		
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_editMenu_frame", $this);
		IGKHtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.EditMenu", $name);
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("save_menu");
		$div = $frm->addDiv();
		$index   = igk_getsv( igk_getv($v_menu,"clIndex"), '0');
	
		$div->add("li")->addSLabelInput(IGK_FD_NAME,"text",igk_getv($v_menu,IGK_FD_NAME), null, true);
		$div->add("li")->addSLabelInput("clIndex", "text",$index, array("isnumeric"=>true), true);
		$div->add("li")->addSLabelInput("clPage","text",igk_getv($v_menu,"clPage"), null);
		
		$this->__getEditController($div, igk_getv($v_menu,"clController"));
	
		$div->add("li")->addSLabelInput("clMethod","text",igk_getv($v_menu,"clMethod"));		
		$div->add("li")->addSLabelInput("clGroup","text", igk_getv($v_menu,"clGroup"));	
		$li = $div->add("li");
		$li->add("label")->Content = R::ngets("clAvailable");
		
		$chb = $li->addInput("clAvailable", "checkbox");
		
		if (igk_getv($v_menu,"clAvailable")){
			$chb["checked"] = true;
		}
		
		$div->addInput("confirm", "hidden", 1);
		//Clear info
		$div->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.save"));
	}
	public function save_menu()
	{	
		if (!igk_qr_confirm())
		{
			return;
		}		
		$this->menu_add_menu(false);			
		$this->View();
		igk_frame_close("theme_editMenu_frame", false);		
	}
	public function __getEditController($div, $selectedMenu, $key = "lb.Controller", $remove=IGK_STR_EMPTY)
	{
			$tab = igk_sys_getuserctrls();
			$li = $div->add("li");
			$li->add("label")->Content = R::ngets($key);
			$sel = $li->add("select");	
			$sel["id"]=$sel["name"] = "clController";
			$sel->add("option", array("value"=>"none"))->Content = IGK_HTML_SPACE;
		if (count($tab) > 0)
			{
		
			foreach($tab as $v)
			{	if (strtolower($remove) == strtolower($v->getName()))
				   continue;
				$opt = $sel->add("option", array("value"=>$v->getName()));
				if ($selectedMenu == $v->getName())
					$opt["selected"] = true;
				$opt->Content = $v->getName();				
			}
			}
			return $sel;
	}
	public function menu_add_menu_frame_ajx()
	{
	
		$frame = igk_add_new_frame($this, "theme_menu_add_menu_frame");		
		$frame->Title = R::ngets("title.Menu");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("menu_add_menu");
		$div = $frm->addDiv();
		$div->add("li")->addSLabelInput(IGK_FD_NAME, "text",null, null, true);
		$div->add("li")->addSLabelInput("clIndex", "text",null, array("isnumeric"=>true), true);
		$div->add("li")->addSLabelInput("clPage");
		
		$this->__getEditController($div, null);		
		$div->add("li")->addSLabelInput("clMethod");		
		$div->add("li")->addSLabelInput("clGroup");	
		$li = $div->add("li");
		$li->add("label")->Content = R::ngets("clAvailable");
		$chb = $li->addInput("clAvailable", "checkbox");
		$chb["checked"] = true;
		//Clear info
		$div->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));	
		igk_wl($frame->Render());
	}
	public function getDefaultEntry()
	{
		return array(
			IGK_FD_NAME=>null,
			"clIndex"=>0,
			"clController"=>null,
			"clMethod"=>null,
			"clPage"=>null,
			"clGroup"=>null,
			"clAvailable"=>null
		);		
	}
	public function reg_menu($t, $saveconfig= true)
	{
		if (is_array($t) == false)
			return;
		extract($t);
		$clIndex = igk_getsv($clIndex, 0);
		$this->val->ClearChilds();
		if (IGKValidator::IsStringNullOrEmpty($clName)) $this->val->add("Name is null or empty");
		if (isset($this->m_customMenu[IGK_FD_NAME])){ $this->val->add("Menu already registered");}
		if ($this->val->HasChilds){
			$this->msbox->copyChilds($this->val);
		}
		else{
			$clName = strtoupper($clName);
			
			$this->m_customMenu[$clName] = array(
				IGK_FD_NAME=>trim($clName),
				"clIndex"=>trim($clIndex),
				"clController"=>trim($clController)=="none"?null:trim($clController),
				"clMethod"=>trim($clMethod),
				"clPage"=>trim($clPage),
				"clGroup"=>trim($clGroup),
				"clAvailable"=>(isset($clAvailable)?1:0)
		);
		
		$this->storeDBConfigsSettingMenu($saveconfig);
	}
	}
	private function storeDBConfigsSettingMenu($saveconfig=true)
	{	
		if ($saveconfig)
		{
			if ($this->__saveConfigMenu())
			{
			//reload menu
				$this->_ReLoadMenu();						
				igk_notifyctrl()->addMsgr("msg.globalmenuupdated");
				igk_debug_wln("notice:save and reloaded");
			}
			else{
				igk_debug_wln("error:not saved menu");
			}
		}
	}
	
	//add menu
	public function menu_add_menu($navigate=true)
	{
		$this->reg_menu($_REQUEST);		
		$this->View();
		if ($navigate)
		{			
			igk_navtocurrent();
		}
	}
	//load config menu from file
	private function _LoadConfigMenu()
	{
		$this->m_customMenu = array();
		$f = igk_io_syspath(IGK_MENU_CONF_DATA);
		$txt = IGKIO::ReadAllText($f);
		$lines = explode(IGK_LF, $txt);
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$e = explode( igk_csv_sep(), $l);			
			$name = strtoupper(trim($e[0]));
			if (empty($name))continue;
			$this->m_customMenu [$name] =array(
				IGK_FD_NAME=>$name,
				"clIndex"=>trim(igk_getv($e,1)),
				"clController"=>trim(igk_getv($e,2)),
				"clMethod"=>trim(igk_getv($e,3)),
				"clPage"=>trim(igk_getv($e,4)),
				"clGroup"=>trim(igk_getv($e,5)),
				"clAvailable"=>trim(igk_getv($e,6)),
				);
		}
		igk_debug_wln("warning: load config menu [".count($this->m_customMenu )."]");
	}
	function __ClearConfigMenu($storeconfig=true)
	{
		$this->m_customMenu = array();
		$this->storeDBConfigsSettingMenu($storeconfig);
	}
	//save config file to file
	function __saveConfigMenu()
	{
		igk_debug_wln("warning: _saveConfigMenu [".igk_count($this->m_customMenu )."]");
		$out = IGK_STR_EMPTY;
		$i = false;
		$line = null;
		foreach($this->m_customMenu as $k=>$v)
		{
			if ($i )
				$out .= "\n";
			$line = IGK_STR_EMPTY;
			$v_sep = false;
			foreach($v as $c=>$m)
			{
				$m = trim($m);
				if ($v_sep){
					$line .= igk_csv_sep();
				}
				else{
					$v_sep = true;
				}
				if (!empty($m))
					$line .= $m;
				
			}
			$out .= $line;
			$i =true;
		}
	  
	  $v =  IGKIO::WriteToFileAsUtf8WBOM(igk_io_currentRelativePath(IGK_MENU_CONF_DATA), $out, true);	
	  if ($v)	  
	  igk_sys_regchange(self::MENU_CHANGE_KEY, $this->m_menuChangedState);
	  return $v;
	}
	private function _initMenu($ul, $menu,  &$pages =null){//init menu in menu item in IGKMenuCtrl
		$add_uri = null;
		if (isset($pages))
		{
		
				$page = strtolower($menu->CurrentPage);
				if (isset($pages [$page]))
				{
					if (!is_array($pages [$page]))
					{
					$cp = $pages [$page];
					$cp->PageIndex = 0;
					$pages[$page] = array($cp);
					$cp->MenuItem["href"] = $cp->MenuItem["href"];//."&pageindex=0";
					}
					$pages [$page][] = $menu;					
					$menu->PageIndex = count($pages [$page])-1;
					$add_uri = "&pageindex=".$menu->PageIndex;
					
					if ($menu->MenuParent)
					{
						$add_uri = strtolower("&v=".substr($menu->Name, strlen($menu->MenuParent->Name)+1));
					}				
				}
				else{
					$pages [$page] = $menu;
				}
				
		}
		
		$menu->updateUri($add_uri);		
		if ($menu->HasChilds())
		{
			$menu->sortChilds();
			$menucl = ".submenu_".$this->_getMenuLevel($menu);
			igk_css_regclass($menucl, "{sys:dispn}");
			
			$v_ul = $menu->Node->add("ul", array("class"=>$menucl));
			foreach($menu->getChilds() as $k)
			{
				$v = $this->_initMenu($v_ul, $k, $pages);
			}
		}
		//add node to uls
		$ul->add($menu->Node);
		
	}
	private function _getMenuLevel($menu){
		if ($menu->MenuParent == null)
			return 0;
		return $this->_getMenuLevel($menu->MenuParent) + 1;
	}
	//-------------------------------------------------------------------
	//select root menu
	//-------------------------------------------------------------------
	public function selectGlobalMenu($page, $index=0)
	{		
		$page = strtolower($page);
		if (isset($this->m_Pages[$page]))
		{
			if ($this->m_menu_selected !=null)
			{
				$this->m_menu_selected["class"] = "-igk-menu_selected";
			}
			$v_rootmenu  = null;
			$v_p = $this->m_Pages[$page];
			if (!is_array($v_p))
				$v_rootmenu = $this->_getRootMenu($v_p);
			else {
				if (isset($v_p[$this->m_CurrentPageIndex]))
					$v_rootmenu = $this->_getRootMenu($v_p[$this->m_CurrentPageIndex]);				
			}
			
			if ($v_rootmenu){
				$this->m_menu_selected = $v_rootmenu->MenuItem;
				$this->m_menu_selected["class"] = "+igk-menu_selected";				
			}			
		}
		else{
			if (igkServerInfo::IsLocal())
			{
				igk_notifyctrl()->addError("web_global_menu not define [".$page."] - ". $_SERVER["REQUEST_URI"]);				
			}
		}
	}
	
	//select root menu
	public function selectConfigMenu($page, $fromcontext=null)
	{
		$page = strtolower($page);
		if (isset($this->m_CPages[$page]))
		{
			if ($this->m_menu_cselected !=null)
			{
				$this->m_menu_cselected->MenuItem["class"] = "-igk-cnf-menu_selected";
			}
			$this->m_menu_cselected = $this->m_CPages[$page];
			$this->m_menu_cselected->MenuItem["class"] = "+igk-cnf-menu_selected";				
		}
		else{
			igk_notifyctrl()->addError("Config menu not define : [".$page."]");		
		}
		//igk_wln("select config menu". $page);
	}
	
	//retreive the root menu of a menu item
	private function _getRootMenu($menu)
	{
		if (($menu == null) || is_array($menu))
			return null;
		if ($menu->MenuParent === null)
			return $menu;
		return $this->_getRootMenu($menu->MenuParent);
	}
	
	public function setParentView($node)
	{
		if ($node)
		{
			IGKHtmlUtils::AddItem($this->m_menuTargetNode,$node);
		}
	}
	public function setConfigParentView($node)
	{
		if ($node)
		{
			IGKHtmlUtils::AddItem($this->ConfigTargetNode, $node);
		}
	}
	protected function initTargetNode(){
		$ul =  IGKHtmlItem::CreateWebNode("ul");
		$this->m_configTargetNode =  IGKHtmlItem::CreateWebNode("ul");
		$this->m_menuTargetNode =  IGKHtmlItem::CreateWebNode("ul");
		return $ul;
	}
	protected function InitComplete(){
		parent::InitComplete();
		//register for menu list changed		
		$this->m_CurrentPage = igk_gettv($this->App->Configs->menu_defaultPage, "default");
		igk_sys_regchange(self::MENU_CHANGE_KEY, $this->m_menuChangedState);
		//load menu
		$this->_LoadMenu();
		$this->setMenuview();
		$this->selectGlobalMenu($this->m_CurrentPage);
	}
	//set the menu host ctrl
	public function setMenuhostCtrl($value)
	{
		if ($this->m_menuHostCtrl != $value)
		{
			
			if (is_object($this->m_menuHostCtrl))
			{
				$this->m_menuHostCtrl->unregView($this);
			}			
			$this->m_menuHostCtrl = $value;
			if ($this->m_menuHostCtrl!=null)
				$this->m_menuHostCtrl->regView($this, "setMenuview");
		}
	}
	public function setMenuview()
	{
		if ($this->App->Configs->menuHostCtrl)
		{			
			$menu_host =  igk_getctrl($this->App->Configs->menuHostCtrl);
			if ($menu_host !=null )
			{
				$this->setMenuhostCtrl($menu_host);
				$this->setParentView($menu_host->TargetNode);		
			}
		}
		
	}
	private function _ReLoadMenu()
	{
		$this->m_init = false;
		$this->_LoadMenu();
		$this->selectConfigMenu($this->m_menu_cselected? $this->m_menu_cselected->Name :"default");
		$this->View();
	}
	private function _LoadMenu()
	{
		
		//load menu from data base
		$this->_LoadConfigMenu();
		
		//setup menu to match menu item
		$v_cmenu = array();
		foreach($this->m_customMenu as $k=>$v)
		{
			if (igk_getv($v,"clAvailable"))
			{
			$v_cmenu[] = new IGKMenuItem($v[IGK_FD_NAME], 
			igk_getv($v,"clPage"),
			igk_getv($v,"clMethod"),
			igk_getv($v,"clIndex"),
			null,
			igk_getv($v,"clController"),
			igk_getv($v,"clGroup")
			);
			}
		}
		
		$ul = $this->m_menuTargetNode;
		$ul["id"] = "web_site_menu";
		$ul["class"] = "menu menufont menu_forecl menu_bgcl";
		$ul->Index = -9999;
		$ul->ClearChilds();
		
		
		
		
		
		
			$tab = array();
			$ctab = array();
			$v_ctab = array();
			$this->m_Menus = array();
			$this->m_Pages = array();
			$this->m_CMenus = array();
			$this->m_CPages = array();
			//create menu from configs files
			$v_confctrl = igk_getctrl(IGK_CONF_CTRL);
			
			
			foreach(IGKApp::getInstance()->getControllerManager()->getControllers() as $k=>$v)
			{			
				//
				//load config menu frame
				//
			
				$m = $v->initMenu();
				if ($v !== $v_confctrl)
				{
					$cm = $v->initConfigMenu();
					if ($cm !== null)					
						$v_ctab = array_merge($v_ctab, $cm);
				}
				else{
					$ctab = $v->initConfigMenu();
				}
				
				if ($m !== null)					
					$tab = array_merge($tab, $m);
				
			}
			//register element
			//IGKMenuItem::Sort($tab);
			$v_sortByIndex = array("IGKMenuItem", "SortMenuByIndex");
			$v_sortByName = array("IGKMenuItem", "SortMenuByName");
			$v_sortByDisplayText = array("IGKMenuItem", "SortMenuByDisplayText");
			
			$tab = array_merge($v_cmenu, $tab);
			igk_usort($tab, $v_sortByName);
			
			$v_list = array();
			foreach($tab as $v)
			{
				$p = $this->_getParentName($v->Name);
				
			if (isset($v_list[$p]))
				{
					$v_list[$p]->add($v);
				}
				else{
					$v_list[$v->Name] = $v;
				}
			}
			igk_usort($tab, $v_sortByIndex);
			
		
			foreach($tab as $t=>$m)
			{
				if ($m->MenuParent ==null){
				//for root menu only
					$this->m_Menus[$m->Name] = $m;
					$this->_initMenu($ul, $m, $this->m_Pages);		
				}
			}
			//init menu setting for drop down menu management
			$sr = $ul->add("script")->Content = <<<EOF
if (window.igk.winui.menu){	window.igk.winui.menu.init();}
EOF;
			
			//init . config menu				
			$v_configTargetNode = $this->m_configTargetNode;
			$v_configTargetNode["class"] = "igk-config-menu-font";
			$v_configTargetNode->Index = -9999;
			$v_configTargetNode->ClearChilds();
			
			
			$div = $v_configTargetNode->add("li")->addDiv();
			$div->addDiv()->addSpace();
			$this->_initConfigMenu($ctab, $div->add("ul"), false);
			igk_usort($v_ctab, $v_sortByDisplayText);
			
			$v_configTargetNode->add("li", array("class"=>"config-menu-separator"))->Content = IGK_HTML_SPACE;
			$div = $v_configTargetNode->add("li")->addDiv();
			
			$this->_initConfigMenu($v_ctab, $div->add("ul"), true);
			
			
			$sr = $v_configTargetNode->addScript();
			$sr->Content = <<<EOF
if(window.igk.configmenu)window.igk.configmenu.init(igk.getParentScriptByTagName());
EOF;
			
			$this->m_init = true;		
	}
	private function _initConfigMenu($v_ctab, $cul, $bygroup=false)
	{		
		if ($bygroup)
		{
			$group  = array();
			foreach($v_ctab as $t=>$m)
			{				
				if (!isset($group[$m->Group]))
				{
					$group[$m->Group] = array();
				}
				$group[$m->Group][] = (object)array("Menu"=>$m, "Node"=>IGK_STR_EMPTY);
			}
			foreach($group as $k=>$v){				
				
					$div = $cul->addDiv();
					$div->addDiv()->setClass("igk-cnf-menu-title")->Content = R::ngets("group.".$k);
					$ul = $cul->add("ul");
					foreach($v as $t=>$m)
					{
						 $this->_initMenu($ul , $m->Menu);
						$this->m_CPages[$m->Menu->CurrentPage] = $m->Menu;				
						$v_a  = $m->Menu->MenuItem;								
						$v_a["page"] = $m->Menu->CurrentPage;
						$this->m_CMenus[$m->Menu->Name] = $m->Menu;	
					}
			}
			
		}
		else{
			foreach($v_ctab as $t=>$m)
			{				
				//$this->_initMenu($cform , $m);
				$this->_initMenu($cul , $m);
				$this->m_CPages[$m->CurrentPage] = $m;
				
				$v_a  = $m->MenuItem;								
				$v_a["page"] = $m->CurrentPage;
				$this->m_CMenus[$m->Name] = $m ;				
			}
		}
	}
	
	
	public function _getParentName($name)
	{
		$t = explode(".", $name);
		$c = count($t);
		if ($c>1)
		{
			$out = IGK_STR_EMPTY;
			$v_sep = false;
			for	($i = 0;$i< $c-1 ; $i++)
			{
				if ($v_sep)
					$out .= ".";
				else 
					$v_sep = true;
				$out .= $t[$i];
			}
			return $out;
		}
		return null;
	}
	
}

final class IGKOtherMenuCtrl extends IGKControllerBase
{
	private $m_allMenus;
	public function getMenus(){return $this->m_allMenus;}
	protected function InitComplete(){
		parent::InitComplete();
		$this->m_allMenus = IGKMenu::GetMenus();
	}
	public function getIsVisible(){return false;}
}

final class IGKMenu extends IGKObject
{
	var $Name;
	var $m_menus;
	
	public static $sm_menus;
	
	public function getMenuFile(){
		return igk_io_baseDir(IGK_DATA_FOLDER ."/menu".$this->Name."conf.csv");
	}
	public function __construct($name)
	{
		$this->Name = $name;
		$this->m_menus = array();
	}
	

	public static function GetMenus()
	{
		//TODO:: GET MENU FROM 
		//get all menu from diffrent mage
		if (self::$sm_menus == null)
		{
			self::$sm_menus = array();			
			//
			$d = igk_io_getFiles(igk_io_baseDir(IGK_DATA_FOLDER), IGK_MENUS_REGEX);
			if ($d){
				foreach($d as $k=>$v)
				{
					$n = igk_regex_get(IGK_MENUS_REGEX, "name", $v);					
				}
			}
		}
		return self::$sm_menus;
	}
	
	public function loadMenu()
	{
		
	}
	public function storeMenu()
	{
		
	}
	public function addMenu($name)
	{
		$n = new IGKMenuItem($name, null,null);
		$this->m_menus[$name]  = $n;
		return $n;
	}
}

class IGKMenuItem extends IGKObject
{
	
	var $Name;
	var $PageIndex;
	var $m_Parent;
	
	private $m_Uri;	
	private $m_Index;
	private $m_key;
	private $m_menuItem;
	private $m_CurrentPage;
	private $m_Childs;
	private $m_group;
	private $m_Visible;
	private $m_VisibleChangedEvent;
	private $m_controller;
	private $m_node;
	public function __toString(){
		return get_class($this). " [ ".$this->Name." ] ";
	}
	//get the group name
	public function getGroup(){return $this->m_group;}
	public function setGroup($group){$this->m_group = $group; return $this; }
	public function & getMenuParent(){return $this->m_Parent;}
	public function getKey(){			return $this->m_key;	}
	public function HasChilds(){return (count($this->m_Childs)>0);}
	public function setMenuItem($menu){ 
		$this->m_menuItem = $menu; 		
		$this->updateView();
		
	}
	//menu item
	public function getMenuItem(){return $this->m_menuItem; }
	//MENUITEM CURRENT PAGE
	public function getCurrentPage(){return $this->m_CurrentPage; }
	public function getIndex(){return $this->m_Index;}  //menu index
	public function getIsVisible(){
	if ($this->m_menuItem)
		return $this->m_menuItem->getIsVisible();
	return false;
	}
	//get the html current node
	// <a></a><ul>...child...</ul>
	public function getNode(){return $this->m_node; }
	protected function setNode($value){ $this->m_node = $value; }
	
	public function getChilds(){ return $this->m_Childs;	}
	
	public function getIsMenuSelected(){		
		$c = $this->m_menuItem["class"];
		if (!$c)
			return false;
		return $c->contain("igk-menu_selected");		
	}
	public function getUri(){
		$uri = IGK_STR_EMPTY;
		if (!empty($this->m_Uri))
			$uri .= $this->m_Uri;
		if (!empty($this->m_CurrentPage)){
			if (strlen($uri) >0)
				$uri.="&";
			if (!empty($this->m_CurrentPage))
				$uri .= "p=".$this->m_CurrentPage;
		}
		$ctrl = $this->m_controller;
		if ($ctrl!=null){
			return $ctrl->getUri($uri);
		}
		if (IGKString::StartWith($uri,'?'))
			return $uri;
		return "?".$uri;
		
		
	}
	public function setIsVisible($value){ 
		if ($this->m_menuItem && ($this->m_controller == null))
			$this->m_menuItem->setIsVisible($value); 
		}
	public static function CreateMenu($attributes )
	{
		if (!is_array($attributes))
		return null;
		$n = igk_getv($attribute,"name");
		$uri = igk_getv($attribute,"uri");
		$i = igk_getv($attribute,"index");
		$p = igk_getv($attribute,"page");
		if (empty($n) || empty($uri) || empty($p))
			return null;
		$menu = new IGKMenuItem($n, $p, $uri, $i);
		foreach($attributes as $k=>$v)
		{
			$menu->$k = $v;  
		}
		return $menu;
	}
	public function __construct($name,$CurrentPage, $uri, $index=0, $key=null, $controller=null, $group=null, $defaulttag="li"){
	$this->m_Parent = null;
	$this->m_Childs = array();
	$this->Name = strtoupper($name);
	$this->m_Uri = $uri;
	$this->m_Index = $index;
	$this->m_CurrentPage = strtolower($CurrentPage);
	$this->m_group = $group;
	$this->m_controller = ($controller!=null)? igk_getctrl($controller, false):null;
	$this->PageIndex = 0;
	$this->m_node =  IGKHtmlItem::CreateWebNode($defaulttag , array("class"=>strtolower(str_replace(".","_","menu_".$this->Name))));
	$item = $this->node->add("a", array("href"=>$this->Uri));
	
	
	
	if($key == null)
		$this->m_key = strtoupper("Menu.".$name);
	else 
		$this->m_key = $name;
		
		$this->m_Visible = true;
		$this->m_VisibleChangedEvent = new IGKEvents($this, "VisibleChanged");
		$this->m_VisibleChangedEvent->add($this, "_visibleChanged");
		
		if ($this->m_controller !=null)
		{
			igk_getctrl(IGK_MENU_CTRL)->addPageChangedEvent($this, "updateview");
			IGKApp::getInstance()->Session->addUserChangedEvent($this, "updateview");
		}
	$item->add("span")->Content = R::ngets($this->Key);
	$this->setMenuItem($item);
	
	}
	public function updateUri($adduri)
	{
		$this->MenuItem["href"] = $this->Uri.$adduri;
	}
	public function updateview(){
		if ($this->m_controller !=null){
			$this->m_menuItem->getIsVisible($this->m_controller->isAvailable);		
			$this->m_menuItem->getParentNode()->setIsVisible($this->m_controller->isAvailable);
		}
	}
	
	public function add($menu){
		if ($menu == null)return;
		$this->_removeParent($menu);
		$this->m_Childs[] = $menu;
		$menu->m_Parent = $this;
	}
	public function remove($menu){
		for($i = 0;$i<count($this->Childs); $i++){
			if ($this->Childs[$i] === $menu){
			unset($this->m_Childs[$i]);
			$this->m_Childs = array_values($this->Childs);
			$menu->m_Parent = null;
			break;
			}
		}
	}
	//<summary>Clear menu item</summary>
	public function Clear(){//Clear menu item
		$this->m_Childs = array();
	}
	private function _removeParent($menu){
		if (($menu != null) && ($menu->MenuParent !=null)){
			$menu->getMenuParent()->remove($menu);			
		}
	}
	//sort menu by index and by name
	//---------------------------------
	public static function SortMenuByIndex($a, $b){
		if ($a->Index < $b->Index)
			return -1;
		else if ($a->Index == $b->Index)
			return self::SortMenuByName($a, $b);
		return 1;
	}
	public static function SortMenuByName($a, $b)
	{
		return strcmp($a->Name, $b->Name);
	}
	public static function SortMenuByDisplayText($a, $b)
	{
		return strcmp(R::ngets("menu.".$a->Name)->getValue(), R::ngets("menu.".$b->Name)->getValue());
	}
	public function sortChilds()
	{
		igk_usort($this->m_Childs, array("IGKMenuItem", "SortMenuByIndex"));
	}
}

///<summary>represent menu build utility</summary>
final class IGKMenuUtils 
{
	public static function BuildMenu($targetNode, $tab, &$menus, &$pages){//menu utils build menu
			$v_list = array();
			foreach($tab as $v)
			{
				$p = self::GetParentName($v->Name);
				
			if (isset($v_list[$p]))
				{
					$v_list[$p]->add($v);
				}
				else{
					$v_list[$v->Name] = $v;
				}
			}
			
			igk_usort($tab, array("IGKMenuItem", "SortMenuByIndex"));
			foreach($tab as $t=>$m)
			{
				if ($m->MenuParent ==null){
					//for root menu only
					$menus[$m->Name] = self::InitMenu($targetNode, $m, $page);		
				}
			}
	}
	
	private static function InitMenu($node, $menu, &$page){//menu utils init the menu base
		$add_uri = null;
		if (isset($pages))
		{
		
				$page = strtolower($menu->CurrentPage);
				if (isset($pages [$page]))
				{
					if (!is_array($pages [$page]))
					{
					$cp = $pages [$page];
					$cp->PageIndex = 0;
					$pages[$page] = array($cp);
					$cp->MenuItem["href"] = $cp->MenuItem["href"];//."&pageindex=0";
					}
					$pages [$page][] = $menu;					
					$menu->PageIndex = count($pages[$page])-1;
					
					$add_uri = "&pageindex=".$menu->PageIndex;
					if ($menu->ParentMenu)
					{
						$add_uri = strtolower("&v=".substr($menu->Name, strlen($menu->ParentMenu->Name)+1));
					}
				}
				else{
					$pages [$page] = $menu;
				}
				
		}
		$menu->updateUri($add_uri);
		
		// $li = $node->add("li" ,array("class"=>"posr"));
		// $item = $li->add("a", array("href"=>$menu->Uri.$add_uri));
		//$item->Content = R::ngets($menu->Key);
		//$menu->setMenuItem($item);
		if ($menu->HasChilds())
		{
			$menu->sortChilds();
			$v_ul = $li->add("ul", array("class"=>"submenu".$this->_getMenuLevel($menu)." "));
			foreach($menu->getChilds() as $k)
			{
				$v = $this->_initMenu($v_ul, $k, $pages);
			}
		}
		//return the menu created
		//return $menu->MenuItem;
	}	
	///<summary>get parent name of  the menu</summary>
	public static function GetParentName($name){
		$t = explode(".", $name);
		$c = count($t);
		if ($c>1)
		{
			$out = IGK_STR_EMPTY;
			$v_sep = false;
			for	($i = 0;$i< $c-1 ; $i++)
			{
				if ($v_sep)
					$out .= ".";
				else 
					$v_sep = true;
				$out .= $t[$i];
			}
			return $out;
		}
		return null;
	}
}


//represent a data adapter factory
abstract class IGKDataAdapter extends IGKObject
{
	private static $sm_regAdapter =null;
	public static function Load()
	{
		self::LoadAdapter();
	}
	public abstract function initSystableRequired($tablename);
	public abstract function initSystablePushInitItem($tablename, $callback);
	public function select($tablename, $entries){}
	public function delete($tablename, $entries){}
	public function deleteAll($tablename){}
	public function update($tablename, $entrie =null) {}	
	public function drop(){$this->deleteAll(); }//shortcut to delete all
	public function selectdb($dbname){}//select db used in some data base
	public abstract function connect();//connect
	public abstract function close();//close your adapter
	public function selectAll($tbname){ return null;}
	public function selectLastId(){ return null; }	
	public function selectAndWhere($tablename, $whereTab){return null;}
	public function ClearTable($tablename){}
	
	//return the igk instance
	public function getApp(){return IGKApp::getInstance(); }
	public function getIsAvailable(){ return true;}
	private static function LoadAdapter()
	{
	//init data adapter class
			$n = "/^IGK(?P<name>(.)+)DataAdapter$/i";
			self::$sm_regAdapter = array();
			foreach( get_declared_classes() as $k=>$v)
			{
				
				if (preg_match($n,$v))
				{
					$t = array();
					preg_match_all($n,$v, $t);
					$s = $t["name"][0];
					
					if (!igk_reflection_class_isabstract($v) && igk_reflection_class_extends($v, "IGKDataAdapter"))
					{
						self::$sm_regAdapter[strtoupper($s)] = new $v();
					}					
				}
			}
	}
	public static function GetAdapters()
	{
		if (self::$sm_regAdapter==null)
		{
			self::LoadAdapter();
			
		}
		return self::$sm_regAdapter;
	}
	public static function CreateDataAdapter($ctrl, $throwexception, $params = null){
		
		$adapt = self::GetAdapters();			
		$n = IGK_STR_EMPTY;
		$key = IGK_STR_EMPTY;
		if (is_string($ctrl))
		{
			$key = strtoupper($ctrl);
			$n = "IGK".$ctrl."DataAdapter";
		}
		else {
			$key = strtoupper($ctrl->getDataAdapterName());
			$n = "IGK".$key."DataAdapter";
		}

		if (isset($adapt[$key]))
		{
			return $adapt[$key];
		}
		if( IGKApp::$DEBUG)
		//throw new Exception("dd");
		igk_wln("CreateDataApter: not found .... ".$ctrl. ":".$n. " :::: ".$ctrl->getDataAdapterName());
		
	//	return null;
		if (class_exists($n) && !igk_reflection_class_isabstract($n))
		{
			$out = new $n(!is_string($ctrl)? $ctrl: null);
		
			if (($out !=null) && ($params !=null))
			{
				$out->configure($params);
			}
			if (!$out->IsAvailable)
			{
				igk_debug_wln("adapter ".$ctrl." not available");
				return null;
			}
			//register adapter
			$adapt[$key] = $out;
			return $out;
		}
		if ($throwexception)//ultimate case not found
			throw new Exception($n . " not found : Controller : ".$ctrl . " Name = ".$ctrl->getDataAdapterName() );
		return null;
	}
	///DATA ADAPTER OVERRIDABLE FUNCTIONS
	public function insert($table, $entries){
		igk_wln("warning :::: must override insert");
		return false;
	}
	public function createTable($tablename, $columninfoArray, $entries=null){
	}
	protected function configure($params){
	}
}

///<summary>used to initialize data adapter list</summary>
final class IGKDataAdapterCtrl extends IGKControllerBase
{
	public function getIsVisible(){return false;}
	
	protected function InitComplete(){
		parent::InitComplete();
		IGKDataAdapter::Load();
	}
}

final class IGKCSVQueryResult extends IGKQueryResult
{
	private $m_columns;
	private $m_rows;
	private $m_rowcount;
	private function __construct()
	{
		
	}
	public function getRows(){return $this->m_rows; }
	public function getColumns(){return $this->m_columns; }
	public static function CreateEmptyResult($result=null, $seacharray=null)
	{		
		$out = new IGKCSVQueryResult();
		$out->m_rowcount = 0;
		$out->m_rows = array();		
		return $out;
	}
	public function AppendEntries($e, $tableinfo=null)
	{
		
		$this->m_rowcount += igk_count($e);
		
		if ($tableinfo!=null)
		{
			foreach($e as $k=>$v)
			{
				$t = array();
				foreach($v as $m=>$n)
				{
					$v_n = $tableinfo[$m];
					$t[$v_n->clName] = $n;
					
				}
				$this->m_rows[] = (object)$t;
			}
		}
		else{
			foreach($e as $k=>$v)
			{
				$this->m_rows[] = $v;
			}
		}
	}
}
final class IGKCSVDataAdapter extends IGKDataAdapter
{
	private $m_fhandle;
	private $m_ctrl;
	private $m_dbname;
	
	public function initSystableRequired($tablename){
		return false;
	}
	public function initSystablePushInitItem($tablename, $callback){
	}
	public function __construct($ctrl = null){
		//don't call parent adapter
		$this->m_ctrl = $ctrl;	
	}
	
	
	public function connect($datafile="file"){
		$this->m_dbname = $datafile;
	}
	///convert tab to line entry
	public function toCSVLineEntry($tab, $key = null)
	{
		$out = IGK_STR_EMPTY;
		$v_sep = false;
		if (is_object($tab))
		{
		
			foreach($tab as $k=>$c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c;
			}
			
			return $out;
		}
		
		if (!is_array($tab))
		{
			return null;
		}
		if ($key!=null)
		{
			$v_sep = false;
			foreach($tab as $c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c->$key;
			}
		}
		else{
			foreach($tab as $c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c;
			}
		
		}
		return $out;
	}
	public static function GetValue($value)
	{
		if (strpos($value,igk_csv_sep()) !== false)
			return "\"".$value."\"";
		return $value;
	}
	//store data entrie to kv
	public static function StoreData($filename, $entries)
	{
		$out = IGK_STR_EMPTY;
		$v_ln = false;
		foreach($entries as $k=>$v)
		{
			if ($v_ln){
				$out .= IGK_LF;
			}
			else 
					$v_ln  = true;
			$v_sep = false;
			foreach($v as $d){
				if ($v_sep){
					$out .= igk_csv_sep();
				}
				else 
					$v_sep = true;
				$out .= self::GetValue($d);
				
			}
			
		}		
		IGKIO::WriteToFileAsUtf8WBOM($filename, $out, true);
	}
	static function __removeguillemet($data)
		{
			if (IGKString::StartWith($data,'"'))
			{
				$data = substr($data, 1);
			}
			if (IGKString::EndWith($data,'"'))
				$data = substr($data, 0, strlen($data)-1);
			return $data;
		}
		
	private static function _CSVReadLine($line)
	{
		$tab = array();
		$rtab = explode(igk_csv_sep(), $line);
		$v = false;
		$r = IGK_STR_EMPTY;
		foreach($rtab as $k=>$i)
		{
			$s = trim($i);
			if ($v == false)
			{
				if (IGKString::StartWith($s, '"'))
				{
					$v = true;
					$r .= substr($s, 1);
				}
				else
					$r .= $i;
			}
			else{
				if (IGKString::EndWith($s, '"'))
				{
				 
					$r .= igk_csv_sep().igk_str_rm_last($s, '"');
					$v = false;
				}
				else
					$r .= igk_csv_sep().$i;
			}
			if ($v==false)
			{
				$tab[] = trim($r);
				$r = IGK_STR_EMPTY;
			}
		}
		
		return $tab;
	}
	public static function LoadData($filename)
	{
		$txt = IGKIO::ReadAllText($filename);
		return self::LoadString($txt);
	}
	public static function LoadString($txt)
	{
		$lines = explode(IGK_LF, $txt);
		$entries = array();		
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$tab = self::_CSVReadLine($l);
			$entries[] = $tab;								
		}		
		return $entries;
	}
	
	public function selectAll($tbname)
	{
			$this->selectAllFile($tbname);
	}
	public function selectAllFile($tbname)
	{
		
		$f = igk_io_basePath(IGK_DATA_FOLDER)."/".$tbname.".csv";		
		if (file_exists($f))
		{
			$r = IGKCSVQueryResult::CreateEmptyResult();
			$r->AppendEntries(self::LoadData($f), $this->m_ctrl->getDataTableInfo());
			return $r;
		}
		return null;
	}
	public function close(){
		if ($this->m_fhandle)
		{
			fclose($this->m_f);
		}
	}
}


final class IGKXMLDataAdapter extends IGKDataAdapter
{
	public function initSystableRequired($tablename){
		return false;
	}
	public function initSystablePushInitItem($tablename, $callback){
	}
	public function connect(){
	}
	public function close(){
	}
	//load first level config node
	public static function LoadConfig($node)
	{
		if (($node ==null) || (!$node->HasChilds))
			return null;
			
		$t = array();
		
		foreach($node->Childs as $k)
		{
				$t[$k->TagName] = $k->innerHTML;
		}		
		return $t;
	}
	///load data file name of text
	public static function LoadData($filename)
	{
			function __loadData($node)
			{
				if ($node->HasChilds)
					{						
						if ($node->ChildCount == 1)
						{
							 if ($node->Childs[0]->NodeType == XmlNodeType::TEXT){
								return $node->innerHTML;
							 }
							 else{
								$t = array();
								$t[$node->TagName] = __loadData($node);
								return (object)$t;
							 }
						}
						else{
							$t = array();
							foreach($node->Childs as $k)
							{
								
								if (isset($t[$k->TagName]))
								{								
									$v = $t[$k->TagName];
									// if (is_array($v))
									// {
										
										// $v[] = __loadData($k);
									// }
									// else{
										$s = array();
										$s[] = $v;
										$s[] = __loadData($k);
										$t[$k->TagName] = $s;
									// }
								}
								else
									$t[$k->TagName] = __loadData($k);
							}
							return (object)$t;
						}
					}
					return null;
			}
			
			$f = $filename;
			if (is_string($f) == false)
				return null;
			$div =  IGKHtmlItem::CreateWebNode("div");
			$s = IGK_STR_EMPTY;
			if (file_exists($f))
			{
				$s = file_get_contents($f);	
			}
			else{
				$s = $f;
			}			
			
			$div->Load($s);
			
			if ($div->HasChilds)
			{
				$d = $div->getChildAtIndex(0);
				if ($d)
				{
					$t = array();
					foreach($d->Childs as $k)
					{
						$t[$k->TagName] = __loadData($k);
					}					
					return (object)$t;
				}
			}
			return null;
			
	}
	public static function storeData($filename, $data){//store xml data setting
		//store configuration data
		$d =  IGKHtmlItem::CreateWebNode("config");
		//store
		foreach($data as $k=>$v)
		{
			$d->add($k)->Content = $v;
		}		
		return IGKIO::WriteToFileAsUtf8WBOM(filename, $d->Render());
	}

	public function __construct(){//xml contructor
		
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------
//SYSTEM CONNTROLLER
//-------------------------------------------------------------------------------------------------------------------------------------------

/// USER TO CONFIGURE DATABASE ACCESS
final class IGKDbCtrl extends IGKConfigCtrlBase
{
	private $m_selectedDb;
	private $m_myadminview;
	private $m_searchtable;	
	private $m_loadTables;	
	
	public function __construct(){
		parent::__construct();
	}
	
	private function _initTableInfo()
	{
		if ($this->m_loadTables ==null)
		{
			$this->m_loadTables  = array();
			//igk_sys_getuserctrls
			$t = igk_sys_getall_ctrl();
			foreach($t as $k=>$v)
			{
				if ($v==$this)continue;
				
				
				$r = $v->getDataTableInfo();
				if ($r!=null){
					$this->m_loadTables[$v->getDataTableName()] = $v;
				}
				$r = $v->loadDataFromSchemas();
				if ($r !=null){
					foreach($r as $kk=>$vv)
					{
						if (isset($this->m_loadTables[$kk]))
						{
							throw new Exception("table loaded");
						}
						$this->m_loadTables[$kk] = $v;
					}
				}
			}
		}
	}
	///<summary>return a controller that manage the table name
	public function getDataTableCtrl($tablename){
		$this->_initTableInfo();
		if (isset(	$this->m_loadTables[$tablename]))
		{
			return $this->m_loadTables[$tablename];
		}
		return null;
	}
	public function getDataTableDefinition($tablename){
		
		$this->_initTableInfo();
		if (isset(	$this->m_loadTables[$tablename]))
		{
			$b = $this->m_loadTables[$tablename]->getDataTableInfo();
			if (isset($b[$tablename]))
			{//is in a multidiention table
				return $b[$tablename];
			}
			else 
				return $b;
		}
		return null;
	}
	//init data base
	public function initDb(){ //db controller no init db
		return null;
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	function pinitSDb()
	{
		$this->initSDb(true);
		igk_navtocurrent();
	}
	//init system data base
	function initSDb($view=true, $nav=true){
		
		$mysql = igk_get_data_adapter($this, true);
		if ($mysql != null)
		{
		
			if ($mysql->connect()  == true){
						
				$r = $mysql->createdb($this->App->Configs->db_name);	
				$mysql->selectdb($this->App->Configs->db_name);
				ini_set("max_execution_time", 0);
				if (function_exists("InitDb"))
				{
					//global function 
					InitDb();
				}
				else {
					//call init for all controllers
					foreach($this->App->getControllerManager()->getControllers() as $k)
					{
						if ($k == $this)
							continue;
						$k->initDb();
					}
				}
				igk_notifyctrl()->addMsgr("msg.db.initialized");
			}
			else 
				igk_notifyctrl()->addError(R::ngets("E.DbNotConnected"));
			$mysql->close();			
				
		
		if ($view)
		{
			$this->View();
		}
			
		}
		else{
			igk_notifyctrl()->addError("<ul><li>Can't create a data base manager . reason : ".$this->getDataAdapterName() ." : ".$mysql."<li></ul>");		
		}
		
		if ($nav)
		{
			igk_navtocurrent();		
		}
	}
	public function getConfigPage(){return "database"; }

	public function View()
	{
	if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);			
			return;
		}
		
		$conf_title = array("class"=> "igk-cnf-title");
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();		
		
		
		$div = $c->addDiv();
		igk_html_add_title($div,"title.DataBaseConfigs");
		$div->addHSep();
		igk_add_article($this, "dbdescription", $div, "div", true);
		$div->addHSep();
		
		$h = $c->addDiv();
		$h->setClass("igk-row");
		
		$div = $h->addDiv(array("class"=>"db_info igk-col-lg-3-1"));
		igk_html_add_title($div,"title.DataBaseManager");
		$div->addHSep();
			
		
		$div->addDiv()->Content = "DataBase : MySQL";
		$div->addDiv()->Content = "Available : " . igk_parsebool(defined("IGK_MSQL_DB_Adapter"));
		$div->addDiv()->Content = "MySQL : " . igk_parsebool(IGK_MSQL_DB_AdapterFunc);
		$div->addDiv()->Content = "MySQLi : " . igk_parsebool(IGK_MSQLi_DB_AdapterFunc);
		$div->addHSep();
		igk_html_add_title($div,"title.Config");
		$div->addHSep();
		$div = $div->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("updatedb");
		$frm->addSLabelInput("dbServer",  "text", $this->App->Configs->db_server); $frm->addBr();
		$frm->addSLabelInput("dbUser", "text", $this->App->Configs->db_user); $frm->addBr();
		$frm->addSLabelInput("dbPasswd","password", null);$frm->addBr();		
		$frm->addSLabelInput("dbName", "text", $this->App->Configs->db_name);$frm->addBr();	
		$frm->addBtn("btn_update", R::ngets("btn.update"));
		
		
		
		//init form
		$div = $h->addDiv(array("class"=>"db_info igk-col-lg-3-2"));
		igk_html_add_title($div,"title.Operations");
		$div->addHSep();
		$frm = $div->add("form", 1);		
		IGKHtmlUtils::AddBtnLnk($frm,  R::ngets("btn.phpmyadmin"), $this->getUri("gotophpmyadmin"), array("onclick"=>"javascript: return true;"));		
		IGKHtmlUtils::AddBtnLnk($frm, "btn.initDb", $this->getUri("pinitSDb"));
		IGKHtmlUtils::AddBtnLnk($frm, "btn.backupdatabase", $this->getUri("backupDb"));
		
		
		
		$this->_showDataBaseBackup($h->addDiv()->setClass("db_info igk-col-lg-3-3"));
		
		//get tables
		
		$frm = null;
		$mysql = igk_get_data_adapter($this, true);
		$v_table = null;
		$h = $c->addDiv()->setClass("igk-row");
		if ($mysql)
		{		
			$mysql->connect();
			$div = $h->addDiv(array("class"=>"db_info igk-col-lg-3-1"));
			
			try{	
				//for databases  						
				$r = $mysql->sendQuery("Show DataBases;");
				if ($r){
					$this->__showDataBases($r, $div, $conf_title);									
					$div = $div->addDiv();
					IGKHtmlUtils::AddBtnLnk($div , "btn.initDb", $this->getUri("pinitSDb"));					
					IGKHtmlUtils::AddBtnLnk($div , "btn.backupdatabase", $this->getUri("backupDb"));
				}				
			
				//show selected data tables
				if (!empty($this->m_selectedDb))
				{					
					$this->__showSelectedDbTables($h->addDiv()->setClass("db_info igk-col-lg-3-2"), $conf_title);	
				}
				else{
					$c->addDiv(array("class"=>"db_info"))->Content = R::ngets("msg.db.cantshowDataBaseTableNoSelectedDb");
				}
			}
			catch(Exception $ex)
			{
				//only for user
				$d  = $h->addDiv();
				$d->Content = "l'utilisateur \"".$this->App->Configs->db_user."\" n'est pas autoriser à lister les bases de données du serveur \"".$this->App->Configs->db_server."\"";
				
				
				$d->addBr();
				$mysql->selectdb($this->App->Configs->db_name);
				try{
				$r = $this->_getTables($this->m_searchtable);			
				$d->add("div", $conf_title)->Content= $this->App->Configs->db_name ." Tables";
				$d->addHSep();
				$d->add(new IGKHtmlSearchItem($this->getUri("searchtable"), $this->m_searchtable));
				$d->addHSep();
				$frm = $d->addForm();
				$frm["action"]=$this->getUri("tableview");									
				$v_table = $frm->addTable();
				if ($r && ($r->Rows!=null))
				{
					$v_theader = false;
					foreach($r->Rows as $tab)
					{					
						
						if ($tab)
						{
							if (!$v_theader)
							{
								//write table header
								$v_theader = true;
								$li = $v_table->add("tr");
								IGKHtmlUtils::AddToggleAllCheckboxTh($li);//->Content = IGK_HTML_SPACE;
								$li->add("th", array("class"=>"fitw"))->Content = R::ngets(IGK_FD_NAME);
								$li->add("th")->Content = IGK_HTML_SPACE;
								$li->add("th")->Content = IGK_HTML_SPACE;
							}
							$tr = $v_table->add("tr");				
							foreach($tab as $k=>$v)
							{			
								
								$s = $v;
								$tr->add("td")->addInput("clTableName[]", "checkbox");
								$tr->add("td")->add("li")->addA(igk_js_post_frame($this->getUri("db_viewtableentries_ajx&n=".$s."&from=".$this->App->Configs->db_name)))->Content = $s;													
								$this->__addEditTable($tr,$s, $this->App->Configs->db_name);
								//drop table 
								$tr->add("td")->add("li")->addA(igk_js_post_frame($this->getUri("db_droptable_ajx&n=".$s."&from=".$this->App->Configs->db_name)))->add("img", 
								array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("info.droptable")))->Content = $s;
							}
						}
					}
					IGKHtmlUtils::AddBtnLnk($frm, "btn.dropalltable", igk_js_ctrl_posturi($this, "db_dropalltables_ajx"));					
					}
				}
				catch(Exception $ex){
				}		
				igk_html_toggle_class($v_table, "tr");
			}
			$mysql->close();		
			
			
		}
	}
	private function __addEditTable($tr, $tablename, $selectedDb=null )
	{
		$tr->add("td")->add("li")->add("a", array("href"=>
		igk_js_post_frame($this->getUri("db_viewtableentries_ajx&n=".$tablename.($selectedDb?"&from=".$this->selectedDb:IGK_STR_EMPTY)))))->add("img", 
		array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("edit"),"alt"=>R::ngets("tip.editdatabase")))->Content = $tablename;
	}
	/// $c target node
	private function __showSelectedDbTables($c, $conf_title=null)
	{
		$tab = $this->_getTablesFromSelectedDb($this->m_searchtable);
		
				if (count($tab)>0)
				{
				
					
					igk_html_add_title($c,"title.Tables");
					$c->addHSep();
						$div = $c->addDiv();
					$div["id"] = "igkdb_tablelist";
					$div->add(new IGKHtmlSearchItem($this->getUri("searchtable"), $this->m_searchtable));
					
					$frm = $div->addForm();
					$frm["action"] = $this->getUri("db_dropSelectedTable");
					
					$frm->addDiv()->Content = $tab->RowCount;
					
					$table = $frm->addTable()->setClass("fitw");
					$tr = $table->add("tr");
					
				
					IGKHtmlUtils::AddToggleAllCheckboxTh($tr);		
					$tr->add("th" , array("class"=>"fitw"))->Content = R::ngets("lb.Name");
					$tr->add("th")->Content = IGK_HTML_SPACE;
					$tr->add("th")->Content = IGK_HTML_SPACE;
					foreach($tab->Rows as $k=>$v)
					{
						$s = $v["Table"];
						$tr = $table->add("tr");
						$tr->add("td")->addInput("tname[]","checkbox", $s);
						$tr->add("td")->add("a", array("href"=>
						igk_js_post_frame($this->getUri("db_viewtableentries_ajx&n=".$s."&from=".$this->m_selectedDb))))->Content = $s;
						
						$this->__addEditTable($tr,$s, $this->m_selectedDb);
						
						$tr->add("td")->add("li")->add("a", array("href"=>igk_js_post_frame($this->getUri("db_droptable_ajx&n=".$s))))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("tip.dropdatabase")))->Content = $s;
					}
					$div = $frm->addDiv();
					
					//$div->addInput("btn_delselection", "submit", R::ngets("btn.droptableselection"));						
					IGKHtmlUtils::AddBtnLnk($div, "btn.droptableselection", igk_js_ajx_postform_frame( $this->getUri("db_dropSelectedTable_ajx")) );
					IGKHtmlUtils::AddBtnLnk($div, "btn.dropalltable", igk_js_ctrl_posturi($this,"db_dropalltables_ajx"));					
					$frm->addBr();
					
				igk_html_toggle_class($table, "tr");
					
		}
	}
	private function __showDataBases( $r,$c, $conf_title)
	{
				igk_html_add_title($c,"title.DATABASES");
				$c->addHSep();
				if (!empty($this->m_selectedDb))
				{
					$c->addDiv()->Content= R::ngets("tip.db.selecteddb", $this->m_selectedDb) ;
				}
				else{
					$c->addDiv()->Content = R::ngets("msg.db.cantshowDataBaseTableNoSelectedDb");
				}
				$div = $c->addDiv();
				$frm = $div->add("form", 1);		
				$frm["action"]=$this->getUri("dataview");
				
				$v_table = $frm->addTable();
				$v_theader =false;
				foreach($r->Rows as $tab)
				{
					if (!$v_theader)
					{
							//write table header
							$v_theader = true;
							$li = $v_table->add("tr");	
							IGKHtmlUtils::AddToggleAllCheckboxTh($li);			
							$li->add("th", array("class"=>"fitw"))->Content = R::ngets("clDataBaseName");
							$li->add("th")->Content = IGK_HTML_SPACE;
							$li->add("th")->Content = IGK_HTML_SPACE;
					}
					if ($tab)
					foreach($tab as $k=>$v)
					{
						$tr = $v_table->add("tr");	
						if (strtolower($v) == strtolower($this->App->Configs->db_name))
						{
							if ($this->m_selectedDb==null)
								$this->m_selectedDb = $v;
							$tr["class"] = "+igk-selectdb-row";
						}
						$tr->add("td")->addInput(IGK_STR_EMPTY,"checkbox");
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("selectdb&n=".$v)))->Content = $v;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("editdb&n=".$v)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("edit"),"alt"=>R::ngets("tip.editdatabase")))->Content = $v;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("dropdb&n=".$v)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("tip.dropdatabase")))->Content = $v;
					}					
				}				
				$frm->addBr();
				igk_html_toggle_class($v_table, "tr");
				return $frm;
	}
	
	private function _showDataBaseBackup($frm)
	{	
			$v_dir = igk_io_currentRelativePath(IGK_BACKUP_FOLDER);		
			$bckdiv = $frm->addDiv();
			igk_html_add_title($bckdiv, "title.Backup");
			$frm->addHSep();
			$v_table = $frm->addTable();
			$v_hasfile =false;
			if (is_dir($v_dir))
			{
			$hdir = opendir($v_dir);
			$v_theader = false;//has table header
				while( ($f = readdir($hdir)))
				{
					if (($f==".") ||($f == ".."))
						continue;
						if (!$v_theader){
							$v_theader = true;
							$li = $v_table->add("tr");
							IGKHtmlUtils::AddToggleAllCheckboxTh($li);	
							$li->add("th")->Content = R::ngets(IGK_FD_NAME);
							$li->add("th")->Content = IGK_HTML_SPACE;
							$li->add("th")->Content = IGK_HTML_SPACE;
						}
						
					$li = $v_table->add("tr");
					$li->add("td")->addInput(IGK_STR_EMPTY,"checkbox");
					$li->add("td")->add("a", array("href"=>$this->getUri("downloadbackupfile&file=".$f)))->Content = $f;
					IGKHtmlUtils::AddImgLnk($li->add("td", array( "class"=>"igk-table-img-action_16x16")), $this->getUri("db_dbRestore&file=".$f), "db_restore_16x16");
					IGKHtmlUtils::AddImgLnk($li->add("td", array( "class"=>"igk-table-img-action_16x16")),$this->getUri("dropBackup&file=".$f), "drop","16px","16px", "lb.dropbackup");
					$v_hasfile = true;
					//$li->add("td")->add("a", array("href"=>$this->getUri("dropBackup&file=".$f)))->add("img"=>Content = $f;
				}
				closedir($hdir);
				
				if ($v_hasfile){			
				IGKHtmlUtils::AddBtnLnk($frm, "btn.ClearBackup", $this->getUri("ClearBackup"));
				}
				else{
					$frm->addDiv()->Content = R::ngets("Msg.NoBackgup");
				}
			}
			
			igk_html_toggle_class($v_table, "tr");
	}
	public function editdb()
	{
		$this->View();
	}
	public function searchtable(){
		$q = igk_getr("q");		
		$this->m_searchtable = $q;
		$this->View();
	}
	
	private function _getTablesFromSelectedDb( $searchkey = null)
	{
		if (empty($this->m_selectedDb))
			return;
			
		$r = null;
		$mysql = igk_get_data_adapter($this, true);
		if ($mysql)
		{
			$mysql->connect($this->m_selectedDb);		
			$r = $mysql->sendQuery("Show Tables;");						
			$mysql->close();
			if ($r){
				$tab = $r->CreateEmptyResult($r);		
			$n = $r->Columns[0]->name;			
			if ($searchkey !=null)
			{			
				$q = strtolower($searchkey);
				foreach($r->Rows as $t)
				{
					if (strstr(strtolower($t->$n), $q))
					{
						$tab->addRow(array("Table"=>$t->$n));	
					}
				 }
				return $tab;
			}
			else{
				foreach($r->Rows as $t)
				{	
					$tab->addRow(array("Table"=>$t->$n));						
				}
				return $tab;			
			}
			}
		}
		return null;
	}
	
	private function _getTables($searchkey = null)
	{
		$r = null;
		
		$mysql = igk_get_data_adapter($this, true);
		if ($mysql)
		{
			
			$mysql->connect($this->App->Configs->db_name);
			$r = $mysql->sendQuery("Show Tables;");
			$tab = $r->CreateEmptyResult($r);		
			$mysql->close();

			$n = $r->Columns[0]->name;			
			if ($searchkey !=null)
			{			
				$q = strtolower($searchkey);
				foreach($r->Rows as $t)
				{
					if (strstr(strtolower($t->$n), $q))
					{
						$tab->addRow(array("Table"=>$t->$n));	
					}
				 }
				return $tab;
			}
			else{
				foreach($r->Rows as $t)
				{	
					$tab->addRow(array("Table"=>$t->$n));						
				}
				return $tab;			
			}
		}
		return null;
	}
	
	public function backupDb(){
			
		$mysql = igk_get_data_adapter($this, true);
		if (!$mysql)
		{ 
			igk_notifyctrl()->addError("can't get ".IGK_MYSQL_DATAADAPTER ." data adapter");
			return;
		}
		$adapter = igk_get_data_adapter("CSV");
		if (!$adapter)
		{ 
			igk_notifyctrl()->addError("can't get csv adapter");
			return;
		}
		
		$v_date = igk_date_now("Ymd_his"); 
		$v_file = igk_io_basePath(IGK_BACKUP_FOLDER."/backup_".$v_date.".cvs");
		$out = IGK_STR_EMPTY;
	
		$db_table = $this->_getTables(null);
		$mysql->connect();
		if ($db_table){			
			foreach($db_table->Rows as $t=>$v)
			{
				
				$v_tbname = $v["Table"];
				
				$r = $mysql->sendQuery("SELECT * FROM `".$v_tbname."`;");
				if ($r){
					$out .= $v_tbname .IGK_LF;
					$v_sep = false;
					$out .= $adapter->toCSVLineEntry($r->Columns, "name").IGK_LF;
					if ($r->Rows){
						
						foreach($r->Rows as $e)
						{
							$out .=$adapter->toCSVLineEntry($e).IGK_LF;													
						}
					}
					else 
						igk_debug_wln("notice: no data row for [".$v_tbname."]");
					$out .= IGK_LF;
				}
				else{
					igk_debug_wln("error: mysql adapter failed");
					igk_debug_wln($r);
					igk_notifyctrl()->addMsgr("Error.Config");
				}
			}
		}
		else{
			igk_debug_wln("error: no table");							
			igk_notifyctrl()->addMsgr("Msg.NoTable");
		}
		
		IGKIO::CreateDir(dirname($v_file));
		if (strlen($out) > 100000)
		{
			//zip file
			igk_zip_content($v_file.".zip", basename($v_file),  $out);
		}
		else{
			igk_io_save_file_as_utf8($v_file, $out, true,0666);		
		}
		$this->View();
		igk_notifyctrl()->addMsgr("Msg.DataBaseSaved");
		igk_navtocurrent();
	}
	private function __restoredb($table, $header, $definition)
	{
		$adapt =igk_get_data_adapter(IGK_MYSQL_DATAADAPTER);
		if ($adapt!=null)
		{
			$dbname = $this->App->Configs->db_name;
			$adapt->connect($dbname);
			$e = $adapt->select($table);			
			$tentries = array();
			if ($e){
			foreach($definition as $row){
				$tab = array();
				$i = 0;
				foreach($e->Columns as $k=>$v)
				{
					if ($i < $e->ColumnCount)
					{
						$tab[igk_getv($v,"name")] = igk_getv($row, $i);
						$i++;
					}
					else
						break;
				}
				$tentries[] = $tab;
				$q = $adapt->GetInsertQuery($table, $tab);
				
				if ($adapt->sendQuery($q, false)==null)
				{
					igk_notifyctrl()->addError("Error Append in query ".$q);
				}				
				
			}
			}
			$adapt->close();
		}
	}
	public function db_dbRestore()
	{
		$v_f = igk_getr("file");
		if (igk_qr_confirm() && $this->App->ConfigMode)
		{
			//igk_notifyctrl()->addMsg("la restauration n'est pas implementer");
			$v_file = igk_io_basePath(IGK_BACKUP_FOLDER."/".$v_f);
			if (!file_exists($v_file))
				igk_notifyctrl()->addErrorr("Msg.noDataToRestore");
			else{					
			
			$e = IGKCSVDataAdapter::LoadData($v_file);
			
			$table = null;
			$definition = null;
			$header = null;
				foreach($e as $k=>$v)
				{
					if (igk_count($v) == 1)
					{
						if ( ($table!=null) && ($definition!=null))
						{
							$this->__restoredb($table, $header, $definition);
						}
						$table = $v[0];
						$definition = array();
						$header = null;
					}
					else {
						if ($header ==null)
							$header = igk_array_tokeys($v);
						else
							$definition[] = $v;
					}
				}
				
				if ( ($table!=null) && ($definition!=null))
				{
					$this->__restoredb($table, $header, $definition);
				}
			}
			$this->View();
		}
		else 
		{
			$frame = igk_frame_add_confirm($this, "confirm_restoration", $this->getUri("db_dbRestore"));
			$frame->Form->Div->Content = R::ngets(IGK_MSG_RESTOREBACKUPFILE_QUESTION, $v_f);
			$frame->Form->addInput("file","hidden", $v_f);
		}
		
	}
	
	public function downloadbackupfile(){
		$v_file = igk_getr("file");
		$v_f = igk_io_currentRelativePath(IGK_BACKUP_FOLDER."/".$v_file);
		if (file_exists($v_f)){
			igk_download_file(basename($v_f), $v_f);
		}
		else{
			igk_notifyctrl()->addError("file not present");
		}
	}
	
	public function dropBackup(){
	
		$v_file = igk_getr("file");
		if (igk_qr_confirm()){
			$v_f = igk_io_currentRelativePath(IGK_BACKUP_FOLDER."/".$v_file);
			unlink($v_f);
			$this->View();
			igk_navtocurrent();
		}
		else{
				$frame = igk_frame_add_confirm($this, "confirm_Clear_backup_file", $this->getUri("dropBackup"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEABACKUPFILE_QUESTION, $v_file);
				$frame->Form->addInput("file","hidden", $v_file);
		}
	}
	
	public function ClearBackup(){
		if (igk_qr_confirm()){
			$v_dir = igk_io_currentRelativePath(IGK_BACKUP_FOLDER);
			IGKIO::RmDir($v_dir);
			$this->View();
			igk_navtocurrent();
		}
		else{
				$frame = igk_frame_add_confirm($this, "confirm_Clear_backup_file",$this->getUri("ClearBackup"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEALLDATABASEBACKUP_QUESTION);
		}
	}
	
	public function selectdb(){
		$this->m_selectedDb = igk_getr("n");
		$this->View();
		igk_navtocurrent("/#igkdb_tablelist");
	}

	public function gotophpmyadmin(){
	if ($this->m_myadminview )
	{
		$h = $this->App->Configs->db_server;
		
		switch(strtolower($h))
		{
			case "127.0.0.1":
			case "localhost":
				if ($_SERVER["SERVER_ADDR"] != "::1")
					$h = $_SERVER["SERVER_ADDR"];
				break;
		}
		igk_html_rm($this->m_myadminview);
		unset($this->m_myadminview);
		$this->m_myadminview = null;
		header("Location: http://".$h."/phpmyadmin");
		igk_exit();
	}
		else{
			$this->m_myadminview = $this->ConfigNode->add("script");
			$uri = $this->getUri("gotophpmyadmin");
			$this->m_myadminview->Content = <<<EOFF
var w = window.open('$uri', 'phpmyadmin');
w.opener.focus();
EOFF;
			
		igk_navtocurrent();
		}
	}
	
	public function updatedb(){
	
		$server= igk_getr("dbServer");
		$user= igk_getr("dbUser");
		$pwd = igk_getr("dbPasswd");
		$dbname = igk_getr("dbName");
		
		$this->App->Configs->db_server = $server;
		$this->App->Configs->db_user = $user;
		$this->App->Configs->db_pwd = $pwd;
		$this->App->Configs->db_name = $dbname;
		
		igk_save_config();
		igk_resetr();
		$this->View();
		igk_navtocurrent();
		igk_exit();
	}
	
	public function dropdb(){
		$n = igk_getr("n");
		if ($n != null)
		{
				$mysql = igk_get_data_adapter($this, true);
				$mysql->connect();
				$r = $mysql->sendQuery("Drop DataBase `".$n."`;");
				$mysql->close();				
		}
		$this->View();
		igk_navtocurrent();		
		igk_exit();
	}
	
	public function db_droptable($dbname=null, $table=null){//drop a data base table
	
		$n = igk_getr("n", $table);
		if (igk_qr_confirm()){
		$mysql = igk_get_data_adapter($this, true);
		if (!$mysql )
			return;
		$dbname = igk_getr("from", $dbname);		
		
		$mysql->connect($dbname);
		$r = $mysql->sendQuery("Drop Table `".$n."`;");
		$mysql->close();				
		$this->View();
		igk_navtocurrent("#igkdb_tablelist");
		igk_exit();
		}
		else{
			$frame = igk_frame_add_confirm($this, "confirm_drop_table", $this->getUri("db_droptable"));
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETESINGLETABLE_QUESTION, $n);
			$frame->Form->addInput("n","hidden",$n);
			return $frame;
		}
	}
	public function db_droptable_ajx()
	{
		$frame = $this->db_droptable();
		if ($frame!=null){
			$frame->RenderAJX();
		}
		
	}
	public function db_viewtableentries_ajx()
	{
		$frame = $this->db_viewtableentries(null,null,false);
		$frame->RenderAJX();
	}
	//view table entries
	public function db_viewtableentries($dbname=null, $table=null, $navigate=true)
	{
		$tb = $table?$table:igk_getr("n");
		$db = $dbname==null? igk_getr("from"):$dbname;
		$mysql = igk_get_data_adapter($this, true);
		if (!$mysql )
			return;
		$mysql->connect($db);
		$r = $mysql->selectAll($tb);		
		$frame = igk_add_new_frame($this, "db_view_entries", "#igkdb_tablelist");
		$frame->Title = R::ngets("title.db_viewtableentries_1", $tb);
		$frame->ClearChilds();
		$div = $frame->Content->addDiv();
		$div["class"]="igk-db-tableentries";
		$title = $div->addDiv();
		$div->addHSep();
		$title["style"]="height:32px;";
		$content = $div->addDiv();
		$content["style"]="overflow:auto;";
		$title->Content = R::ngets("title.TableInfo", $db.".".$tb);
		
		$table = $content->addTable();
		$table["class"]="fitw";
		$table["style"]= "border:1px solid black";
		$tr = $table->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$pkey  = null;
		$pkname = null;
		
		
		foreach($r->Columns as $k)
		{
			$td = $tr->add("th");	
			$td->Content = $k->name;
			if (($pkey == null) && $k->primary_key==1){
				$pkey = $k->name;
			}
		}
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($r->Rows as $k)
		{
			$tr = $table->add("tr");	
			$tr->add("td")->Content = IGK_HTML_SPACE;
			foreach($k as $e=>$v)
			{
				$tr->add("td")->Content = ($e == IGK_FD_PASSWORD) ? IGK_HTML_SPACE : $v;
			}
			
			IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("db_edit_entry_ajx&n=".$k->$pkey."&s=".$pkey)), "edit");
			IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("db_drop_entry&n=".$k->$pkey."&s=".$pkey), "drop");
		}		
		$div->addHSep();
		
		$this->setParam("db:dbname", $db);
		$this->setParam("db:table", $tb);
		$this->setParam("db:r", $r);
		$this->setParam("db:columns", $r->Columns);
		//options
		$cdiv = $div->addDiv();
		IGKHtmlUtils::addImgLnk($cdiv, igk_js_post_frame($this->getUri("db_insert_db_entry_frame_ajx")), "add");
		IGKHtmlUtils::addImgLnk($cdiv, $this->getUri("db_Clearall_db_entry"), "drop");
		
		IGKHtmlUtils::AddBtnLnk($div, R::ngets("btn.close"), $frame->CloseUri);
		IGKHtmlUtils::ToggleTableClassColor($table, "tr");		
		
		$this->View();		
		$mysql->Close();
		if ($navigate){
			igk_navtocurrent();
			igk_exit();
		}
		return $frame;
	}
	
	public function db_update_entry()
	{
		if(!$this->ConfigCtrl->IsConnected)
			return;
			
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		$n = $this->getParam("update:n");
		$s = $this->getParam("update:s");
			$adapter = igk_get_data_adapter($this, true);
		if ($adapter )
		{
			$o = igk_get_robj();
			$adapter->connect($dbname);
			$q = $adapter->GetUpdateQuery($table, $o, " `".mysql_real_escape_string ($s)."`='". mysql_real_escape_string ($n)."'",
				igk_db_getdatatableinfokey($table)
			);
		
			$adapter->sendQuery($q);
			$adapter->close();
		}
		igk_frame_close("edit_entry_frame");	
		$this->db_viewtableentries($dbname, $table);
			
	}
	
	public function db_edit_entry_ajx()
	{
		
		$n = igk_getr("n");
		$s = igk_getr("s");
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		
		$frame = igk_add_new_frame($this,"edit_entry_frame");
		$frame->Title  = R::ngets("title.db_editentry");
		$frame->Content->Clear();
		
		
		
		$frm = $frame->Content->addForm();
		$frm["action"] = $this->getUri("db_update_entry");; 
		$this->setParam("update:n",$n);
		$this->setParam("update:s",$s);
		
		$mysql = igk_get_data_adapter($this, true);
		if ($mysql )
		{
			$mysql->connect($dbname);
			$q = "SELECT * FROM `".$table."` WHERE `".mysql_real_escape_string ($s)."`='". mysql_real_escape_string($n)."'";
			
			$e = $mysql->sendQuery($q);			
			if ($e->RowCount == 1)
			{
				$ul = $frm->add("ul");
				
				$l = $e->getRowAtIndex(0);
				foreach($e->Columns as $k)
				{
					$li = $ul->add("li");	
					$v = $k->name;
					$pwd = $k->name == IGK_FD_PASSWORD;
					switch(strtolower($k->type))
					{
						case "text":
							break;
						case "string":
							$li->addSLabelInput($k->name, $pwd ? "password" : "text", $pwd? "" : $l->$v);
							break;
						case "blob":
							$t = $li->addSLabelTextarea($k->name, "lb.".$k->name, array("class"=>"-cltextarea"));
							$t->textarea->Content =$pwd? "" : $l->$v;
							break;
						default:
							$li->addSLabelInput($k->name, "text",  $l->$v);
							break;
					}								
				}
			}			
			$mysql->close();
		}
		$frm->addHSep();
		$frm->addInput("btn_update", "submit", R::ngets("btn.update"));
		
		igk_wl($frame->Render());
	}
	public function db_dropSelectedTable_ajx($dbname=null){	
		//grand access if connected
		if(!$this->ConfigCtrl->IsConnected)
			return;		
		$db = $dbname? $dbname: $this->App->Configs->db_name;		
		if (igk_qr_confirm())
		{
				if ($db == null)
				{
					igk_wln("no db name selected");
					return;
				}
				$h = null;
				
				$mysql = igk_get_data_adapter($this, true);
				if (!$mysql )
					return;
				$query = $this->getParam("db:dropSelectedTable");
				$h = igk_getv($query, "tname");				
				$mysql->connect($db);
				if ($h){
					foreach($h as $k=>$v)
					{
						try{
							$r = $mysql->sendQuery("Drop Table `".$v."`;");						
						}
						catch(Exception $ex)
						{
							igk_wln(" error ".$ex);
						}
					}
				}
				$mysql->close();				
				$this->setParam("frame:tname", null);				
				$this->View();	
				$this->setParam("db:dropSelectedTable",null);	
				igk_notifyctrl()->addMsgr("msg.databaseupdated");				
				igk_navtocurrent();
		}
		else{
				$tname = igk_getv($_REQUEST, "tname");
				if ($tname && (count($tname)>0))
				{
				$frame = igk_frame_add_confirm($this, "confirm_Clear_backup_file", $this->getUri("db_dropSelectedTable_ajx"));
				$frame->Form->Div->Content = R::ngets("q.deleteallselecteddbtable");					
				//$frame->Form->Div->addDiv()->addPrev($_REQUEST);
				$frame->Form->addInput("dbname", "hidden", $dbname);
				$this->setParam("db:dropSelectedTable", $_REQUEST);	
				$frame->RenderAJX();
				}
				
		}
	}
	
	public function db_dropalltables_ajx($dbname=null){//drop all tables in this databases
		if (igk_qr_confirm())
		{
			$r = $this->_getTables($this->m_searchtable);
			$db = $dbname? $dbname: $this->App->Configs->db_name;
			if ($r->Rows){
				$mysql = igk_get_data_adapter($this, true);
				if ($mysql)
				{
					$mysql->connect($db);
					
					foreach($r->Rows as $t)
					{
						$s = $mysql->sendQuery("Drop Tables `".$t["Table"]."`;");
					}
					$mysql->close();
				}
			}
			$this->View();	
			igk_navtocurrent();
		}
		else{
			$frame = igk_frame_add_confirm($this, "drop_all_table_confirm_frame",$this->getUri("db_dropalltables_ajx"));
			$frame->Form->Div->Content = R::ngets(IGK_DELETEALLTABLE_QUESTION);
			$frame->RenderAJX();
		}
	}

	public function db_drop_entry()
	{
		$n = igk_getr("n");
		$s = igk_getr("s");
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		
			$db = igk_get_data_adapter($this, true);
			if ($db)
			{
			$db->connect();
			$db->selectdb($dbname);
			//delete
			$db->delete($table, array($s=>$n));			
			$db->close();
			}	
		
		$this->db_viewtableentries($dbname, $table);
		
	}
	public function db_insert_db_entry()
	{
		
		$r = $this->getParam("db:r");
		$dbname = $this->getParam("db:dbname");
		$n = $this->getParam("db:table");
		
		$b = igk_get_robj();		
		
		$db = igk_get_data_adapter($this, true);
		if ($db){
			$db->connect();
			$db->selectdb($dbname);
			//insert db entry
			$t = igk_db_getdatatableinfokey($n);
			//igk_wln($t);
			$db->insert($n, (array)$b, $t);
			$db->close();
		}	
		$this->db_viewtableentries($dbname, $n);
		igk_exit();
	}
	public function db_insert_db_entry_frame_ajx(){
		$frame = igk_add_new_frame($this, "db_insert_entry_frame");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.db.insertnewentry");								
		$d = $frame->Content;
		$frm = $d->addForm();		
		$frm["action"]= $this->getUri("db_insert_db_entry");
		//$frm["igk-js-ajx-form"] = "1";
		$ul  = $frm->add("ul");
		$c = $this->getParam("db:columns");
		if ($c){
			foreach($c as $k)
			{
				$li = $ul->add("li");	
				switch(strtolower($k->type))
				{
					
					case "blob":
						$li->addSLabelTextarea($k->name, "lb.".$k->name, array("class"=>"-cltextarea"));
						break;
					case "string":
					case "text":
					default:
						$li->addSLabelInput($k->name, "text", $k->def);
						break;
				}				
			}
		
		}
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.add"));
		//IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.close"), $frame->CloseUri);
		$frame->RenderAJX();
	}
	public function db_Clearall_db_entry()
	{
		$r = $this->getParam("db:r");
		$dbname = $this->getParam("db:dbname");
		$tbname= $this->getParam("db:table");
		//$n = igk_getr("confirm");
		if (igk_qr_confirm())
		{
			$db = igk_get_data_adapter($this, true);
			if ($db){
			$db->connect();
			$db->selectdb($dbname);
			//delete all entries
			$db->deleteAll($tbname);
			$db->close();
			}	
			$this->db_viewtableentries($dbname, $tbname);
		}
		else{			
			$frame = igk_frame_add_confirm($this, "frame_Clearall",$this->getUri("db_Clearall_db_entry"));							
			$frame->Form->Div->Content = R::ngets("Q.WILLYOUDROPTHECONTENTOFTHISTABLE", $tbname);				
		}		
		
	}


	
}
//-----------------------------------------------------------------------------
///represent a language language controller
//-----------------------------------------------------------------------------

 
 
final class IGKLangCtrl extends IGKConfigCtrlBase
{
	private $m_searchkey;
	private $m_changeState;
	private $m_search_new_key;
	const DEFAULT_LANG_FOLDER = IGK_DEFAULT_LANG_FOLDER;
	
	public function getName(){return IGK_LANG_CTRL;}
	
	public function IsFunctionExposed($funcName)
	{
		switch($funcName)
		{
			case "getlangkeys":
			case "mod_key":
				return true;
		}
		return parent::IsFunctionExposed($funcName);
	}
	//publid function to get current languages file
	public function getlangkeys(){
	
		$format = igk_getr("format", "xml");
		$v_node =  IGKHtmlItem::CreateWebNode("languages");
		switch($format)
		{
			case "xml":
				header("Content-Type: application/xml");
				break;
		}
		$v_node["name"] = R::GetCurrentLang();
		$tab = R::GetLangInfo();
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		$c = 0;
		//return;
		foreach($ktab as $k)
		{
			$v = $tab[$k];
		
			$tr = $v_node->add("item");
			$tr["name"] = igk_parsexmlvalue($k);
			$tr["value"] = igk_parsexmlvalue($v);
		}
		igk_wl($v_node->Render());
		igk_exit();
	
	}
	
	
	public function __construct(){
		parent::__construct();
	}
	protected function InitComplete()
	{
		parent::InitComplete();
		R::getInstance()->PageLangChangedEvent->add($this, "View");
		R::getInstance()->KeysAdded->add($this, "keyAdded");	
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onLangChanged");		
		$this->App->Doc->lang = R::GetCurrentLang();
	}
	public function keyAdded($obj, $key)
	{	
		$v = $this->getParam("lang:onview");
		if (!$v){
			if (!empty($key))
			{
				$this->View();
			}
			else 
				throw new Exception("try to add empty key");
		}
	}
	public function onLangChanged($ctrl)
	{		
		$r = R::getInstance();
		$c =  $r->langChangedConf;
		if ($ctrl->isChanged("LangChanged", $c))
		{	
			$this->reloadlang();
		}
	}
	public function add_key()
	{
		igk_wln("key added");
		$n = igk_getr("clname");
		$v = igk_getr("clvalue");
		if (!empty($n))
		{
			R::AddLang($n, $v);
			R::SaveLang();
		}
		igk_navtocurrent();
	}
	public function add_key_frame_ajx()
	{
		$frame = igk_add_new_frame($this, "add_key_frame");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.editLangkeyframe");								
		$d = $frame->Content;
		$frm = $d->addForm();		
		$frm["action"]= $this->getUri("add_key");
		$ul  = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clname");
		$ul->add("li")->addSLabelInput("clvalue");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.add"));
		
		$frame->RenderAJX();
	}
	public function reloadlang()
	{	
		R::LoadLang();
		$this->View();
	}
	public function get_new_keys(){
		$this->m_search_new_key = !($this->m_search_new_key);
		$this->View();
		igk_navtocurrent();
	}
	private function loadLangOptions($c)
	{	 
		IGKHtmlUtils::AddBtnLnk($c, R::ngets("btn.add"),"#", array("onclick"=>igk_js_post_frame($this->getUri("add_key_frame_ajx")). " return false; "));		
		IGKHtmlUtils::AddBtnLnk($c, R::ngets("btn.searchnewkey"),$this->getUri("get_new_keys"));		
		IGKHtmlUtils::AddBtnLnk($c, R::ngets("btn.reload"), $this->getUri("reloadlang"));
		//IGKHtmlUtils::AddBtnLnk($c, R::ngets("btn.restoredefault"), igk_js_post_frame($this->getUri("lang_load_default")));
		//IGKHtmlUtils::AddBtnLnk($c, R::ngets("btn.saveAsdefault"), $this->getUri("lang_save_as_default"));
	}
	public function getIsVisible(){
		//igk_is_conf_connected() || 
		return parent::getIsVisible();
	}
	public function View()
	{
		//igk_wln("is visible ".parent::getIsVisible()) ;
		
		$uri = $this->getUri("");
		$k = strtolower($this->Name.":script");
		$this->App->Doc->Body->addScriptContent($k,  "igk.ctrl.regCtrl('{$this->Name}', '{$uri}'); ");
	
		$this->setParam("lang:onview",true);
		$this->App->Doc->lang = R::GetCurrentLang();
		$c = $this->TargetNode;
		$c->ClearChilds();
		if ( !$this->getIsVisible())
		{
			igk_html_rm($c);
			return;
		}	
		igk_html_add($c, $this->ConfigNode);
		$c->Index = 100;		
		$div = $c->addDiv();		
		igk_html_add_title($div, "title.language.ctrlconfig");
		$div->addHSep();
		igk_add_article($this, "language.description",$div->addDiv());
		
		$div = $c->addDiv();
		$div["style"]="margin:16px 0px 16px 0px;";
		$div->addHSep();
		
		$frm = $div->addForm();
		$languages = $frm->add("ul");
		$languages["class"] = $languages["id"] = "igk-language-list";
		
		foreach(igk_getctrl(IGK_LANGUAGE_CTRL)->Languages as $k=>$v)
		{
			$languages->add("li")->add("a", array("href"=>"?l=".$v))->add("img", array(
			"style"=>"border:1px solib #a1a1a1;",
			"src"=>R::GetImgUri("flag_$v")));
		}
		//add new lang button 
		IGKHtmlUtils::AddImgLnk($frm, igk_js_post_frame($this->getUri("lang_add_new_frame_ajx")), "add");
		$div->addHSep();
		
		//search key button
		$c->add(new IGKHtmlSearchItem($this->getUri("searchkey"), $this->m_searchkey));
		$c->addHSep();
		$this->loadLangOptions($c);
		$c->addBr();
		
		
		$frm = $c->addForm();		
		igk_notify_sethost($frm->addDiv());
		$frm["action"]= $this->getUri("update_language");		
		$frm["method"]="POST";
		$frm["id"]="frm_langkeys_view";
		
		$d  = $frm->addDiv();	
		igk_add_loading_frame($d->addDiv()->setClass("dispb fitw alignc"));
		$d->addScript()->Content = 
		"(function(q){\$ns_igk.ready(function(){window.igk.ajx.apost('".$this->getUri("lang_getKeys_ajx")."',null,function(xhr){ if (this.isReady()){ this.setResponseTo(q); }}, true);});} )(igk.getParentScript());";		
		$this->setParam("lang:gui_langview", $frm);
		
		$c->addHSep();
		$this->loadLangOptions($c);
		
		$this->setParam("lang:onview",null);
	}
	public function lang_add_new_frame_ajx()
	{
		$frame = igk_add_new_frame($this, "add_lang_frame");
		$frame->Title = R::ngets("title.AddNewLang");		
		$frame->ClearChilds();				
		$frm = $frame->Content->addForm();
		$frm["action"]= $this->getUri("lang_add_lang"); 
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clKey");
		$ul->add("li")->addSLabelInput("clFile", "file");
		$frm->addHSep();
		$frm->addInput("btn_submit","submit" ,R::ngets("btn.add"));
		igk_wl($frame->Render());
		return $frame;
	}
	public function lang_add_lang()
	{
		$f = igk_getv($_FILES, "clFile");
		$c = igk_getr("clKey");
		igk_getctrl(IGK_LANGUAGE_CTRL)->addLang($c);
		
		if ($f["size"]> 0)
		{
			loadtempfile($f["tmp_name"], $f["name"], "flag_".c, "Flags");
		}
		$this->View();		
		igk_navtocurrent();
	}
	public function lang_getKeys_ajx()
	{		
		$frm = $this->getParam("lang:gui_langview");
		if ($frm == null)
			return;
		
		$frm->ClearChilds();
		$c = 0;
		if ($this->m_search_new_key)
		{
			$frm->addDiv()->Content = R::ngets("msg.yourfindkeykey");
		}
		
		
		$table = $frm->addTable()->setClass("listlangentry");		
		
		$tr = $table->add("tr");
		$tr["class"]="tbh";
	 IGKHtmlUtils::AddToggleAllCheckboxTh($tr);
	 
	 
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>"fitw"))->Content = R::ngets("Value");
		$tr->add("th")->Content = "&nbsp;";
		$i = 0;
		
		//get key and keys sort
		$tab = R::GetLangInfo();
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		
		//foreatch keys as keys tab
		$v_count = 0;
		$pages_filter = array();
		$pages_filter[] = array();
		$page_c = 0;
		foreach($ktab as $k)
		{
			$v = $tab[$k];
			if ($this->m_search_new_key)
			{
				if (empty($k) || (($this->m_searchkey) && !strstr(strtolower($k),strtolower($this->m_searchkey))) || 
				( $v != $k))
					continue;				
			}
			else{
				if (empty($k) || (($this->m_searchkey) && !strstr($k,strtolower($this->m_searchkey))) )
					continue;
			}
			$pages_filter[$page_c][$k] = $v;
		
				
			$c++;
			$v_count++;
			if ($v_count >= 50)
			{
				$v_count = 0;
				$page_c++;
				$pages_filter[] = array();
			}
		}
		
		$cpage = igk_getr("page",0);
		foreach($pages_filter[$cpage] as $k=>$v)
		{
			$tr = $table->add("tr");			
			$tr->add("td")->addInput("check_values_".$c, "checkbox");
			$tr->add("td")->add("label",array("for"=>"e_values".$c, "class"=>"-cllabel"))->Content = $k;
			$td = $tr->add("td");
			$td->add("input", array("type"=>"text", "class"=>"cltext" , "value"=>$v,"name"=>"e_values[]", "id"=>"e_values".$c ));
			
			$tr->add("input", array("type"=>"hidden","value"=>$k,"name"=>"e_keys[]", "id"=>"e_keys[]" ));
			
			$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("rmkey&n=".base64_encode($k))))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("info.droptable")))->Content = $v;
		
		}
		$p = igk_count($pages_filter);
		if ($p > 1){
		$page = $frm->addDiv()
		->setClass("alignt alignc")		
		->addPagination();
		$page->CurrentPage = $cpage;
		$page->MaxPage = $p;
		$page->PrevUri = "javascript: ns_igk.ajx.post('".$this->getUri("lang_getKeys_ajx&page=".($cpage-1))."', null, ns_igk.ajx.getResponseNodeFunction(this, 'form') ); return false;";
		$page->NextUri = "javascript: ns_igk.ajx.post('".$this->getUri("lang_getKeys_ajx&page=".($cpage+1))."', null, ns_igk.ajx.getResponseNodeFunction(this, 'form') ); return false;";
		
		for($i = 0; $i < igk_count($pages_filter); $i++)
		{
			$p = $page->addPage($i+1, "javascript: ns_igk.ajx.post('".$this->getUri("lang_getKeys_ajx&page=".$i)."', null, ns_igk.ajx.getResponseNodeFunction(this, 'form') ); return false;");
			if ($i == $cpage)
			{
				$p["class"] = "igk-active";
			}
		}
			$page->flush();
		}
		
		
		$frm->addInput("btn_update","submit",  R::ngets("btn.update"));
		
		IGKHtmlUtils::ToggleTableClassColor($table, "tr",1);
		IGKHtmlUtils::AddBtnLnk($frm ,R::ngets("btn.rmAll"), $this->getUri("Clearall"), array(
			"onclick"=>"javascript: var frm =igk.getParentByTagName(this,'form');    if ( frm && window.confirm('Etes vous sure de vouloir tout supprimer?')) {frm.confirm.value = 1; frm.action =this.href ; frm.submit(); }return false;"
		) );
		
		$frm->addInput("btn_rmsel", "submit",R::ngets("btn.rmSelection"), array("onclick"=>"this.form.action ='".$this->getUri("removeselectedmenu")."'; "));				
		
		$frm->addInput("max_values", "hidden",$c);	
		$frm->addInput("confirm", "hidden",0);			
		$frm->RenderAJX();
		igk_exit();
	}
	///remove selected items
	public function removeselectedmenu()
	{
		$m = igk_getr("max_values", 0);
		$keys = igk_getr("e_keys", null) ;
		$mc = 0;
		//get the reference of the tab control
		$tab = & R::getInstance()->langRes;
		
		$before = count($tab);
		for($i = 0; $i< $m; $i++)
		{
			$t = igk_getr("check_values_".$i);
			if ($t)
			{
					$n =$keys[$i];
					//igk_wln("echo : ".$n . " : ". $tab[$n]);
					if (R::RemoveKey($n))
					{
						$mc++;
					}
			}
		}
		$after = count($tab);
		
		if (R::SaveLang())
		{
			igk_notifyctrl()->addMsg("delete selected value ".$mc .":".$before. " / ".$after ."/".count( R::getInstance()->langRes));				
		}
		else{
			igk_notifyctrl()->addErrorr("E.LangNotSave");
		}
		igk_navtocurrent();
		
	}
	// public function lang_load_default()
	// {
		// $v = R::getInstance();
		// if (igk_qr_confirm())
		// {
		// $file = $v->GetCurrentLangPath();
		// if (file_exists($file))
		// {
			
			// copy($file, $v->GetCurrentLangPath());
			// $v->LoadLang();
			// $this->View();
		// }
		// if (!igk_sys_isAJX())
		// igk_navtocurrent();
		// }
		// else{
			 // $frame = igk_frame_add_confirm($this, "frame_restore_defaultlang",$this->getUri("lang_load_default&ajx=1"));							
		
			// $frame->Form->Div->Content = R::ngets("Q.AREUSHURETORESTOREDEFAULTLANG");				
			// if (igk_sys_isAJX())
			// {
				// igk_wl($frame->Render());
				// igk_exit();
			// }
		// }
	// }
	// public function lang_save_as_default()
	// {
		// $file = $this->get_savefile();
		
		// $v = R::getInstance();		
		// $out = "<?php \n";	
		// $tab = $v->langRes;
		// $ktab = array_keys($tab);
		// igk_usort($ktab, "igk_key_sort");
		// foreach($ktab as $k)
		// {
			// $v = $tab[$k];
			// $v = str_replace("\'", "'", str_replace("\"", "&quot;",$v));
			// if (!empty($k))
			// {
				// $out .= "R::AddLang(\"$k\", \"".$v."\"); \n"; 			
			// }
		// }
		// $out .= "?
		// IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);	
		// igk_notifyctrl()->addMsgr("MSG.SAVELANGFILEOK", basename($file));
		// $this->View();
		// igk_navtocurrent();
	// }
	
	public function Clearall(){
		if (igk_qr_confirm()){
			R::ClearLang();
			$this->View();
		}
		else{
			$frame = igk_frame_add_confirm($this, "frame_Clearall",$this->getUri("Clearall"));							
			$frame->Form->Div->Content = R::ngets("Q.AREUSHURETODELETEALL");							
		}
	}
	
	public function update_language(){
	
		if (igk_getr("btn_rmsel")!=null) { $this->removeselectedmenu(); return;}
	
		$td = igk_getr("e_keys", null);
		$tv = igk_getr("e_values", null);
		if(is_array($td))
		{
			foreach($td as $k=>$v)
			{
				R::AddLang($v, $tv[$k]);
			}
		}
		if (R::SaveLang())
		{
			igk_notifyctrl()->addMsgr("msg.languageupdated");
		}
		else{
			igk_notifyctrl()->addErrorr("E.LanguageNotupdated");
		}
		$this->View();
		igk_navtocurrent();	
	}
	
	public function searchkey()
	{
		$this->m_searchkey = igk_getr("q");
		$this->View();
	}
	
	public function searchkey_ajx(){
		$this->searchkey();
		igk_wl( $this->TargetNode->Render());
	}
	
	public function getConfigPage(){return "langconfig"; }
	
	public function rmkey()
	{
		$n = base64_decode( igk_getr("n"));
		R::RemoveKey($n);
		R::SaveLang();
		$this->View();
		igk_navtocurrent();
	}

	
	public function mod_key()
	{
		if (igk_qr_confirm()){			
			R::AddLang(igk_getr("clName"), igk_getr("clValue"));
			R::SaveLang();
			igk_frame_close(__FUNCTION__);
			igk_navtocurrent();
			igk_exit();
		}
		else{
			$f = igk_add_new_frame($this, __FUNCTION__);
			$f->Content->ClearChilds();
			$frm = $f->Content->addDiv()->addForm();
			$frm["action"] = $this->getUri(__FUNCTION__);
			$f->Title = R::ngets("title.lang.changekeyvalue");
			$frm->addGroupControl()
			->addSLabelInput("clName", "text", igk_getr("key"))
			->input->setClass("igk-form-control")
			->setAttribute("readonly","true");
			$frm->addGroupControl()
			->addSLabelInput("clValue","text", igk_getr("key"))->input->setClass("igk-form-control");
			$frm->addHSep();
			$frm->addDiv()->addInput("btn.update" , "submit", R::ngets("btn.update"))->setClass("igk-btn igk-btn-default");
			$frm->addDiv()->addInput("confirm" , "hidden", 1);
			$f->RenderAJX();	
			igk_exit();			
		}	
	}
}

/// represent the load data manager
final class IGKLanguageCtrl extends IGKNonVisibleControllerBase
{
	const DATAFILE = "Data/languages.csv";
	private $m_languages;
	
	public function getLanguages(){
		return $this->m_languages;
	}
	public function getName(){return IGK_LANGUAGE_CTRL;	}
	public function __construct()
	{
		parent::__construct();
		$this->m_languages = array();
		$this->_loadData();
	}
	public function getLangRegex()
	{
		$o = "(";
		$i = 0;
		foreach($this->m_languages as $k)
		{
			if ($i ==1)
				$o.="|";
			$o.= $k;
			$i=1;
		}
		$o.=")";
		return $o;
	}
	private function _loadData()
	{
		$r = IGKCSVDataAdapter::LoadData(igk_io_syspath(self::DATAFILE));
		if ($r)
		{
			$this->m_languages = array();
			foreach($r as $l)
			{		
				$this->m_languages[$l[0]] = $l[0];
			}
		}
	}
	public function addLang($n)
	{
		if (!empty($n) && !isset($this->m_languages[$n]))
		{
			$this->m_languages[$n] = $n;
			$out = IGK_STR_EMPTY;
			foreach($this->m_languages as $k=>$v){
				$out .= $v."\n";
			}
			IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $out,true);
			
		}
	}
	public function View(){
		//do nothing
	}
	public function getDataAdapterName()	{return "CSV";}
	public function initDb(){//init support language db
	$content = <<<EOF
fr,
en,
nl
EOF;
		IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $content,true);
		$this->_loadData();
	}
}


///<summary>
///used to configure layout controller list
///</summary>
final class IGKLayoutCtrl extends IGKNonVisibleControllerBase
{
	private $m_currentLayout;
	
	public function getCurrentLayout(){return $this->m_currentLayout;}
	public function setCurrentLayout($value){$this->m_currentLaout = $value;}
	public function getName(){return IGK_LAYOUT_CTRL; }
	public function getDataAdapterName(){ return IGK_CSV_DATAADAPTER;}
	public function loadLayout(){
		IGKIO::CreateDir(IGK_LAYOUT_FOLDER);
		$n = igk_getr("clName");
		$f = igk_currentRelativePath("Layouts/".$n.".xml");
		$t = igk_getv($_FILES,"clFile");	
		if (igk_io_move_uploaded_file($t["tmp_name"], $f))
		{
			//register layout
		}
		
	}
	public function removeLayout(){
		$n = igk_getr("n");
		$f = igk_currentRelativePath("Layouts/".$n.".xml");
		if (file_exists($f))
		{
			unlink($f);
		}
	}
	public function IsFunctionExposed($funcname){
		return true;
	}
}

//-----------------------------------------------------------------------------------------
//PICTURES RESOURCES CONTROLLERS
//-----------------------------------------------------------------------------------------
final class IGKPICRESCtrl extends IGKConfigCtrlBase
{
	private $m_fileres;// CSV DATA  - name
					 //           - uri
	private $m_cpage;//current page
	private $m_selectedir ;
	private $m_searchentry;
	private $m_fileexts;
	private $m_changeState;
	//constante
	const DATAFILE = "Data/upload.csv";
	const TARGETDIR = "R/Img";	
	const PICRES_KEY = "PicResChanged";
	
	private $m_lastDate;
	protected function InitComplete()
	{
		parent::InitComplete();
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onPicResChanged");
		$this->m_fileres = $this->App->Doc->Theme->res;
		$this->_loadData();
	}
	public function onPicResChanged($ctrl){
		if ( $ctrl->isChanged(self::PICRES_KEY, $this->m_changeState))
		{
			$this->_loadData();
		}
	}
	
	///<summary>get all pictures resources entries</summary>
	public function getAllPics()
	{
		return $this->m_fileres;
	}
	//store data
	private function _storeData()
	{
		$out = IGK_STR_EMPTY;
		foreach($this->m_fileres as $k=>$v)
		{
			$out .= $k.igk_csv_sep().$v.IGK_LF;
		}
		if (IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $out, true))
		{
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange(self::PICRES_KEY, $this->m_changeState);
			return true;
		}
		return false;
	}
	public function getName(){		return IGK_PIC_RES_CTRL;	}
	public function __construct()
	{
		parent::__construct();			
	}
	
	private function _getexts()
	{
		$tab = explode(";",strtolower(IGK_ALLOWED_EXTENSIONS));
		$this->m_fileexts = array();
		foreach($tab as $k)
		{
			$this->m_fileexts[strtolower($k)] = $k;
		}
	}
	public function regPicture($name, $link){
		if ($link){
			$this->m_fileres[$name] = $link;
		}
	}
	private function _support($ext)
	{
		$this->_getexts();
		return isset($this->m_fileexts[strtolower($ext)]);
	}
	function _loadData()
	{
		//Clear file list
		$this->m_fileres = array();
		$f = igk_io_syspath(self::DATAFILE);
		$txt = IGKIO::ReadAllText($f);
		$lines = explode(IGK_LF, $txt);
		
		$this->_initDefaultPictureRes();
		$this->initPicturesRes(igk_io_currentRelativePath("R/Img"));
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$e = explode( igk_csv_sep(), $l);			
			//replace with registered files
			$this->m_fileres [$e[0]] = igk_html_uri($e[1]);
		}		
	}
	//# add resources
	public function add_res($name, $uri)
	{
		
		$this->m_fileres[$name] = $uri;
		if (!isset($this->m_fileres[$name]))
		{
			$this->m_fileres[$name] = $uri;
			return true;
		}
		return false;
		
	}
	public function initPicturesRes($dir)
	{
		if (!is_dir($dir))
			return;
		//retrive all picture file from directory
		$r = IGKIO::GetPictureFile($dir);		
		foreach($r as $k)
		{
			$n = igk_io_basenamewithoutext($k);
			if (!isset($this->m_fileres[$n]))
				$this->m_fileres[$n] = igk_html_uri(igk_io_basePath($k));
		}
	}
	/// init default resources
	private function _initDefaultPictureRes()
	{	//init default controller
		$dir = dirname(__FILE__)."/Default/R/Img";
		$this->initPicturesRes($dir);
	}
	public function getConfigPage(){return "pictureresconfig";}
	
	public function getImgUri($name, $check=false)
	{		
		$b = igk_getv($this->m_fileres, $name, IGK_STR_EMPTY);
		if ($check && empty($b))
			return $b;;
		return igk_html_resolv_img_uri(igk_io_baseDir($b));
	}
	public function viewpic($name=null){
		$n = ($name==null)? igk_getr("name",$name):$name;
	// igk_wln("call name");
	// igk_show_prev($this->m_fileres[$n]);
	
	$f = igk_io_currentRelativePath(igk_getv($this->m_fileres, $n, IGK_STR_EMPTY));
		if (file_exists($f))
		{
			header("Content-type: image/png");
			igk_wl( IGKIO::ReadAllText($f));
		}
		else{
			header("Content-type: image/png");
			igk_wl( IGKIO::ReadAllText(igk_io_currentRelativePath(igk_getv($this->m_fileres, "none"))));
		}
		igk_exit();
	}

	protected function initTargetNode(){
		return IGKHtmlItem::CreateWebNode("div", array("class"=>strtolower($this->Name)));
	}	
	public function View(){		
		$div = $this->TargetNode;
		$div->ClearChilds();
		if ($this->getIsVisible())
		{
			IGKHtmlUtils::AddItem($div, $this->ConfigNode);	
			switch($this->m_cpage)
			{
				case "showentries":
					$this->showentries();
					break;
				default:
					$this->_showdefault();
					break;
			}
		}
		else{
			igk_html_rm($div);
		}
	}
	private function _showdefault()
	{
		$div = $this->TargetNode;
		igk_html_add_title($div, "title.PictureResourcesManager");
		$div->addHSep();
		
		igk_add_article($this, "pictures.res", $div->addDiv());
		$div->addHSep();
		//show directory
		$tab = IGKIO::GetDirList(igk_io_currentRelativePath(self::TARGETDIR));
		
		igk_html_add_title($div, "title.PictureResourcesManagerFolder");
		if ($tab && (count($tab)>0))
		{
			$ul = $div->add("ul");
			foreach($tab as $k)
			{
				$li = $ul->add("li");
				$li->add("label",array("class"=>"-cllabel cell_minsize dispib"))->add("a", array(
					"href"=>$this->getUri("setdir&d=".base64_encode(urldecode($k))),
					"class"=>"config-fileviewdir"))->Content = basename($k);
				if ((count(IGKIO::GetDirList($k)) == 0) && (count(IGKIO::GetDirFileList($k)) == 0)){
					IGKHtmlUtils::AddImgLnk($li, $this->getUri("dropdir&d=".base64_encode(urldecode($k))), "drop");
				}
				// $li = $ul->add("li");
				// $li->Content = $k;
			}
		}
		$div->addHSep();
		igk_html_add_title($div, "title.UploadPictures");
		$frm = $this->_addLoadPicForm($div);
		
		
		IGKHtmlUtils::AddBtnLnk($frm, "btn.showallpics", $this->getUri("showentries"));
		IGKHtmlUtils::AddBtnLnk($frm, "btn.rmAll", $this->getUri("deleteall"), array(
		"onclick"=>igk_js_lnk_confirm(R::ngets(IGK_MSG_ALLPICS_QUESTION)->getValue())
		));
		$frm->addInput("confirm", "hidden", 0);		
	}
	private function _addLoadPicForm($div)
	{
		$frm = $div->addForm();
		$frm["action"]=$this->getUri("loadfile");
		$frm["method"]="POST";
		$frm["enctype"]=IGK_HTML_ENCTYPE;
		
		
		$frm->addSLabelInput("dir","text", $this->m_selectedir);$frm->addBr();
		$frm->addSLabelInput("name","text", null, null,true);$frm->addBr();
		$frm->addSLabelInput("pics", "file",null, array("multiple"=>false, "accept"=>"image/*" ),true);$frm->addBr();
		
		$frm->add("input", array("type"=>"hidden" , "name"=>"MAXFILESIZE", "value"=>5000));
		$frm->addHSep();
		$frm->addBtn("upload",R::gets("btn.upload"));
		return $frm;
	}
	public function dropdir()
	{		
		$dir = basename(base64_decode( igk_getr("d", null)));
		$dir = igk_io_baseDir(self::TARGETDIR ."/".$dir);		
		if (is_dir($dir)){
		
		if (IGKIO::RmDir($dir))
			igk_notifyctrl()->addMsgr("msg.directorydrop");
		else
			igk_notifyctrl()->addErrorr("msg.directorynotdrop");
			//igk_io_currentRelativePath(self::TARGETDIR ."/".$dir));
			$this->View();
		}
		igk_navtocurrent();
	}
	public function setdir()
	{
		$this->m_selectedir = basename(base64_decode( igk_getr("d", null)));		
		$this->View();
		
	}
	public function loadtempfile($tempfile, $name, $id,  $dir)
	{
			$f = $tempfile;
			$ext = IGKIO::GetFileExt($name);
			
			if (!$this->_support(".".$ext))
			{
				igk_notifyctrl()->addError(ERR_FILE_NOT_SUPPORTED);
				return;
			}	
		if (IGKIO::CreateDir($dir))
		{//ensure that file exits
			//igk_wln("dir created");
			$dest = igk_io_getdir($dir."/".$id.".". $ext);
			if (!move_uploaded_file($f, $dest))
			{
				igk_notifyctrl()->addError("Unable to move uploaded file to ".$dest);
			}
			else{
				$this->m_fileres[$id] = igk_io_basePath($dest);
				if (!$this->_storeData())
				{
					igk_notifyctrl()->addError("Can't store data  to file \"".$id."\"");
					unlink($dest);
					unset($this->m_fileres[$id]);
				}
				else {
					igk_notifyctrl()->addMsg( R::gets("MSG.FileUploaded"));
				}
			}		
	}
	}
	public function loadfile()
	{
		$id  = igk_getr("name");
		$dir = igk_getr("dir");
		
		$target = IGK_STR_EMPTY;
		$dest=IGK_STR_EMPTY;
		if (($id==null) || isset($this->m_fileres[$id]))
		{
			igk_notifyctrl()->addError(R::ngets("ERR.FILEISNULLORALREADYREGISTERED"));
			igk_navtocurrent();
			return;
		}
		if ($dir)
			$target = igk_io_currentRelativePath(self::TARGETDIR."/".$dir);
		else
			$target = igk_io_currentRelativePath(self::TARGETDIR);
		
		
			$f = $_FILES["pics"]["tmp_name"];	
			$name = $_FILES["pics"]["name"];
			$ext = IGKIO::GetFileExt($name);
			
			if (!$this->_support(".".$ext))
			{
				igk_notifyctrl()->addError(ERR_FILE_NOT_SUPPORTED);
				return;
			}	
		if (IGKIO::CreateDir($target))
		{//ensure that file exits
			//igk_wln("dir created");
			$dest = igk_io_getdir($target."/".$id.".". $ext);
			if (!move_uploaded_file($f, $dest))
			{
				igk_notifyctrl()->addError("Unable to move uploaded file to ".$dest);
			}
			else{
				$this->m_fileres[$id] = igk_io_basePath($dest);
				if (!$this->_storeData())
				{
					igk_notifyctrl()->addError("Can't store data  to file \"".$id."\"");
					unlink($dest);
					unset($this->m_fileres[$id]);
				}
				else {
					igk_notifyctrl()->addMsg( R::gets("MSG.FileUploaded"));
				}
			}		
		}
		else {
				$this->msbox->addError("Unable to move uploaded file to ".$dest);
				
		}	
		$this->View();		
	}
	
	//delete picture
	public function delfile(){
		$id=igk_getr("name");
		if (($id==null) || !isset($this->m_fileres[$id]))
			return;
		$f = igk_io_currentRelativePath($this->m_fileres[$id]);
		if (file_exists($f))
		{
			if (unlink($f))
			{
				unset($this->m_fileres[$id]);
				$this->_storeData();
			}
			else 
				$this->msbox->addError("unabled to delete file");
		}
		else{
				//protection
				unset($this->m_fileres[$id]);
				$this->_storeData();
		}
		$this->View();
	}
	public function searchentry(){
	
		$this->m_searchentry = strtolower(igk_getr("q"));
		$this->View();
	}
	public function show_loadfile_frame()
	{
		$frame = igk_add_new_frame($this, "load_pic_frame");
		$frame->Title = R::ngets("title.loadpictureres");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $this->_addLoadPicForm($d);
		
	}
	public function showentries()
	{
		if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
		{		
			$this->m_cpage = "showentries";
			$div = $this->TargetNode;
			$div->ClearChilds();
			igk_html_add_title($div, "title.images");
			$div->addHSep();
			$div->add(new IGKHtmlSearchItem($this->getUri("searchentry"), $this->m_searchentry));
			$div->addHSep();
			$frm = $div->addForm();
			$frm["method"]="POST";
			$frm["action"]= $this->getUri();
			
			
			$v_div= $frm->addDiv();
			IGKHtmlUtils::AddBtnLnk($v_div, "btn.Return", $this->getUri("gotodefaultview"));			
			IGKHtmlUtils::AddBtnLnk($v_div, "btn.loadfile", $this->getUri("show_loadfile_frame"));
			IGKHtmlUtils::AddBtnLnk($v_div, R::ngets("btn.RemoveBrokenfiles"), $this->getUri("remove_broken_file"));
			$frm->addBr();
			$info = $frm->addDiv();
			
			$tab = $frm->addTable();
			$tr = $tab->add("tr");
			IGKHtmlUtils::AddToggleAllCheckboxTh($tr);
			$tr->add("th")->Content = R::gets(IGK_FD_NAME);
			$tr->add("th")->Content = R::gets("clLink");
			$tr->add("th")->Content = R::gets("clSize");
			$tr->add("th")->Content = IGK_HTML_WHITESPACE;
			
			$v_ttab = array_keys($this->m_fileres);
			sort($v_ttab);
			$v_count = 0;
			foreach($v_ttab as $k)
			{
				$v = $this->m_fileres[$k];
				if (empty($v) || !empty($this->m_searchentry) && !strstr(strtolower($k), strtolower($this->m_searchentry))
						&& !strstr(strtolower($v), strtolower($this->m_searchentry)))
					continue;
				$tr = $tab->add("tr" , array("class"=>"fitw"));	
				$tr->add("td")->addInput(IGK_STR_EMPTY,"checkbox");
				$tr->add("td")->Content = $k;
				$tr->add("td")->add("a", array("href"=>igk_js_post_frame($this->getUri("viewpic_ajx&name=".$k))))->Content = $v;				
				$file = igk_io_currentRelativePath($v);
				if (file_exists($file))
				{
					$size = @filesize( $file);
					if ($size === false)
					{
						$tr->add("td")->Content =  "?";
					}
					else 
						$tr->add("td")->Content =  IGKIO::GetFileSize( $size);
				}
				else 
					$tr->add("td")->Content = "broken";
				$tr->add("td", array("class"=>"igk-table-img-action_16x16"))->add("a", array("href"=>
				$this->getUri("delfile&name=".$k)))->add("img", array("src"=>R::GetImgUri("drop")));
				
				$v_count++;
			}
			$info->Content = $v_count;
			$div = $frm->add("div", null, 1000);
			IGKHtmlUtils::AddBtnLnk($div, "btn.Return", $this->getUri("gotodefaultview"));		
			IGKHtmlUtils::AddBtnLnk($div, "btn.loadfile", $this->getUri("show_loadfile_frame"));			
			IGKHtmlUtils::AddBtnLnk($div, R::ngets("btn.RemoveBrokenfiles"), $this->getUri("remove_broken_file"));
		}
	
	}
	
		public function viewpic_ajx()
		{
			$frame = igk_add_new_frame($this, "viewpic_frame");
			$frame->Title = R::ngets("title.picture_1", igk_getr("name"));
			$c = $frame->Content;
			
			$c->ClearChilds();
			$c->addDiv(array("class"=>"alignc"))->add("img", array("src"=>$this->getUri("viewpic&name=".igk_getr("name"))));
			$c->addDiv()->Content = "image definition";
			$frame->RenderAJX();
		}
		public function remove_broken_file()
		{
			$v_ttab = array_keys($this->m_fileres);
			sort($v_ttab);
			$r  = false;
			$i = 0;
			foreach($v_ttab as $k)
			{
				$v = $this->m_fileres[$k];			
				$file = igk_io_currentRelativePath($v);
				if (!file_exists($file))
				{
					unset($this->m_fileres[$k]);
					$r = true;
					$i++;
				}
			}
				if ($r){
					$this->_storeData();
					$this->View();
					igk_notifyctrl()->addMsgr("msg.brokenfilesremoved", $i);
				}
				else{
					igk_notifyctrl()->addInfor("msg.nobrokenfilesremoved");
				}
		}
		public function gotodefaultview()
		{
			$this->m_cpage = null;
			$this->View();
		}
	public function deleteall()
	{
		if (igk_qr_confirm()){
		$dir = igk_io_baseRelativePath(self::TARGETDIR);
		if (is_dir($dir) && !IGKIO::RmDir(igk_io_baseRelativePath(self::TARGETDIR)))
		{
			$this->msbox->addError("Impossible de supprimer le repertoire.");
		}
		else{
			foreach($this->m_fileres as $k=>$v)
			{
				$f = igk_io_currentRelativePath($v);
				if (file_exists($f))
					unlink($f);
			}
			$this->m_fileres= array();
			$this->_storeData();
			$this->View();
		}
		}
		else{
			$frame = igk_frame_add_confirm($this, "delete_all_pics_frame");		
			$frame->Form["action"] = $this->getUri("deleteall");
			$frame->Form->Div->Content = R::ngets(IGK_MSG_ALLPICS_QUESTION);
			
		}
	}
	
	
}
class IGKXmlOptions
{
	var $Indent;
	var $ParentDepth;
}

//-----------------------------------------------------------------------------------------
//MODULE-CONTROLLER AND ARTICLE MANAGER
//-----------------------------------------------------------------------------------------
final class IGKControllerAndArticlesCtrl extends IGKConfigCtrlBase
{
	private $m_SelectedController;
	private $m_selectedLang;
	private $m_search_article;
	private $m_search_view;
	private $m_filter_article_lang;
	private $m_SelectedControllerChangedEvent;
	
	public function getSelectedController(){return $this->m_SelectedController; }
	
	public function getName(){ return IGK_CA_CTRL;}
	
	public function setSelectedController($value){ 
		if ($this->m_SelectedController != $value)
		{
			$this->m_SelectedController = $value;
			$this->onSelectedControllerChanged();
		}
	}
	protected function onSelectedControllerChanged()
	{
		$this->m_SelectedControllerChangedEvent->Call($this, array());
	}
	
	//--------------------------------------------
	//get the article content	
	//--------------------------------------------
	public function getCtrlArticle(){
		$c = igk_getr("ctrl");//get the controller
		$n = igk_getr("n"); //article name		
		igk_getctrl($c)->getArticle($n);
		igk_exit();
	}
	
	
	public function setdefaultpage(){
		$this->App->Configs->web_pagectrl = igk_getr("clDefaultCtrl");
		igk_save_config();
		$this->View();
	}
	public function setdefaultpage_ajx(){
		$this->setdefaultpage();
	}
	
	private function _getviewid(){$this->getName()."_views";}
	
	
	//---------------------------------------------------------------------------------------
	// ARTICLES FUNCTIONS
	//---------------------------------------------------------------------------------------	
	public function ca_viewArticles($div, $ctrl=null)
	{
		$ctrl = ($ctrl==null)? igk_getctrl($this->SelectedController, false) : $ctrl;
		if ($ctrl == null)
			return null;
	
		$div->add(new IGKHtmlSearchItem($this->getUri("search_article"), null, "m_search_article"));
		$dir = $ctrl->getArticlesDir();
		$t = IGKIO::GetDirFileList($dir);
		$lang_search = null;
		$frm = $div->addForm();
		
		if (!(($this->m_selectedLang == null) || ($this->m_selectedLang == ALL_LANG)))
			$lang_search = $this->m_selectedLang;
		if ($t && count($t)>0){
			sort($t);
				$ul = $frm->addTable();
				$ul["id"]=$this->_getarticleid();
				$tr = $ul->add("tr");
				$tr->add("th", array("style"=>"width:16px"))->Content = IGK_HTML_SPACE;
				$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$n = null;
				foreach($t as $k)
				{
					$n =  basename($k);
					// if (!IGKString::EndWith(strtolower($n), igk_get_article_ext()))
					// {continue;}
					if ($lang_search && !IGKString::EndWith(strtolower($n), igk_get_article_ext($lang_search)))
						continue;
					if($this->m_search_article && !strstr(strtolower($n), strtolower($this->m_search_article)))
						continue;
					$tr = $ul->add("tr");
					$tr->add("td")->Content =IGK_HTML_SPACE;
					$tr->add("td")->add("a", array("href"=>$this->getUri("download_article&n=".$n)))->Content = $n;
					//IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("edit_article&n=".basename($k)), "edit");
					IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("ca_edit_article_ajx&navigate=1&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($k))), "edit");
					//IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("edit_articlewtiny&n=".basename($k))), "tiny");
					IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("ca_edit_articlewtiny_f_ajx&navigate=1&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($k))), "tiny");
					IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("ca_drop_article_ajx&ctrlid=".$ctrl->Name."&n=".base64_encode(basename($k)))), "drop");
				}
			}
		$frm["action"]= $this->getUri("ca_add_article_frame");
		$frm->addBtn("btn_addarticle", R::ngets("btn.AddArticle"));
		if ($ctrl!=null)
		{
			$frm->addInput("ctrlid", "hidden", $ctrl->Name);		
		}	
	}
	
	private function _getarticleid(){
		return $this->getName()."_articles";
	}
	
	public function search_view()
	{
		$this->m_search_view = igk_getr("m_search_view");
		$this->View();
	}
	//write article for tiny
	private  function __write_article_for_tiny($file, $v_content, $property=null)
	{
		if (empty($file))
			return false;
		
		$v_dummy =  IGKHtmlItem::CreateWebNode("dummy");
		$v_dummy->Load($v_content);
		
		if ($v_dummy->HasChilds){
			
			
			if ($property)
			{
				if ($property->RemoveImgSize)
				{
					$tab  = $v_dummy->getElementsByTagName("image");
					igk_wln("remove image style");
					foreach($tab as $k)
					{
						$k["width"] = null;
						$k["height"] = null;
					}
				}
				$tab  = $v_dummy->getElementsByTagName("*");
				if ($property->RemoveStyles)
				{					
					foreach($tab as $k)
					{
						$k["style"] = null;
					}
				}
			}
			
			$s = null;// (object)array("Indent"=>true, "ParentDepth"=>null);
			if ($v_dummy->ChildCount === 1)
			{
				$s = new IGKXmlOptions();
				$s->Indent = true;
				$s->ParentDepth = $v_dummy->Childs[0];						
				IGKIO::WriteToFileAsUtf8WBOM($file, $s->ParentDepth->getinnerHTML($s), true);	
				
			}
			else{
				$s = new IGKXmlOptions();
				$s->Indent = true;
				$s->ParentDepth = $v_dummy;
				IGKIO::WriteToFileAsUtf8WBOM($file,  $s->ParentDepth->getinnerHTML($s), true);					
			}
			return true;
		}
		else{
			IGKIO::WriteToFileAsUtf8WBOM($file, IGK_STR_EMPTY, true);	
			return true;
		}
		return false;
	}
	private function __updateview($ctrl)
	{
		if ($ctrl && $ctrl->getIsVisible())
		{					
			if (($this->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER) && igk_reflection_class_extends(get_class($ctrl), "IGKConfigCtrlBase" ))
				$ctrl->showConfig();
			else
				$ctrl->View();	
		}
	}
	public function update_articlewtiny(){
		
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_empty_line( igk_html_unscape(igk_getr("clContent")));
		$id = igk_getr("clctrl");
		$v_frame = igk_getr("clframe");
		$property = (object)array(
			"RemoveImgSize" =>igk_getr("clRemoveImgSize"),
			"RemoveStyles" =>igk_getr("clRemoveStyles")
		);
		
		$ctrl = igk_getctrl($id, false);
		if ($this->__write_article_for_tiny($f, $v_c, $property))
		{
			$this->__updateview($ctrl);
			igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved" , basename($f)));
		}
		else {
			igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
		}
	}
	
	public function update_article(){
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_empty_line(igk_html_unscape(igk_getr("clContent")));		
		$v_frame = igk_getr("clframe");
		$v_dummy =  IGKHtmlItem::CreateWebNode("div");
		$id = igk_getr("clctrl");
		$ctrl = igk_getctrl($id, false);
		
		if (!empty($f))
		{	
	
			try{
			//try to know if well html file
			$v_dummy->Load($v_c);
				
				if (igk_io_save_file_as_utf8($f, $v_c, true,false))		
				{
					$this->__updateview($ctrl);					
					igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved" , basename($f)));					
				}
				else 
					igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
				
				igk_ctrl_viewparent($ctrl,null);
				igk_frame_close($v_frame, false);		
			}
			catch(Exception $ex){			
				igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
				igk_notifyctrl()->addError($ex);
				igk_show_exception($ex);
				igk_exit();
			}
		}
	}
	///<summary> edition d'article simple par une demande ajax</summary>
	public function ca_edit_article_ajx($ctrlid=null, $name=null)
	{
		//fc : force creation
		$frame = $this->ca_edit_article_frame($ctrlid, igk_getr("n", igk_getr("fn")), 1, igk_getr("m", 0), igk_getr("fc") );
		if ($frame){
			//$frame->Form->addDiv()->Content = "navigable ".igk_getr("navigate",0);
			$frame->Form->addInput("navigate", "hidden", igk_getr("navigate",0));
			$frame->RenderAJX();
		}
	}
	///<summary> create d'un FrameDialog pour l'édition d'article </summary>
	///<params>
	///$ctrlid: controller ou id du controller
	///$name: nom ou chemin d'accèss au fichier
	///$ajx:  s'il s'agit d'un context ajax ou nom
	///$mode: si mode = 1 alors le name un le chemin d'accès complet au fichier sinon il s'agit du nom dans le repertoire Articles du controlleur
	///$force: force creation if not exists
	///</params>
	public function ca_edit_article_frame($ctrlid=null, $name=null, $ajx=0, $mode=0, $force=false)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);
		
		if ($force || file_exists($f))
		{
		
			$frame = igk_add_new_frame($this, "frame_edit_article", $ajx==1?null: "#".$this->_getarticleid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticle_1", basename($f));						
			$str = IGKIO::ReadAllText($f);
			
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_article".( ($ajx==1)?null: "#".$this->_getarticleid()));
			$ul = $frm->add("ul");
			
			$txt = $ul->add("li")->addTextArea("clContent", $str);	
			$txt["class"] = "frame_textarea";

			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
			$frame->Form = $frm;
			return $frame;
		}
		return null;
	}

	
	public function ca_edit_articlewtiny_frame($ctrlid=null, $name=null, $ajx=0, $mode=0)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);			
		if (file_exists($f))
		{
		//TODO:
			$frame = igk_add_new_frame($this, "frame_edit_article", $ajx==1?null: "#".$this->_getarticleid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticlewtiny_1", basename($f));					
			$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_articlewtiny".( ($ajx==1)?null: "#".$this->_getarticleid()));
			$ul = $frm->add("ul");
			$ul->add("li")->addSLabelInput("clRemoveStyles", "checkbox");
			$ul->add("li")->addSLabelInput("clRemoveImgSize", "checkbox");
			//$ul->add("li")->addTextArea("clContent",utf8_decode($str));
			$ul->add("li")->addTextArea("clContent", $str);
			igk_js_enable_tinymce($ul, "exact", "clContent");
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));	
			return $frame;			
		}
		return null;
	}
	public function ca_edit_articlewtiny_f_ajx($ctrlid=null, $name=null)
	{
		$frame = $this->ca_edit_articlewtiny_f_frame($ctrlid,$name?$name: igk_getr("n", igk_getr("fn")), 1, igk_getr("m", 0), igk_getr("fc") );
		if ($frame)
			$frame->RenderAJX();		
	}
	public function ca_update_articlewtiny_f()
	{
		//full
		if (!$this->App->ConfigMode)
		{
			igk_navtocurrent();
			return;
		}		
		$this->update_articlewtiny();
		//reload frame
		$_REQUEST["ctrlid"] = igk_getr("clctrl");
		$_REQUEST["n"] = basename(urldecode(base64_decode(igk_getr("clfile"))));
		igk_frame_close("frame_edit_article");	
		igk_navtocurrent();
	}
	public function ca_edit_articlewtiny_f_frame($ctrlid=null, $name=null, $ajx=0, $mode=0,$force = false)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);				
		if ($force || file_exists($f))
		{
			//TODO:
			$frame = igk_add_new_frame($this, "frame_edit_article");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticlewtiny_1", basename($f));					
			$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("ca_update_articlewtiny_f");
			$ul = $frm->add("ul");
			$ul->add("li")->addSLabelInput("clRemoveStyles", "checkbox");
			$ul->add("li")->addSLabelInput("clRemoveImgSize",  "checkbox");
			//$ul->add("li")->addTextArea("clContent",utf8_decode($str));
			$ul->add("li")->addTextArea("clContent",$str);
			igk_js_enable_tinymce($ul, "exact", "clContent");
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));	
			return $frame;			
		}
		return null;
	}
	public function edit_article()
	{
		$this->ca_edit_article_frame($this->SelectedController, igk_getr("n"));		
	}
	public function edit_articlewtiny(){
		$this->ca_edit_articlewtiny_frame($this->SelectedController, igk_getr("n"));
	}
	
	/*
	*remove an article.
	*/
	public function drop_article(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getArticlesDir()."/".$n);					
		$_FRAMENAME = "frame_drop_article_confirmation";
		if (file_exists($f))
		{
			if (igk_qr_confirm()){
				unlink($f);
			}
			else{
				$frame = igk_frame_add_confirm($this, $_FRAMENAME, $this->getUri("drop_article"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION, $n);
				$frame->Form->addInput("n", "hidden",$n);		
			}
			$this->View();
		}
	}
	public function ca_drop_article_ajx(){
		$n = base64_decode(igk_getr("n"));
		$ctrl = ($c = igk_getr("ctrlid",null))? igk_getctrl($c) :  $this->SelectedController;
		
		if (($ctrl == null) || !isset($n))
		{
			igk_notifyctrl()->addErrorr("err.nocontroller.selected");			
			return null;
		}
		$f= igk_io_getdir(igk_getctrl($ctrl)->getArticlesDir()."/".$n);					
		$_FRAMENAME = "frame_drop_article_confirmation";
		
		if (file_exists($f))
		{
			if (igk_qr_confirm())
			{	
				unlink($f);
				igk_show_prev($_REQUEST);
				igk_getctrl($ctrl)->View();
				if (igk_getr("navigate")==1)
				{//navigate and render document
					$this->App->Doc->body->RenderAJX();
				}
				else {
					igk_wl(igk_getctrl($ctrl)->TargetNode->innerHTML);							
				}
			}
			else{
				$frame = igk_frame_add_confirm($this, $_FRAMENAME, $this->getUri("ca_drop_article_ajx"));				
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION, $n);
				$frame->Form["igk-confirmframe-response-target"] = strtolower($ctrl);
				$frame->Form->addInput("n", "hidden",base64_encode($n));		
				$frame->Form->addInput("navigate", "hidden",igk_getr("navigate"));		
				$frame->Form->addInput("ctrlid", "hidden",$ctrl->Name);	
				$frame->RenderAJX();
			}			
		}
		else{
			igk_notifyctrl()->addInfor("msg.ca_drop_article_ajx_no_article_to_remove");
		}
	}
	/*
	*get an article. download it 
	*/
	public function download_article(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getArticlesDir()."/".$n);			
		if (file_exists($f))
		{
			igk_download_file(basename($f), $f);		
			igk_navtocurrent();
			igk_exit();
			
		}
	}
	
	//filter article by language
	public function filter_article_by_lang(){
		$this->m_filter_article_lang = igk_getr("n");
		$this->View();
	}
	/*
	*search article . reload the view
	*/
	public function search_article(){
		$this->m_search_article = igk_getr("m_search_article");		
		$this->View();
	}
	
	private function _buildViewArticle($div, $ctrl=null)
	{
		$v_divarticle = $div->addDiv();
		$v_divarticle["id"] = "view_articles";
		igk_html_add_title($v_divarticle, "title.Articles");	
		$frm = $v_divarticle->addForm();			
		$frm["action"]= $this->getUri("ca_add_article_frame");
		$frm->add("label")->Content = R::ngets("lb.Language");						
		$tab =array_merge(array(ALL_LANG), igk_getctrl(IGK_LANGUAGE_CTRL)->Languages);			
		$select = igk_html_build_select($frm, "clLang", $tab, array("allowEmpty"=>false, "keysupport"=>false),$this->m_selectedLang);		
		//ctrl uri for selection chanaged
		$ctrln = ($ctrl == null) ? IGK_STR_EMPTY : "&ctrl=".$ctrl->Name;
		
		$select["onchange"]="javascript:  (function(p){var q = p.form.parentNode; window.igk.ajx.post('".$this->getUri("ca_ctrl_article_select_lang_ajx{$ctrln}&n=").
		"'+p.value, null, function(xhr){ if (this.isReady()){ this.setResponseTo(q); }});})(this);";
		$this->ca_viewArticles($v_divarticle->addDiv(array("id"=>"igk-div-articles")), $ctrl);
			
	}
	

	//-----------------------------------------------
	// VIEWS FUNCTIONS
	//-----------------------------------------------

	public function ca_viewViewFiles($div, $ctrl=null){
		$ctrl = ($ctrl!=null)? $ctrl : igk_getctrl($this->SelectedController, false);
		if ($ctrl == null)
			return null;
		$div->add(new IGKHtmlSearchItem($this->getUri("search_view#frm_ctrl_view"), null, "m_search_view"));
		$frm = $div->addForm();
		$frm["id"]=$frm["name"] = "frm_ctrl_view";
		$frm["action"]= $this->getUri("add_viewframe");
		$dir = $ctrl->getViewDir();
			$t = IGKIO::GetDirFileList($dir);
		if ($t && count($t)>0){
		sort($t);
		$ul = $frm->addTable();
		$ul["id"]=$this->_getviewid();
		$tr = $ul->add("tr");
		$tr->add("th", array("style"=>"width:16px"))->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
		$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
		foreach($t as $k)
		{
			if ($this->m_search_view && !strstr(strtolower($k), $this->m_search_view))
				continue;
			$tr = $ul->add("tr");
			
			$tr->add("td")->Content = IGK_HTML_SPACE;
			$tr->add("td")->add("a", array("href"=>$this->getUri("ca_download_view&n=".basename($k))))->Content = basename($k);
			IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("ca_edit_view&n=".basename($k)), "edit");
			IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("ca_drop_view&n=".basename($k)), "drop");
		}
		}
		
		$frm->addBtn("btn_addView", R::ngets("btn.AddView"));
		//$frm->addInput("ajx", "hidden", 1);
	}
	
	
	public function ca_update_view(){
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_empty_line(igk_getr("clContent"));
		$v_frame = igk_getr("clframe");		
		$ctrl = igk_getctrl($this->SelectedController, false);	
		$v_old = IGKIO::ReadAllText($f);
		
		
		//save the content from text area 
		igk_io_saveContentFromTextArea($f, $v_c, true);		
		$error = array();		
		$code = 0;
		@exec("php -l \"".$f."\"", $error, $code);
		
		igk_show_prev($error);
		
		igk_notifyctrl()->addMsg(R::ngets("MSG.ViewFileSaved" , basename($f)));
		$ctrl->View();
		igk_frame_close($v_frame);
	
	}
	public function ca_edit_view($oldcontent=null, $errormesage=null, $error=null){
		//edit frame 	
		$ctrl = igk_getctrl($this->SelectedController, false);
		$n = igk_getr("n");
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir($ctrl->getViewDir()."/".$n);			
		if (file_exists($f))
		{
			//view edit frame
			$frame = igk_add_new_frame($this, "frame_edit_view", "#".$this->_getviewid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editview", basename($f));	
			$str=null;
			if (!$oldcontent)
				$str =utf8_decode( IGKIO::ReadAllText($f));					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("ca_update_view#".$this->_getviewid());
			if ($error)
			{
				$frm->add("div", array("class"=>"notification_bad"))->Content = "Somme Error Append When try to save the file: <br/ >" 
				. $errormesage.
				"<br/>".$oldcontent;
			}
			$ul = $frm->add("ul");
			$area = $ul->add("li")->addTextArea("clContent", ($oldcontent==null)? $str: $oldcontent);		
			$area["style"] = "width: 400px; min-height: 300px;";
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("n", "hidden", $n);
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
			$frm->Width = "400px";
			$frm->Height = "300px";
		}
	}
	public function ca_drop_view(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getViewDir()."/".$n);					
		$_FRAMENAME = "frame_ca_drop_view_confirmation";
		if (file_exists($f))
		{
			if (igk_qr_confirm()){
				unlink($f);
			}
			else{
				$frame = igk_frame_add_confirm($this, $_FRAMENAME,$this->getUri("ca_drop_view"));			
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION,$n);
				$frame->Form->Div->addInput("n", "hidden",$n);		
			}
			$this->View();
		}
	}
	//download view file
	public function ca_download_view(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getViewDir()."/".$n);			
		if (file_exists($f))
		{
			igk_download_file(basename($f), $f);
			igk_exit();
		}
	}
	
	
	
	
	//-----------------------------------------------
	// CONTROLLLERS  FUNCTIONS
	//-----------------------------------------------
	
	
	public function update_ctrl($oldcontent=null){
		
		
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c =utf8_encode( igk_html_unscape(igk_getr("clContent"),IGK_STR_EMPTY));
		$v_frame = igk_getr("clframe");		
		$ctrl = igk_getctrl($this->SelectedController, false);	
		
		if (igk_php_check_and_savescript($f, $v_c, $error, $code) == false)
		{
			$this->ca_edit_view($v_c, count($error)."update_ctrl::failed: code : ".$code." ".  implode("<br />",$error), true);			
		}	
		else{
			session_destroy();			
			igk_getctrl(IGK_CONF_CTRL)->reconnect();
			igk_notifyctrl()->addMsg(R::ngets("MSG.ViewFileSaved" , basename($f)));
			igk_exit();
		}
	}
	public function ca_edit_ctrl_ajx($oldcontent =null){
	//controller frame
		$name = igk_getr("n",null);
		$ctrl = $name == null ? igk_getctrl($this->SelectedController, false) : igk_getctrl($name, false);
		if ($ctrl == null)
			return null;
		$f= igk_io_getdir($ctrl->getDeclaredFileName());			
		if (file_exists($f))
		{
			$frame = igk_add_new_frame($this, "frame_edit_ctrl",".");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editctrl", basename($f));	
			$str=null;
			if (!$oldcontent)
				$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_ctrl" .($name == null ?IGK_STR_EMPTY:"&n=".$name));
			if ($oldcontent){
				$frm->add("div", array("class"=>"notification_bad"))->Content = "Error Happend : <br/ >" . $errormesage;
			}
			$ul = $frm->add("ul");
			$v_txtarea = $ul->add("li")->addTextArea("clContent", ($oldcontent==null)? $str: $oldcontent);		
			$v_txtarea["class"] = "igk-phpcodearea";
			$frm->addScript()->Content = "window.igk.editor.phpcodearea.init('clContent',{});";
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);			
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
			$frame->RenderAJX();
		}
	}
	
	public function ca_edit_ctrl_properties_ajx($render=true)
	{
			//edit controller frame
			$name = igk_getr("n",null);
			$ctrl = $name == null ? igk_getctrl($this->SelectedController, false) : igk_getctrl($name, false);
			if ($ctrl == null)
				return null;
			$f= igk_io_getdir($ctrl->getDeclaredFileName());
			$frame = igk_add_new_frame($this, "frame_edit_ctrl_properties",".");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editctrl.properties", $ctrl->Name);
			
			$frm = $frame->Content->addForm();
			$frm["action"]=$this->getUri("ca_update_ctrl_properties". ($name == null ?IGK_STR_EMPTY:"&n=".$name));
			$frm->addInput("frame_name", "hidden", $frame->Id);
			$ul = $frm->add("ul");
			
			$d = igk_sys_getdefaultCtrlConf();
			
			$v_itab = null;
			$v_classname = get_class($ctrl);
			if (method_exists($v_classname,"GetNonConfigurableConfigInfo"))
			{				
				$v_itab = igk_array_tokeys(call_user_func_array(array($v_classname,"GetNonConfigurableConfigInfo"),array()));
			
				
			}
			
			foreach($d as $k=>$v)
			{
				if (isset($v_itab[$k]))
					continue;
				
				$vv = igk_getv($ctrl->Configs, $k);
				
				switch(strtolower($k))
				{			
					case "clparentctrl":
						$t = igk_getctrl(IGK_MENU_CTRL)->__getEditController($ul, $vv, "lb.parentcontroller", $this->SelectedController);
						$t["id"] = $t["name"]= $k;
					break;
					case "cldataadaptername":
						$li = $ul->add("li");
						$this->_ca_add_adapter($li, $k, $vv);
						break;
					case "cldataschema":
						$li = $ul->add("li");
						$li->add("label", array("for"=>$k))->Content = R::ngets("lb.".$k);
						$sl = $li->addSelect($k);					
						$sl->addOption("false")->Content = R::ngets("enum.false");
						$sl->addOption("true")->Content = R::ngets("enum.true");
						$sl->select(igk_parsebool($vv));						
						break;
					default:
						$li = $ul->add("li");
						$li->add("label", array("for"=>$k))->Content = R::ngets("lb.".$k);
						$li->addInput($k,"text", $vv);
					break;
				}
			}
			
			$this->_buildAdditionalInfo($ctrl, $ul);
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"))->setClass("igk-btn");
		if ($render)
		$frame->RenderAJX();
	}
	public function ca_edit_ctrl_views_ajx($render=true){//edit controller views file 
		$fid = "ca_edit_ctrl_views_ajx_frame";
		$frame = igk_add_new_frame($this, $fid);
		$p = $frame->ForCtrl;
		$ctrl = igk_getctrl(igk_getr("n", $p? $p->Name: null), false);
		
		$frame->Title = R::ngets("title.editcontrollerviews_1", $ctrl->Name);
		$c = $frame->Content;
		$c->ClearChilds();
		
		//builds controller view
		$this->_buildViewView($c->addDiv(), $ctrl);
		
		if ($render)
			$frame->RenderAJX();
		return $frame;
	}
	public function ca_edit_ctrl_force_view_ajx(){
		$ctrl = igk_getctrl(igk_getr("n"), false);
		if ($ctrl){
			$ctrl->View();
			if ($ctrl->TargetNode){
				$c =  IGKHtmlItem::CreateWebNode("script");
				$c->RenderAJX();
				igk_exit();
			}
		}
		
	}
	
	
	public function unreg_view_frame()
	{
		$frame_name = "ca_edit_ctrl_atricles_ajx_frame";
		$frame = igk_get_frame($frame_name);
		if ($frame!=null)
		{
			$frame->ForCtrl->removeViewCompleteEvent($this, "view_frame_complete" );
			igk_frame_close($frame_name);
		}
	}
	public function ca_edit_ctrl_atricles_ajx($rendering=true){//edit ctrl articles
		$frame_name = "ca_edit_ctrl_atricles_ajx_frame";
		$frame = igk_add_new_frame($this, $frame_name);
		$p  = $frame->ForCtrl;
		$n = igk_getr("n", $p? $p->Name : null);		
		$ctrl = igk_getctrl($n);	
		if ($ctrl == null)
		{			
			$frame->ForCtrl =null;
			$frame->IsRegister =null;
			igk_frame_close($frame_name);			
			return;
		}		
		$frame->Title = R::ngets("title.editctrlaticles_1", $ctrl->Name);
		$frame->CloseUri = $this->getUri("unreg_view_frame");
		$c = $frame->Content;
		$c->ClearChilds();
		$d = $c->addDiv();
		//add div  article management
		$this->_buildViewArticle($d, $ctrl);
		//bin frame to controller view
		$t = $frame->IsRegister;
		if (!$t)
		{
			$t = true;
			$frame->IsRegister = $t;
			$ctrl->addViewCompleteEvent($this, "view_frame_complete" );
		}
		if ($rendering)
			$frame->RenderAJX();
		$frame->ForCtrl = $ctrl;
	}
	public function view_frame_complete()
	{
		//reload script
		$tb = $_REQUEST;
		igk_resetr();
		$this->ca_edit_ctrl_atricles_ajx(false);	
		$_REQUEST = $tb;
				
	}
	
	private function _ca_add_adapter($node, $k, $default=null, $nonevalue=false)
	{	
		$t = IGKDataAdapter::GetAdapters();
		$node->add("label", array("for"=>$k))->Content = R::ngets("lb.".$k);
		$sl = $node->add("select");
		$sl["id"] = $sl["name"] = $k;
		foreach($t as $m=>$c)
		{
			$opt = $sl->add("option");
			$opt["value"] = $m;
			if ($m == $default)
				$opt["selected"]="true";
			
			$opt->Content = $m;
		}
	}
	public function ca_update_ctrl_properties()
	{
		$name = igk_getr("n",null);
		$ctrl = $name == null ? igk_getctrl($this->SelectedController, false) : igk_getctrl($name, false);		
		if ($ctrl == null)
			return null;
		$c = igk_get_robj();
		$oldparent = $ctrl->Configs->clParentCtrl;
		foreach($c as $k=>$v)
		{
			$s = igk_getr($k);
			switch($k)
			{
				case "clParentCtrl":				{
					if ($s == "none")
					{
						$ctrl->Configs->$k =null;						
					}
					else {
						
						if (igk_can_set_ctrlparent($ctrl, $s))
						{
							
							$ctrl->Configs->$k = $s;
						}
						else{
							igk_debug_wln("can't changed parent");
						}
					}
				}
				break;				
				default : 
					$ctrl->Configs->$k = $s;
				break;
			}
		}	
		$ctrl->storeDBConfigsSetting();
		igk_notifyctrl()->addMsg(R::ngets("msg.ctrlsettingupdated_1" , $ctrl->Name));
		
		if ($ctrl->Configs->clParentCtrl != $oldparent)
		{
			igk_sys_viewctrl($oldparent);
		}
		igk_ctrl_viewparent($ctrl);
		if (igk_is_confpagefolder())
		{
			igk_frame_close(igk_getr("frame_name"));
		}
		else
			$this->ca_edit_ctrl_properties_ajx(false);
		$this->View();
	}
	
	

	//select controller ajx
	public function select_controller_ajx(){
		$this->SelectedController = igk_getr("n");		
		$this->View();
		igk_wl( $this->TargetNode->innerHTML);		
	}
	
	public function ca_ctrl_article_select_lang_ajx(){
		//change the selected language
		$ctrl = igk_getctrl(igk_getr("ctrl"), false);
		$this->m_selectedLang  = igk_getr("n");
		$div =  IGKHtmlItem::CreateWebNode("div");
		$this->_buildViewArticle($div,$ctrl);
		igk_wl($div->innerHTML);
	}
	
	private function setup_defaultpage($ctrltab =null)
	{
		$ctrltab = $ctrltab == null ? igk_get_default_pagesctrl() : $ctrltab;
		$ctrl = igk_getctrl($this->App->Configs->web_pagectrl, false);
		
		if ((count($ctrltab)>0) && ($ctrl ==null))
		{
			$n = $ctrltab[0]->getName();					
			if ($this->App->Configs->web_pagectrl != $n)
			{
				$this->App->Configs->web_pagectrl = $ctrltab[0]->getName();
				igk_save_config();
			}
		}
	}
	
	function __viewDefaultPageCtrl($t)
	{
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("setdefaultpage");
			
			igk_html_add_title($frm, "title.defaultpagectrl");	
			
			$ul = $frm->add('ul');
			$li = $ul->add("li");
			$li->add("label", array("for"=>"clDefaultCtrl"))->Content = R::ngets("lb.defaultpagectrl");
			
			$sl = $li->add("select");
			$sl["id"]=$sl["name"] = "clDefaultCtrl";
			$sl["onchange"]="javascript:window.igk.ajx.post('".$this->getUri('setdefaultpage_ajx&')."'+this.id+'='+this.value, null, null);"; 
			
			$ctrltab = igk_get_default_pagesctrl();
			if (count($ctrltab) == 0)
			{
				$this->App->Configs->web_pagectrl = null;
				$ul->add("li")->add("span")->Content = R::ngets("Warning.NoDefaultController");
			}
			else
			{
				$this->setup_defaultpage($ctrltab);
				
				foreach($ctrltab as $k)
				{
					$opt = $sl->add("option");
					$n = strtolower($k->Name);
					$opt["value"] = $k->Name;
					if ($n == strtolower($this->App->Configs->web_pagectrl))
					{
						$opt["selected"] ="true";
					}
					$opt->Content = $k->getDisplayName();
				}
			}			
			$frm->addDiv()->add("noscript")->addInput("btn_add", "submit");
	}
	function __viewMenuHostCtrl($t)
	{
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("ca_setmenuhost");
			
			$tab = igk_sys_getuserctrls();
			if (igk_count($tab) == 0)
			{
				$frm->add("div")->Content = R::ngets("msg.nocontroller.for.menu");
			}
			else{			
			$frm->add("label", array("for"=>"clCtrlMenuHost"))->Content = R::ngets("lb.MenuHostCtrl");
			$sl = $frm->add("select");
			$sl->setId("clCtrlMenuHost");
			$sl["onchange"]="javascript:window.igk.ajx.post('".$this->getUri('ca_setmenuhost_ajx&')."'+this.id+'='+this.value, null, null);"; 
			
			$sl->add("option",array("value"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
			
			$v_menuhost = $this->App->Configs->menuHostCtrl;
			foreach($tab as $v)
			{				
				//select the first controller				
				$opt = $sl->add("option", array("value"=>$v->getName()));
				if ($v->getName() == $v_menuhost)
				{
					$opt["selected"]="true";
				}
				$opt->Content = $v->getDisplayName();
				
			}
			$frm->addDiv()->add("noscript")->addInput("btn_add", "submit");
			}
	}
	//ca for controller and article
	public function ca_setmenuhost()
	{
		$v_n = igk_getr("clCtrlMenuHost");
		$this->App->Configs->menuHostCtrl = $v_n;
		igk_save_config();
		$this->View();
			//refresh the controller
			
		$ctrl = igk_getctrl($v_n);
		igk_getctrl(IGK_MENU_CTRL)->setMenuhostCtrl($ctrl);		
		igk_sys_viewctrl($v_n);
		
	}
	public function ca_setmenuhost_ajx()
	{
		$this->ca_setmenuhost();
	}
	
	private function _view_ctrl_EditCtrl($t)
	{	
		
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("ca_drop_controller");	
			$frm->add("label")->Content = R::ngets("lb.Controllers");
			$select = $frm->add("select");
			 $select["onchange"]=<<<EOF
javascript: (function(i){ var q = window.igk.getParentById(i, '{$this->TargetNode["id"]}'); window.igk.ajx.post('{$this->getUri('select_controller_ajx&n=')}'+i.value, null, function(xhr){  if (this.isReady()){ this.setResponseTo(q);  var p = q.getElementsByTagName('select')[0]; p.focus(); }})})(this); 
EOF;
			$select["name"]=$select["id"]= "controlleur";
			
			$tab =  igk_sys_getuserctrls();
			if (count($tab) > 0)
			{
			
			foreach($tab as $v)
			{				
				//select the first controller
				if ($this->SelectedController === null)
					$this->SelectedController = $v->getName();
				$opt = $select->add("option", array("value"=>$v->getName()));
				if ($v->getName() == $this->SelectedController)
					$opt["selected"] = "true";
				$opt->Content = $v->getDisplayName();
				
			}
				$ctrl = igk_getctrl($this->SelectedController);
				IGKHtmlUtils::AddImgLnk($frm, igk_js_post_frame($this->getUri("ca_add_ctrl_frame_ajx")), "add");
				$this->_view_ctrl_options($ctrl, $frm);
			}
		
	}
	private function _view_ctrl_options($ctrl, $targetNode)
	{
	
		
		IGKHtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_ctrl_ajx")), "edit");
		IGKHtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_ctrl_properties_ajx")), "setting");
		
		if ($ctrl->CanEditDataTableInfo){
			IGKHtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_db_ajx")), "ico_db");
		}
			
		IGKHtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_ctrl_drop_ajx")), "drop");
	}
	
	public function ca_selectedCtrlChanged()
	{
		$t = $this->getParam("ctrl:ca_tabInfo");
		if ($t !=null)
			$t->ClearChilds();
		//reset table info
		$this->setParam("ctrl:ca_tabInfo",null);
	}
	public function ca_update_dbdata()
	{
		$obj = igk_get_robj();
		
		$e =  IGKHtmlItem::CreateWebNode("DataDefinition");
		$e["TableName"] = igk_getr("clTableName");
		unset($obj->clTableName);
		$v_kexist = array();
		for ($i = 0; $i < igk_count($obj->clName); $i++)
		{
			if (empty($obj->clName[$i]) || isset($v_kexist[$obj->clName[$i]]))
				continue;
				
			$v_kexist[$obj->clName[$i]] = 1;
			$cl = $e->add("Column");
			foreach($obj as $k=>$v)
			{
				$cl[$k] = $v[$i];
			}			
		}
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		igk_io_save_file_as_utf8($f, $e->Render((object)array("Indent"=>true)));		
		igk_frame_close("add_edit_db_frame");
		
		//reset table info
		$this->setParam("ctrl:ca_tabInfo",null);
		$this->View();
	}
	///<summary>request edit data base with ajx </summary>
	public function ca_edit_db_ajx()
	{
		//edit db frame
		
		$ctrl = igk_getctrl($this->SelectedController);
		if ($ctrl==null)
			return;
		$frame = igk_add_new_frame($this, "add_edit_db_frame");
		$frame->Title = R::ngets("title.editdbArticle", $this->SelectedController );
		$d = $frame->Content;
		$d->ClearChilds();
		
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("ca_update_dbdata");
		$div = $frm->addDiv();
		$div["style"]="max-width:824px; max-height:400px; min-height: 200px;  overflow:auto;";
		
		$ul = $div->add("ul");
		$ul->Index = -10;
		$ul->add("li")->addSLabelInput("clTableName", "text", $ctrl->DataTableName);
		
		$t = $this->ca_getTableInfo();		
		
		$div->add($t);
		
		$frm->addHSep();
		$div = $frm->addDiv();
		$a = IGKHtmlUtils::AddImgLnk($div,"#", "add");
		$a->a["onclick"] =  igk_js_ajx_post_auri($this->getUri("ca_addfield_ajx"),"window.igk.ctrl.ca_update");
		$a = IGKHtmlUtils::AddImgLnk($div,"#", "drop");
		$a->a["onclick"] =  igk_js_ajx_post_auri($this->getUri("ca_ClearTableList_ajx"),"window.igk.ctrl.ca_updatetable");
	
		
		$frm->addInput("btn.update", "submit",  R::ngets("btn.update"));
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		if (file_exists($f)){
			$frm->addInput("btn.update", "button",  R::ngets("btn.dropdb"))
			->setAttribute("onclick", igk_js_ajx_post_auri("ca_db_drop_db_file_ajx"));
		}
		igk_wl($frame->Render());
		
	}
	public function ca_db_drop_db_file_ajx(){
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		if (file_exists($f)){
			unlink($f);
			$this->View();
			igk_frame_close("add_edit_db_frame");
		}
		igk_exit();
	}
	public function ca_getTableInfo()
	{		
		$t = $this->getParam("ctrl:ca_tabInfo");
		$table = null;
		if ($t !=null)
			return $t;
		else 
			$table =  IGKHtmlItem::CreateWebNode("table");

			
		
		$ctrl = igk_getctrl($this->SelectedController);

		$tr = $table->add("tr");
		$t = IGKdbColumnInfo::GetColumnInfo();
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($t as $v=>$k)
		{
			$tr->add("th")->Content = R::ngets($v);
		}
		$tr->add("th")->Content = IGK_HTML_SPACE;	
		
		
		
		if (file_exists($ctrl->getDBConfigFile()))
		{
			$tab = $ctrl->getDataTableInfo();
			foreach($tab as $k)
			{				
				$table->add( $this->ca_getFieldInfo($k));
			}
			
		}
		else{
			$info = IGKdbColumnInfo::NewEntryInfo();
			$info->clIsPrimary = true;
			$table->add( $this->ca_getFieldInfo($info));
		}
		$this->setParam("ctrl:ca_tabInfo", $table);
		return $table;
	}
	public function ca_getFieldInfo($info)
	{
		$tr =  IGKHtmlItem::CreateWebNode("tr");
		$tr["__id"] = igk_new_id();
		$tr->add("td")->Content = IGK_HTML_SPACE;
		foreach($info as $v=>$k)
		{
			$td = $tr->add("td");
			switch(strtolower($v))
			{
				case "clisunique":
				case "clautoincrement":
				case "clisprimary":
				case "clisindex":
				case "clnotnull":
				case "clisuniquecolumnmember":
				case "clisnotinqueryinsert":
					//$td["class"]="alignc";
					$c = $td->add("div", array("class"=>"dispb fitw", "style"=>"text-align:center;"))->addInput("__cl".$v."[]","checkbox", null, array("onchange"=>"javascript:(function(q){window.igk.ctrl.ca_update_checkchange(q, '".$v."[]');})(this);"));
					if ($k) 
						$c["checked"]="true";
					$td->addInput($v."[]", "hidden", $k);
					break;
				case "cltype":
					//igk_html_build_select($target, $name, $tab, $attributes=null, $selectedvalue = null, $attr=null)
					igk_html_build_select($td, $v."[]",  IGKdbColumnDataType::GetDbTypes() ,
					null,
					$k); 
					break;
				default:
				$i = $td->addInput($v."[]","text", $k);
				$i["class"]="-cltext";
				$i["style"]="max-width:125px;";
				break;
			}
		}
		IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("ca_dropfield&n=".$tr["__id"]), "drop");
		
		return $tr;
	}
	public function ca_addfield_ajx()
	{			
		$c = $this->ca_getFieldInfo(IGKdbColumnInfo::NewEntryInfo());	
		if ($table = $this->getParam("ctrl:ca_tabInfo"))
		{
			igk_html_add($c, $table);
		}
		igk_wln($c->Render());
	}
	public function ca_dropfield()
	{
		$n = igk_getr("n");
		$table = $this->getParam("ctrl:ca_tabInfo");
		$tr = $table->getElementByAttribute("__id", $n);
		if ($tr)
		{		
			igk_html_rm($tr);
		}
	}
	public function ca_ClearTableList_ajx()
	{
		$this->setParam("ctrl:ca_tabInfo", null);
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		if (file_exists($f))
			@unlink($f);
		igk_wl($this->ca_getTableInfo()->Render());
	}
	
	/*
	*CTRL ARTICLE AND CONFIGURATION VIEW ARTICLE
	*/
	public function View(){
		//VIEW: CTRLANDARTICLE
		$t = $this->TargetNode;
		if ($this->getIsVisible())
		{

					
			IGKHtmlUtils::AddItem($t, $this->ConfigNode);
			$t->ClearChilds();			
			
			igk_html_add_title($t, "title.ControllerManager");
			$t->addHSep();
			igk_add_article($this, "controller_and_article", $t->addDiv(), null,true);
			$t->addHSep();
			//add default form ctrl
				
			$this->_view_ctrl_EditCtrl($t);
			$t->addHSep();
			$this->__viewDefaultPageCtrl($t);
			$this->__viewMenuHostCtrl($t);
			
			$t->addHSep();
			
			$dv = $t->addDiv();
			$dv["class"] = "controller_info";
		    $this->_view_ctrl_info(igk_getctrl($this->SelectedController), $dv);
			
			$frm = $t->addForm();
			$frm->addBr();
			
			$frm->addBtn("btn_remove", R::ngets("btn.removeController") , "submit", array(
			"onclick"=>
			"javascript: return window.igk.ctrl.confirm_frame(this,'".
			R::ngets(IGK_MSG_DELETEFILE_QUESTION,$this->SelectedController)->getValue().
			"', '".$this->getUri("drop_controller") .
			"');"));
			
			$frm->addInput("confirm", "hidden", 0);			
			IGKHtmlUtils::AddBtnLnk($frm, "btn.addcontroller",  igk_js_post_frame($this->getUri("ca_add_ctrl_frame_ajx")) );
			IGKHtmlUtils::AddBtnLnk($frm, "btn.showcontrollerview", igk_js_post_frame( igk_getctrl(IGK_CONF_CTRL)->getUri("cc_view_controllerschema_ajx")));
			
			$t->addHSep();			
			$this->_buildViewArticle($t);
			$t->addHSep();			
			$this->_buildViewView($t);
			
			$this->TargetNode->addScript()->Content = <<<EOF
window.igk.system.createNS("igk.fn.config", {select_ctrl: function(i, targetid, uri){var q = window.igk.getParentById(i, targetid ); window.igk.ajx.post(uri, null, function(xhr){  if (this.isReady()){ this.setResponseTo(q); var p = q.getElementsByTagName('select')[0]; p.focus(); }})}});
EOF;
			
		}
		else{
			$this->TargetNode->ClearChilds();
			igk_html_rm($this->TargetNode);
		}
		
	}
	public function _buildViewView($div,$ctrl=null)
	{	
		igk_html_add_title($div, "title.Views");
		$this->ca_viewViewFiles($div, $ctrl);
	}
	
	
	public function ca_remove_child()
	{
		$ctrl = igk_getctrl(igk_getr("clParentCtrl"));
		$p = igk_getctrl(igk_getr("clChild"));
		
		if (!$ctrl || !$p)
			return;			
		IGKApp::$DEBUG = true;	
		$p->setWebParentCtrl(null, true);		
		$ctrl->unregChildController($p);		
		IGKApp::$DEBUG = false;
		$this->View();
	}
	public function ca_remove_parent()
	{
		$ctrl = igk_getctrl(igk_getr("clCtrl"));
		$p = igk_getctrl(igk_getr("clParent"));
		
		if (!$ctrl || !$p)
			return;			
		IGKApp::$DEBUG = true;				
		$p->unregChildController($ctrl);		
		$ctrl->setWebParentCtrl(null, true);	
		IGKApp::$DEBUG = false;
		$this->View();
	}
	
	private function _view_ctrl_info($ctrl, $target)
	{
		if ($ctrl==null)
			return;
			
		$p = $target->addDiv();
		$p["class"]="igk-cnf-ctrl-info";
		$p->addDiv(array("class"=>"igk-cnf-selected-ctrl"))->Content = $this->SelectedController;
		
		$p->addDiv()->Content = R::ngets("Q.ISWEBPAGECTRL_1", igk_parsebools(igk_reflection_class_extends(get_class($ctrl), "IGKDefaultPageCtrl" ))->getValue());
		$p->addDiv()->Content = R::ngets("lb.CtrlType")->getValue() . " : ". igk_sys_ctrl_type($ctrl);
		
		$p->addBr();
		$table = $p->addTable();
		$t = $table->add("tr");
		$t->add("th")->Content = R::ngets("title.Parent");
		$t->add("th")->Content = IGK_HTML_SPACE;
		
		if ( $ctrl->Configs->clParentCtrl != null)
		{
			$tr = $table->add("tr");
			$tr->add("td")->add("li")->add("a", array("href"=>"#", "onclick"=>"javascript:window.igk.fn.config.select_ctrl(this, '".$this->TargetNode["id"]."', '".$this->getUri('select_controller_ajx&n='.$ctrl->Configs->clParentCtrl)."'); "))->Content = $ctrl->Configs->clParentCtrl;
			IGKHtmlUtils::AddImgLnk($tr->add("td",array("style"=>"min-with:16px; min-height:16px;")),$this->getUri("ca_remove_parent&clCtrl=".$ctrl->getName()."&clParent=".$ctrl->Configs->clParentCtrl), "drop");
		}
		else {
			$tr = $table->add("tr");
			$tr->add("td" ,array("colspan"=>2))->Content =  R::ngets("msg.noparent");
			
		}
		
		$p->addBr();
		$table = $p->addTable();
		$tr = $table->add("tr");
		$tr->add("th")->Content = R::ngets("title.Childs");
		$tr->add("th")->Content = R::ngets("title.index");
		$tr->add("th", array("style"=>"width:16px"))->addSpace();
		
		if (igk_count($ctrl->Childs) > 0)
		{
	
			$tab = $ctrl->Childs;
			
			usort($tab, "igk_sort_byNodeIndex");
			
			foreach($tab as $k)
			{
				$tr = $table->add("tr");
				$tr->add("td")->add("a", array("href"=>IGK_JS_VOID,"onclick"=>"javascript:window.igk.fn.config.select_ctrl(this, '".$this->TargetNode["id"]."', '".$this->getUri('select_controller_ajx&n='.$k->Name)."'); return false; "))->Content = $k->Name; 				
				$tr->add("td")->Content = $k->TargetNode->Index;
				IGKHtmlUtils::AddImgLnk($tr->add("td",array("style"=>"min-with:16px; min-height:16px;")),$this->getUri("ca_remove_child&clParentCtrl=".$ctrl->Name."&clChild=".$k->Name), "drop");
			}
		}
		else {
			$tr = $table->add("tr");
			$tr->add("td",array("colspan"=>3))->Content = R::ngets("msg.nochilds");
		}		
		$p->addHSep();
		//additional info entertaiment
		$table = $p->addTable();
		$tr = $table->add("tr");
		$tr->add("th")->Content = R::ngets("lb.properties");
		$tr->add("th")->Content = R::ngets("lb.values");
		
		
			foreach($ctrl->Configs as $k=>$v)
			{
				if ($k == "clParentCtrl")
					continue;
				$tr = $table->add("tr");
				$tr->add("td")->add("label")->Content =R::ngets( "lb.".$k);
				$tr->add("td")->add("label")->Content = $v;			
			}
		//add controller info options
		$div =  $p->addDiv();
		$this->_view_ctrl_options($ctrl, $div);
	}
	//drop controller ajx function
	public function ca_ctrl_drop_ajx()
	{
		$this->ca_drop_controller_ajx($this->SelectedController);
	}	
	public function ca_add_article_frame()
	{
		$ctrl = (($c = igk_getctrl( igk_getr("ctrlid", null), false))!=null)? $c: $this->SelectedController;	
		if ($ctrl == null)
		{
			igk_notifyctrl()->addMsg("no controller selected");
			return null;
		}	
		$frame = igk_add_new_frame($this, "add_article_frame", "#article");
		$frame->Title = R::ngets("title.addArticle", $this->m_selectedLang );
		$this->m_selectedLang = igk_getr("clLang", $this->m_selectedLang );
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("ca_add_article");
		$frm->addSLabelInput(IGK_FD_NAME);
		$frm->addBr();
		$lg = $this->m_selectedLang?$this->m_selectedLang:"fr";
		$frm->add("label")->Content = R::ngets("lb.currentlang",$lg );
		$frm->addInput("clLang", "hidden", $lg);		
		$frm->addInput("clCtrl", "hidden", $ctrl->Name);	
		$frm->addBr();
		$txt = $frm->addTextArea("clContent", null);
		igk_js_enable_tinymce($frm);
		$frm->addHSep();
		$frm->addBtn("btn_save", R::ngets("btn.save"));
		return $frame;
	}
	public function ca_add_article_frame_ajx()
	{
		$frame = $this->ca_add_article_frame();
		if ($frame){
			$frame->RenderAJX();
		}
	}
	
	public function add_viewframe(){
		$frame = igk_add_new_frame($this, "add_view_frame");
		$frame->Title = R::ngets("title.addView");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("add_view");
		$frm->addSLabelInput(IGK_FD_NAME);
		$frm->addBr();
		$frm->addTextArea("clContent");
		$frm->addHSep();
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	public function IsFunctionExposed($funcname)
	{
		if ("ca_view_body_ajx" == $funcname)
			return true; //available on external context
		return parent::IsFunctionExposed($funcname);
	}
	public function ca_view_body_ajx()
	{
		$uri = base64_decode(igk_getr("uri"));
		igk_loadr($uri);	
		//load connection uri
		if ($this->App->getControllerManager()->InvokeUri($uri, false))
		{
			$this->App->getControllerManager()->ViewControllers();
			$this->App->Doc->body->RenderAJX();		
		}
	}
	public function ca_drop_controller_ajx($ctrl=null)
	{	
		$a = $ctrl? $ctrl: (($ctrl = igk_getr("clController")) ? $ctrl :  igk_getr("n"));
		
		if ($a)
		{
			$ctrl = igk_getctrl($a,false);
			if ($ctrl == null)
				return;
		
			$is_ajx = (igk_sys_isAJX());
			if (igk_qr_confirm())
			{		
				if ($ctrl->canDelete)
				{		
					$uri = igk_getctrl(IGK_CONF_CTRL)->getReconnectionUri();				
					igk_getctrl(IGK_CTRL_MANAGER)->removeController($a);	
					$this->SelectedController = null;
					$this->View();
					//Clear an reconnect
					$ctrl = igk_getctrl(IGK_CONF_CTRL);	
					if ($is_ajx)
					{												
						$index = igk_io_currentRelativePath("index.php");						
						if ($this->CurrentPageFolder != IGK_CONFIG_PAGEFOLDER)
						{	
							$uri = "./".$this->getUri("ca_view_body_ajx&uri=".base64_encode($uri."&navigate=0"));													
						}
						else
							$uri.= "&navigate=1";
						
						session_destroy();
						igk_navtocurrent($uri);	
						igk_exit();
					}
					else {
						$ctrl->ClearSessionAndReconnect(false);
					}
				}
				else{
					$this->msbox->addError("impossible de supprimer le controller. cela peut entrainer des incohérences");
				}
			}
			else{
				$frame = igk_frame_add_confirm($this, "drop_controller_frame", $this->getUri("ca_drop_controller_ajx"));				
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETECTRL_QUESTION, $a);
				$frame->Form->addInput("clController", "hidden", $a);
				$frame->Form->addInput("forceview", "hidden", igk_getr("forceview",null));//force view to force current view
				if (igk_sys_isAJX())
				{
					$frame->Form->addInput("ajx", "hidden", "1");					
					$frame->RenderAJX();
				}				
			}
		}
		
	}
	
	public function _buildAdditionalInfo($ctrl, $p)
	{
		$d = null;
		if (is_object($ctrl))
		{
			$n = igk_sys_ctrl_type($ctrl);
			$d = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $n);
		}
		else if (is_string($ctrl))
		{
			$d = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $ctrl);
		}
		if ($d==null)
			return;
			
		$tab = call_user_func( array($d, "GetAdditionalConfigInfo"));
	if (is_array($tab))
		{
			foreach($tab as $k=>$v)
			{				
				if (is_object($v))
				{
					$li = $p->add("li");
					$li->addLabel("lb.".$k, $k);
					$defaultv = igk_getv( igk_getv($ctrl, "Configs"),$k,  igk_getv($v, "clDefaultValue"));
					switch(strtolower($v->clType))
					{
						case "select":
							igk_html_build_select($li, $k, $v->clValues, null, $defaultv, null);
							break;
						case "file":
							break;
						case "bool":
							$chk = $li->addInput($k, "checkbox", "1");
							if ($defaultv == 1)
								$chk["checked"] = new IGKHtmlNoValueAttribute();
							break;
						default :
							$li->addInput($k, "text",   $defaultv );
							break;
					}
					
				}
				else{
					$p->add("li")->addSLabelInput($v, "text",  igk_getv( igk_getv($ctrl, "Configs"), $v) );
				}
			}
		}
	}
	public function ca_get_ctrl_type_info_ajx()
	{
		$p = $this->getParam("ca:view_frame");
		$n = igk_getr("n");
		if ($p != null)
		{
			$p->ClearChilds();				
			$this->_buildAdditionalInfo($n, $p);
			$p->RenderAJX();
		}
		else{
			igk_notifybox_ajx("no [ca:view_frame] setup");
		}		
	}
	
	//add controller frame
	public function ca_add_ctrl_frame_ajx($renderframe=true)
	{			
		$frame = igk_add_new_frame($this, "add_ctrl_frame");		
		$frame->Title = R::ngets("title.AddController");		
		$frame->Content->ClearChilds();
		$frm = $frame->Content->addForm();
		$frm["action"]= $this->getUri("ca_add_ctrl"); 		
		$nid = $this->TargetNode["id"];
		
		$js_change_func = <<<EOF
(function(q){ if (!q)return; window.igk.ajx.post('{$this->getUri("ca_get_ctrl_type_info_ajx&n=")}'+q.value,null,function(xhr){if (this.isReady()){ 	var s = \$igk(q.form).getChildById('view_frame');  this.setResponseTo(s); }});})
EOF;
		
		$frm["onsubmit"]= "javascript: window.igk.ajx.postform(this,'".$this->getUri("ca_add_ctrl_ajx")."', ns_igk.ajx.fn.append_to_body, false ); this.reset(); return false;";
		
		$frm->add("li")->addSLabelInput(IGK_FD_NAME,"text", null,null, true);
		$frm->add("li")->addSLabelInput("clDisplayName");
		$h = $frm->add("li")->addSLabelInput("clRegisterName");
		$h->input["tooltip"] = R::ngets("tooltip.controller.registername");
		$li = $frm->add("li");
		$li->add("label", array("for"=>"clCtrlType"))->Content = R::ngets("lb.ctrlType");		
		//controller type
		$t = array_keys(IGKCtrlTypeManager::GetControllerTypes());
		sort($t);
		$sel = igk_html_build_select($li, "clCtrlType", $t, null, "DefaultPage");
		
		$sel["onchange"]="javascript:{$js_change_func}(this);";
		$p = $this->getParam("ca:view_frame");
		if ($p == null)
		{
			$p = $frm->addDiv();
			$p->setId("view_frame");		
			$p["class"] = "igk-ctrl-additionnal-properties";
			$this->setParam("ca:view_frame", $p);	//node to render view frame
		}
		$p->ClearChilds();
		igk_html_add($p, $frm);		
		//table to view parent controller list
		$li = $frm->add("li");	
		$this->_frm_tablevisiblectrl($li, "clParentCtrl");
		$this->_ca_add_adapter($frm->add("li"), "clDataAdapterName", IGK_MYSQL_DATAADAPTER);
		$frm->add("li")->addSLabelInput("clTargetNodeIndex");
		$frm->add("li")->addSLabelInput("clVisiblePages");
		$frm->add("li")->addSLabelInput("clDescription");
		
		
		$frm->addHSep();
		$frm->addInput("confirm", "hidden", "1");
		$frm->addBtn("btn_add", R::ngets("btn.Add"));			
$frm->addScript()->Content = <<<EOF
(function(){
var r = \$igk(\$ns_igk.getParentScriptForm());
if (!r)return;
 (function(q){ if (!q)return;
 var p = q.select("#liPageName");
 var c = q.select("#clWebPage");
 if (c && p)
	c.reg_event("change",function(){ if (this.checked) p.css('display:block;'); else p.css('display:none'); });})(r);
 {$js_change_func}((r).select("#clCtrlType").getItemAt(0));
})();
EOF;
		if ($renderframe)
		{
			$frame->RenderAJX();
		}
		return $frame;
	}
	private function _frm_tablevisiblectrl($li, $name, $value =null, $showspace=true)
	{
		
		$tab =  igk_sys_getuserctrls();
		if (count($tab) > 0)
		{
			$li->add("label")->Content = R::ngets("lb.parentctrl");
			$sel = $li->add("select");	
			$sel["id"]=$sel["name"] = $name;
			if ($showspace)
				$sel->add("option", array("value"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
			foreach($tab as $v)
			{	
				$opt = $sel->add("option", array("value"=>$v->getName()));
				$opt->Content = $v->DisplayName;
				if ($value && !$value == $v->getName())
				{
					$this->value = $v->getName();
				}
			}
		}
	}
	//add controller ajx method
	public function ca_add_ctrl_ajx()
	{
		if (igk_qr_confirm() && $this->ConfigCtrl->IsConnected)
		{			
			$parentCtrl =  igk_getr("clParentCtrl",null);
			if (igk_getctrl(IGK_CTRL_MANAGER)->add_ctrl(igk_getr("clWebPage",false),$parentCtrl ))
			{	
				igk_notifyctrl()->addMsgr("msg.controllerupdate");
				if ($parentCtrl && ($p  = igk_getctrl($parentCtrl))){
					//reload the parent view
					$p->View();
				}
			}
			igk_resetr();			
			$this->View();
			$frame = igk_get_frame("add_ctrl_frame");
			if (!$frame)
			{
				$this->setParam("ca:view_frame",null);
			}
			$this->ca_add_ctrl_frame_ajx(false);
			igk_notifyctrl()->notify_ajx();
		}
	}
	public function ca_add_ctrl(){//add a controller 
		if (igk_qr_confirm() && $this->ConfigCtrl->IsConnected)
		{			
			igk_getctrl(IGK_CTRL_MANAGER)->add_ctrl(igk_getr("clWebPage",false), igk_getr("clParentCtrl",null));		
			igk_resetr();		
			$this->setParam("ca:view_frame",null);
			//force the create of a new frame 
			$this->ca_add_ctrl_frame_ajx(false);
			$this->View();
		}
		igk_navtocurrent();
	}
	
	public function ca_add_article(){//add article frame
		$ctrl = igk_getr("clCtrl");
		$name = igk_getr(IGK_FD_NAME);
		$content = igk_getr("clContent");
		$lang = igk_getr("clLang", igk_sys_getconfig("default_lang","fr"));
		$e =  IGKHtmlItem::CreateWebNode("error");
		if (IGKValidator::IsStringNullOrEmpty($name)){ $e->add("li")->Content = "name not defined";}
		//if (IGKValidator::IsStringNullOrEmpty($content)){ $e->add("li")->Content = "Content not defined";}
		if (IGKValidator::IsStringNullOrEmpty($lang)){ $e->add("li")->Content = "Language not define";}
		
		if (!$e->HasChilds)
		{
			$obj_ctrl = igk_getctrl($ctrl);
		
			if ($obj_ctrl == null)
			{
				igk_show_prev($_REQUEST);
				die("not controller found");
			}
				
			//$d = dirname($obj_ctrl->getDeclaredFileName());
			$a = $obj_ctrl->getArticlesDir();//$d."/Articles";
			IGKIO::CreateDir($a);
			//matched template file our
			$file = igk_io_get_article_file($name, $a, $lang);
		
			if ($this->__write_article_for_tiny($file, igk_html_unscape($content)))
			{
				igk_resetr();
				igk_setr("controlleur", $ctrl );
			
			}
			else{
				igk_notifyctrl()->addErrorr("err.filenotsaved");
			}
			$obj_ctrl->View();
		}
		else{
			$this->msbox->copyChilds($e);
		}
		$this->View();
		//igk_navtocurrent();
	}
	
	public function add_view(){
		$n = igk_getr(IGK_FD_NAME);
		$ctrl = $this->SelectedController;
		$content = igk_getr("clContent");
		$this->val->ClearChilds();
		
		if (IGKValidator::IsStringNullOrEmpty($n)){ $this->val->add("li")->Content = "Name not defined";}
		
		if (!$this->val->HasChilds)
		{
			
			$a = igk_getctrl($ctrl)->getViewDir();
			if (IGKIO::CreateDir($a)){
				$file =$a."/".$n.".phtml";
				IGKIO::WriteToFileAsUtf8WBOM($file, igk_html_unscape($content), true);						
			}
		}
		else{
			$this->msbox->copyChilds($this->val);
		}
		$this->View();
		igk_navtocurrent();		
	}

	public function getConfigPage()
	{
		return "articleconfig";
	}
	protected function InitComplete(){
		parent::InitComplete();
		$this->setup_defaultpage();
	}
	public function __construct(){
		parent::__construct();
		$this->m_SelectedController = null;
		$this->m_SelectedControllerChangedEvent = new IGKEvents($this, "SelectedControllerChanged");
		$this->m_SelectedControllerChangedEvent->add($this, "ca_selectedCtrlChanged");
	}
}


//File Manager
final class IGKFileManagerCtrl extends IGKConfigCtrlBase
{
	private $m_directory;
	
	public function fm_updatefile()
	{
		$url = igk_getr("uri");
		$content = igk_getr("content");
		if (($url == null) || is_file($url))
		{
				return;
		}
		IGKIO::WriteToFileAsUtf8WBOM($url, $content , true);		
	}
	public function createfile()
	{
		$url = igk_getr("uri");
		if (($url == null) || is_file($url))
		{
				return;
		}
		IGKIO::WriteToFileAsUtf8WBOM($url, IGK_STR_EMPTY, true);		
	}
	public function getConfigPage()
	{
		return "filemanager";
	}
	
	public function __construct(){
		parent::__construct();
	}
	public function loadfiles_frame()
	{
		$frame = igk_add_new_frame($this, "upload_files_frame");
		$frame->Content->ClearChilds();
		$frame->Title = R::ngets("title.loadFilesFrames");
		$frame->Width = "300px";
		$d = $frame->Content;
		$frm  = $d->addForm();
		$frm["action"] = $this->getUri("loadfiles");
		
		$frm->addFile("clFile", true);
		$frm->addInput("MAX_FILE_SIZE", "hidden", "15000000");
		$frm->addHSep();
		$frm->addBtn("btn_confirm", R::ngets("btn.upload"));
	}
	public function createdir_frame()
	{
		$frame = igk_add_new_frame($this, "createdir_frame");
		$frame->Title = R::ngets("title.createDirFrame");
		$frame->Content->ClearChilds();
		$frame->Width = "300px";
		$d = $frame->Content;
		$frm  = $d->addForm();
		$frm["action"] = $this->getUri("createdir");
		
		$frm->addSLabelInput(IGK_FD_NAME);
		$frm->addHSep();
		$frm->addBtn("btn_confirm", R::ngets("btn.create"));
	}
	public function createdir()
	{
		$ndir = igk_getr(IGK_FD_NAME);
		if (empty($ndir))
			return;
		$path = igk_io_getdir(igk_io_currentRelativePath($this->m_directory)."/".$ndir);
		if (!is_dir($path))
		{
			mkdir($path);
			$this->View();
		}
	}
	public function loadfiles()
	{
		$t = igk_getv($_FILES,"clFile");		
		$path = igk_io_currentRelativePath($this->m_directory);
		igk_frame_close("upload_files_frame");
		$error = false;
		if (is_array($t["name"]))
		{
			for($i =0; $i< count($t["name"]) ; $i++)
			{
				if ($t["error"][$i] == 0)
				 {
				move_uploaded_file($t["tmp_name"][$i], igk_io_getdir($path."/".$t["name"][$i]));
				}
				else{
					igk_notifyctrl()->addError("can't upload file [".$t["name"][$i]."] error : ".$t["error"][$i]." " .ini_get("upload_max_filesize")." file is authorized" );
					$error = true;
				}
			}
		}
		else{
			if ($t["error"]==0)
			{
				move_uploaded_file($t["tmp_name"], igk_io_getdir($path."/".$t["name"]));
				$error = true;
			}
		}
		if (!$error)
		{
			igk_notifyctrl()->addMsgr("MSG.FileUploadSuccess");
		}
		$this->View();
		igk_navtocurrent();
		
	}
	
	
	public function View()
	{
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$c = $this->TargetNode;
		
		IGKHtmlUtils::AddItem($c, $this->ConfigNode);
		$c->ClearChilds();
		
		$d = $c->addDiv();
		igk_html_add_title($d, "title.FileManager");
		$d->addHSep();
		igk_add_article($this, "filesystem.description", $d->addDiv());
		$d->addHSep();
		//action list
		IGKHtmlUtils::AddBtnLnk($d, R::ngets("btn.loadFiles") , $this->getUri("loadfiles_frame"));		
		IGKHtmlUtils::AddBtnLnk($d, R::ngets("btn.createDir") , $this->getUri("createdir_frame"));
		$d->addHSep();		
		//show path list
		$sep = explode(DIRECTORY_SEPARATOR , IGKIO::GetDir($this->m_directory));
		if (($count = count($sep))>0)
		{
			$path = $d->addDiv();
			$bs = $d->addDiv()->setClass("igk-breadcrumbs");
			//$path->Content = $this->m_directory;
			$cpath =null;
			$nid = $this->TargetNode["id"];
			for($i = 0; $i<$count; $i++)
			{
				if ($i!= 0){
					$path->add("span", array("class"=>strtolower($this->getName()."_dirseparator")))->Content  = "&gt;";
					$cpath .= DIRECTORY_SEPARATOR;
				}
				$cpath .=  $sep[$i];
				$bs->add("li")->addA("#")->setAttribute("onclick",
				"javascript:ns_igk.ajx.post('".
					$this->getUri("gotoparent_ajx&n=".($count-$i-1))."', null, ns_igk.ajx.fn.replace_content(ns_igk.getParentById(this, '".
					$nid .
					"'))); return false; ")->Content  =$sep[$i];
				$path->add("span",  array("class"=>strtolower($this->getName()."_dir")))->add("a", 
				array(
					//"href"=>$this->getUri("open_fulldir&d=".urlencode($cpath)),
					"onclick"=>"javascript: (function(i){var q= window.igk.getParentById(i, '".
					$nid ."'); if (q){ window.igk.ajx.post('".
					$this->getUri("gotoparent_ajx")."', null, function(xhr){ if (this.isReady()){ q.innerHTML = xhr.response;}});}})(this); return false;",
					)
				)->Content  = $sep[$i];
			}
		
		}
		//
		$this->_showdir($this->m_directory);
		
	}
	public function open_fulldir()
	{
		$this->m_directory = igk_getr("d");
		$this->View();
	}
	public function open_fulldir_ajx()
	{
		$this->open_fulldir();
		igk_wl($this->TargetNode->innerHTML);		
	}
	
	
	private function _showdir($dir)
	{
		$path = igk_io_currentRelativePath($dir?$dir: "");
		//protection
		if (!is_dir($path))
		{
			$s = realpath(igk_io_currentRelativePath(""));
			igk_debug(true);
			igk_wln("not a dir ".$path. " ? ".$dir ." :: ".igk_io_currentRelativePath(""));
			igk_debug(false);
			igk_notifyctrl()->addErrorr("e.notadirectory_1", $path);
			//$this->m_directory = null;
			if (!is_dir($s))
			{
				return;
			}
			$this->m_directory = igk_io_basePath($s);
			$path = $this->m_directory;
		}
		$tab = $this->TargetNode->addTable()->setClass("config-file_listview");
		$tr = $tab->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = R::ngets("clSize");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		
		
		$hdir = opendir($path);
		$cangotoperent = false;
		if ($hdir)
		{
			$files = array();
			$dirs = array();
			while(($cdir = readdir($hdir)))
			{
				if (($cdir==".") || ($cdir== ".."))
				{			
					if (($dir!=null) && ($dir != '/') && ($cdir =="..") && ($dir!="."))
					{	
						$cangotoperent = true;
					}
					continue;
				}
				
				$cf = igk_io_getdir($path."/".$cdir);
				if (is_dir($cf))
				{
					$dirs[$cdir] = $cf;
				}
				else if (is_file($cf))
				{
					$files[$cdir] = $cf;
				}
			}			
			closedir($hdir);
			
			//sorlist 
			igk_array_sortkey($files);
			igk_array_sortkey($dirs);
			
			if ($cangotoperent)
			{	
				$tr = $tab->add("tr");
				$tr->add("td")->Content = IGK_HTML_SPACE;
				$tr->add("td", array("colspan"=>"6"))->add("li")->add("a", array(
				"href"=>$this->getUri("gotoparent"),
				"onclick"=>"javascript: (function(i){var q= window.igk.getParentById(i, '".$this->TargetNode["id"].
				"'); if (q){ window.igk.ajx.post('".$this->getUri("gotoparent_ajx")."', null, function(xhr){ if (this.isReady()){ q.innerHTML = xhr.response; }});}})(this); return false;",
				"class"=>"config-fileviewdir"))->Content ="..";
				
			}	
			
			foreach($dirs as $k=>$v)
			{
	
			$f = base64_encode(urldecode($k));
				$tr = $tab->add("tr");
				
						$li = $tr->add("td",array("style"=>"width:16px;"))->add("li");
				$li->addInput(IGK_STR_EMPTY, "checkbox",null,null);
				
				$tr->add("td")->add("li")->add("a", array(
					"href"=>$this->getUri("opendir&d=".urldecode($k)),
					"class"=>"config-fileviewdir",
					"onclick"=>"javascript:(function(i){var q= window.igk.getParentById(i, '".$this->TargetNode["id"]."');if (q){ window.igk.ajx.post('".$this->getUri("opendir_ajx&d=".urldecode($k)).
					"', null, function(xhr){ if (this.isReady()){ this.setResponseTo(q); window.igk.winui.saveHistory(i.href);}}); return false;}})(this); return false;"))->Content = $k;
					
				$tr->add("td",array("style"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
				$tr->add("td",array("style"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
				IGKHtmlUtils::AddImgLnk($tr->add("td",array("style"=>"min-with:16px; min-height:16px;")),$this->getUri("change_authorisation&d=".$f),"ico_auth");
				
				if (IGKIO::IsDirEmpty($v)){
					
					
					IGKHtmlUtils::AddImgLnk($tr->add("td",array("style"=>"with:16px; height:16px;")),$this->getUri("drop_dir_or_file&d=".$f),"drop");
				}
				else
					$tr->add("td")->Content = IGK_HTML_SPACE;
				$tr->add("td",array("style"=>IGK_STR_EMPTY))->Content = IGK_HTML_SPACE;
			}
			//select|filename|size|edit|changeautorisation|drop
			foreach($files as $k=>$v)
			{
				$f = base64_encode(urldecode($k));
				$tr = $tab->add("tr");
				
				$li = $tr->add("td", array("style"=>"width:16px;"))->add("li");
				$li->addInput(IGK_STR_EMPTY, "checkbox",null, null);
				$li = $tr->add("td")->add("li");
				$li->add("a", array("href"=>$this->getUri("getfile&d=".$f),
				"class"=>"config-fileviewfile"))->Content = $k;
				$file = igk_io_currentRelativePath($this->m_directory ."/".$k);
				if (file_exists($file))
				{
					$size = @filesize($file);
					if ($size === false)
					{
						$tr->add("td", array("class"=>"alignr"))->Content = "?";
					}
					else
						$tr->add("td",array("class"=>"alignr"))->Content = IGKIO::GetFileSize( $size);
				}
				else 
					$tr->add("td")->Content = "broken";
				
				IGKHtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("edit&d=".$f),"edit");
				IGKHtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("change_authorisation&d=".$f),"ico_auth");
				IGKHtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("fc_renameframe&d=".$f),"ico_rename");
				IGKHtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px")),$this->getUri("drop_dir_or_file&d=".$f),"drop");
			}
			
			$this->TargetNode->addHSep();
			IGKHtmlUtils::AddBtnLnk($this->TargetNode, R::ngets("btn.rmAll"), $this->getUri("removeAll"));
			igk_html_toggle_class($tab);
		}
	}
	public function fc_renameframe()
	{
		$d = urldecode(base64_decode(igk_getr("d")));
		$frame = igk_frame_add_confirm($this, "rename_file_frame", $this->getUri("fc_rename"));		
		$frame->Title = R::ngets("title.renamefile",$d);
		$div = $frame->Form->Div;		
		$div->addInput("d", "hidden", igk_getr("d"));
		$div->addSLabelInput(IGK_FD_NAME, IGK_FD_NAME, "text", $d);
		
		
	}
	//rename file
	public function fc_rename()
	{
		$d = urldecode(base64_decode(igk_getr("d")));
		$e = igk_getr(IGK_FD_NAME);
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		$out = igk_io_currentRelativePath($this->m_directory ."/".$e);
		rename($file, $out);
		$this->View();	
	}
	public function removeAll()
	{
		if (igk_qr_confirm())
		{
		  igk_notifyctrl()->addError("Dont be so .... No Implement ".  __LINE__);
		}
		else{
			$frame = igk_frame_add_confirm($this, "confirm_remove_all", $this->getUri("removeAll"));		
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DROPALL_QUESTION);
		}
	}
	public function change_authorisation()	{//change file authorisation
	
		if (!igk_is_conf_connected())
			return;
		$d = urldecode(base64_decode(igk_getr("d")));
		
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);	
		if (!igk_qr_confirm())
		{
		function addcheckbox($li, $name, $check, $key){
			$li->addInput($name, "checkbox", false, array("checked"=>$check));
			$li->add("label", array("for"=>$name))->Content = R::ngets($key);
		}
		
		$frame = igk_frame_add_confirm($this, "change_authorisation_frame", $this->getUri("change_authorisation"));		
		$frame->Title = R::ngets("title.changeFileAuthorization", $d);
		$div = $frame->Form->Div;
		$div->addDiv()->Content = R::ngets("lb.user");
		$div->addHSep();
		$c = $div->add("ul");
		$perms = @fileperms($file); 
		addcheckbox($c->add("li"),"ur",false,"lb.Read");
		addcheckbox($c->add("li"),"uw",false,"lb.Write");
		addcheckbox($c->add("li"),"ux",false,"lb.Execute");
		
		$div->addDiv()->Content = R::ngets("lb.group");
		$div->addHSep();
		$c = $div->add("ul");
		
		addcheckbox($c->add("li"),"gr",false,"lb.Read");
		addcheckbox($c->add("li"),"gw",false,"lb.Write");
		addcheckbox($c->add("li"),"gx",false,"lb.Execute");
		
		$div->addDiv()->Content = R::ngets("lb.other");
		$div->addHSep();
		$c = $div->add("ul");
		
		addcheckbox($c->add("li"),"or",false,"lb.Read");
		addcheckbox($c->add("li"),"ow",false,"lb.Write");
		addcheckbox($c->add("li"),"ox",false,"lb.Execute");
		$div->addHSep();
		$div->addDiv()->Content = R::ngets("lb.Recusivity");
		addcheckbox($div->addDiv(),"clRecursif",true,"lb.Recursive");
		
		$frame->Form->addInput("d", "hidden", base64_encode(urlencode($d)));
		}
		else{
			$u = 0;
			$g=0;
			$o=0;
			$u |= igk_getr("ur")?4:0;
			$u |= igk_getr("uw")?2:0;
			$u |= igk_getr("ux")?1:0;
			
			$g |= igk_getr("gr")?4:0;
			$g |= igk_getr("gw")?2:0;
			$g |= igk_getr("gx")?1:0;
			
			$o |= igk_getr("or")?4:0;			
			$o |= igk_getr("ow")?2:0;
			$o |= igk_getr("ox")?1:0;
			$v = '0'.$u.''.$g.''.$o;			
			if (file_exists($file) ||is_dir($file))
			{
				if (is_dir($file) && igk_getr("clRecursif"))
				{
					$r = igk_file_chmod($file, octdec($v), true);
				}
				else
					$r = @chmod($file, octdec($v));
				if ($r){
					igk_notifyctrl()->addMsg("Permission changer ", substr(sprintf('%o', $file), -4));
				}
				else
					igk_notifyctrl()->addError("Impossible de changer les autorisation de [".basename($file)."]");
			}
			
		}
		
	}
	public function drop_dir_or_file()
	{
		if (!igk_is_conf_connected())
		{return;}
		$d = urldecode(base64_decode(igk_getr("d")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			if (igk_qr_confirm()){
				unlink($file);
				$this->View();
			}
			else{
				$frm = igk_frame_add_confirm($this, "confirm_file_delete", $this->getUri("drop_dir_or_file"));				
				$frm->Form->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION, basename($file));
				$frm->Form->addInput("d","hidden",base64_encode(urlencode($d)));
			}
		}
		else if (is_dir($file))
		{
			if (igk_qr_confirm()){
				rmdir($file);				
				$this->View();
			}
			else{
				$frm = igk_frame_add_confirm($this, "confirm_file_delete",$this->getUri("drop_dir_or_file"));
				$frm->Form->Content = R::ngets(IGK_MSG_DELETEDIR_QUESTION, basename($file));
				$frm->Form->addInput("d","hidden",base64_encode(urlencode($d)));
			}
		}
	}
	public function getfile($file = null)
	{
		if (!igk_is_conf_connected())
				return ;
		$d = urldecode(base64_decode(igk_getr("d")));
		
		$file = $file? $file: igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			$size = filesize($file);
			igk_download_content(basename($file), $size,  IGKIO::ReadAllText($file));		
			igk_exit();
		}
	}
	public function edit()
	{
		if (!igk_is_conf_connected())
				return ;
		$d = urldecode(base64_decode(igk_getr("d")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			$frame = igk_add_new_frame($this, "config-edit_file", "#filesystem",$this->App->Doc->body); 			
			$str = IGKIO::ReadAllText($file);
			$frame->Title = R::ngets("title.editFile", basename($file));		
			$frame->ClearChilds();
			$d = $frame->Content;
			$frame = $d->addForm();
			$frame["action"]=$this->getUri("updatefile#fileman");
			$ul = $frame->add("ul");
			$ul->add("li")->addTextArea("clContent", $str);
			$frame->addInput("clfile", "hidden", base64_encode(urlencode(basename($file))));
			$frame->addHSep();
			$frame->addBtn("btn_update", R::ngets("btn.Update"));
	
		}
	}
	public function updatefile()
	{
		if (!igk_getctrl(IGK_CONF_CTRL)->IsConnected)
				return ;
		$d = urldecode(base64_decode(igk_getr("clfile")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			igk_io_saveContentFromTextArea($file, igk_getr("clContent"), true);			
			igk_frame_close("config-edit_file");
		}
		igk_navtocurrent();
	}
	public function opendir_ajx()
	{
		$d = (igk_getr("d"));
		if ($d)
		{
			if (($this->m_directory == null)||($this->m_directory=="/"))
				$this->m_directory = $d;
			else 
				$this->m_directory .= "/".$d;
			$this->View();			
		}
		
		igk_wl($this->TargetNode->innerHTML);
	}
	public function opendir()
	{
		$d = (igk_getr("d"));
		if ($d)
		{
			if (($this->m_directory == null)||($this->m_directory=="/"))
				$this->m_directory = $d;
			else 
				$this->m_directory .= "/".$d;
			$this->View();
			igk_navtocurrent();
		}
	}
	public function gotoparent()
	{
		$c = dirname($this->m_directory);
		if (!empty($c))
		{
				$this->m_directory = $c;
				$this->View();
		}
	}
	public function gotoparent_ajx()
	{
		$count = igk_getr("n", 1);
		$c = $this->m_directory;
		while($count>0){
			$c = dirname($c);
			$count--;
		}
		if (!empty($c))
		{
			$this->m_directory = $c;
			$this->View();
			igk_wl($this->TargetNode->innerHTML);
		}
	}
}
///<summary>used to inform the system to not write attribute value</summary>
final class IGKHtmlNoValueAttribute extends IGKObject
{
	public static function IsNoValue($t)
	{
		return is_object($t) && (get_class($t) ==  __CLASS__);
	}
	public function getValue(){return true;}	
}
///<summary>notification message</summary>
interface IIGKNotifyMessage
{
	function addMsg($message);
	function addMsgr($keymessage);
	function addSuccess($message);
	function addSuccessr($keymessage);
	function addError($message);
	function addErrorr($keymessage);
	function addWarning($message);
	function addWarningr($keymessage);
	function addInfo($message);
	function addInfor($keymessage);
}

final class IGKHtmlNotificationItem extends IGKHtmlItem
{
	private $m_owner;
	private $m_script;
	
	public function __construct($owner)
	{
		parent::__construct("div");
		$this->m_script =  IGKHtmlItem::CreateWebNode("script");
		$this->m_script->Content = "\$ns_igk.winui.notifyctrl.init(\$ns_igk.getParentScript());";
		$this->m_owner = $owner;
		$this["class"]="igknotificationctrl";
		$this["igk-control-type"] = "notifyctrl";
		$this["id"] ="igknotificationctrl";
	}
	public function Render($xmloption=null){//render HtmlNotificationItem
		if (!$this->HasChilds)
			return;
			
		igk_html_add($this->m_script, $this);
		$out = parent::Render($xmloption);
		$this->ClearChilds();
		if ($this->m_owner->TargetNode === $this){
			$this->m_owner->setNotifyHost(null);
		}
		return $out;
	}
	public function __toString(){return "HtmlNotificationItem"; }
	
	function addMsg($msg){
		$this->add("div", array("class"=>"igk-notify igk-notify-default"))->Content = $msg;
	}
	function addMsgr($key){
		$this->addMsg(R::ngets($key));
	}
	function addSuccess($msg){
		$this->add("div", array("class"=>"igk-notify igk-notify-success"))->Content = $msg;
	}
	function addSuccessr($key){
		$this->addSuccess(R::ngets($key));
	}
	function addError($msg){
		$this->add("div", array("class"=>"igk-notify igk-notify-danger"))->Content = $msg;
	}
	function addErrorr($key){
		$this->addMsg(R::ngets($key));
	}
	function addWarning($msg){
		$this->add("div", array("class"=>"igk-notify igk-notify-warning"))->Content = $msg;
	}
	function addWarningr($key){
		$this->addWarning(R::ngets($key));
	}
	function addInfo($msg){
		$this->add("div", array("class"=>"igk-notify igk-notify-info"))->Content = $msg;
	}
	function addInfor($key){
		$this->addInfo(R::ngets($key));
	}
}


///<summary>Notification controller. used to inform user of some modification</summary>
///<note>according to the notification type message targetnode expose class 
///igk-notify_w for warning
///igk-notify-success for good message
///igk-notify_i for information
///igk-notify-danger for bad message
///</note>
final class IGKNotificationCtrl extends IGKControllerBase 
implements IIGKNotifyMessage
{
	
	private $m_notifyhost; //defaut primary host
	private $m_notificationChilds; //array of notification object
	
	public function getMsError(){return $this->m_hasmsg; }
	public function setMsError($v){ $this->m_hasmsg = $v; }
	public function getName(){return IGK_NOTIFICATION_CTRL;}
	public function getHasMsg(){
		return $this->TargetNode->HasChilds;
	}
	
	
	///<summary>get notification item</summary>
	public function getNotification($name, $reg=false){
		if ($this->m_notificationChilds == null)
			$this->m_notificationChilds = array();
			
		if (empty($name))
			return null;
			
		if (isset($this->m_notificationChilds[$name]))
			return $this->m_notificationChilds[$name];
		if ($reg)
		{
			$i = new IGKHtmlNotificationItem($this);
			$this->m_notificationChilds[$name]  = $i;
			return $i;
		}
		return null;
	}
	///<summary>free notification item</summary>
	public function unsetNotication($name)
	{
		if (isset($this->m_notificationChilds[$name]))
		{
			unset($this->m_notificationChilds[$name]);
		}
	}
	
	public function setNotifyHost($notifyhost, $name=null)
	{
		if ($name==null)
			$this->m_notifyhost = $notifyhost;	
		if ($notifyhost)
		{
			$n = $this->getNotification($name);
			if (($n == null) && ($name == null)){				
				$s = new IGKHtmlSingleViewItem( $this->TargetNode);
				igk_html_add($s, $notifyhost);				
			}
			else{
				if ($n !=null){
				$s = new IGKHtmlSingleViewItem( $n);
				igk_html_add($s, $notifyhost);
				}
				
			}
		}
		
	}
	public function getNotifyHost(){
		if ($this->m_notifyhost == null)
			$this->m_notifyhost = $this->app->Doc->body;
		return $this->m_notifyhost;
	}
	
	protected function InitComplete(){//notify host init complete
		parent::InitComplete();
		$this->App->Session->addUpdateSessionEvent($this, "onUpdateSession");		
	}
	protected function onUpdateSession()
	{
		if($this->HasMsg ){
			$this->View();
		}
	}
	
	protected function initTargetNode()
	{
		$v =  new IGKHtmlNotificationItem($this);
		return $v;
	}
	
	public function addError($msg)
	{
		$this->TargetNode->add("div", array("class"=>"igk-notify igk-notify-danger"))->Content = $msg;
		
	}
	function addSuccess($msg){
		$this->TargetNode->addSuccess($msg);
	}
	function addSuccessr($key){
		$this->TargetNode->addSuccessr($key);
	}
	public function addErrorr($key)
	{
		$this->addError(R::ngets($key));
	}
	public function addWarningr($msg){
		$this->addWarning(R::ngets($msg));
	}
	public function addWarning($msg){
		$this->setParam("ajx:renderincontext", null);
		$this->TargetNode->add("div", array("class"=>"igk-notify igk-notif-warning alert-warning"))->Content = $msg;
		$this->m_hasmsg = true;
	}
	public function addInfor($msgKeys){//add info with message key
		$this->addInfo(R::ngets($msgKeys));
	}
	public function addInfo($msg){
		$this->TargetNode->add("div", array("class"=>"igk-notify igk-notify-info"))->Content = $msg;
		$this->m_hasmsg = true;
	}
	public function addErrori($msgcode)
	{
		$c = igk_error($msgcode);
		if ($c){
			$li =  IGKHtmlItem::CreateWebNode("div",array("class"=>"alignl"));			
			$li->add("label")->Content = "Message : ";
			$li->add("span")->Content = R::ngets($c["Msg"]);		
			$this->addError($li->Render(null));
		}
	}
	
	public function addMsgr($msg)
	{
		$this->addMsg(R::ngets($msg));
	}
	public function addMsg($msg)
	{	
		$this->TargetNode->add("div", array("class"=>"igk-notify igk-notify-success"))->Content = $msg;			
	}	
	public function notify_ajx()
	{		
		$view = igk_getr("rv");
		$render =false;
		//$this->setParam("ajx:renderincontext", null);
		if (igk_sys_isAJX())
		{
		if ($this->HasMsg)
		{
			//igk_wln("$view : view" .$this->getParam("ajx:renderincontext"));
			if ($this->getParam("ajx:renderincontext") !== true)
			{	
			$this->setParam("ajx:renderincontext", true);			
			$d = IGKHtmlItem::CreateWebNode("div")->addScript();
			$uri = $this->getUri("notify_ajx&rv=1");
			
			$d->Content =<<<EOF
(function(){ ns_igk.ajx.post('${uri}',null, ns_igk.ajx.fn.prepend_to_body); })();
EOF;
			$d->RenderAJX();			
			}
			else if ($view) {
				$render = true;
			}
		}
		}
		else{				
			$render = $this->HasMsg;
		}
		if ($render)
		{
			$this->TargetNode->RenderAJX();
			$this->m_hasmsg = false;
			$this->setParam("ajx:context", null);
			$this->setParam("ajx:renderincontext", null);	
		}
	}
	public function pageFolderChanged($sender=null, $args=null)
	{
		if ($this->HasMsg){
			$this->TargetNode->ClearChilds();
			$this->View();		
		}
	}
	///<summary>Render notification controller</summary>
	public function View()
	{
		if (!$this->HasMsg)
		{
			igk_html_rm($this->TargetNode);
		}
		else{
			$this->TargetNode->setIndex(-10000);			
			$host = $this->NotifyHost;
			if ($host!==null){
				igk_html_add($this->TargetNode, $host);
			}
		}
	}	
	
}


final class IGKConfigData
{
	private $m_configCtrl;
	private $m_configEntries;
	private $m_confile;
	
	public function __toString(){
	return "IGKConfigurationData [Count: ".count($this->m_configEntries)."]";
	}
	public function SortByKeys()
	{
		$keys = array_keys($this->m_configEntries);
		sort($keys);
		$t = array();
		foreach($keys as $k)
		{
			$t[$k] = $this->m_configEntries[$k];
		}
		$this->m_configEntries = $t;
		
	}
	
	/// full path to
	/// conffile : configuration file
	/// configctrl : hosted controller
	/// entries: default entry
	public function __construct($conffile , $configCtrl, $entries){
		$this->m_confile = $conffile;
		$this->m_configCtrl = $configCtrl;
		$this->m_configEntries = $entries;
		
	}
	public function __get($key){
		if (isset($this->m_configEntries[$key]))
			return $this->m_configEntries[$key];
		return null;
	}
	public function __set($key, $value){
		
		if (isset($this->m_configEntries[$key]))
		
		{
			if ($value == null)
			{
				unset($this->m_configEntries[$key]);
			}
			else{
				$this->m_configEntries[$key] = $value;
			}
		}	
		else if (is_string($value) && !empty($value))
		{
			$this->m_configEntries[$key] = $value;
		}
	}
	//
	public function saveData(){
	
		$file = $this->m_confile; 			
		$out = IGK_STR_EMPTY;
		$v_ln = false;
		foreach($this->m_configEntries as $k=>$v)
		{
			if ($v_ln)
			{
				$out .= IGK_LF;
			}		
			else {
					$v_ln  = true;		
			}
			$out .= IGKCSVDataAdapter::GetValue($k).igk_csv_sep().IGKCSVDataAdapter::GetValue($v);				
		}		
		return IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);
	}

		public function getEntriesKeys()
		{
			return array_keys($this->m_configEntries);
		}
		public function getEntries(){
			return $this->m_configEntries;
		}
		
		public function setConfig($name, $value)
		{
			if ($name) 
				$this->m_configEntries[$name] = $value;
		}
		public function getConfig($name, $default=null)
		{
			return igk_getv($this->m_configEntries, $name, $default);
		}
}


final class IGKAppConfig extends IGKObject
{
	private $m_configEntries;
	private $m_datas;
	private $m_oldState;
	private static $sm_instance;
	
	
	const CHANGE_REG_KEY = "IGKConfigDataChanged";
	//get config entries
	public function getConfigEntries(){ return $this->m_configEntries;	}
	
	public function getData(){
		return $this->m_datas;
	}
	private function __construct()
	{
		$this->_loadConfig();
	}
	
	public function checkConfigDataChanged($ctrl)
	{				
		$v = $ctrl->isChanged(IGKAppConfig::CHANGE_REG_KEY, $this->m_oldState);
		if ($v){
			$this->_loadConfig();
			return true;
		}
		return false;
	}
	public static function getInstance(){// return get igk IGKAppConfig instance 
		if (self::$sm_instance == null)
		{
			self::$sm_instance = new  IGKAppConfig();
		}
		return self::$sm_instance;
	}
	//load configuration files configs.csv
	private function _loadConfig()
	{
		$file =IGK_CONF_DATA;
		$this->m_configEntries = array();
		$fullpath =igk_io_syspath($file);
		
		$f = IGKCSVDataAdapter::LoadData($fullpath);
		if ($f !== null)
		{
			foreach($f as $k=>$v)
			{	
				$this->m_configEntries[$v[0]] = trim(igk_getv($v, 1));
			}
		}
		$this->m_datas = new IGKConfigData($fullpath, $this, $this->m_configEntries);
		
	}

	public function saveConfig(){//save the app configuration file
		if ($this->m_datas==null)
			return;
		$this->m_datas->SortByKeys();
		if ($this->m_datas->saveData())
		{		
			$this->_updateCache();
			igk_sys_regchange(self::CHANGE_REG_KEY, $this->m_oldState);
		}
	}
	private function _updateCache(){
		
		$f = igk_io_baseDir(IGK_CACHE_DATAFILE);		
		if ($this->Data->cache_loaded_file)
		{
			igk_io_save_file_as_utf8($f,IGK_STR_EMPTY, true);
			//force cache of the files
			IGKApp::CacheLibFiles(true);
			igk_notifyctrl()->addMsgr("msg.cachefilestored");
		}
		else {
			if (file_exists($f))
			{				
			    $c = unlink($f);
				$t = unlink(igk_io_baseDir(IGK_FILE_LIB_CACHE));
				igk_notifyctrl()->addMsg(R::ngets("msg.cachefileunlink_1", basename($f)));							
			}
		}				
	}
}



///<summary>used to manage config manager</summary>
final class IGKConfigCtrl extends IGKControllerBase
implements IIGKConfigController
{
	private $m_configuration;
	private $m_ConfigUser;
	private $m_configEntries;
	private $m_ConfigNode;
	private $m_configMenuNode;
	private $m_menuCtrl;	
	private $m_connectBtn;
	private $m_selectedconfigCtrl;
	private $m_datas;
	private $m_menuName;
	private $m_headerNode;	
	private $m_connexionFrame;
	private $m_configFrame;//frame for config
	private $m_oldState;
	private $m_configInfo;
	
	
	
	
	//---------------------------------------------------------------------------
	//events
	//---------------------------------------------------------------------------
	private $m_ConfigUserChangedEvent; //user changed
	private $m_configSettingChangedEvent;  // setting changed
	
	public function getName(){return IGK_CONF_CTRL; }
	
	
	public function  getConfigInfo(){return $this->m_configInfo; }
	public function  getConfigNode(){return $this->m_ConfigNode; }
	
	public function getConfigMenuNode(){return $this->m_configMenuNode;}
	public function getSelectedConfigCtrl(){return $this->m_selectedconfigCtrl;}
	public function getSelectedMenuName() { return $this->m_menuName; }
	public function getData(){ return $this->m_datas;}
	//get a administrative user
	public function getConfigUser(){ return $this->m_ConfigUser;}
	//get a administrative user is connected
	public function getIsConnected(){
		return ($this->ConfigUser!=null);
	}
	//get is connected and in config page
	public function getIsConfiguring()
	{		
		return ($this->getIsConnected())&&($this->App->CurrentPageFolder == IGK_CONFIG_MODE);
	}
	public function getCanConfigure()
	{
		return ($this->getIsConnected());
	}
	public function showConfig()
	{
		$this->View();
	}
	public function getConfigPage(){
		return "configs";
	}
	
	public function getReconnectionUri()
	{
		$q = array(
			"u"=>$this->ConfigUser->clLogin,
			"pwd"=>$this->ConfigUser->clPwd,
			"selectedCtrl"=>$this->SelectedConfigCtrl? $this->SelectedConfigCtrl->Name:null,
			"selectPage"=>$this->SelectedMenuName);
		$uri = $this->getUri("startconfig&q=".base64_encode(
		'?'.http_build_query($q)));	
		return $uri;
	}
	
	public function ClearSessionAndReconnect($navigate=true)
	{	
		if ($this->IsConnected)
		{
			$uri = $this->getReconnectionUri();
			igk_getctrl(IGK_SESSION_CTRL)->clearS(false);										
			//igk_navtocurrent($uri);
			header("Location: ".$uri);
			igk_exit();			
		}
		igk_navtocurrent();
		igk_exit();
	}
	//cc: config controller function 
	public function cc_view_controllerschema_ajx()
	{
		$frame = igk_add_new_frame($this, "configctrlschema_frame");
		$d = $frame->Content;
		$frame->Title = R::ngets("title.viewcontrollerschema");
		$d->ClearChilds();
		$d->addDiv()->Content = "Schema structurel";
		$d->add("image" , array("src"=>$this->getUri("cc_controllerschema")));		
		$frame->RenderAJX();
	}
	public function cc_controllerschema(){//get the controller hierarchi format
		$this->App->getControllerManager()->cm_controllerschema();
	}	
	//
	//a fin de maintenir la connexion lors de la suppression d'un controller
	//restart la configuration
	public function reloadConfig($uri)
	{
		$tab = igk_getquery_args($uri);
		//igk_show_prev($tab);		
	}
	
	private function check_connect($user)
	{
		$adm = strtolower($this->App->Configs->admin_login);
		$adm_pwd = strtolower($this->App->Configs->admin_pwd);
		return (($adm == $user->clLogin) && ($adm_pwd == $user->clPwd));
		
	}
	public function startconfig()
	{
		$q = base64_decode(igk_getr("q"));
		$ajx = igk_getr("ajx");
		$tab = igk_getquery_args($q);
		
		$u =(object)array("clLogin"=>$tab["u"], "clPwd"=>$tab["pwd"]);

		 $v = $this->check_connect($u);
		 if ($v)
		 {
				$this->m_ConfigUser = igk_sys_create_user($u);
				$this->onConfigUserChanged();
				$ctrl = igk_getctrl(igk_getv($tab, "selectedCtrl", IGK_CONF_CTRL ));
				$p = igk_getv($tab, "selectPage","default");	
				if ($ctrl)
				{	
					//show controller config
					$ctrl->showConfig();		
				}
				else{
					//show this config					
					$this->ShowConfig();
				}
				//allow navigation.
				if (igk_getr("navigate", 1))
				{
					if (!$ajx)
					{
						igk_navtocurrent();		
						igk_exit(); 
					}
					else{
						//render selected target node from ajx context
						if($ctrl){
							$ctrl->TargetNode->RenderAJX();
						}
					}
				}				
		}
		else{
			igk_notifyctrl()->addErrorr("err.failedtoconnect");
			igk_wln("failed to reconnect");
		}
		igk_exit();
	}
	/// set selected menu config
	/// $ctrl = selected config controller
	/// $menuname = menu name
	/// $context = from context. info
	public function setSelectedConfigCtrl($ctrl, $fromContext=null){ 
		
		if ($this->m_selectedconfigCtrl !== $ctrl)
		{
			$this->m_selectedconfigCtrl = $ctrl;
			if ($ctrl && $ctrl->ConfigPage)
			{
				$this->_loadConfig();
				$this->_selectMenu($ctrl->ConfigPage, "IGKConfigCtrl");
				
			}	
		}
	}
	protected function _selectMenu($page, $context=null)
	{
			$this->m_menuCtrl->selectConfigMenu($page, "IGKConfigCtrl");
			$this->m_menuName = $page;
	}
	private function initConnexionNode($frm)
	{
		
		//init connection frame		
		if ($frm == null)
			$frm =  IGKHtmlItem::CreateWebNode("form")->AppendAttributes( array("class"=>"connexion_frame"));	
		$frm->ClearChilds();
	//vertical line	
	$frm["method"]="POST";
	$frm["action"]=$this->getUri("connect");
	$a =  IGKHtmlItem::CreateWebNode("a")->AppendAttributes( array("href"=>new IGKHtmlRelativeUriValueAttribute()));
	$a->Content =  "Go to index";
	$a["style"]="color:white;";
	$igk_framename = IGK_FRAMEWORK;
	$igk_version = IGK_VERSION;
	$c = null;
	
if (igk_agent_isAndroid())
{
	//connexion android frame.
	//------------------------
	igk_css_regclass(".igk-android-login-form", "[bgcl:igk-android-login-form-bg]");
	igk_css_regcolor("igk-android-login-form-bg", "#eee");
	
	$frm["class"] = null;
	$frm["class"]="fitw alignc alingm fith ";
	$frm["style"] ="position:relative; padding-bottom:48px;";
	$frm->Content["style"] = "top:0px; bottom:0px; position:relative; overflow-y:auto; height:100%; background-color:#DFDFDF;vertical-align:middle;";
	
	
	$kdiv = $frm->addDiv()->setClass("no-overflow");
	$kdiv["style"] = "height:auto; vertical-align:bottom; display:inline-block;  vertical-align:middle;";
	$div = $kdiv->addDiv();
	
	$div->addDiv()->setClass("dispib")
	->setAttribute("style","text-align:center; color:white; font-size:3.4em;vertical-align:middle;text-shadow: 1px 1px 0px black, -1px -1px 2px #ddd; margin-bottom:32px;")
	->Content= IGK_PLATEFORM_NAME."<span class=\"igk-smaller alignt\" style=\"font-size:0.4em\">TM</span> Configuration";
	
	$div = $kdiv->addContainer()->addDiv();
	
	$cdiv = $div->addRow()->addContainer();
	$cdiv->add("label")->setClass("igk-hbox")->Content = R::ngets("lb.clLogin");
	$cdiv->addInput("clLogin", "text")
	->setAttribute("placeholder", R::ngets("tip.login"))
	->setClass("dispb fitw igk-sm-fitw igk-form-control");
	
	$cdiv = $div->addRow()->addContainer();
	$cdiv->add("label")->setClass("igk-hbox")->Content = R::ngets("lb.clPwd");
	$cdiv->addInput("clPwd", "password")
->setAttribute("placeholder", R::ngets("tip.pwd"))
->setClass("dispb fitw igk-sm-fitw igk-form-control");
	
	
	
	$cdiv = $div->addRow()->addContainer();
	$cdiv->addDiv()->addInput("btn_connect","submit", R::ngets("btn.connect"))->setClass("-clsubmit fitw igk-btn igk-btn-connect");
	
	$cdiv = $div->addRow()->addContainer()->setClass("igk-smaller");
	$cdiv->addA(igk_io_baseUri())->Content = "goto index";
	
	
	$frm->addDiv()->setClass("dispb posfix fitw no-overflow loc_l loc_b")
	->setAttribute("style", "font-size:0.8em; position:fixed; height:48px;")
	->addDiv()->Content = "{$igk_framename} - ( ".IGK_PLATEFORM_NAME." ) - {$igk_version}<br />Configuration Manager";	
}
else{
$notification = igk_notification_response("connexion:frame");
$out = <<<EOF
<div id="connectionTag" class="igk-cnf-connexion-div">
<div id="LayerDocument_52559464" style=" width:300px; height:400px; position:relative; color:white;  display:inline-block;" >
 
<div id="id_layer" style="width:300px; height:400px; z-index:0; position:absolute;">
<div id="id_board"  style="width:301px; height:401px; position:absolute; padding-top: 48px; background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAAGRCAYAAAAw6+XgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAU5SURBVHhe7dSxCcAwAANB7b+bZ0ogtQfIwwmuUv/bzgPQ8O12APyRaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkmJmltr04BXpXuO4PkAAAAABJRU5ErkJggg==');left:0px; top:0px;">
	{$notification}
	<ul>
	<li><label class="cllabel" >Login</label><input type="text" name="clLogin" class="cltext" /><br /></li>
	<li><label class="cllabel" >Password</label><input type="password" name="clPwd" class="clpassword" /><br /></li>
	</ul>	
	<li><input type="submit" class="clsubmit" name="connect" value="connexion" /></li>	
	
</div>
<div id="id_content" style="width:301px; height:131px; position:absolute;background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAACDCAYAAADYgk3EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIqSURBVHhe7cnBCcAwAAOxDNv9Z2jw2wM4oAO97tw+gEekNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABZJ0kud8wN9z4XWBD/VeQAAAABJRU5ErkJggg==');left:0px; top:270px;">
${igk_framename} - ${igk_version}<br />
Configuration Manager
</div>
<div id="id_foot" style="width:301px; height:31px; position:absolute;background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAAAfCAYAAACyJpv8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACRSURBVHhe7dTBCYBAEATBzT+QS88IFMWHLwO4hhooWNh/zxzXAtjfuebd7xNgN6IFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQMoXrecAKDAza23mBqing/ZAmi1SAAAAAElFTkSuQmCC');left:0px; top:0px;">
	
</div>	
</div>
</div>
	<div id="igk_cpv"></div>
</div>
EOF;

	$frm->Load($out);
	$i = $frm->getElementById("id_board");
	$c = $frm->getElementById("igk_cpv");
	if ($i)
		$i->add($a);
}
	$this->m_connexionFrame = $frm;
		if ($c)
			$c->Content = IGK_COPYRIGHT;
	}
	protected function initTargetNode()
	{
		$node =  IGKHtmlItem::CreateWebNode("div")->setAttribute("class","igk-cnf-page fitw fith igk-powered-view");	
		
		$this->m_configFrame =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>"igk-cnf-frame"));		
		$this->m_headerNode =  $this->m_configFrame->addDiv(array("class"=>"igk-cnf-header-node fitw igk-auto-fix-top"));
		
		$div = $this->m_configFrame->addDiv(array("class"=>"fitw disptable"));
		$this->m_configMenuNode= $div->addDiv(array("id"=>"igk-cnf-menu", "class"=>"igk-cnf-menu"));
		$this->m_ConfigNode = $div->addDiv()->setId("igk-cnf-content")->setClass("igk-cnf-content");	
		$this->m_configInfo = $div->addDiv(array("id"=>"igk-cnf-info", "class"=>"igk-cnf-info"));	

		return $node;
	}
	private function __NoIE6supportView()
	{
		igk_wln("no ie 6 supported");
		igk_exit();
	}
	
	public function getIsVisible(){
		//for config controller only visible on page in config mode
		return ($this->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER);
	}
	public function getIsAvailable(){
		return ($this->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER);
	}
	public function init_param_callback($name, $callback){
		$bar = $this->getParam($name);
		if ($bar ==null)
		{
			$bar = $callback($this);
			$this->setParam($name, $bar);
		}
		return $bar;
	}
	public function View()
	{		
		if (!$this->IsAvailable){	
			$this->App->Doc->Body["class"] = "-igk-cnf-body";
		}
		else{
			$this->App->Doc->Body["class"] = "+igk-cnf-body";
			if (igk_agent_isIE() && igk_agent_ieVersion() < 7)
			{
				 $this->__NoIE6supportView();
				 return;
			}
			if ($this->App->getFirstUse())
			{
				$this->__initPageConfig();
			}		
			$this->m_menuCtrl->setConfigParentView($this->m_configMenuNode);		
			if (!$this->IsConnected)
			{
				$this->getTargetNode()->ClearChilds();
				//igk_html_rm($this->m_configFrame);		
				$this->initConnexionNode($this->m_connexionFrame);
				igk_html_add($this->m_connexionFrame, $this->getTargetNode());	
				
				
			}
			else{			
				if ($this->getIsVisible())
				{
				
		
					igk_html_rm($this->m_connexionFrame, true);	
					igk_html_add($this->m_configFrame, $this->getTargetNode());				
					$this->m_headerNode->ClearChilds();
					$this->m_headerNode->addDiv(array("class"=>"floatl igk-cnf-logo"))->add("a", array("class"=>"dispb fitw fith" , "href"=>IGK_WEB_SITE))->Content = IGK_HTML_SPACE;
					
					// if (igk_agent_isAndroid())
					// {
						
						// $bar  = $this->init_param_callback("android:navbar", function($ctrl){
							// return $ctrl->getTargetNode()->addTopNavBar();
						// });
						// $bar->ClearChilds();
						// $bar->addDiv()
						// ->setClass("disptable")
						// ->setAttribute("style","position:relative; display:inline-block; top:8px; bottom: 0px; margin-bottom:8px;")
						// ->Content = "<div style=\"display:table-cell; height:auto; font-size: 2.1em; vertical-align:middle;\" >IGKDEV</div>";
						// $navbtn = $bar->addToggleButton();
						// $navbtn->Target = "#android-menu";
						// $navbtn->addBar(3);
						
						// $bar->addSpace()->setClass("clearb");
					// }
					
					//toggle button only visible for small device
					$navbtn = $this->m_headerNode->addToggleButton();
					$navbtn->Target = "#android-menu";
					$navbtn->setClass("igk-sm-only floatr");
					$navbtn->ClassProperty = "posab igk-col-sm-3-2";
					$navbtn->addBar(4);
			
					$android_menu = $this->m_headerNode->add("ul");
					$android_menu->setId("android-menu");
					
					
					
					$android_menu["class"] = "igk-android-menu-options";
					$android_menu["igk-data-menu"] = 1;
					$android_menu["igk-data-menu-binding"] = "#igk-cnf-menu";
					
				//	$android_menu->addScript()->Content = "(function(){var q= ns_igk.getParentScript(); ns_igk.ready(function(){ \$igk(q).setCss({width: '60%'});}); })();";
					
					
					
					
					
			
			
					$h = $this->m_headerNode->add("h1", array("class"=>"igk-cnf-title"));				
					$h->Content = R::ngets(IGK_CONF_PAGE_TITLE, igk_get_string_propvalue($this->App->Configs, "website_title"));		
					
					if ($this->SelectedConfigCtrl == null)
					{			
						$this->setpage();
					}
				}	
			}	
		}	
		$this->_onViewComplete();
	}
	
	
	public function __construct(){
		parent::__construct();
		$this->m_ConfigUserChangedEvent = new IGKEvents($this, "ConfigUserChangedEvent");//raise when config user changed
		$this->m_configSettingChangedEvent = new IGKEvents($this, "ConfigSettingChangedEvent");//raise when configuration setting changed
		$this->_loadConfig();
	}
	//load configuration files configs.csv
	private function _loadConfig()
	{
		$file =IGK_CONF_DATA;
		$this->m_configEntries = array();
		$fullpath =igk_io_syspath($file);
		
		$f = IGKCSVDataAdapter::LoadData($fullpath);
		if ($f !== null)
		{
			foreach($f as $k=>$v)
			{	
				$this->m_configEntries[$v[0]] = trim(igk_getv($v, 1));
			}
		}
		$this->m_datas = new IGKConfigData($fullpath, $this, $this->m_configEntries);
		
	}
	public function registerConfig($ctrl)
	{///register config controlleur
		
	}
	
	protected function InitComplete()
	{		
		parent::InitComplete();		
		$this->m_configuration = false;		
		$this->m_menuCtrl = igk_getctrl(IGK_MENU_CTRL , true);
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "checkConfigDataChanged");
		
		igk_sys_regpagefolderChanged("home", $this, "__initPageConfig");
		igk_sys_regpagefolderChanged("Configs", $this, "__initPageConfig");
		
	}
	protected function __initPageConfig()
	{		
		
		switch($this->App->CurrentPageFolder)
		{
			case IGK_CONFIG_MODE:				
				$this->App->Doc->body["class"] = "-igk-client-page";				
				igk_html_rm($this->App->Doc->bodypage);
				igk_html_add($this->TargetNode, $this->App->Doc->body);
				break;
			default:	
				$this->App->Doc->body["class"] = "+igk-client-page";
				igk_html_rm($this->TargetNode);
				IGKHtmlUtils::AddItem($this->App->Doc->bodypage,$this->App->Doc->body);						
				break;
		}	
	}
	
	public function checkConfigDataChanged($ctrl)
	{
		if (IGKAppConfig::getInstance()->checkConfigDataChanged($ctrl))
		{
			$this->onConfigSettingChanged();
		}
	}
	protected function onConfigUserChanged()
	{
		if ($this->m_ConfigUserChangedEvent !=null)
		{
			$this->m_ConfigUserChangedEvent->Call($this, null);
		}
	}
	protected function onConfigSettingChanged()
	{
		if ($this->m_configSettingChangedEvent !=null)
			$this->m_configSettingChangedEvent->Call($this, null);
	}
	public function addConfigUserChangedEvent($obj, $method)
	{
		return $this->m_ConfigUserChangedEvent->add($obj, $method);
	}
	public function removeConfigUserChangedEvent($obj, $method=null)
	{
		$this->m_ConfigUserChangedEvent->remove($obj, $method);
	}
	public function addConfigSettingChangedEvent($obj, $method)
	{
		return $this->m_configSettingChangedEvent->add($obj, $method);
	}
	public function removeConfigSettingChangedEventt($obj, $method=null)
	{
		$this->m_configSettingChangedEvent->remove($obj, $method);
	}
	
	public function initConfigMenu(){//init system config menu		
		return array(
			new IGKMenuItem("Home", "default", $this->getUri("setpage"),-900),
			new IGKMenuItem("PhpInfo", "phpinfo", $this->getUri("show_phpinfo"),-800),
			new IGKMenuItem("ConfigurationMenuSetting", "configurationMenuSetting", $this->getUri("show_configuration_menu_setting"),-700),
			new IGKMenuItem("GoToIndex", null, $this->getUri("gotoindex"),10800),
			new IGKMenuItem("ClearSession",null, $this->getUri("Clearsession"),10810),
			new IGKMenuItem("Reconnect",null, $this->getUri("reconnect"),10850),
			new IGKMenuItem("LogOut", null, $this->getUri("logout"),10900)
		);
	}
	
	
	
	public function gotoindex()
	{		
		igk_navtobase(IGK_STR_EMPTY);		
		igk_exit();
	}
	public function Clearsession()
	{
		$this->SelectedConfigCtrl = null;
		igk_getctrl(IGK_SESSION_CTRL)->clearS();
		igk_navtocurrent();
		igk_exit();
			
	}
	public function reconnect()
	{		
		$this->ClearSessionAndReconnect();
		return;
	}
	

	public function show_phpinfo(){
		$this->SelectedConfigCtrl = null;
		$this->setpage("phpinfo");
		
	}
	public function getphpinfo(){	
		$this->ConfigNode->ClearChilds();
		phpinfo();
		igk_exit();
	}
	
	public function show_configuration_menu_setting()
	{
		$this->SelectedConfigCtrl = null;
		$this->setpage("configurationmenusetting");
	}
	private function _view_ConfigMenuSetting($node)
	{
		
		igk_html_add_title($node->addDiv(), "title.ConfigurationMenuSetting");
		$node->addHSep();
		$f = $this->getDataDir()."/config.menu.xml";
		$txt = IGKIO::ReadAllText($f);
		$dummy =  IGKHtmlItem::CreateWebNode("dummy");
		$dummy->Load($txt);
		$b = igk_getv($dummy->getElementsByTagName("configmenu"),0);
		
		$v_subdiv = $node->addDiv();
		
		foreach($b->Childs as $k=>$v)
		{
			$v_d = $v_subdiv->addDiv();
			//title
			$t = $v_d->addDiv(array("class"=>"table table-stripped config-menu-title"));
			$t->Content = $v->TagName;
		}
	}
	public function setpage($p="default")
	{
		$p = igk_getr("p", $p);		
		$this->ConfigNode->ClearChilds();
		$v_supported = true;
		
		switch($p)
		{
			case "configurationmenusetting":
				$this->SelectedConfigCtrl = null;
				$this->_selectMenu("ConfigurationMenuSetting", "IGKConfigCtrl::setpage");		
				$div = $this->ConfigNode->addDiv();
				$this->_view_ConfigMenuSetting($div);			
				break;
			case "phpinfo":				
				$this->_selectMenu("phpinfo", "IGKConfigCtrl::setpage");	
				$iframe = $this->ConfigNode->add("iframe", array("class"=>"fitw fith no-border")); 
				$iframe["src"] = $this->getUri("getphpinfo");
				$iframe["style"]="min-height:800px; ";
			break;
			case "default":			
				$this->SelectedConfigCtrl = null;
				$this->_selectMenu("default", "IGKConfigCtrl::setpage");				
				$div = $this->ConfigNode->addDiv();				
				igk_html_add_title($div, "title.frameworkInfo");
				$div->addHSep();
				
				$ul = $div->add("ul");
				$ul->add("li")->Content = "FrameworkCodeName : ". IGK_PLATEFORM_NAME;
				$ul->add("li")->Content = "FrameworkVersion : ". IGK_VERSION;
				$ul->add("li")->Content = "FrameworkRelease : ".IGK_RELEASE_DATE;
				$ul->add("li")->Content = "Author : ". IGK_AUTHOR;
				$li = $ul->add("li", array("class"=>"alignt" ));
				$li->add("span", array("class"=>"alignt -lblabel" ))->Content = "Author Contact : ";
				$li->add("a", array("class"=>"alignt deco_u", "style"=>"text-decoration:underline" , "href"=>"mailto:".IGK_AUTHOR_CONTACT))->Content = "@igkdev.be";
				$ul->add("li")->Content = "PhpVersion : ". PHP_VERSION;
				$ul->add("li")->Content = "ServerName : ".$_SERVER["SERVER_NAME"];
				$ul->add("li")->Content = "Server IP: ".igkServerInfo::ServerAddress();
				$ul->add("li")->Content = "IsLocal : ". igk_parsebool(igkServerInfo::IsLocal());
				$ul->add("li")->Content = "RemoteIP : ". igkServerInfo::RemoteIp();
				
				
				$div = $this->ConfigNode->addDiv();
				
				igk_html_add_title($div, "title.AdministrativeConfig");
				$div->addHSep();
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_domain_setting");	
				igk_notify_sethost($frm->addDiv(),"update_domain_setting");
				$frm->addSLabelInput("website_domain", "text", $this->App->Configs->website_domain);$frm->addBr();				
				$frm->addSLabelInput("website_title",  "text", $this->App->Configs->website_title);$frm->addBr();	
				$frm->addSLabelInput("website_prefix",  "text", $this->App->Configs->website_prefix);$frm->addBr();	
				$frm->addSLabelInput("website_adminmail",  "email", $this->App->Configs->website_adminmail);$frm->addBr();	
				$frm->addBtn("btn_domainName", R::ngets("btn.update"));
				
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_adminpwd");
				$frm->addHSep();
				$frm->addSLabelInput("passadmin",  "password");$frm->addBr();				
				$frm->addBtn("btn_domainName", R::ngets("btn.update"));
				
				//update current lang
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_defaultlang");
				$frm->addHSep();
				if (!$this->App->Configs->default_lang)
				{
					$this->App->Configs->default_lang = R::GetCurrentLang();
				}								
				$frm->addSLabelInput("cldefaulLang",  "text",  $this->App->Configs->default_lang);
				$frm->addBr();				
				$frm->addBtn("btn.updateCurrentLang", R::ngets("btn.update"));
				
				//update global configs
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_default_tagname");
				$frm->addHSep();											
				$frm->addSLabelInput("cldefault_node_tagname", "text",  $this->App->Configs->app_default_controller_tag_name);
				$frm->addBr();				
				$frm->addBtn("btn.updateGlobalSetting", R::ngets("btn.update"));
				
				$this->ConfigNode->AddHSep();
				$frm = $this->ConfigNode->addForm();					
				$frm["action"] = $this->getUri("conf_update_setting");
				$div = $frm->addDiv();
				$ul = $div->add("ul");
				$ul["class"]="igk-row other-conf-setting";
				$tab = array(				
				 "cldebugmode"=> "AllowDebugging",
				 "clCacheLoadedFile"=> "cache_loaded_file",				
				 "clarticleconfig"=> "allow_article_config",
				 "clinformAccessConnection"=> "informAccessConnection",
				 "clautochepage"=> "allow_auto_cache_page");
				
				foreach($tab as $s=>$t){
					$this->_checkedItemConfig($ul->add("li")->setClass("igk-col igk-col-lg-3-1")->addDiv(), $s, $t);
				}				
				$li = $ul->add("li")->setClass("igk-col igk-col-lg-3-1")->addDiv();
				$li->addInput("clcache_file_time", "text",  igk_getdv($this->App->Configs->cache_file_time, 3600))->setClass("floatr")
				->setAttribute("style","width:80px");
				$li->add("label")->setClass("clearb")->Content = R::ngets("lb.clcache_file_time");
				
				
				
				
				$frm->addBtn("btn_updatedebugmode", R::ngets("btn.update"));
				$frm->add('a')				
				->setClass("clsubmit")
				->setAttribute("href", $this->getUri("clearcache"))
				->setAttribute("onclick", "javascript: ns_igk.ajx.post(this.href+'&ajx=1', null,null);  return false;")
				->Content = R::ngets("btn.clearcache");
				
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("resetconfig");
				$frm->addBr();
				$frm->addHSep();
				$frm->addBtn("btn_resetconfig", R::ngets("btn.resetconfig"));
				break;
			default :
				$v_supported = false;
				break;
		}		
		if ($v_supported)
		{
			$this->ConfigInfo->ClearChilds();
			igk_add_article($this, "help.".$this->Name.".".$p, $this->ConfigInfo->addDiv(), null, true);		
		}
		else{
			//call the show config of the selected controller
		}		
	}
	public function clearcache(){
	
		IGKControllerManagerObject::ClearCache();		
		if (igk_sys_isAJX())
		{
			igk_exit();
		}
	}
	public function update_default_tagname()
	{
		 $s = igk_getr("cldefault_node_tagname", "div");
		 if (!empty($s))
			$this->App->Configs->app_default_controller_tag_name = $s;
		
		igk_save_config();		
		igk_resetr();
		$this->View();		
		igk_notifyctrl()->setNotifyHost(null);
		igk_notifyctrl()->addMsgr("msg.ConfigOptionsUpdated");		
		igk_navtocurrent();
	}
	function _checkedItemConfig($target, $name, $param)
	{
			$target->add("label", array("for"=>$name))->Content = R::ngets("lb.".$param);
			$chb = $target->addInput($name, "checkbox", null);
			$chb["value"]="1";
			if ($this->App->Configs->$param)
				$chb["checked"] = "true";
	}
	
	public function resetconfig(){
		if(igk_qr_confirm())
		{
			@unlink(igk_io_currentRelativePath("Data/configure"));
			igk_getctrl("igkdbCtrl")->initSDb(false);
			$this->reconnect();			
		}
		else{
			$frame = igk_frame_add_confirm($this, "frame_reset_config", $this->getUri("resetconfig"));				
			$frame->Form->Div->Content = R::ngets("msg.confirmResetConfig");	
		}
	}
	//update debug mode
	public function conf_update_setting()
	{		
		$this->App->Configs->AllowDebugging = igk_getr("cldebugmode", false);
		$this->App->Configs->cache_loaded_file = igk_getr("clCacheLoadedFile", false);
		$this->App->Configs->allow_article_config = igk_getr("clarticleconfig", false);
		$this->App->Configs->allow_auto_cache_page = igk_getr("clautochepage", false);
		$this->App->Configs->cache_file_time = igk_getr("clcache_file_time", false);
		$this->App->Configs->informAccessConnection = igk_getr("clinformAccessConnection", false);
		igk_save_config();		
		igk_notifyctrl()->setNotifyHost(null);
		
		$this->View();
		igk_notifyctrl()->addMsgr("msg.configOptionsUpdated");
		igk_resetr();
		
		//igk_navtocurrent();
	}
	
	public function update_defaultlang()
	{
		$this->App->Configs->default_lang = igk_getr("cldefaulLang","Fr");		
		igk_save_config();		
		igk_notifyctrl()->addMsgr("msg.langupdated");
		$this->View();
		igk_navtocurrent();
	}
	public function update_adminpwd()
	{
		$d = igk_getr("passadmin");
		if ($d && (strlen($d)> IGK_MAX_CONFIG_PWD_LENGHT)){
			$this->App->Configs->admin_pwd = md5($d);				
			$this->View();
			igk_notifyctrl()->addMsgr("msg.pwdupdated");
			igk_save_config();	
			
		}
		igk_navtocurrent();
	}
	public function update_domain_setting()
	{
		$d = igk_getr("website_domain");
		$title = igk_getr("website_title");
		$prefix = igk_getr("website_prefix");
		
		if ($d)	$this->App->Configs->website_domain = $d;
		$this->App->Configs->website_title = $title;
		$this->App->Configs->website_prefix = $prefix;
		$this->App->Configs->website_adminmail = igk_getr("website_adminmail", null);
		igk_save_config();
		igk_notifyctrl(__FUNCTION__)->addSuccessr("msg.domainupdate");	
		$this->View();			
		igk_navtocurrent();
	}

	public function connect($u=null,$pwd=null, $redirect=true){	//connect to server for administration
		if ($this->IsConnected )
		{
			$this->View();		
			return;
		}
		$u = ($u==null)? strtolower(igk_getr("clLogin",$u)) : $u;
		$pwd = ($pwd==null)? strtolower(md5(igk_getr("clPwd",$pwd))) :md5($pwd);
	
		if (empty($u) || empty($pwd))
		{
			$this->msbox->addError(R::gets(igk_geterror_key(IGK_ERR_LOGORPWDNOTVALID)));
			$not = igk_notifyctrl()->getNotification("connexion:frame", true);
			$not->addError("login failed. no matching requirement");
			$this->View();							
		}
		else 
		{
			$adm = strtolower($this->App->Configs->admin_login);
			$adm_pwd = strtolower($this->App->Configs->admin_pwd);
		

			if ( ($adm == $u) && 
				 ($adm_pwd ==$pwd))
			{			
				$us = (object)array("clLogin"=>$u, "clPwd"=>$pwd, "csrf"=>"igk-".(IGK_STR_EMPTY.rand()+time()));
				
				$this->m_ConfigUser = igk_sys_create_user($us);	
				
				$this->onConfigUserChanged();
				
				$this->View();
				
				$this->_send_notification_mail();
				
			}
			else {
				$this->msbox->addError(R::gets(igk_geterror_key(IGK_ERR_LOGORPWDNOTVALID)));
				igk_debug_wln("config login no tok");
				$not = igk_notifyctrl()->getNotification("connexion:frame", true);
				$not->addError("login failed. please try again or contact the administrator");
				$this->View();
			}
		}
		if ($redirect){
			
			igk_navtocurrent();
		}
	}	
	//<summary> send mail notification</summary>
	private function _send_notification_mail()
	{
			if ($this->App->Configs->informAccessConnection){
					$to = $this->App->Configs->website_adminmail;
					if ($to){
						$message =  IGKHtmlItem::CreateWebNode("div");
						$message->Content = "You connected to ".$this->App->Configs->website_domain." platform at ". igk_mysql_datetime_now();
						$message["class"]="fitw fith container";
						
						$d = new IGKHtmlDoc($this->App, true);
						$d->ForMailTransport = true;
						$d->Body->add($message);
						igk_mail_sendmail($to, "no-reply@".$this->App->Configs->website_domain, "Connexion Notification", $d->Render(), null);
					}
				}
	}
	public function logout($redirect=true, $detroysession=true){
	
		if ($this->IsConnected)
		{
		
			$this->m_ConfigUser = null;
			$this->setSelectedConfigCtrl(null);			
			$this->onConfigUserChanged();
		}
		if ($detroysession )
			session_destroy();
		$this->View();
		if ($redirect)
		{
			igk_navtocurrent();		
			igk_exit();
		}
	}
}
//mail controller
class IGKMailCtrl extends IGKConfigCtrlBase
{
	private $m_mailSendEvent; 
	
	public function __construct(){
		parent::__construct();
		$this->m_mailSendEvent = new IGKEvents($this, "MailSend");
	}
	public function addMailSendEvent($obj, $func){
		if( $this->m_mailSendEvent!=null)
		$this->m_mailSendEvent->add($obj, $func);
	}
	public function removeMailSendEvent($obj, $func)
	{
		if( $this->m_mailSendEvent!=null)
		$this->m_mailSendEvent->remove($obj, $func);
	}
	public function onMailSended($args)
	{
		if( $this->m_mailSendEvent!=null)
			$this->m_mailSendEvent->Call($this, $args);
	}
	
	public function send_contactmail($fromName, $message=null)
	{
		$obj = igk_get_robj();		
		
		$enode =  IGKHtmlItem::CreateWebNode("div");
		$mail = new IGKMail();
			
		$this->initMailSetting();
		$this->init_mail_config($mail);

			
			
			$mail->addTo($this->App->Configs->mail_contact);			
			$div =  IGKHtmlItem::CreateWebNode("div");
			$div["style"] = "border:1px solid black; min-height:32px;";
			$ul = $div->add("ul");
			$ul->add("li")->Content = "Message From: ".$fromName;
			$ul->add("li")->Content = "Email: ".$obj->clYourmail;
			
			$msg = $div->addDiv();
			$msg->Content = $obj->clMessage;			
			
			$mail->HtmlMsg = utf8_decode($div->Render()); 
			$mail->Title = utf8_decode($obj->clSubject);
			$mail->ReplyTo = $obj->clYourmail;
			$mail->From =  "website@".$this->App->Configs->website_domain;
			if ($mail->sendMail())
			{				
				igk_resetr();	
				$div =  IGKHtmlItem::CreateWebNode("div");
				$div->Content = R::ngets("msg.email.correctlysend");
				$div->addScript()->Content = "igk.animation.autohide(igk.getParentScript(), 3000);";
				$e = new IGKHtmlSingleViewItem($div);				
				$this->onMailSended(array(
					"clEmail"=>$obj->clYourmail,
					"clFirstName"=>$obj->clFirstName,
					"clLastName"=>$obj->clLastName
				));
				return  array(true, $e);		
			}
			else{
				$enode->Add("li")->Content = R::ngets("msg.mail.sendmailfailed");				
				return  array(false, $enode);		
			}
			
	}
	
	public function IsFunctionExposed($func = null){//mail
		switch($func)
		{
			case "sendmailto":
			return true;
		}
		return parent::IsFunctionExposed($func);
	}
	public function sendmailto()
	{
		$to = igk_getr("n");
		$s = igk_getr("s");
		
		$m =  IGKHtmlItem::CreateWebNode("script");
		$m->Content =<<<EOF
window.open("mailto:$to?subject=$s","sendmail");

EOF;
		$this->App->Doc->body->add(new IGKHtmlSingleViewItem($m));
		igk_navtocurrent();
		
	}
	public function initMailSetting()
	{	
		 ini_set("smpt_port", $this->App->Configs->mail_port);
		 ini_set("SMTP", $this->App->Configs->mail_server);
		 ini_set("sendmail_from", $this->App->Configs->mail_admin);
	}
	private function init_mail_config($mail)
	{
		$mail->UseAuth = $this->App->Configs->mail_useauth;
		$mail->User = $this->App->Configs->mail_user;//"igkdevbe"; //"bondje.doue@gmail.com";
		$mail->Pwd = $this->App->Configs->mail_password;//"bonajehost1983"; //"bonaje123";
		$mail->Port = $this->App->Configs->mail_port; //587;//  465; //587;
		$mail->SmtpHost = $this->App->Configs->mail_server;
		$mail->SocketType = $this->App->Configs->mail_authtype;//"ssl";
	}
	//send mail to element
	public function sendmail($from, $to,$subject, $message){
	     // Pour envoyer un mail HTML, l'en-tête Content-type doit être défini
		$header = null;
		$this->initMailSetting();
		$mail = new IGKMail();
		$this->init_mail_config($mail);

		$mail->HtmlMsg = $message;
		$mail->Title = $subject;
		$mail->From = $from;
		$mail->HtmlCharset = "utf-8";
		$mail->TextCharset = "utf-8";
		$mail->addTo($to);
		return $mail->sendMail();	
	}
	
	public function getConfigPage()
	{
		return "mailserver";
	}
	public function View(){
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();
		igk_html_add_title($c, "title.ConfigMailServer");
		$c->addHSep();
		igk_add_article($this, "mailserver", $c->addDiv(), null, true);
		
		$c->addHSep();
		
		
		$div = $c->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("mail_update");
		
		$frm->addSLabelInput("server",  "text", $this->App->Configs->mail_server); $frm->addBr();
		$frm->addSLabelInput("baseFrom", "text", $this->App->Configs->mail_admin);$frm->addBr();
		$frm->addSLabelInput("port", "text", $this->App->Configs->mail_port);$frm->addBr();
		$frm->addSLabelInput("clContactTo", "text", $this->App->Configs->mail_contact);$frm->addBr();
		
		$o = $frm->addSLabelInput("useauth","checkbox", $this->App->Configs->mail_useauth);
		$o->input["value"]="1";
		$frm->addBr();
		$frm->addLabel("cl.mailAuthType", "clAuthType");
		igk_html_build_select($frm, 
		"clAuthType", 
		array("ssl"=>"ssl","tsl"=>"tsl"),
		null,
		$this->App->Configs->mail_authtype
		); $frm->addBr();
		
		
		$frm->addSLabelInput("clMailUser", "text", $this->App->Configs->mail_user);$frm->addBr();
		$frm->addSLabelInput("clMailPwd", "password", $this->App->Configs->mail_password);$frm->addBr();
		$frm->addBtn("btn_update", R::ngets("btn.update"));
		
		
		
		$frm = $div->addForm();
		igk_notify_sethost($frm->addDiv(), "mail:notifyResponse");
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("mail_testmail");		
		$frm->addSLabelInput("clTestMail","text", $this->App->Configs->mail_testmail);$frm->addBr();		
		$frm->addBtn("btn_testmail", R::ngets("btn.TestMail"));
	}
	
	
	public function mail_testmail()
	{
		$to  = igk_getr("clTestMail");
		$this->App->Configs->mail_testmail = $to;
		igk_save_config();
			$mailctrl = igk_getctrl("igkmailctrl");			
			$c = $this->App->Configs->mail_contact;
			if ( ($mailctrl!= null) && !empty($c))
			{
			//from 
			//to
				if (
				$mailctrl->sendmail(					
					$c,//from 
					$to,//to			
				"Mail test: ".$this->App->Configs->website_domain, 
				"This mail is a test mail From <b> " .$this->App->Configs->website_domain."<b>"))
				{
					igk_notifyctrl("mail:notifyResponse")->addMsgr("msg.mailsend");
				}
				else{
					igk_notifyctrl("mail:notifyResponse")->addErrorr("msg.mailnotsend");
				}
			}
			else 
				$this->msbox->addError("error ... ".$this->App->Configs->mail_contact);
		
		$this->View();
	}
	
	public function mail_update(){
	
		$server= igk_getr("server");
		$mail= igk_getr("baseFrom");
		$port = igk_getr("port");
		$useauth = igk_getr("useauth");
		$this->App->Configs->mail_server = $server;
		$this->App->Configs->mail_port = $port;
		
		$this->App->Configs->mail_admin = $mail;
		$this->App->Configs->mail_useauth = $useauth;
		$this->App->Configs->mail_contact  = igk_getr("clContactTo");
		$this->App->Configs->mail_authtype = igk_getr("clAuthType");
		$this->App->Configs->mail_user=igk_getr("clMailUser");
		$this->App->Configs->mail_password = igk_getr("clMailPwd");
		
		
		igk_save_config();
		igk_notifyctrl()->addMsgr("msg.mailupdatedd");
		$this->View();
		igk_navtocurrent();
		igk_exit();
	}
	
}


//
//BACKGROUND IMAGE ADORATOR 
//
final class IGKBackgroundImgCtrl extends IGKConfigCtrlBase
{
		private $m_imglist;
		private $m_configTargetNode;
		private $m_currentIndex;
		private $m_allowRandom;
		private $m_lastChanged;
		const PROP_CHANGED = "BackgroundAdoratorChanged";
		public function __construct()
		{
			parent::__construct();
			$this->m_currentIndex = null;
			$this->m_imglist = array();
		}
		private function _getadoratordir()
		{
			return  igk_io_syspath("R/Img/".(($this->App->Configs->adorator_fade_directory)?$this->App->Configs->adorator_fade_directory:"Adorator"));	
		}
		
		public function IsFunctionExposed($function)
		{
			return true;
		}
		
		
		protected function InitComplete()
		{
			parent::InitComplete();
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "SettingChanged");
			
		}
		public function SettingChanged($ctrl)
		{			
			if ($ctrl->isChanged(self::PROP_CHANGED, $this->m_lastChanged))
			{
				$this->View();
			}
		}
		protected function initTargetNode()
		{
			$this->m_configTargetNode =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes(array("class"=>strtolower($this->getName())));
			return IGKHtmlItem::CreateWebNode("div");
		}
			
		public function getConfigPage()
		{
			return "backgroundsetting";
		}
		private function __viewConfig()
		{
				$this->m_configTargetNode->ClearChilds();
				$this->ConfigNode->ClearChilds();
				IGKHtmlUtils::AddItem($this->m_configTargetNode, $this->ConfigNode);
				$d = $this->m_configTargetNode;
				igk_html_add_title($d, "title.BackgroundAdoratorSetting");
				$d->addHSep();
				$frm = $d->addForm();
				$frm["action"] = $this->getUri("updatevalue");
				$ul = $frm->add("ul");				
				
				$ul->add("li")->addSLabelCheckbox("clEnabled",  $this->App->Configs->adorator_fade_enabled);
				$ul->add("li")->addSLabelInput("clFadeinterval","text", igk_gettv($this->App->Configs->adorator_fade_interval , 500));
				$ul->add("li")->addSLabelInput("clRotationInterval", "text", igk_gettv($this->App->Configs->adorator_rotation_interval, 10000));
				$ul->add("li")->addSLabelCheckbox("clRandom", $this->App->Configs->adorator_random_enabled);
				$frm->addHSep();
				$ul = $frm->add("ul");
				$ul->add("li")->addSLabelInput("clDir", "text", $this->App->Configs->adorator_fade_directory?$this->App->Configs->adorator_fade_directory:"Adorator" );				
				$frm->addBtn("btn_update", R::ngets("btn.update"));							
		}
		public  function showConfig()
		{
			parent::showConfig();
			if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
			{
				$this->__viewConfig();				
			}
			else {
				igk_html_rm($this->m_configTargetNode);
			}
		}
		public function updatevalue()
		{
			$this->App->Configs->adorator_fade_directory =   igk_getr("clDir","Adorator");
			$this->App->Configs->adorator_fade_enabled = igk_getr("clEnabled",false);
			$this->App->Configs->adorator_fade_interval = igk_getr("clFadeinterval");
			$this->App->Configs->adorator_rotation_interval = igk_getr("clRotationInterval");
			$this->App->Configs->adorator_random_enabled = igk_getr('clRandom');
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange(self::PROP_CHANGED, $this->m_lastChanged);
			igk_save_config();
			$this->showConfig();
			igk_notifyctrl()->addMsgr("msg.backgroundimageadorator.updated");			
			$this->View();
			igk_navtocurrent();
			
		}
		public function getIsVisible()
		{
			return $this->App->Configs->adorator_fade_enabled;
		}
		public function getfilelist_ajx()
		{
				$s = $this->_getadoratordir();
				if (is_dir($s))
				{
				$tab = IGKIO::GetDirFileList($s);		
				$node =  IGKHtmlItem::CreateWebNode("images");
				foreach($tab as $k){
					$node->add("image", array("src"=>igk_io_baseUri(igk_io_basePath($k))));
				}
				igk_wl($node->Render());
				}
		}
		public function View()
		{	
			$c = $this->TargetNode;
			$c->ClearChilds();		
			if (!$this->getIsVisible())
			{
				
				igk_html_rm($c);
				return;
			}
			
			$c["class"]="web_background_img posab zback loc_t loc_l fith fitw";
		
			IGKHtmlUtils::AddItem($c, $this->App->Doc->body);
			//default picture
			$c->add("div", 	array("class"=>"front posab loc_t loc_l fitw fith"));//->Content = "nbsp;";

	$out = IGK_STR_EMPTY;
	$s = $this->_getadoratordir();
	$tab = IGKIO::GetDirFileList($s);	
	
	if ($tab && count($tab>0)){
			$script = $c->addScript();
			
	$afi = $this->App->Configs->adorator_fade_interval;
	$ari = $this->App->Configs->adorator_rotation_interval;
	$rnd = igk_parsebool( $this->App->Configs->adorator_random_enabled? true: false);
	$defindex = -1;
	if ($this->m_currentIndex)
{
	$defindex = $this->m_currentIndex;
}
			$p =<<<EOF
igk.animation.InitBgAdorator(igk.getParentScriptByTagName('div'), 20, $ari, $afi,$rnd,  '{$this->getUri('getfilelist_ajx')}',{$defindex}, '{$this->getUri('updateindex_ajx&index=')}');
EOF;
				$script->Content = $p;
		
		}
		}
		
		
		public function updateindex_ajx()
		{
			$this->m_currentIndex = igk_getr("index");
			$this->View();
			igk_exit();
		}
	
}

//>
//represent a Palette controller Model
//>
final class IGKPaletteCtrl extends IGKNonVisibleControllerBase
{
	private $m_palettes;
	
	//get the name of the controller
	public function getName(){ return IGK_PALETTE_CTRL;}
	
	//get list of palettes	
	public function getPalettes(){ return $this->m_palettes; }
	
	//get the palette directory
	public function getPaletteDir(){
		return igk_io_baseDir("R/Palettes");
	}	
	public function loadFile($fname)
	{
		if (!file_exists($fname))return;
		
		$v_name = igk_io_basenamewithoutext($fname);
		
		$v_t = null;
		if (isset($this->m_palettes[$v_name]))
		{
			$v_t = $this->m_palettes[$v_name];
		}
		else 
			$v_t = array();		
		
		$e =  IGKHtmlItem::CreateWebNode("pal");
		try{
		$e->Load(IGKIO::ReadAllText($fname));
		
		$e = igk_getv($e->getElementsByTagName("palette"), 0);
		if ($e){
		foreach($e->Childs as $k)
		{
			if (strtolower($k->TagName)=="item")
			{
				$v = $k["color"];
				$n = $k["name"];
				$v_t[$n] = $v;
			}
		}
		
		$this->m_palettes[$v_name] = $v_t;
		}
		}
		catch (Exception $ex) {
		}
	}
	protected function InitComplete()
	{
		parent::InitComplete();
		$this->loadPalette();		
		$this->App->Session->addUpdateSessionEvent($this, "updatePaletteSession");
	}
	public function updatePaletteSession(){
		//refresh cal the view if necessary
		if (igk_is_debuging()){
			igk_getctrl(IGK_PALETTE_CTRL)->loadPalette();
		}
	}
	public function loadPalette()
	{
		if(IGKIO::CreateDir($this->getPaletteDir()))
		{
			$v_tfiles = IGKIO::GetFiles($this->getPaletteDir(), "/\.gkpal$/i", false);
			foreach($v_tfiles as $f)
			{
				$this->loadFile($f);
			}
		}
	}
	//remove palette
	public function RemovePalette($id){
		$s = $this->getPaletteDir()."/".$id.".gkpal";
		if (file_exists($s))
		{			
			unlink($s);
			$this->m_palettes = array();
			$this->loadPalette();
		}
	}
	public function __construct()
	{
		parent::__construct();
		$this->m_palettes = array();
	}
	
}
//------------------------------------------------------------------------------------
///- THEME CONTROLLER
//------------------------------------------------------------------------------------
final class IGKThemeCtrl extends IGKConfigCtrlBase
{
	private $m_search;
	private $m_searchkey;
	private $m_searchColor;
	private $m_searchRes;
	private $m_rendering;
	private $m_selectedMenu;
	private $m_lastThemeChanged; //last language key changed
	private $m_cssFileTable;
	
	public static function GetRegClass(){
		return IGKHtmlClassValueAttribute::GetRegClass();
	}
	public static function UnRegClass($key){
		return IGKHtmlClassValueAttribute::UnRegClass($key);
	}
	public function __construct(){
		parent::__construct();
		$this->m_search = null;
		$this->m_rendering =false;
		$this->m_cssFileTable = array();
	}
	public function getName(){return IGK_THEME_CTRL;}
	///<summary>load theme by name</summary>
	public function loadTheme(){
		//THEME CTRL // LOAD THEME
		//igk_debug_wln("notice:loadtheme");		
		$f = igk_io_syspath("R/Themes/".$this->App->Doc->Theme->Name.".phtml");		
		if (file_exists($f))
		{
			$this->App->Doc->Theme->load($f);
		}
	}
	public function saveTheme(){		
		$this->App->Doc->Theme->save();		
	}
	public function ResetTheme(){
		$this->App->Doc->Theme->def->Attributes->Clear();
		$this->saveTheme();
		igk_exit();
	}
	public function removeTheme(){	
		$f = igk_io_syspath("R/Themes/".$this->App->Doc->Theme->Name.".phtml");			
		if (file_exists($f))
		{
			@unlink(igk_io_currentRelativePath($f));						
			igk_notityctrl()->addMsgr("msg.theme.updated");
			$this->View();
		}
	
	}
	protected function InitComplete(){
		parent::InitComplete();
		IGKApp::getInstance()->Session->RegClasses->regEvent->add($this, "ReloadView");		
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onThemeChangedProc");				
		//load custom theme
		$this->_initTheme();
	}
	private function _initTheme()
	{	
		//remove all themes
		//$this->app->Doc->ClearStyle();
		//init system theme
		$this->App->Doc->initSysTheme();
		//load system theme
		$this->loadTheme();
		//load additional css theme
		$this->themeLoadCssFiles();
	}
	public function onThemeChangedProc($ctrl)
	{
		$n = $this->App->Doc->Theme->RegChangedKey;		
		if ($ctrl->isChanged($n, $this->m_lastThemeChanged))
		{
			//merge theme with the current
			$this->loadTheme();
			if ($this->getIsVisible())
				$this->View();
		
		}
	}
	public function ReloadView()
	{
		if ($this->m_rendering)
			return;
		$this->View();
	}
	function _adddel_action($frm)
	{
			$frm->addInput("btn_delaction","button", R::ngets("btn.rmSelection"), array("onclick"=>"javascript:this.form.btn_action.value = 1; this.form.submit()"));
	}
	public function delete_selection()
	{
		$tab = igk_getr("keytab");
		igk_debug_wln("notice:IGKThemeCtrl::delete_selection");
		
		$x = igk_getr("ccount", 0);
		for($i = 0; $i<$x; $i++)
		{
			$t = igk_getr("css_i_".$i);
			if ($t)
			{
				$this->App->Doc->Theme->def->Attributes[$tab[$i]] = null;
			}
		}
			
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
	}
	public function save_as_default(){
		$frame_name = "save_as_default_frame";
		if (igk_qr_confirm())
		{
		 $n = igk_getr(IGK_FD_NAME,"default");
		 $f = igk_io_syspath(IGK_DEFAULT_THEME_FOLDER."/".$n.".themes");
		
		if ( !IGKIO::CreateDir(dirname($f))|| !$this->App->Doc->Theme->save($f))
		{
			igk_notifyctrl()->addError(R::gets("ERR.CANTSAVEFILE"));
		}
		else{
			igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved", basename($f)));
		}
		igk_frame_close($frame_name);
		igk_navtocurrent();
		}
		else{
			$frame = igk_add_new_frame($this, $frame_name);
			$d = $frame->Content;
			$frame->Title = R::ngets("title.SAVEDefaultTheme");
			$d->ClearChilds();
			$frm = $d->addForm();
			$frm["action"] = $this->getUri("save_as_default");
			$frm->addSLabelInput(IGK_FD_NAME, "text", "default", true);
			$frm->addHSep();
			$frm->addInput("confirm", "hidden", 1);
			$frm->addBtn("btn_save", R::ngets("btn.Save"),"submit");
			
		}
	}
	public function select_menu(){
		$this->m_selectedMenu = igk_getr("n","default");
		$this->View();
	}
	public function View(){					
		$this->TargetNode->ClearChilds();
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		//rendering to ignored theme management update
		$this->m_rendering = true;
		//load not registrated registrated class
		foreach(IGKThemeCtrl::GetRegClass() as $k)
		{
			if(!isset($this->App->Doc->Theme[$k]))
				$this->App->Doc->Theme[$k]=IGK_STR_EMPTY;
		}
		IGKHtmlUtils::AddItem($this->TargetNode, $this->ConfigNode);
		$node = $this->TargetNode;	
		$node->ClearChilds();
		igk_html_add_title($node, R::ngets("title.themeManager"));
		$node->add(new IGKHtmlSeparatorItem());
		
		
		
		$this->m_selectedMenu = $this->m_selectedMenu?$this->m_selectedMenu: "themes";
		$div = $node->addDiv();
		igk_add_article($this,"themes.description", $div);
		$node->addHSep();
		//view menu
		$menut = array("themes", "cssFiles", "palette","color", "font", "system_theme");
		$t = array();
		foreach($menut as $k)
		{
			$t[$k] = $this->getUri("select_menu&n=".$k);
		}
		IGKHtmlUtils::CreateConfigSubMenu($node, $t, $this->m_selectedMenu);
		unset($t);
		$node->addHSep();
		
		$frm = $this->TargetNode->addForm();
		$frm["action"] = $this->getUri("update_name");	
		$frm["id"]="class_editor";
		$frm->addBr();
		$frm->addSLabelInput("theme_name", "text",$this->App->Doc->Theme->Name);		
		IGKHtmlUtils::AddBtnLnk($this->TargetNode,R::ngets("btn.savetheme"), $this->getUri("save_as_default"));	
		$node->addHSep();
		switch(strtolower($this->m_selectedMenu))
		{
			case "palette":			
				$this->_th_showPalette();
				break;
			case "cssfiles":
				$this->themeShowCssFiles();
				break;
			case "font":			
				$this->_showFont();	
				break;
			case "color":
				$this->_showColor();
			break;
			case "system_theme":
				$this->_showSystemTheme();
			break;
			default:
				$this->_showThemes();
				break;
		}
		
		$this->TargetNode->addHSep();
		
		$this->m_rendering = false;
	}
	//-----------------------------------------------------------------------------------------------------
	// THEMES FUNCTION . SHOW CURRENT THEME
	//-----------------------------------------------------------------------------------------------------
	private function _showThemes()
	{
		$div = $this->TargetNode;		
		$div = $div->addDiv();
		igk_add_loading_frame($div);		
		$div->addScript()->Content = "(function(q){ igk.ajx.apost('".$this->getUri("themeViewPrimaryConfig_ajx")."',null, function(xhr){if (this.isReady()){ this.setResponseTo(q); }}, false);})(igk.getParentScript());";
		
	}
	
	public function themeViewPrimaryConfig_ajx()
	{	
		$c =  IGKHtmlItem::CreateWebNode("div");
		$div = $c;
		igk_html_add_title($div, R::ngets("title.CSSClass"));
		$div->addHSep();
		
		
		igk_setr("q", igk_getr("q", $this->m_searchkey));
		$div->add(new IGKHtmlSearchItem($this->getUri("search")));
		$div->addBr();
		$frm = $div->addForm();
		$frm["action"] = $this->getUri("theme_updatekeys");
		//view all themes
		$tab = null;
		$ttab = null;		
		$v_index= 0;
		if ($this->m_search === null)
		{
			$tab =  $this->App->Doc->Theme->def->Attributes->ToArray();
			$ttab =$this->App->Doc->Theme->def->Attributes->ToArray();
		}
		else{
			$tab =  $this->m_search;
			$ttab = $this->m_search;
		}
		if (count($ttab)>0)
		{
		$ctab = array_keys($ttab);
		igk_usort($ctab, "igk_key_sort");
		$this->_adddel_action($frm);
		$frm->addSpace();
		$this->_themeFormControl($frm);

		$tcount = $frm->addDiv();		
		$ul  = $frm->addTable();	
		$tr = $ul->add("tr");		
		
		IGKHtmlUtils::AddToggleAllCheckboxTh($tr);
		
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>"fitw") )->Content =  R::ngets("clValue");
		$tr->add("th",array("class"=>"box_16x16"))->Content = IGK_HTML_SPACE;
		$tr->add("th",array("class"=>"box_16x16"))->Content = IGK_HTML_SPACE;
		
		foreach($ctab as $k)
		{
			$kk = $this->App->Doc->Theme->def[".".$k];
			if (!empty($kk) || empty($k))
				continue;
				
			$v = $tab[$k];
			$li = $ul->add("tr");
			$chbox = $li->add("td")->add("input", array("type"=>"checkbox"));//Content = IGK_HTML_SPACE;
			$chbox["name"] = "css_i_".$v_index;
			
			$li->add("td" ,array("class"=>"no-wrap"))->add("span", array("for"=>"key_".$v_index, "class"=>"-cllabel dispb no-wrap"))->Content = $k;
			$txt = $li->add("td")->addInput("key_".$v_index, "text", $v);
			
			$v_id = htmlentities($k);			
			$li->add("td" ,array("class"=>"box_16x16"))->add("a", array("href"=>$this->getUri("theme_editkey&id=".base64_encode($v_id))))->add("img", array("src"=>R::GetImgUri("edit")));
			$li->add("td" ,array("class"=>"box_16x16"))->add("a", array("href"=>$this->getUri("theme_rmkey&id=".base64_encode($v_id))))->add("img", array("src"=>R::GetImgUri("drop")));
			$v_index++;
			
		$li->addInput("keytab[]","hidden", $v_id);
		}
		
		igk_html_toggle_class($ul, "tr");
		$tcount->Content  =  $v_index;
		}
		$frm->addInput("ccount","hidden",$v_index);
		$frm->addInput("btn_action","hidden","0");
		$frm->addBtn("btn_update", R::ngets("btn.Update"));		
		$frm->addSpace();
		$this->_adddel_action($frm);
		$this->_themeFormControl($frm);
		igk_wln($c->innerHTML);
		return;
	}
	public function restore_theme(){
		$n  = base64_decode(igk_getr(IGK_FD_NAME));		
		if(!empty($n)){
		$this->App->Doc->Theme->Name = $n;
		$this->loadTheme();		
		$this->View();
		}
		igk_navtocurrent();
	}
	private function _showSystemTheme(){
		$node = $this->TargetNode;
		igk_html_add_title($node, R::ngets("title.SystemThemeManager"));
		$node->addHSep();
		$frm = $node->addForm();
		$frm["action"] = $this->getUri("restore_theme");
		
		$dir = igk_io_currentRelativePath(IGK_DEFAULT_THEME_FOLDER);
		$tab = IGKIO::GetDirFileList($dir);
		if ($tab && (count($tab)>0))
		{
			$frm->add("label", array("for"=>IGK_FD_NAME))->Content = R::ngets(IGK_FD_NAME);		
			$sl = $frm->add("select");		
			$sl["id"]=$sl["name"] = IGK_FD_NAME;			
			foreach($tab as $k)
			{
				$opt = $sl->add("option");
				$s = igk_io_remove_ext(basename($k));
				$opt["value"]=base64_encode ($s);
				$opt->Content =$s;
			}
		}
		else{
			$frm->addDiv()->Content = "no theme found: ". $dir;
		}
		$frm->addHSep();
		$frm->addBtn("btn_validate", R::ngets("btn.restore"));
	}
	
	//--------------------------------------------------
	//PALETTE FUNCTIONS
	//--------------------------------------------------
	public function palette_UpdateCurrentPaletteName_ajx()
	{
		$r = igk_getr("clCurrentPaletteName");		
		$this->App->Configs->CurrentPaletteName = $r;
		igk_save_config();
	}
	private function _th_showPalette(){
		$node = $this->TargetNode;
		igk_html_add_title($node, R::ngets("title.paletteManager"));
		$node->add(new IGKHtmlSeparatorItem());
		
		igk_add_article($this,"themes.palette.description", $node);
		$frm = $node->addForm();
		
		$div = $frm->add("div", array("style"=>"height: auto; line-height: 16px; max-width : 300px;"));
		
		$optiondiv = $div->addDiv();
		$w = 16;
		$h = 16;
		$p = IGK_STR_EMPTY;		
		$cl = "#000";
		$li = $optiondiv->add("li");
		$li->addLabel("lb.currentPaletteName");
		$sel = $li->add("select");
		$sel["id"]=$sel["name"] = "clCurrentPaletteName";
		$sel["onchange"]= "javascript:window.igk.ajx.post('".$this->getUri('palette_UpdateCurrentPaletteName_ajx&')."'+this.id+'='+this.value, null, null);"; 
		
		$currentPal = igk_getv($this->App->Configs, "CurrentPaletteName", null);		
		$v_check = true;
		$sel->add("option",array("value"=>IGK_STR_EMPTY));
		foreach(igk_getctrl(IGK_PALETTE_CTRL)->Palettes as $k=>$v)
		{
			
			$cdiv = $div->addDiv();
			$v_t = $cdiv->addDiv();
			$v_t->Content = $k;						
			IGKHtmlUtils::AddImgLnk($v_t, igk_js_post_frame($this->getUri("theme_dropPalette_ajx&id=".$k)), "drop");
			
			$v_option = $sel->add("option",array("value"=>$k));
			
			if ($k == $currentPal){
				$v_option["selected"]="true";
				$v_check = false;
			}
			$v_option->Content = $k;
			
			foreach($v as $m=>$n)
			{
				$p = $n;
				$f = $cdiv->add("a", array("style"=>"display: inline-block; width:".$w."px; 
				height:".$h."px; margin: 1px; background-color:".$p.";"));	
				$f->Content = IGK_HTML_SPACE;
				$f["href"]="#";//	$this->getUri("setColor&cl=".$p);
			}
		}
		if (!$v_check)
		{
			$this->App->Configs->CurrentPaletteName = null;
		}
		IGKHtmlUtils::AddBtnLnk($frm,R::ngets("btn.AddPalette"), igk_js_post_frame($this->getUri("theme_addPalette_ajx")));
	}
	
	public function theme_dropPalette_ajx()
	{
		$id = igk_getr("id");
		$frame = igk_frame_add_confirm($this,"theme_droppalette_confirm_frame", $this->getUri("theme_dropPalette"));
		$frame->Form->Div->Content = R::ngets("msg.confirmsuppression");			
		$frame->Form->Div->addInput("clId", "hidden", $id);			
		$frame->RenderAJX();
	}
	public function theme_dropPalette()
	{
		if (igk_qr_confirm())
		{
			$id = igk_getr("clId");
			igk_getctrl(IGK_PALETTE_CTRL)->RemovePalette($id);
			$this->View();
			$this->TargetNode->RenderAJX();
			igk_exit();
		}		
	}
	public function theme_addPalette_ajx(){
		$frame = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addPalette", $this,  "#palette_form");
		IGKHtmlUtils::AddItem($frame,  $this->App->Doc->body);	
		$frame->Title = R::ngets("title.AddPalette");
		
		$d = $frame->Content;
		$frame->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("theme_addPalette");
		$frm->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name");
		$li = $frm->add("li");
		$li->add("label", array("for"=>"clFile"))->Content = R::ngets("lb.palette");
		$li->addInput("clFile","file","file");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));
		
		$frame->RenderAJX();
	}
	
	public function theme_addPalette()
	{
		$v_c = igk_getv($_FILES, "clFile");
		
		if ($v_c)
		{
			$v_fname = igk_getctrl(IGK_PALETTE_CTRL)->getPaletteDir()."/".igk_getr(IGK_FD_NAME).".gkpal";
			igk_io_move_uploaded_file($v_c["tmp_name"], $v_fname);
			igk_notifyctrl()->addMsgr("msg.paletteAdded");			
			igk_getctrl(IGK_PALETTE_CTRL)->loadFile($v_fname);
			$this->View();
		}		
	}
	
	
	//--------------------------------------------------
	//STYLES FUNCTIONS
	//--------------------------------------------------
	///<summary>used in configuration mode to edit controller style in configuration mode. when article is added</summary>
	public function theme_editStyle_ajx($render=true){
		$n = igk_getr("n"); //name of the controller
		$ctrl = igk_getctrl($n);
		$frame = igk_add_new_frame($this, "edit_frame_ajx");
		
		
		$n = strtolower($ctrl->Name );		
		$frame->Title = R::ngets("title.editclassentry");
		$frame->Width = "700px";
		$frame->Height = "400px";
		$frame->ClearChilds();
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("theme_editStyle_validateajx");
		$frm->setId("editstyle-ajx-form");
		$frm["class"] = "editstyle-ajx-form";
		
		$frm->add("li")->add("label", array("for"=>"clValue"))->Content = $n;
		
		
		$area = $frm->add("li")->add("textarea");
		$area["class"]="cltextarea +theme_stylearea";
		$area->setId("clValue");
		$area->Content = $this->App->Doc->Theme[$n];
		$frm->addInput(IGK_FD_NAME, "hidden", $n);
		$frm->addInput("clUpdated", "hidden", $n);
		$frm->addInput("clCibling", "hidden", igk_getr("cibling")); //to allow cibling on the document
		$frm->addHSep();
		$frm->addBtn("btn_update", R::ngets("btn.update"));
		if ($render)
		$frame->RenderAJX();		
	}
	public function theme_editStyle_validateajx(){		
		$t = igk_get_robj();
		$this->App->Doc->Theme[$t->clName] = $t->clValue;
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		igk_notifyctrl()->addMsgr("msg.themestyle.updated");
		igk_resetr();
		$_REQUEST["n"] = $t->clName;
		$this->theme_editStyle_ajx(false);		
		header("Location: ".igk_io_baseUri()."/#".$t->clName);
		igk_exit();
	}
	public function theme_editkey(){	
		$n = base64_decode(igk_getr("id"));		
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addkey", $this, "#class_editor");		
		IGKHtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		
		$frm->Title = R::ngets("title.editclassentry");
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("theme_addKey");
		$frm->add("li")->add("label")->Content = $n;
		$frm->add("li")->Content = IGK_HTML_SPACE;		
		$frm->add("li")->addSLabelInput("clValue","text", $this->App->Doc->Theme[$n] );
		$frm->addInput(IGK_FD_NAME, "hidden", $n);
		$frm->addInput("clUpdated", "hidden", $n);
		$frm->addHSep();
		$frm->addBtn("btn_update", R::ngets("btn.update"));	
	}
	public function theme_addKey($navigate=true){
		$n = trim( igk_getr("clName"));
		$v = igk_getr("clValue");
		if ($n){
			$this->App->Doc->Theme[$n] = $v;
		}
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
		$t = igk_getr("clUpdated" , false);
		if ($t)
		{
			igk_frame_close("theme_addkey");
		}
		if ($navigate)
			igk_navtocurrent();
	}
	public function theme_updatekeys(){
	
		if (igk_getr("btn_action") == 1){ $this->delete_selection(); return;}
		
		 $keytab= igk_getr("keytab");
		 $hv = igk_getr("ccount");
		 $n = igk_getr("theme_name");
		
		
		for($i = 0 ; $i< $hv; $i++)
		{			
			$this->App->Doc->Theme[$keytab[$i]] = igk_getr("key_".$i);
		}
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
		
		try{
			igk_notifyctrl()->addMsgr("msg.themeupdated");
			igk_navtocurrent();
		}catch(Exception $ex)
		{
			igk_show_exception($ex);
		}
	}

	
	//--------------------------------------------------
	//FONT FUNCTIONS
	//--------------------------------------------------
	private function _showFont(){
		$d = $this->TargetNode;
		igk_html_add_title($d, R::ngets("title.FontManager"));
		$d->add(new IGKHtmlSeparatorItem());
		
		igk_add_article($this,"themes.fontmanager.description", $d);		
		$d->add(new IGKHtmlSearchItem($this->getUri("searchfont"), $this->m_searchfont,"qft"));
		$d->addHSep();
		
		$frm = $this->__getfontform();
		$d->add($frm);
	}
	public function getFontDir(){ 
		return igk_io_syspath(IGK_RES_FONTS);
	}
	public function add_font(){
		$f = igk_getv($_FILES, "clfile");
		$n = igk_getr(IGK_FD_NAME);
		if (($f["error"] == 0) && igk_qr_confirm() ){
			if (IGKIO::CreateDir($this->FontDir))
			{
				$destination = IGKIO::GetDir($this->FontDir."/".$f["name"]);
				
				if (!file_exists($destination))
				{
					if (!igk_io_move_uploaded_file($f["tmp_name"],$destination))
					{
						igk_notifyctrl()->addError("move upload file failed");
					}
					else{
							$d = igk_html_uri(igk_io_basePath($destination));
							igk_notifyctrl()->addMsg("Font added : ".$d);
							$this->App->Doc->Theme->addFont($n, $d);
					}
				}
				else{
					igk_notifyctrl()->addError("failed file already exists");
					$d = igk_io_basePath($destination);
					$this->App->Doc->Theme->addFont($n, $d);
				}
			}
			else{				
				igk_notifyctrl()->addError("can't create a directory");
			}
		}
		else{
				igk_notifyctrl()->addError("can't add font ". $f["error"] );
		}
		$this->View();
		igk_navtocurrent();
	}
	
	public function theme_buildFontTable($table, $presentation=null)
	{
		//header
		$tr = $table->add("tr");
		IGKHtmlUtils::AddToggleAllCheckboxTh($tr);//->add("th")->Content = IGK_HTML_SPACE;
		
		$tr->add("th")
		->setClass("fitw")
		->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = R::ngets("clPath");
		//$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th", array("style"=>"width:24px;"))->Content = IGK_HTML_SPACE;
		
		//had content
		$dir = igk_io_currentRelativePath(IGK_RES_FONTS);	
		$ft = $this->App->Doc->Theme->getFont();
		//
		$ajx = igk_sys_isAJX()?"&ajx=1":"";
		foreach($ft->Attributes as $k=>$v)		
		{
			$tr = $table->add("tr");
			
			$tr->add("td",array("style"=>"width:16px; "))
			->addInput("fontnames[]", "checkbox", $k)
			->setStyle("width:auto;");//Content = IGK_HTML_SPACE;
			$tr->add("td")->Content = $k;
			$f = igk_getv($v, 'File');
			if ($f && file_exists(igk_io_currentRelativePath($f)))
			{
				$tr->add("td")->add("a",array("href"=>$this->getUri("getfontfile&n=".base64_encode($v))))->Content = $v;
			}
			else{
				$tr->add("td")->Content = "????";
			}				
			IGKHtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px;")),igk_js_post_frame($this->getUri("drop_font_ajx&n=".base64_encode($k))), "drop");		
			if ($presentation)
			{
			$presentation->add("li", 
				array(
				"igk-font-tool-tip"=>$k, 
				"igk-font-drop-font"=>$this->getUri("drop_font{$ajx}&n=".base64_encode($k)),
				"igk-font-drop-font-uri"=>R::GetImgUri("drop")))				
				->setClass("dispib")
				->addDiv(array("style"=>"height:48px; font-family: '".$k."';"))->Content = "igK";
			}
		}
			
	}
	private function __getfontform(){
		$frm =  IGKHtmlItem::CreateWebNode("form");
		//bind actions
		
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.addNewFont"), igk_js_post_frame($this->getUri("ft_add_font_frame_ajx")));	
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.installFontFrame"), igk_js_post_frame($this->getUri("ft_install_font_frame_ajx")));
		
		$table  = $frm->add("table", array("class"=>"fitw"));
		$ul = $frm->add("ul", array("id"=>"font_list", "class"=>"font_list"));
		
		$this->theme_buildFontTable($table, $ul);
		
		//bind actions
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.addNewFont"), igk_js_post_frame($this->getUri("ft_add_font_frame_ajx")));	
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.installFontFrame"), igk_js_post_frame($this->getUri("ft_install_font_frame_ajx")));
		
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.rmAll"),igk_js_post_frame($this->getUri("Clear_all_font_ajx")));//, array("onclick"=>"if(confirm('".R::gets("MSG.CONFIRMALLFONTSUPRESSIONQUESTION")."')){ igk_confirm_lnk(this);} return false;"));
		$frm->addInput("confirm", "hidden", 0);
		
		return $frm;
	}
	//font function
	public function ft_add_font_frame_ajx(){
		$frame = igk_add_new_frame($this, "add_font_frame", "?#font_list");
		$frame->Title = R::ngets("title.addfont");		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("add_font");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput(IGK_FD_NAME);
		$ul->add("li")->addSLabelInput("clfile",  "file");
		$frm->addInput("confirm", "hidden", 1);
		$frm->addHSep();
		$frm->addInput("btn_confirm", "submit", R::ngets("btn.addfont"));		
		$frame->RenderAJX();
	}
	public function ft_install_font_frame_ajx(){
		$frame = igk_add_new_frame($this, "ft_install_font_frame");
		$frame->setTitle(R::ngets("title.install_fontframe_dialog"));
		$frame->Content->ClearChilds();
		igk_getregctrl("sys")->viewInstallFontForm($frame->Content, $this);
		$frame->RenderAJX();
	}
	
	public function drop_font(){
		$v = base64_decode(igk_getr("n"));		
		$this->App->Doc->Theme->removeFont($v);
		$this->View();
	}
	public function drop_font_ajx(){
		if (igk_qr_confirm())
		{
			$this->drop_font();
			$this->View();
			igk_navtocurrent();
		}
		else{
			$n = igk_getr("n");
			$frame = igk_frame_add_confirm($this, "drop_font_frame", $this->getUri("drop_font_ajx"));				
			$frame->Form->Div->Content = R::ngets("q.delete_font_1", base64_decode($n));						
			$frame->Form->addInput("n","hidden", $n);
			$frame->RenderAJX();
		}
	}
	public function Clear_all_font_ajx(){
		if (igk_qr_confirm())
		{
			$this->App->Doc->Theme->ClearFont();
			$this->View();		
			igk_navtocurrent();
		}
		else{
			$frame = igk_frame_add_confirm($this, "Clearallfont_confirm_frame", $this->getUri("Clear_all_font_ajx"));				
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEALLFONT_QUESTION);	
			$frame->RenderAJX();
		}
	}
	public function getfontfile(){
		$v = base64_decode(igk_getr("n"));
		igk_getctrl(IGK_FILE_MAN_CTRL)->getfile(igk_io_currentRelativePath($v));
	}
	
	
	private function __addbtn($frm, $ctrl){		
			IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.add"), $ctrl->getUri("addnewcolorframe#colorman"));			
			IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.importcolorfile"), $ctrl->getUri("th_importcolorfileframe#colorman"));			
			IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.downloadcolor"), $ctrl->getUri("th_downloadcolorfile#colorman"));			
			IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.Clearthemecolor"), $ctrl->getUri("th_Clearthemecolor#colorman"));
	}
	//--------------------------------------------------
	//COLOR FUNCTION
	//--------------------------------------------------
	public function th_Clearthemecolor()
	{
		$this->App->Doc->Theme->cl->Attributes->Clear();
		igk_notifyctrl()->addMsgr("msg.colorupdated");
		$this->View();
	}
	public function th_downloadcolorfile()
	{
		$v_div =  IGKHtmlItem::CreateWebNode("Colors");
		foreach($this->App->Doc->Theme->cl->Attributes as $k=>$v)
		{
			$v_div->add("color", array("name"=>$k, "value"=>$v));
		}
		$s = "<?xml version=\"1.0\" ?>\r\n".$v_div->Render((object)array("Indent"=>true));
		igk_download_content("colortheme.xml", strlen($s),  $s);
		//$v_div->RenderAJX();
		igk_exit();
	}
	public function th_importcolorfile()
	{
		
		igk_wln("th_importcolorfile");
		$v_f = igk_getv($_FILES, "clColorFile");
		$text = IGKIO::ReadAllText($v_f["tmp_name"]);
		$v_t =  IGKHtmlItem::CreateWebNode("div");		
		$v_t->Load($text);		
		$v_clt = igk_getv($v_t->getElementsByTagName("Colors"), 0);		
		if ($v_clt !== null)
		{
			igk_wln("load color");
			foreach($v_clt->Childs as $k=>$v)
			{
				if ($v->TagName=="color")
				{
					$this->App->Doc->Theme->addColor($v["name"], $v["value"]);	
					
				}
			}
			$this->View();			
		}	
		igk_notifyctrl()->addMsgr("Msg.ColorUpdated");
		igk_frame_close("theme_importcolorfile");
		
	}
	public function th_importcolorfileframe()
	{
		$frm = igk_add_new_frame($this, "theme_importcolorfile", "#colorman",$this->App->Doc->body); 
		
		 
		$frm->Title = R::ngets("title.importcolorfile");		
		$frm->ClearChilds();
		$d = $frm->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("th_importcolorfile#colorman");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clColorFile", "file",null);		
		$frm->addHSep();
		$frm->addBtn("btn_import",R::ngets("btn.import") );
	}

	private function _showColor(){
		
		$d = $this->TargetNode;
		$t = igk_html_add_title($d, R::ngets("title.ColorManager") );				
		$t->setId("colorman");
		$d->addHSep();
		igk_add_article($this,"themes.colormanager.description", $d);
		$d->addHSep();
		$d->add(new IGKHtmlSearchItem($this->getUri("searchcolor"), $this->m_searchColor,"qcl"));
		$d->addHSep();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("changecl");
		//get colors
		$colors = igk_getv($this->App->Doc->Theme->getElementsByTagName("Colors"),0);
		
		
		$this->__addbtn($frm, $this);
		$frm->addBr();
		$frm->addBr();
		igk_notify_sethost($frm->addDiv());
		$tab = $frm->addTable()->setClass("fitw");
		if (igk_sys_getconfig("BootStrap.Enabled"))
			$tab["class"] = "table table-striped";
		$ctab = $colors->Attributes->ToArray();
		
		$stab = array_keys($ctab);
		igk_usort($stab, "igk_key_sort");
		$tr = $tab->add("tr");
		IGKHtmlUtils::AddToggleAllCheckboxTh($tr);
		
		$tr->add("th", array("class"=>"fitw-2"))->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>"fitw-2"))->Content = R::ngets("clValue");		
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		
		foreach($stab as $k)
		{
			if (($this->m_searchColor) && !strstr($k, $this->m_searchColor) )
				continue;
				$v = IGKHtmlUtils::GetValue($ctab[$k]);
				
				$tr = $tab->add("tr");
				$tr->add("td")->add("input", array("type"=>"checkbox"));
				$tr->add("td")->Content = $k;
				$tr->add("td")->Content = $v;
				$tr->add("td")->add($this->_newColorBox(igk_css_treatcolor($colors, $v, true),array(
				"href"=>igk_js_post_frame($this->getUri("editColor&n=".$k."&cl=".urlencode($v))))));				
				IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("dropcolor&n=".$k), "drop");
				
		}
		$frm->addBr();
		$this->__addbtn($frm, $this);
		igk_html_toggle_class($tab);
		
	}
	public function editColor(){
		$n = urldecode(igk_getr("n"));
		$cl = igk_getr("cl");
		$frm = $this->addnewcolorframe( $n, $cl);
		$frm->RenderAJX();
		igk_exit();
	}
	public function addnewcolorframe($name=null, $color=null){
		$frame = igk_add_new_frame($this, "theme_addcolor", "#colorman",$this->App->Doc->body); 
		$edit = $name !=null;
		if (!$edit)
			$frame->Title = R::ngets("title.addColorTheme");		
		else 
			$frame->Title = R::ngets("title.editColorTheme");		
		$frame->ClearChilds();
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("addColorThemeKey#colorman");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput(IGK_FD_NAME,  "text", $name);
		$ul->add("li")->addSLabelInput("clColor",  "text", $color);		
		if ($edit)
			$ul->add("li")->addInput("clEdit", "hidden", true);
		$frm->addBtn("btn_add", $edit? R::ngets("btn.Edit") :R::ngets("btn.Add"));
		return $frame;
	}
	public function addColorThemeKey(){
		$cl = igk_getr(IGK_FD_NAME);
		$cv = igk_getr("clColor");
		if (!empty($cl))
		{
			$this->App->Doc->Theme->addColor($cl, $cv);	
			igk_notifyctrl()->addMsg("Color modifier ".$cl." = ".$cv);
			if (igk_getr("clEdit"))
			{
				$this->View();
				igk_frame_close("theme_addcolor");
			}
		}
		$this->View();
	}
	public function dropcolor(){
		$cl = igk_getr("n");
		$this->App->Doc->Theme->removeColor($cl);		
		$this->View();
		
	}
	private function _newColorBox($cl, $attribs =null, $width=16, $height=16){
		$box =  IGKHtmlItem::CreateWebNode("a")->AppendAttributes(array("class"=>"color_view nodecoration dispib", "style"=>
"width:".$width."px; height:".$height."px; background-color:".$cl.";"));
		$box->AppendAttributes($attribs);
		$box->Content = " ";
		return $box;
	}
	public function searchcolor(){
		$this->m_searchColor = igk_getr("qcl");
		$this->View();
	}
	
	
	//--------------------------------------------------
	//RES FUNCTION
	//--------------------------------------------------	
	private function _showRes(){
		$d = $this->TargetNode;
		
		igk_html_add_title($d, R::ngets("title.resManager"));
		$d->add(new IGKHtmlSeparatorItem());
		$d->add(new IGKHtmlSearchItem($this->getUri("searchres"),$this->m_searchRes,"qres"));
		$frm = $d->addForm();
	}
	public function searchres(){
	$this->m_searchRes = igk_getr("qres");
		$this->View();
	}
	private function _themeFormControl($frm)
	{	
		IGKHtmlUtils::AddBtnLnk($frm, "btn.Add" , igk_js_post_frame($this->getUri("theme_addKeyFrame_ajx"))); 
		IGKHtmlUtils::AddBtnLnk($frm, "btn.deleteallempty" , igk_js_post_frame($this->getUri("theme_deleteall_emptyclass_ajx"))); 
	}
	public function theme_deleteall_emptyclass_ajx(){
		if (igk_qr_confirm())
		{
		
			$tab = $this->App->Doc->Theme->def->Attributes->ToArray();
			$out = array();
			foreach($tab as $k=>$v)
			{
				if (empty($v)){
					$this->App->Doc->Theme[$k] = null;
					IGKThemeCtrl::UnRegClass($k);		
			
					continue;
				}
				$out[$k] = $v;
			}
			
			$this->App->Doc->Theme->def->Attributes->Clear();
			$this->App->Doc->Theme->setAttributes($out);
			igk_getctrl(IGK_THEME_CTRL)->saveTheme();			
			$this->View();
			//igk_navtocurrent();
		}
		else{
			$frame = igk_frame_add_confirm($this,__FUNCTION__, $this->getUri(__FUNCTION__));
			$frame->RenderAJX();
		}
	}
	public function theme_addKeyFrame_ajx(){
		
		$frame= igk_add_new_frame($this, "theme_addkey", "#class_editor"); //igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addkey", $this, "#class_editor");
		
		$frame->Title = R::ngets("title.AddClass");
		$d = $frame->Content;
		$frame->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("theme_addKey");
		$frm->add("li")->addSLabelInput("clName");
		$frm->add("li")->addSLabelInput("clValue");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));	
		
		$frame->RenderAJX();		
	}
	
	public function search($searchkey=null){
		$q = igk_getr("q",$searchkey);
		
		
		if (empty($q))
		{			
			$this->m_search = null;
			$this->m_searchkey = null;
			$this->View();
			return;
		}
		$tab = $this->App->Doc->Theme->def->Attributes->ToArray();
		$out = array();
		foreach($tab as $k=>$v)
		{
			if (strstr($k, $q))
			{
				$out[$k]=$v;
			}
		}
		$this->m_search = $out;
		$this->m_searchkey = $q;
		$this->View();
	}
	public function update_name(){
		$n = igk_getr("theme_name", "default");
		$this->App->Doc->Theme->Name = $n;
		$this->View();
	}
	//--------------------------------------------------
	//CSS CLASS KEYS FUNCTION
	//--------------------------------------------------	
	public function theme_rmkey($key=null){
		$key = ($key == null)? base64_decode(igk_getr("id")) : $key;
		if (!empty($key))
		{
			$this->App->Doc->Theme[$key] = null;
			IGKThemeCtrl::UnRegClass($key) ;		
			igk_getctrl(IGK_THEME_CTRL)->saveTheme();
			$this->search($this->m_searchkey);
			$this->View();
		}
	}
	//search all available keys that match the "t" pattern
	public function theme_findkey_ajx(){
		$t = igk_getr("t");
		if ($t == null){
			return;
		}
		$tab = $this->App->Doc->Theme->def->Attributes->ToArray();
		$out = array();
		$rep =  IGKHtmlItem::CreateWebNode("response");
		$keys = array_keys($tab);
		sort($keys);
		
		foreach($keys as $k)
		{
			$v = $tab[$k];
			if (strstr($k, $t))
			{				
				$rep->add("item", array("name"=>$k))->Content = $v;
			}
		}
		$rep->RenderAJX();		
	}
	protected function initTargetNode(){
		$t =  IGKHtmlItem::CreateWebNode("div")->AppendAttributes( array("class"=>strtolower($this->getName())));
		return $t;
	}
	
	public function getConfigPage()
	{
		return "themectrlconfig";
	}
	
	private function getCssDataFile()
	{
		return igk_io_currentRelativePath(IGK_DATA_FOLDER."/StylesData.xml");
	}
	public function themeCurrentMedia()
	{
		if(IGKUserAgent::IsIE())return "ie";
		if(IGKUserAgent::IsMod())return "mod";
		if(IGKUserAgent::IsChrome()) return "chr";
		if(IGKUserAgent::IsSafari()) return "saf";
		if(IGKUserAgent::IsAndroid())return "android";
		if(IGKUserAgent::IsIOS())return "ios";		
		return "ie";
	}
	public function themeIsSupportMedia($target)
	{
		if ($target=="*")return true;
		if (strstr($target, $this->themeCurrentMedia()))
			return true;
		return false;
	}
	private function themeLoadCssFiles()
	{
		$this->m_cssFileTable = array();
		$t =  IGKHtmlItem::LoadNode(IGKIO::ReadAllText($this->getCssDataFile()));

		if (($t!=null) && ($t->HasChilds))
		{			
			
			foreach($t->Childs as $k=>$v)
			{
				$k = igk_html_uri($v["file"] );
				if ($this->themeAddCss($k, $v["target"], $v["block"]))
				{
					if (!igk_is_debuging())
					{
						$this->app->Doc->addStyle($k);
					}
				}
			}
		}		
	}
	private function themeAddCss($file, $device="ie" , $block=false)
	{
		if (!isset($this->m_cssFileTable[$file]))
		{
			$v_cssObj = new StdClass;
			$v_cssObj->Uri = $file;
			$v_cssObj->Target = $device;
			$v_cssObj->Block = $block;
			$this->m_cssFileTable[$file] = $v_cssObj;				
			return true;
		}
		return false;
	}
	///add css file to system
	public function themeAddCssFile($file, $device="ie")//supported device all, ie, mod, android, ios
	{
		if ($this->themeAddCss(igk_html_uri($file), $device))
		{
			$this->themeSaveCssData();
		}
	}
	function themeSaveCssData()
	{
		$o =  IGKHtmlItem::CreateWebNode("cssData");
		foreach($this->m_cssFileTable as $k=>$v)
		{
			$css = $o->add("css");
			$css["file"] = $v->Uri;
			$css["target"] = $v->Target;
			$css["block"] = $v->Block;
		}
		IGKIO::WriteToFileAsUtf8WBOM($this->getCssDataFile(), $o->Render());
	}
	public function themeGetCss()
	{
		$t = IGK_STR_EMPTY;
		foreach($this->m_cssFileTable as $k=>$v)
		{
			if ( !$v->Block && $this->themeIsSupportMedia($v->Target))
			{
				$t .="/* ". $k. "*/\n";
				$t .= IGKIO::ReadAllText(igk_io_currentRelativePath($k))."\n";
			}
		}
		return $t;		
	}
	public function themeShowCssFiles()
	{
		$t =  IGKHtmlItem::CreateWebNode("table");
		$t["class"]="fitw";
		
		$b =  array("style"=>"width:16px;");
		$tr = $t->add("tr");
		$tr->add("th", $b)->addSpace();
		$tr->add("th");
		$tr->add("th");
		$tr->add("th", $b)->addSpace();
		$tr->add("th", $b)->addSpace();
		$tr->add("th", $b)->addSpace();
		foreach($this->m_cssFileTable as $k=>$v)
		{
			$tr = $t->add("tr");
			$tr->add("td", $b)->addSpace();
			$tr->add("td")->add("a", array("href"=>$this->getUri("themeDownloadCssFile&n=".base64_encode($k))))->Content = $v->Uri;
			$tr->add("td")->Content = $v->Target;			
			
			IGKHtmlUtils::AddImgLnk($tr->add("td"),igk_js_post_frame($this->getUri("themeEditFile_ajx&n=".base64_encode($k))), "edit", "16px", "16px","dropCSS File" );			
			IGKHtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("themeBlockCssFile&n=".base64_encode($k)),$v->Block? "block": "unblock", "16px", "16px","dropCSS File" );
			IGKHtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("themeDropFile&n=".base64_encode($k)), "drop", "16px", "16px","dropCSS File" );
			
		}
		$this->TargetNode->add($t);
		//actions button div
		$t =  IGKHtmlItem::CreateWebNode("div");
		//9
		IGKHtmlUtils::AddBtnLnk($t, "btn.addCssFile", igk_js_post_frame($this->getUri("themeAddNewCssFile_ajx")));
		$this->TargetNode->add($t);
	}
	public function themeAddNewCssFile_ajx()
	{
		//$t =  IGKHtmlItem::CreateWebNode("div");
		//$t->Content  = "Add New Css File Not Implement";
		
		
		$frame = igk_add_new_frame($this, "frame_themeAddNewCssFile");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.addCssFile");		
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("themeAddCssFileFunc");
		$ul = $frm->add("ul");			
		$ul->add("li")->addInput("clName", "text", "newfile");		
		$sl = $ul->add("li")->add("select");
		$sl["id"]=$sl["name"]="clFor";
		$sl->add("option")->Content = "ie";
		$sl->add("option")->Content = "mod";
		
		$frm->addHSep();
		$frm->addBtn("btn_update", R::ngets("btn.add"));		
		if (igk_sys_isAJX())
		{
			$frame->RenderAJX();
		}
		
		//$t->RenderAJX();
	}
	public function themeAddCssFileFunc()
	{
		$n = igk_getr("clName", null);
		
		if ($n && preg_match("/([a-zA-Z_][a-zA-Z0-9_]+)/i", $n) )
		{
			$f = igk_io_currentRelativePath("Styles/".$n.".css");
			IGKIO::WriteToFileAsUtf8WBOM($f, "/* ".$n." */", true);
			igk_frame_close("frame_themeAddNewCssFile");
			$this->themeAddCssFile(igk_html_uri(igk_io_basePath($f)),  igk_getr("clFor","ie"));
			$this->View();
		}
	}
	public function themeBlockCssFile()
	{
		$n = base64_decode(igk_getr("n"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			return;			
		}
		$this->m_cssFileTable[$n]->Block = !$this->m_cssFileTable[$n]->Block;
		$this->themeSaveCssData();
		$this->View();
	}
	public function themeEditFile_ajx()
	{
		$n = base64_decode(igk_getr("n"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			igk_wl("ERROR: no file to edit");
			return;			
		}
		$p = $this->m_cssFileTable[$n];
		$f = igk_io_currentRelativePath($p->Uri);
		
		if(file_exists($f))
		{
		$frame = igk_add_new_frame($this, "frame_themeEditFile");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.editCssFile", basename($n));						
		$str = IGKIO::ReadAllText($f);					
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("themeUpdateCssFile");
		$ul = $frm->add("ul");
		$txt = $ul->add("li")->addTextArea("clContent", $str);			
		$txt["class"] = "frame_textarea";
		$frm->addInput("clfile", "hidden", base64_encode($n));
		$frm->addInput("clframe", "hidden", $frame["id"]);
		$frm->addBtn("btn_update", R::ngets("btn.Update"));
		
		if (igk_sys_isAJX())
		{
			$frame->RenderAJX();
		}
		}
		else{
			igk_wl("ERROR: FILE NOT EXISTS");
		}
	}
	public function themeUpdateCssFile()
	{
		$n = base64_decode(igk_getr("clfile"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			return;			
		}
		igk_io_saveContentFromTextArea(igk_io_currentRelativePath($n), igk_getr("clContent"), true);
		igk_frame_close("frame_themeEditFile");
	}
	public function themeDropFile()
	{
		$n = base64_decode(igk_getr("n"));
		if (isset($this->m_cssFileTable[$n]))
		{
			@unlink(igk_io_currentRelativePath($n));
			unset($this->m_cssFileTable[$n]);
			$this->themeSaveCssData();
			$this->View();
		}
	}
	
	
}

//represent a frame controller
final class IGKFrameDialogCtrl extends IGKControllerBase
implements IIGKFrameController 
{
	private $m_frames;
	public function getName(){return IGK_FRAME_CTRL;}
	
	public function closeFrame_ajx()
	{
		$id = igk_getr("id");
		igk_frame_close($id);
	}
	public function __construct(){
		parent::__construct();
		$this->m_frames = array();
	}
	public function View(){
	//notion to view
	}
	public function ContainFrame($id, $frame, $remove=true)
	{
		if (isset($this->m_frames[$id]))
		{
			if ($frame !== $this->m_frames[$id])
			{
				igk_wln("contains but not same handle $id");
				if ($remove){
					unset($this->m__frames[$id]);										
				}
				return false;
			}
			return true;
		}
		else{
			//free frame
		}
		return false;
	}
	
	public function createFrame($id, $owner, $closeuri=null, $reloadcallback = null){
		if (($id == null ) ||!is_string($id))
			return null;
			
		if ( isset($this->m_frames[$id]))
		{
			$v_dial =  $this->m_frames[$id];
			
			$b = $v_dial->getOwner();
			
			// igk_wln("frame already exists ".get_class($v_dial->getOwner()) . "  ". get_class($owner));
			// igk_wln("frame already exists ?". ($b === $owner));
			// igk_exit();
			if ($b === $owner)
				return $v_dial;			
		}
		$v_dial = new IGKMsDialogFrame($this, $id, $owner, $reloadcallback);
		$v_dial->ClearChilds();
		$cluri = null;
		if ($closeuri){
			$cluri = "&closeuri=".urlencode($closeuri);
		}
		else{
			$cluri="&navigate=1";
		}
		$v_dial->setCloseUri($this->getUri("closeFrame&id=".$id.$cluri));	
		$v_dial["id"] = $id;
		$this->m_frames[$id]= $v_dial;			
		return $v_dial;
	}
	public function getFrame($id)
	{
		if ( isset($this->m_frames[$id]))
		{
			return $this->m_frames[$id];
		}
		return null;
	}
	
	public function close_frame_ajx()
	{
		$href = base64_decode(igk_getr("href"));
		$tag = igk_getquery_args($href);
		$this->closeFrame(igk_getv($tag, "id"));
		igk_wl( $this->App->Doc->body->Render());
		igk_exit();
		
	}
	public function closeFramre_ajx()
	{
		$this->closeFrame();
	}
	public function closeFrame($id=null, $navigate = null){				
		$v_id = ($id!=null)? $id :igk_getr("id",0);
		$closeuri = null;
		$navigate = $navigate ===null? igk_getr("navigate", false): $navigate;
		
		if ( isset($this->m_frames[$v_id]))
		{
			$frame = $this->m_frames[$v_id];
			$args = igk_getquery_args($frame->closeUri);
			if (($closeuri = urldecode(igk_getr("closeuri")))==null)
				$closeuri = urldecode(igk_getv($args, "closeuri"));
			igk_html_rm($frame);				
			if (method_exists(get_class($frame->Owner), "frameClosed"))
			{
				$frame->Owner->frameClosed();
			}
			//call the closed method
			$frame->closeMethod();			
			//unset frame id
			unset($this->m_frames[$v_id]);
			//unset frame
			unset($frame);
		}	
		else {
			//....
			igk_wln("frame not found ".$v_id);
		}
		
		if (!igk_sys_isAJX() ){
	
			if ($closeuri)
			{		
				igk_navtocurrent($closeuri);
				igk_exit();
			}
			else if ($navigate)
			{
				igk_navtocurrent();
				igk_exit();
			}
		}
	}
}


//page  controlleurs
final class IGKPageManagerCtrl extends IGKConfigCtrlBase
{
	private $m_oldpage;
	
	public function __construct()
	{
		parent::__construct();
		$this->m_oldpage = null;
	}
	public function getIsVisible(){
		return true;
	}
	protected function initTargetNode()
	{
		$t =  IGKHtmlItem::CreateWebNode("div");
		$t["class"]="igk-web-pageinfo";
		return $t;
	}
	protected function InitComplete(){
		parent::InitComplete();		
		//::register page change event
		$this->App->addCurrentPageEvent($this, "View");
	}
	public function View()
	{	
		//view Configs
		if ($this->getIsVisible())
		{			
		
			switch ($this->CurrentPageFolder)
			{
				case IGK_CONFIG_PAGEFOLDER:					
					$this->App->Doc->body["class"] = "-".$this->m_oldpage;
					$this->_viewConfig();	
					break;
				default:
					$this->_showPage();
					break;
			}
		}
		else {		
			igk_html_rm($this->TargetNode);
		}
			
	}
	private function _showPage()
	{
		$page = igk_getctrl(IGK_MENU_CTRL)->CurrentPage;
		$t = $this->TargetNode;	
		$t->ClearChilds();
		$dir = $this->getPageFolderFullPath ();	
		
		$file = igk_io_getdir($dir."/".$page.".".R::GetCurrentLang().".phtml");
		if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
		{
			return;
		}
		//add page node always at the top
		igk_html_add($this->TargetNode, $this->App->Doc->body,-500);
		$this->App->Doc->body["class"] = "-".$this->m_oldpage;
		$this->m_oldpage = $page;
		$this->App->Doc->body["class"] = "+".$this->m_oldpage;		
		if(file_exists($file))
		{
			$v_str = igk_html_bind_content($this, @file_get_contents($file));						
			$t->Load($v_str);
		}
	}
	private function _viewConfig(){
		if ( $this->ConfigCtrl->SelectedConfigCtrl !== $this) 
			return;
		$this->ConfigNode->ClearChilds();
		$div =  IGKHtmlItem::CreateWebNode("div");
		igk_html_add($div, $this->ConfigNode);		
		
		
		$node = $div;
		$this->addTitle($node, "title.PageManagerEditor");
		$node->addHSep();
		igk_add_article($this,"page.description", $node->addDiv());
		$node->addHSep();

		$node->addDiv()->add("label")->Content = "CurrentLang : ". R::GetCurrentLang();
		$frm = $node->addForm();
	
		//get page list
		$p = igk_getctrl(IGK_MENU_CTRL)->getPageList();
		
		$tab = $frm->addTable();
		$tab["class"] ="igk-table igk-table-hover" ;
		$tr = $tab->add("tr");
		$tr->add("th", array("style"=>"min-width:200px"))->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($p as $k)
		{
			$tr = $tab->add("tr");
			$tr->add("td")->add("a" ,array("href"=>$this->getUri("getfile&n=".$k)))->Content = $k;
			IGKHtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("editPageFrame&name=".$k), "edit", "16px", "16px","editpage" );
			IGKHtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("editPageFrameWTiny&name=".$k), "tiny", "16px", "16px","editpage" );
		}
	}
	public function editPageFrame($wtiny=false)
	{
		$n = igk_getr("name");
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("page_editframe", $this);
		IGKHtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.editpage_1", $n);
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("savePage");
		$frm->add("li")->add("label")->Content =IGK_STR_EMPTY ;
		$frm->addInput("name", "hidden", $n);
		$file = $this->getPageFile($n);
		$area = $frm->add("li")->addTextArea("clContent", file_exists($file)? IGKIO::ReadAllText($file):null );
		if ($wtiny)
			igk_js_enable_tinymce($frm, 'exact', array("clContent"));
		
		$frm->addBtn("btn_save", R::ngets("btn.Update"));	
	}
	public function editPageFrameWTiny()
	{
		$this->editPageFrame(true);
	}
	public function getPageFile($n)
	{	
		$dir = $this->getPageFolderFullPath ();
		$file =  igk_io_getdir($dir."/".$n.".".R::GetCurrentLang().".phtml");
		return $file;
	}
	public function getfile(){
		$n = igk_getr("n");
		$file = $this->getPageFile($n);
		if (file_exists($file))
		{
			igk_download_file(basename($file), $file);
		}
		else{
			igk_notifyctrl()->addError("impossible d'obtenir le fichier ".basename($file));
		}
	}
	private function getPageFolderFullPath(){
		return igk_io_basePath(IGK_PAGE_FOLDER);
	}
	public function savePage(){
		//save content with tiny in utf8 without bom
		$n = igk_getr("name");				
		$content = igk_getr("clContent");		
		$dir = $this->getPageFolderFullPath();
		
		IGKIO::CreateRDir($dir);		
		$file = igk_io_getdir($dir."/".$n.".".R::GetCurrentLang().".phtml");
		$out = igk_html_unscape( $content);	
		IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);	
		igk_frame_close("page_editframe");
	}
	
	public function getConfigPage()
	{
		return "pageconfig";
	}
}

///group controlleur
final class IGKUserGroupController extends IGKNonVisibleControllerBase
{	
	public function getDataTableName(){return "tbigk_usergroups"; }
	public function getDataTableInfo()
	{
	
	return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clUserId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10, "clIsIndex"=>true, "clIsUniqueColumnMember"=>true ,"clFromTable"=>"tbigk_users" ,"clLinkType"=>"tbigk_users")),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGroupId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10,"clIsIndex"=>true, "clIsUniqueColumnMember"=>true , "clFromTable"=>"tbigk_groups", "clLinkType"=>"tbigk_groups" ))
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->insert($n, array("clUserId"=>1, "clGroupId"=>2));		
	}
	
}

//group controlleur
final class IGKGroupController extends IGKConfigCtrlBase
{
	private $selectedGroup;
	public function getConfigPage()
	{
		return "groupconfig";
	}
	public function getConfigCategory(){
		return "managment";
	}
	
	
	public function getDataTableName(){return "tbigk_groups"; }
	public function getDataTableInfo()
	{
	return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255, "clIsUnique"=>true ))
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function initDataEntry($db)
	{		
		$n = $this->DataTableName;
		$db->insert($n, array(IGK_FD_NAME=>"users"));
		$db->insert($n, array(IGK_FD_NAME=>"admin"));
	}
	public function View()
	{
		$this->TargetNode->ClearChilds();
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);			
			return;
		}
		$this->_showConfig();
	}
	public function group_default_view(){
		$this->CurrentView = null;
		$this->View();
	}
	private function _showConfig()
	{
		igk_html_add($this->TargetNode, $this->ConfigNode);
		$node = $this->TargetNode;
		$this->addTitle($node, "title.GroupEditor");
		$node->addHSep();
		igk_add_article($this,"group.description", $node->addDiv());
		$node->addHSep();
		switch($this->CurrentView)
		{
			case "viewusers":
				$d = $node->addDiv();
				
				$id = igk_getr("clId");
				$group = $this->selectedGroup==null ?  igk_db_table_select_row("tbigk_groups", $id) : $this->selectedGroup;
				
				if($group == null)
				{
					$this->CurrentView = null;
					$this->View();
					igk_exit();
				}
				
				$d->addDiv()->setClass("igk-title-2")->Content = $group->clName;
				
				$d = $node->addDiv();
				IGKHtmlUtils::AddImgLnk($d, $this->getUri("group_default_view"), "back_48x48", "48px", "48px");
				igk_notify_sethost($d->addDiv());
				$options = $d->addDiv();
				$users = igk_db_table_select_where("tbigk_users", null);
				
				$tb = $d->addDiv()->addTable();
				$tb["class"] = "igk-table-hover";

				$r = igk_db_table_select_where("tbigk_usergroups",array("clGroupId"=>$group->clId));
				$tb->setHeader(IGK_STR_EMPTY, 
				R::ngets("clName"), IGK_STR_EMPTY);
				if ($r && $r->HasRow){
				foreach($r->Rows as $k=>$v){
					$r = $tb->addRow();
					$u = igk_db_table_select_row("tbigk_users", array("clId"=>$v->clUserId));				
					if ($u){
						$r->add("td")->addInput("clUsers[]", "checkbox", $u->clId);												
						$r->add("td")->Content = igk_user_fullname($u);
						IGKHtmlUtils::AddImgLnk($r->add("td"), $this->getUri("group_remove_user&clId=".$v->clId), "drop");
					}
				}				
				}
				else{
					$d->addDiv()->Content = "No Rows";
				}
				$frm = $options->addForm();
				$frm["action"] = $this->getUri("group_add_userto_group");
				$p = $frm->addSelect("clUserId");
				if ($users){
				foreach($users->Rows as $k=>$v){
					$p->add("option")->setAttribute("value", $v->clId)->Content = igk_user_fullname($v);
				}
				}
				$frm->addInput("clGroupId", "hidden", $this->selectedGroup->clId);
				IGKHtmlUtils::AddImgLnk($frm->add("span"), "javascript: \$igk(this).getParentByTagName('form').submit(); return false;",  "add");
				$this->selectedGroup = $group;
			break;
			default:
				
				
				$frm = $node->addForm();
				
				$table = $frm->addTable();
				$table["class"]="igk-table igk-table-hover igk-table-stripped";
				$tr = $table->add("tr");
				$tr->add("th", array("style"=>"width:16px;"))->Content = IGK_HTML_SPACE;
				$tr->add("th", array("class"=>"fitw"))->Content = R::ngets("clName");
				$tr->add("th", array("style"=>"width:16px;"))->Content = IGK_HTML_SPACE;
				$tr->add("th", array("style"=>"width:16px;"))->Content = IGK_HTML_SPACE;
				$tr->add("th", array("style"=>"width:16px;"))->Content = IGK_HTML_SPACE;
				$e = $this->getDbEntries();
				if ($e && ($e->RowCount>0))
				foreach($e->Rows as $k=>$v)
				{
					$tr = $table->add("tr");
					$tr->add("td")->Content = IGK_HTML_SPACE;
					$tr->add("td")->Content = $v->clName;
					//IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("group_view_auth&clId=".$v->clId),"auth");
					IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("group_view_user&clId=".$v->clId),"user");
					IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("group_dropgroup_ajx&clId=".$v->clId)),"drop")->img["alt"] = "drop group";
				}	
				$frm->addHSep();
				$v_ackdiv = $frm->addDiv();
				IGKHtmlUtils::AddImgLnk($v_ackdiv, igk_js_post_frame($this->getUri("group_add_group_ajx")), "add");
			break;
		}
		
	}
	public function group_add_userto_group(){
		$obj = igk_get_robj();		
		if (igk_db_insert($this, "tbigk_usergroups", array("clUserId"=>$obj->clUserId, "clGroupId"=>$obj->clGroupId))){
		igk_notifyctrl()->addMsg("group associated");
		}
		else{
			igk_notifyctrl()->addError("group not associated");
		}
		$this->View();
	}
	public function group_remove_user(){
		igk_db_delete($this, "tbigk_usergroups", igk_getr("clId"));
		$this->View();	
	}
	private function group_removeGroup($id)
	{
		igk_db_delete($this, $this->getDataTableName(), array("clId"=>$id));
		return true;
	}
	public function group_dropgroup_ajx(){
		$id = igk_getr("clId");
		if (igk_qr_confirm())
		{		
			if ($this->group_removeGroup($id))
			{
				igk_notifyctrl()->addMsgr("msg.group.removed");	
			}
			$this->View();
			$this->TargetNode->RenderAJX();
			
		}
		else{			
			$frame = igk_frame_add_confirm($this, "confirm_frame", $this->getUri("group_dropgroup_ajx&clId=".$id));
			$frame->Form->Div->Content = R::ngets("msg.confirmsuppression");			
			$frame->Form->Div->addInput("clId", "hidden", $id);			
			$frame->RenderAJX();
		}
	}
	public function group_add()
	{
		$v = igk_get_robj();
		if($v){
		igk_db_insert($this, $this->getDataTableName(), $v);
		$this->View();
		}
	}
	public function group_add_group_ajx()
	{
		$frame = igk_add_new_frame($this, "group_add_new_frame");
		$frame->title = R::ngets("title.AddNewGroup");
		$div = $frame->Content ;
		$frm = $div->addForm();
		$frm["action"] = $this->getUri("group_add");
		$ul = $frm->add("ul");		
		$ul->add("li")->addSLabelInput("clName", IGK_STR_EMPTY);
		$frm->addHSep();
		$frm->addInput("btn.add", "submit", R::ngets("btn.Add"));		
		$frame->RenderAJX();
	}
	public function group_view_user(){
		$this->CurrentView = "viewusers";
		$this->selectedGroup = igk_db_table_select_row("tbigk_groups", igk_getr("clId")); 
		$this->View();
	}
	public function group_view_auth(){
		$this->CurrentView = "viewauth";
		$this->View();
	}
}
//groups and authorisation
final class IGKGroupAuthorisations extends IGKConfigCtrlBase
{
	public function getConfigCategory(){
		return "managment";
	}
	public function getDataTableInfo(){//get data table name for :: IGKGroupAutorisations
		return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGroupId", IGK_FD_TYPE=>"Int", "clNotNull"=>true,"clIsUnique"=>0,  IGK_FD_TYPELEN=>10 , "clLinkType"=>"tbigk_groups" )),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clAuthId", IGK_FD_TYPE=>"Int","clNotNull"=>true, "clIsUnique"=>0,  IGK_FD_TYPELEN=>10 , "clLinkType"=>"tbigk_autorisations" )),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGrant", IGK_FD_TYPE=>"Int","clNotNull"=>true, IGK_FD_TYPELEN=>10, "clDescription"=>"Grand Access depending on the autorisation usage")),
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function getDataTableName(){return "tbigk_groupautorisations"; }
	public function getConfigPage()
	{
		return "groupauth";
	}
	public function IsUserAuthorised($s, $actionName, $authTable= IGK_TB_AUTHORISATIONS, $userGroupTable="tbigk_groupautorisations")
        {
            if (($s == null) || empty($actionName))
                return false;
            if ($s->clLevel == -1)
                return true;//administrator have all access
            //get auth
            $r = igk_db_table_select_row($authTable,  array("clName"=>$actionName));            
            $v_r = true;
            if ($r)
            {
                //get autorisation id
                $v_authid = $r->clId;
                //find group that user is member of
                $v_usergroup =igk_db_table_select_where($userGroupTable, array("clGroupId"=> $s->clId));
                
                foreach ($v_usergroup->Rows as  $item )
                {
                    $q = igk_db_table_select_where($userGroupTable, array("clGroupId"=>$item->clGroupId,
                    "clAuthId"=> $v_authid));
                    if ($q && ($q->RowCount == 1))
                    {
                        $v_r = $v_r && ($q->getRowAtIndex(0)->clGrant== 1);
                    }
                }
                return !$v_r;
            }
            else
            {

                $p = (object)array();
                $p->clName = $actionName;
                igk_db_table_insert($this, $authTable, $p);
            }
            return false;
     }
	public function auth_check_auth(){
		$id = igk_getr("clUser");
		$auth = igk_getr("clAuth");
		$row = igk_db_table_select_row("tbigk_users", $id);
		$b = igk_notifyctrl()->getNotification("notify:checkauth", true);
		$b->addMsg(" ::: is authorise : ". igk_parsebool( $this->IsUserAuthorised($row, $auth) ));

		$this->View();
	}
	public function View(){
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_html_add_title($t, "title.manageauth");
		
		$t->addHSep();
		igk_add_article($this, "auth.managerdesc" , $t->addDiv(), null, true);
		$t->addHSep();
	
		$frm = $t->addForm();
		$frm["action"] = $this->getUri("auth_check_auth");		
		$ul=  $frm->add("ul");
		$li = $ul->add("li");
		$li->add("label")->Content = R::ngets("lb.users");
		$select = $li->addSelect("clUser");		
		$r = igk_db_table_select_where("tbigk_users", null, $this);
		$select->add("option");
		if ($r)
		foreach($r->Rows as $k=>$v){
			$opt = $select->add("option");	
			$opt["value"] = $v->clId;
			$opt->Content = igk_user_fullname($v);
		}
		$ul->add("li")->addSLabelInput("clAuth");
		igk_notify_sethost($frm->addDiv(), "notify:checkauth");
		$frm->addInput("btn.input", "submit", R::ngets("btn.CheckAuth"));
	
	
	
		$frm = $t->addForm();
		igk_notify_sethost($frm->addDiv());
		
		
		$this->auth_options($frm);
		
		$table = $frm->addTable();
		$table["class"] = "igk-table igk-table-hover";
		
		$r = igk_db_table_select_where(IGK_TB_AUTHORISATIONS, null, $this);
		
		$tr = $table->add("tr");
		$tr->add("th")->addSpace();
		$tr->add("th")->setClass("fitw")->Content = R::ngets("lb.clName");
		$tr->add("th")->addSpace();
		$tr->add("th")->addSpace();
		if($r){
		foreach($r->Rows as $k=>$v){
			$tr = $table->add("tr");
			$tr->add("td")->addInput("clAuths[]", "checkbox");
			$tr->add("td")->Content = $v->clName;
			IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("auth_edit_frame_ajx&clId=".$v->clId)), "edit");
			IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("auth_delete_authorisation_ajx&clId=".$v->clId)), "drop");
			
		}
		}
		$this->auth_options($frm);
	}
	private function _isAuth($q , $t)
	{
		foreach($q->Rows as $k=>$v){
			if ($v->clGroupId == $t)
				return $t;
		}
		return false;
	}
	public function auth_edit_frame_ajx(){
		$id = igk_getr("clId");
		$row = igk_db_table_select_row(IGK_TB_AUTHORISATIONS, $id);
		if ($row==null)
		{
			igk_navtocurrent();
			igk_exit();
		}
		if (igk_qr_confirm()){
		
			igk_frame_close(__FUNCTION__);
			
			$gp = igk_getr("clGroups");
			igk_db_delete($this, $this->getDataTableName(), array("clAuthId"=>$id));
			if ($gp)
			{
			foreach($gp  as $k=>$v){
				igk_db_insert($this, $this->getDataTableName(), array("clAuthId"=>$id, "clGroupId"=>$v, "clGrant"=>1));
			}
				igk_db_reload_index($this, $this->getDataTableName());
			}
			$this->View();
		    igk_navtocurrent();
			
			
			
			igk_exit();
		}
		else{
		$frame = igk_add_new_frame($this, __FUNCTION__);
		$frame->Title = R::ngets("title.edit_authorisation_1", $row->clName);
		$frame->Content->ClearChilds();
		$d = $frame->Content->addDiv();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri(__FUNCTION__);
		$d = $frm->addDiv();
		$d["class"] = "igk-form-group";
		//view group that have this authorisation
		
		$table = $d->addTable();
		$table["class"] = "igk-table igk-table-hover";
		$r = igk_db_table_select_where("tbigk_groups" /*$this->getDataTableName(), array("clAuthId"=>$id)*/,null);
		if ($r){
			$g = igk_db_table_select_where($this->getDataTableName(), array("clAuthId"=>$id));
			$groupindex = array();
			foreach($g->Rows as $k=>$v){
				$groupindex[$v->clGroupId] = $v;
			}
			//igk_show_prev($groupindex);
			$tr = $table->add("tr");
			$tr->add("th")->addSpace();
			$tr->add("th")->Content = R::ngets("lb.Group");
			$tr->add("th")->addSpace();
			foreach($r->Rows as $k=>$v){
				$tr = $table->add("tr");
				$tr->add("td")->addInput("clGroups[]", "checkbox", $v->clId)->setAttribute("checked",isset($groupindex[$v->clId]));
				$tr->add("td")->Content = $v->clName ;
				IGKHtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("auth_remove_group_ajx&clId=".$id."&clGroupId=".$v->clId)), "drop" );
			}
		}
		$div = $frm->addDiv();
		//IGKHtmlUtils::AddImgLnk($div, igk_js_post_frame($this->getUri("auth_add_group_ajx&clId=".$id)), "add");
		$frm->addHSep();
		$frm->addInput("clId", "hidden", $id);
		$frm->addInput("confirm", "hidden", 1);
		$frm->addInput("btn.confim", "submit", R::ngets("btn.confirm"));
		$frame->RenderAJX();
		}
	}
	public function auth_add_group_ajx(){
		$id = igk_getr("clId");
		$row = igk_db_table_select_row(IGK_TB_AUTHORISATIONS, $id);
		if ($row == null)
		{
			igk_navtocurrent();
			igk_exit();
		}
		if (igk_qr_confirm())
		{
			igk_frame_close(__FUNCTION__);
			$gp = igk_getr("clGroups");
			igk_db_delete($this, $this->getDataTableName(), array("clAuthId"=>$id));
			if ($gp)
			{
			foreach($gp  as $k=>$v){
				igk_db_insert($this, $this->getDataTableName(), array("clAuthId"=>$id, "clGroupId"=>$v));
			}
				igk_db_reload_index($this, $this->getDataTableName());
			}
			$this->View();
			igk_navtocurrent();
		}
		else{
		$frame = igk_add_new_frame($this, __FUNCTION__);
		$frame->Title = R::ngets("title.add_group_1", $row->clName);
		$frame->Content->ClearChilds();
		$d = $frame->Content->addDiv();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri(__FUNCTION__);
		$d = $frm->addDiv();
		$d["class"] = "igk-form-group";
		
		$table = $d->addTable();
		$table ["class"] = "igk-table igk-table-hover igk-table-striped";
		$table->setHeader(IGK_STR_EMPTY, 
		R::ngets("lb.clGgroupName"),
		IGK_STR_EMPTY);
		
		$r = igk_db_table_select_where("tbigk_groups");
		foreach($r->Rows as $k=>$v)
		{
			$tr = $table->addRow();
			$tr->add("td")->addInput("clGroups[]", "checkbox", $v->clId);
			$tr->add("td")->Content = $v->clName;
		}
		
		$frm->addHSep();
		$frm->addInput("confirm", "hidden", "1");
		$frm->addInput("clId", "hidden", $id);
		$frm->addInput("btn.confirm", "submit");
		$frame->RenderAJX();
		}
	}
	public function auth_remove_group_ajx(){
	if (igk_qr_confirm())
	{
		igk_frame_close(__FUNCTION__);
		$h = igk_db_delete($this, $this->getDataTableName(), array(
			"clId"=>igk_getr("clId"),
			"clGroupId"=>igk_getr("clGroupId")));
			
		if ($h)
			igk_notifyctrl()->addMsgr("msg.group.removed");
		else{
			igk_notifyctrl()->addErrorr("msg.group.not_removed");
		}
		$this->View();
		igk_navtocurrent();
	}
	else{
			$frame = igk_frame_add_confirm($this, __FUNCTION__, $this->getUri(__FUNCTION__));
			$frame->Form->addInput("clId", "hidden", $id);
			$frame->Form->Div->Content = R::ngets("q.confirm_remove_group_auth");
			$frame->RenderAJX();
		}
	}
	public function auth_add_authorisation_ajx(){
	if (igk_qr_confirm())
	{
		$o = igk_get_robj();
		if (igk_db_insert($this, IGK_TB_AUTHORISATIONS, $o))
			igk_notifyctrl()->addMsgr("msg.authorisation.added");
		else{
			igk_notifyctrl()->addErrorr("msg.authorisation.notadded");
		}
		$this->View();
		igk_navtocurrent();
	}
	else{
		$frame = igk_add_new_frame($this, __FUNCTION__);
		$frame->Title = R::ngets("title.edit_authorisation_1");
		$d = $frame->Content->addDiv();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri(__FUNCTION__);
		$d = $frm->addDiv();
		$d["class"] = "igk-form-group";
		$d->addSLabelInput("clName");
		
		$frm->addHSep();
		$frm->addInput("confirm", "hidden", "1");
		$frm->addInput("btn.confirm", "submit");
		$frame->RenderAJX();
		}
	}
	private function auth_options($frm){
		IGKHtmlUtils::AddImgLnk($frm->add("span"), igk_js_post_frame($this->getUri("auth_add_authorisation_ajx")), "add");
	}
	public function auth_delete_authorisation_ajx(){
		$id = igk_getr("clId");
		$row = igk_db_table_select_row(IGK_TB_AUTHORISATIONS, $id);
		if (igk_qr_confirm() && $row)
		{
			igk_db_delete($this, IGK_TB_AUTHORISATIONS, array("clId"=>$id));
			$this->View();
			igk_navtocurrent();
		}
		else{
			$frame = igk_frame_add_confirm($this, __FUNCTION__, $this->getUri(__FUNCTION__));
			$frame->Form->addInput("clId", "hidden", $id);
			$frame->Form->Div->Content = R::ngets("q.confirm_auth_suppression");
			$frame->RenderAJX();
		}
	}
}


final class IGKAutorisationsCtrl extends IGKControllerBase
{
	public function getDataTableName(){return IGK_TB_AUTHORISATIONS ;}
	
	public function getIsVisible(){return false;}
	
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function getDataTableInfo(){
		return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>50, "clIsUnique"=>true))		
		);
	}	
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->insert($n, array(IGK_FD_NAME=>"mod_articles"));
		$db->insert($n, array(IGK_FD_NAME=>"mod_view"));
		$db->insert($n, array(IGK_FD_NAME=>"mod_post"));
	}
	
}




final class IGKDebugCtrl extends IGKControllerBase
{
	private $m_topdiv;
	private $m_optionsdiv;
	private $m_debuggerviewnode;
	
	public function getDebuggerView()
	{
		return $this->m_debuggerviewnode;
	}
	public function View()
	{		
		if ($this->getIsVisible())
		{
			//append to 
			$body = igk_sys_debugzone_ctrl();
			if ($body!=null){
				igk_html_add($this->getTargetNode(), $body->getTargetNode());
			}
		}
		else
			igk_html_rm($this->getTargetNode());
	}
	public function getIsVisible(){
		return igkServerInfo::IsLocal();
	}
	protected function InitComplete(){
		parent::InitComplete();		
	}
	public static function error_handler($errno,$message,$file,$line,$context) 
	{
		switch($errno) {
			// ignore warnings and notices
			case E_WARNING:
			case E_NOTICE:
			case E_USER_NOTICE:
			case E_USER_WARNING:
				break;
			// log PHP and user errors
			case E_ERROR:
			case E_USER_ERROR:
					  // Do some processing on fatal errors
				break;
			}
	}
	public function addMessage($div)
	{
		$this->m_topdiv->add($div);
	}
	protected function initTargetNode()
	{
		$node = parent::initTargetNode();
		$cl = strtolower($this->getName());
		$node["class"]=$cl." loc_t loc_l zback posr";
		$node->add("h2")->Content = R::ngets("title.debugger");
		$this->m_topdiv = $node->add("div",array("class"=>$cl."_content"));
		$this->m_optionsdiv = $node->add("div", array("class"=>$cl."_options posr loc_b loc_l"));
		IGKHtmlUtils::AddBtnLnk($this->m_optionsdiv, "btn.ClearDebug",$this->getUri("ClearDebug"));
		
		
		$this->m_debuggerviewnode = IGKHtmlItem::CreateWebNode("div");
		
		return $node;
		
	}
	public function ClearDebug()
	{
		$this->m_topdiv->ClearChilds();
	}
	
	
}
///<summary>Represenet IGKErrorManager </summary>
final class IGKErrorCtrl extends IGKControllerBase{

	var $target;
	
	private $m_errorUri;
	
	public function getName(){
		return IGK_ERROR_CTRL;
	}

	public function __construct(){
		parent::__construct();
		$this->m_visible = false;
	}	
	public function addError($uri){//error controller add error
		if ($this->m_errorUri == null)
			$this->m_errorUri = array();
		$this->m_errorUri[] = $uri;
		$this->View();
	}
	public function getIsVisible(){
		return igk_count($this->m_errorUri);
	}
	public function View(){//error controller not visibile
	}
}

/// controller de changement. permet à un controlleur de signaler un changement de configuration
final class IGKChangeManagerCtrl extends IGKConfigCtrlBase
{
	private $m_datas;
	private $m_propertyChangedEvent;
	private $m_loadConfigEvent;	
	private $m_vChange;
	private $m_ConfigNode;
	
	
	const DATE_CONST = 'Y-m-d H:i:s';
	public function getName(){		return IGK_CHANGE_MAN_CTRL;	}
	
	//ajout et suppression d'évènement
	public function addPropertyChangedEvent($obj, $method){
		$this->m_propertyChangedEvent->add($obj, $method);
	}
	public function removePropertyChangedEvent($obj, $method)
	{
		$this->m_propertyChangedEvent->remove($obj, $method);
	}
	//register to config event
	public function addLoadConfigEvent($obj, $method)
	{
		$this->m_loadConfigEvent->add($obj, $method);
	}
	public function removeLoadConfigEvent($obj, $method)
	{
		$this->m_loadConfigEvent->remove($obj, $method);
	}
	//donné sauvegarder par le controlleur
	public function getData(){
		return $this->m_datas;
	}
	public function __construct(){
		parent::__construct();
		$this->m_propertyChangedEvent = new IGKEvents($this, get_class($this)."::PropertyChanged");
		$this->m_loadConfigEvent =  new IGKEvents($this, get_class($this)."::loadConfigEvent");
		$this->loadConfig();
	}
	public function getConfigPage()
	{
		return "changectrl";
	}
	
	//enregistrer les changements sur un paramètre de configuration. 
	//cela a pour effet de mettre a jour la ligne de temps.
	public function registerChange($itemname, & $entrynewdata)
	{
		if (!$this->App->Configs->changectrl_checkchange)
			return;
		$d = date(self::DATE_CONST);
		$this->m_datas->$itemname = $d;
		$this->m_datas->LastChange = $this->m_datas->$itemname ;
		$this->m_datas->saveData();		
		$entrynewdata = $d;
	}
	//supprimer la sauvegarde sur un paramètre de configuration
	public function unregisterChange($itemname){
		if (!$this->App->Configs->changectrl_checkchange)
			return;
		$d = date(self::DATE_CONST);
		$this->m_datas->$itemname = null;
		$this->m_datas->LastChange = $d;
		$this->m_datas->Save();		
	}
	//detecter si la propriété a changer au cour du temp. retourne true si besoin de recharge sinon false
	public function isChanged($entryname, & $entrynewdata =null ){
		$n = $entryname;
		if ($this->Data->$n ==null)
			return;
		$data = $this->Data->$n ;
		$m = (($data != null) && (!empty($entrynewdata))) ;
		$reload = $m && ($data != $entrynewdata);
		if ($this->Data->$n != $entrynewdata)
		{
			$entrynewdata = $data;
		}
		return $reload;	
	}
	protected function InitComplete()
	{
		parent::InitComplete();
		//a chaque fois que la session doit être mis a jour recharger la configuration
		$this->App->Session->addUpdateSessionEvent($this, "loadConfig");		
	}
	public function getIsVisible(){
		return false;
	}
	public function IsFunctionExposed($function){//make all function available
		return true;
	}
	public function View(){
		//not visible
		$this->TargetNode->ClearChilds();
		if ($this->App->Configs->changectrl_checkchange)
		{
			$i = $this->App->Configs->changectrl_interval? $this->App->Configs->changectrl_interval : 'null';
			igk_html_add($this->TargetNode, $this->App->Doc->Body);		
			$this->TargetNode->addScript()->Content = "igk.ctrl.changement.init('".$this->getUri("checkforupdate_ajx")."', ".$i.");";
		}
		else{
			igk_html_rm($this->TargetNode);
		}
		
	}
	public function checkforupdate_ajx()
	{ 
		$this->loadConfig();
		if ($this->isChanged("LastChange", $this->m_vChange))
		{
			igk_wl(R::ngets("MSG.DATACHANGED"));
		}		
	}
	

	public function update_change()
	{
		$i = igk_getr("clCheckChange", false);
	
		$this->App->Configs->changectrl_checkchange = $i;
		$this->App->Configs->changectrl_interval = igk_getr("clChangeInterval");		
		igk_save_config();
		igk_resetr();
	
		igk_notifyctrl()->addMsgr("msg.configs.updated");
		$this->showConfig();
		$this->View();
	}
	//configuration view
	public function showConfig()
	{
		parent::showConfig();
		//view Config
		$c = $this->m_ConfigNode;
		$c->ClearChilds();
		IGKHtmlUtils::AddItem($c, $this->ConfigNode);
		igk_html_add_title($c, "title.ChangeCtrlManager");
		$c->addHSep();
		igk_notify_sethost($c->addDiv());
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("update_change");
		
		$ul = $frm->add("ul");
		$t = array();
		if ($this->App->Configs->changectrl_checkchange) 
			$t["checked"] = "true";
		
		$ul->add("li")->addSLabelInput("clCheckChange", "checkbox", $this->App->Configs->changectrl_checkchange, $t);
		$ul->add("li")->addSLabelInput("clChangeInterval",  "text", $this->App->Configs->changectrl_interval);
		
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	public function loadConfig()	
	{
		$fullpath = igk_io_syspath(IGK_CHANGE_CONF_DATA);
		$f = IGKCSVDataAdapter::LoadData($fullpath);
		if ($this->m_datas == null)
			$this->m_datas = new IGKConfigData($fullpath, $this, array());
		if ($f != null)
			{			
		foreach($f as $k=>$v)
		{	
			$c  = igk_getv($v,0);
			if ($c){
			// if ( igk_getv($this->m_datas,$v[0]) != $v[1])
			// {
				// $this->m_datas->$c =igk_getv($v, 1);	
			// }
			// else{
				$this->m_datas->$c = igk_getv($v, 1);
			// }
			}
		}
		}
		$this->__onLoadConfigEvent();
	}
	protected function __onLoadConfigEvent()
	{
		$this->m_loadConfigEvent->Call($this, null);
	}
	
	public function showinfo()
	{
		$this->TargetNode->ClearChilds();
		IGKHtmlUtils::AddItem($this->TargetNode, $this->App->Doc->body);
		$ul = $this->TargetNode->add("ul");
		foreach($this->m_datas->getEntries() as $k=>$v)
		{
			$ul->add("li")->Content = $k.":".$v;
		}
	}

	private static function CompareDate($date1, $date2)
	{
		return igk_date_compare($date1, $date2);
	}
	protected function initTargetNode()
	{
		$this->m_ConfigNode =  IGKHtmlItem::CreateWebNode("div");
		return parent::initTargetNode();
	}
	
}
//-----------------------------------------------------------------------------------
//represent a method controller
//-----------------------------------------------------------------------------------
class IGKMetaController extends IGKConfigCtrlBase
{
	var $Description;
	var $EndocingType;
	var $Keyword;
	var $Copyright;
	var $title;
	
	public function __construct()
	{
		parent::__construct();
		$this->Description = new IGKMetaValue();
		$this->Author = new IGKMetaValue();
		$this->EndocingType = new IGKMetaValue();
		$this->Keyword = new IGKMetaValue();
		$this->Copyright = new IGKMetaValue();		
		$this->title = new IGKMetaValue();		
		$this->EndocingType->Value = IGK_ENCODINGTYPE; //default encoding type value
		$this->Copyright->Value =IGK_COPYRIGHT; //default copyright value
		$this->title->Value = IGK_STR_EMPTY;
		
	}
	public function getConfigPage()
	{
		return "metactrl";
	}
	
	public function View ()
	{
	
		$c = $this->TargetNode;		
		if (!$this->getIsVisible())
		{
			igk_html_rm($c);
			return;
		}
		$c->ClearChilds();
		IGKHtmlUtils::AddItem($c, $this->ConfigNode);
		igk_html_add_title($c, "title.MetaController");
		$c->addHSep();
		igk_add_article($this, "metaconfig", $c->addDiv(),null, true);
		$c->addHSep();
		
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("meta_update");
		
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clDesc", "text", $this->App->Configs->meta_description);
		$ul->add("li")->addSLabelInput("clCopyright","text", $this->App->Configs->meta_copyright);
		$ul->add("li")->addSLabelInput("clKeysWords",  "text" , $this->App->Configs->meta_keysword);
		$ul->add("li")->addSLabelInput("clEncType", "text" , $this->App->Configs->meta_enctype);
		$ul->add("li")->addSLabelInput("clDefaultTitle",  "text" , $this->App->Configs->meta_title);
		
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	function __reset_value()
	{
			$this->Description->Value = 	$this->App->Configs->meta_description;	
			$this->EndocingType->Value = $this->App->Configs->meta_enctype;
			$this->Keyword->Value = $this->App->Configs->meta_keysword;
			$this->Copyright->Value = $this->App->Configs->meta_copyright ;
			$this->title->Value = $this->App->Configs->meta_title ;
			
	}
	public function meta_update()
	{
		$this->App->Configs->meta_description = igk_getr("clDesc");
		$this->App->Configs->meta_copyright = igk_getr("clCopyright");
		$this->App->Configs->meta_keysword = igk_getr("clKeysWords");
		$this->App->Configs->meta_enctype= igk_getr("clEncType");
		$this->App->Configs->meta_title = igk_getr("clDefaultTitle");
		igk_save_config();
		$this->__reset_value();
		$this->View();
		igk_notifyctrl()->addMsgr("Msg.metaUpdated");
		igk_navtocurrent();
	}
	protected function InitComplete()
	{
		parent::InitComplete();
		//init default property
		$this->__reset_value();	
		$this->App->Doc->Metas->Author = IGK_AUTHOR; 
		$this->App->Doc->Metas->Copyright = $this->Copyright;		
		$this->App->Doc->Metas->Description = $this->Description ;
		$this->App->Doc->Metas->Keywords = $this->Keyword;		
		$this->App->Doc->Metas->ContentType =  $this->EndocingType; 			
		
	}	
}
//meta value 
class IGKMetaValue extends IGKObject implements IIGKHtmlGetValue
{
	private $m_value;
	public function getValue(){//meta get value
		return $this->m_value;
	}
	public function setValue($value){ $this->m_value = $value;}
	
	public function __toString(){
		return "IGKMetaValue[". $this->getValue()."]";
	}
}

//view references controller
final class IGKReferenceCtrl extends IGKConfigCtrlBase
{
	private $m_selectedMenu;
	private $m_selectedClass;
	private $m_selectedInterface;
	private $m_searchkey;
	
	public function getConfigPage()
	{
		return "referencectrl";
	}
	public function View()
	{
		extract($this->getSystemVars());
		$c = $this->TargetNode;		
		if (!$this->getIsVisible())
		{
			igk_html_rm($c);
			return;
		}
		IGKHtmlUtils::AddItem($c, $this->ConfigNode);		
		$c->ClearChilds();
		igk_html_add_title($c,"References");
		$c->addHSep();
		$menut = array("vars", "const", "functions", "class","interface");
		$t = array();
		foreach($menut as $k)
		{			
			$t[$k] = $this->getUri("select_menu&n=".$k);
		}
		
		$dv = $c->addDiv();
		
		
		$c->addHSep();
		$div = $c->addDiv(array("id"=>"div_ref_output"));
		$pmenu = IGK_STR_EMPTY;
		switch(strtolower($this->m_selectedMenu))
		{
			case "funcdoc":
				$this->ref_getfuncdef($div);
				break;
			case "const":
				$pmenu = "const";
				$this->getGlobalConst($div);
				break;
			case "vars":
				$pmenu = "vars";
				$this->getGlobalVars($div);
				break;
			case "class":
				$pmenu = "class";
				$this->getDeclaredClass($div);				
				break;
			case "interface":
				$pmenu = "interface";
				$this->getDeclaredInterface($div);
				break;
			case "interfaceinfo":
				$pmenu = "interface";
				$this->getInterfaceDefinition($div);
				break;
			case "classinfo":
				$pmenu = "class";
				$this->getClassInfo($div);
				break;
			case "functions":
			default:
				$pmenu = "functions";
				$this->getGlobalFunctions($div);
			break;
		}
		
		IGKHtmlUtils::CreateConfigSubMenu($dv, $t, $pmenu);
		unset($t);
	}
	public function getInterfaceDefinition($div)
	{
		$name =igk_getr("n");
$div->add("h2")->Content = "Interface : ".$name;
$div->add("p")->Content = "Properties";
$t = get_class_vars($name);
if (count($t)== 0)
{
	$div->addDiv()->Content =  "no vars defined";
}
else{
$div->add("pre")->Content = count($t);
foreach($t as $k=>$v)
{
	$div->add("span", array("style"=>'display:block; float:left; width:200px; overflow:hidden'))->Content = "var ".$v."();";
	
}
}

$div->addBr()->setClass("clearb");
$div->add("h3")->Content = "Methods";

$t = get_class_methods($name);
if (count($t) == 0)
{
	$div->add("label")->Content =  "no methods";
}
else {
foreach($t as $k)
{
	$div->add("span", array("style"=>'display:block; float:left; width:200px; overflow:hidden'))->Content = "function ".$k."();";
}
}
	}
	
	public function showinterfaceinfo(){
	$name = igk_getr("n");
if (!interface_exists($name))
{
	igk_debug_wln("warning:". $name." not a valid interface");
	return;
}
$this->m_selectedMenu = "interfaceinfo";
$this->View();


	}
	private function getClassInfo($node, $name=null){
		$n = ($name == null)? igk_getr("n") : $name;
		if (!class_exists($n)){
			$node->addDiv()->Content = "class does't exits";
			return;
		}
		
		$node->add("h2")->Content = "Class : ".$n ;
		$d = new ReflectionClass($n);
		$fname = $d->getFileName();
		
		$info = $node->addDiv();
		$ul = $info->add("ul");
		$ul->add("li")->Content = "FileName  : ". ((empty($fname))? "unknow" : $fname);
		$ul->add("li")->Content = "Parent : " . get_parent_class($n);
		$imps = class_implements($n);
		if (count($imps) > 0){
			$timp = $info->addDiv();
			$timp->add("h2")->Content = "implements : ";
			$tul = $timp->add("ul");
			foreach($imps as $k=>$v){
			  $tul->add("li")->add("a", array("href"=>$this->getUri("showinterfaceinfo")))->Content = $k;	
			}
		}
		
		$node->addHSep();
		$info = $node->addDiv();
		$info->add("h2")->Content = "Descriptions";
		
		if (file_exists($fname))
		{
			$s = IGKIO::GetDir($this->getDataDir()."/References");///class.$n");	
			if (IGKIO::CreateDir($s))
			{
				igk_add_article($this, $s."/class.$n",$node->addDiv(), null, true);
			}
		}
		
		
		$node->addHSep();
		$info = $node->addDiv();
		$info->add("h2")->Content = "Properties";
		$this->App->Doc->Theme[".w200px"] = "width:200px; ";
		$t = get_class_vars($n);
		if (count($t)>0){
		
			foreach($t as $k=>$v){
				$info->add("span", array("class"=>"floatl dispb w200px "))->Content = $k;
			}
		}
		else{
			$info->addDiv()->Content = "No Properties";
		}
		//get mehods
		$t = get_class_methods($n);
		
		$node->add("div", array("class"=>"clearb"));
		
		$node->addHSep();
		$info = $node->addDiv();
		$info->add("h2")->Content = "Methods";
		if (count($t)> 0){
			sort($t);
			foreach($t as $k=>$v){
			$info->add("span", array("class"=>"floatl dipsb w200px"))->Content = $v;
			}
		}
		else{
		$info->addDiv()->Content = "No Public methods";
		}
	
	}
	private function getMethodInfo($node){
	}
	private function getDeclaredClass($node){
	igk_html_add_title($node, "title.globalclass");
		
		$node->add(new IGKHtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());		
		$tab = get_declared_classes();
		sort($tab);
		foreach($tab as $v)
		{
			
			
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl no-overflow", "style"=>"width:230px"))->add("a",
				array("href"=>$this->getUri("showclassinfo&n=".$v))
				)->Content = $v;
			
			
		}
	}
	public function showclassinfo(){
		$n = igk_getr("n");
		$this->m_selectedMenu = "classinfo";
		$this->View();
	}
	private function getDeclaredInterface($node){
	igk_html_add_title($node, "title.globalinterface");
		
		$node->add(new IGKHtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		$tab = get_declared_interfaces();
		sort($tab);		
		foreach($tab as $v)
		{
			
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl no-overflow", "style"=>"width:230px"))->add("a", array("href"=>$this->getUri("showinterfaceinfo&n=".$v)))->Content = $v;
			
			
		}
	}
	private function getGlobalVars($node){
		igk_html_add_title($node, "title.globalvars");
		
		$node->add(new IGKHtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		extract($this->getSystemVars());
		$tab = get_defined_vars() ;
			
		foreach($tab as $k=>$v)
		{
			
				if ($this->m_searchkey && !strstr(strtolower($k),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl no-overflow", "style"=>"width:230px"))->Content = $k;
			
			
		}
	}
	private function getGlobalConst($node){
		igk_html_add_title($node, "title.globalconst");
		
		$node->add(new IGKHtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		$tab = get_defined_constants();			
		foreach($tab as $k=>$v)
		{
				if ($this->m_searchkey && !strstr(strtolower($k),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl no-overflow", "style"=>"width:430px"))->Content = $k ."=".$v ;
		}
	}
	private function getGlobalFunctions($node){
		igk_html_add_title($node, "title.globalfunctions");
		
		$node->add(new IGKHtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array("class"=>"cl_functionslist"));		
		foreach(get_defined_functions() as $k)
		{
			sort($k, SORT_STRING);
			foreach($k as $v){
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$s = new ReflectionFunction($v);
				
				$href = IGK_STR_EMPTY;
				if ($s->getFileName())
				{
					$href=$this->getUri("ref_funcdef&n=".$v);
				}
				else{
					$href = "http://php.net/manual/".R::GetCurrentLang()."/function.".str_replace("_","-",$v).".php";
				}
				$div->add("li" , array("class"=>"dispib floatl no-overflow", "style"=>"width:230px"))->add("a", 
				array("class"=>IGK_STR_EMPTY, "href"=>$href))->Content = $v;
			}
			
		}
	}
	///<summary></summary>
	public function ref_funcdef(){//get function definition
		$this->m_selectedMenu = "funcdoc";
		$this->View();
	}
	public function ref_getfuncdef($div){
		$n = igk_getr("n");
		$div->add("h1")->Content = $n;
		$t = $div->addDiv();
		$s = new ReflectionFunction($n);
		$ul = $t->add("ul");
		$ul->add("li")->Content  = "FileName : ".igk_io_basePath($s->getFileName());
		$ul->add("li")->Content  = "StartLine : ".$s->getStartLine();
		$ul->add("li")->Content  = "EndLine : ".$s->getEndLine();
		$ul = $t->addDiv();
		//TODO: add descriptions
		$ul->Content = "Description";
		
	}
	public function searchgfunc(){
		$this->m_searchkey = igk_getr("q");
		$this->View();
		igk_navtocurrent();
	}
	public function select_menu()
	{
		$this->m_selectedMenu = igk_getr("n");
		$this->m_searchkey = null;
		$this->View();
		igk_navtocurrent();
	}
}
//view configs tools
final class IGKToolsCtrl extends IGKConfigCtrlBase
{
	private $m_tools;
	public function __construct()
	{
		parent::__construct();
		$this->m_tools = array();
	}
	public function getConfigPage()
	{
		return "toolctrl";
	}
	public function RegisterTool($ctrl)
	{
		$this->m_tools[$ctrl->Name] = $ctrl;
		$this->regChildController($ctrl);
	}
	
	public function View()
	{
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}		
		$t = $this->TargetNode;
		$t->ClearChilds();
		igk_html_add($t, $this->ConfigNode);
		igk_html_add_title($t,"Tools");
		$t->addHSep();
		$d = $t->addDiv();
		$th = $this->App->Doc->getSysTheme();
		$th[".igk-tool-option div"] = "padding: 4px; background-color:white"; 
		$d["class"] = "igk-tool-option table ";
		
		foreach($this->m_tools as $k=>$v)
		{	
			$v->showTool($d->addDiv()->setAttribute("class", "dispib floatl marg4"));			
		}
	}
}
///represent a base class for a tool
abstract class IGKToolCtrlBase extends IGKControllerBase
{
	//<summary>get if this controller is a system controller</summary>
	public function getIsSystemController(){
		return true;
	}
	public function getImageUri(){ return IGK_STR_EMPTY;
	}
	protected function InitComplete()
	{
		parent::InitComplete();
		igk_getctrl("IGKToolsCtrl")->RegisterTool($this);
	}
	public function View(){
	}
	public function doAction(){
		//configure and do action
	}
	public function showTool($ownernode)
	{
		igk_html_add( $this->TargetNode, $ownernode);
		$t = $this->TargetNode;
		$t["class"]= "dispib alignc alignt";
		$t["style"]= "min-width: 96px; min-height:72px;";
		$t->ClearChilds();
		$d = $t->addDiv();
		$a = $d->add("a", array("class"=>"alignc dispib", "href"=>$this->getUri("doAction")));
		$a->add("img", array("style"=>"width: 48px; height:48px;display:inline-block;", "src"=>$this->getImageUri()));
		$a->addDiv()->Content = R::ngets("tool.".$this->Name);
		
	}
	public function hideTool($ownernode)
	{
		igk_wln("hidde ".$ownernode);
		igk_html_rm($this->TargetNode);
		$t = $this->TargetNode;
		$t->ClearChilds();
		
	}
}




//-----------------------------------------------------------------------------------
//REPRESENT FINAL FPDF CONTAINS
//-----------------------------------------------------------------------------------
require_once(dirname(__FILE__)."/igk_fpdf.php");
final class IGKPDF extends IGKObject
{
	private $m_fpdf;
	private $m_title;
	private $m_author;
	private $m_subject;
	private $m_keywords;
	
	public function getFpdf (){
		return $this->m_fpdf;
	}
	public function __construct($type="P", $unit="mm", $format="A4")
	{		
		$this->init($type,$unit, $format);
	}
	//-------------------------------------------------------------------
	//set properties 
	//-------------------------------------------------------------------
	public function setTitle($value){$this->m_title = $value;}
	public function setAuthor($value){$this->m_author = $value;}
	public function setSubject($value){$this->m_subject = $value;}
	public function setKeywords($value){$this->m_keywords = $value;}
	public function setXY($x, $y){ $this->FPDF->SetXY($x, $y); }
	public function setMargin($left, $top, $right){		$this->FPDF->SetMargins($left, $top, $right);	}
	public function setWidth($w){	$this->FPDF->SetLineWidth($w);	}
	public function setFontSize($w){	$this->FPDF->SetFontSize($w);	}
	public function setFont($name, $type, $size){	$this->FPDF->SetFont($name, $type, $size);	}
	//get title
	//-------------------------------------------------------------------
	public function getTitle(){ return $this->m_title; }
	public function getAuthor(){ return $this->m_author; }
	public function getSubject(){ return $this->m_subject; }
	public function getKeywords(){ return $this->m_keywords; }
	public function getStringWidth($s){ return $this->FPDF->GetStringWidth($s); }
	public function getX(){ return $this->FPDF->GetX(); }
	public function getY(){ return $this->FPDF->GetY(); }
	public function getPageNo(){ return $this->FPDF->PageNo(); }
	
	public function save(){
		$this->m_fpdf->save();
	}
	public function restore(){
		$this->m_fpdf->restore();
	}
	public function setTransform($m11, $m12, $m21, $m22, $offsetx, $offsety){
		$this->m_fpdf->setTransform(array(
			$m11, $m12,
			$m21, $m22,
			$offsetx, $offsety));
	}
	
	public function init($type="P", $unit="mm", $format="A4", $firstpage=true)
	{
		$this->m_fpdf = new IGKFPDF($type, $unit,$format);
		$this->m_fpdf->SetFont("Arial", IGK_STR_EMPTY, 12);
		if ($firstpage){
		//add first page
		$this->addPage();
		}
	}
	
	public function addPage()
	{
		$this->m_fpdf->AddPage();
	}
	public function renderPage()
	{
		$this->m_fpdf->renderPage();
	}
	
	public function addCPage($type="P", $format="A4"){//add custom page. $type=P or L , $format = "A4" or size 
		$this->m_fpdf->AddPage($type,$format);
	}
	public function addBr($h=null)
	{
		$this->m_fpdf->Ln($h);
	}
	public function addFont($fn, $style=IGK_STR_EMPTY, $file=null)
	{
		$this->m_fpdf->AddFont($fn,$style, $file);
	}
	
	public function drawImg($file, $x=null, $y=null,$w=0,$h=0,$type=null,$link=null)
	{
		$this->FPDF->Image($file, $x,$y,$w,$h,$type,$link);
	}
	public function setfColorw($webcolor)
	{
		$cl = IGKColorf::FromString($webcolor);
		$this->setfColorf($cl->R, $cl->G, $cl->B);
	}
	public function setfColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetFillColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	public function setdColorw($webcolor)
	{
		$cl = IGKColorf::FromString($webcolor);
		$this->setdColorf($cl->R, $cl->G, $cl->B);
	}
	public function setdColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetDrawColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	public function settColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetTextColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	public function settColorw($webcolor)
	{
		$cl = IGKColorf::FromString($webcolor);
		$this->settColorf($cl->R, $cl->G, $cl->B);
	}
	
	public function drawLine($x1, $y1, $x2, $y2)
	{
		$this->m_fpdf->Line($x1, $y1, $x2, $y2);
	}
	public function drawCText($w, $h, $text, $border=0, $ln=1, $align= "L", $fill=false , $link=null)
	{
		$this->m_fpdf->Cell($w, $h, $text, $border, $ln, $align, $fill, $link);
	}
	public function drawText($text, $x, $y)	{//draw text at position
		$this->m_fpdf->Text($x, $y, $text);
	}
	public function drawWText($h, $text , $link=null)	{//draw wide text. $height, $text, link
		$this->m_fpdf->Write($h, $text, $link);
	}
	public function drawMultiTextCell($w, $h, $text , $border=0,  $align="L", $fillcolor=false)
	{
		$this->m_fpdf->MultiCell($w, $h, $text , $border,  $align, $fillcolor);
	}
	public function drawRect($x,$y,$w,$h){
		$this->FPDF->Rect($x,$y,$w,$h);
	}
	public function fillRect($x,$y,$w,$h){
		$this->FPDF->Rect($x,$y,$w,$h, 'F');
	}
	public function drawLink($x,$y,$w,$h, $link){
		$this->FPDF->Rect($x,$y,$w,$h, $link);
	}
	//link funciton
	//-
	public function createLink()
	{
		return $this->FPDF->AddLink();
	}
	public function setLink($id, $y=0, $p=-1 )
	{
		return $this->FPDF->SetLink($id, $y,$page);
	}
	public function drawImage($imgfileObject, $x, $y){
		if (file_exists($imgfileObject)){
			$this->FPDF->Image($imgfileObject, $x, $y);			
		}
	}
	//to end 
	public function Render($name="pdfdocument.pdf", $dest="I")
	{
		$this->m_fpdf->title = $this->Title;
		$this->m_fpdf->author = $this->Author;
		$this->m_fpdf->subject = $this->Subject;
		$this->m_fpdf->keywords = $this->Keywords;
		$this->m_fpdf->Output($name, $dest);		
	}
}

//-----------------------------------------------------------------------------------------
/// MAIL FUNCTION
//-----------------------------------------------------------------------------------------
//represent a mail attachement
class IGKMailAttachement extends IGKObject
{
	var $Type;
	var $ContentType;
	var $Link;	
	var $CID;
	var $Visible;
	var $Name;
	
	private  $m_Data;
	
	public function __construct()
	{
		$this->ContentType = "text/plain";
		$this->Visible = false;
		
	}
	public function setContent($content)
	{
		$this->m_Data = $content;
		return $this;
	}
	public function getContent(){ return $this->m_Data; }
	public function getData()
	{
		if ($this->Type == "Content")
			return chunk_split(base64_encode( $this->m_Data),76,"\n");	
		return chunk_split(base64_encode( file_get_contents($this->Link)),76,"\n");	
	}
}
//represent a mail object
class IGKMail extends IGKObject
{
	private $m_to;
	private $m_tocc;
	private $m_toBcc;
	private $m_files;
	private $m_textmsg;
	private $m_htmlmsg;
	private $m_title;
	private $m_from;
	private $m_replyto;
	
	private $m_smtp_port;
	private $m_useAuth;
	private $m_user;
	private $m_pwd;
	private $m_socketType="tls"; //tls or ssl
	private $m_socketTimeout = 15;
	private $m_smtphost ;
	
	
	private  $html_charset =  "iso-8859-1";
	private  $text_charset = "iso-8859-1";
	
	const PART_ALTERNATIVE = "multipart/alternative";	
	const PART_MIXED = "multipart/mixed";
	
	const CONTENT_PLAIN_TEXT = "text/plain";
	const CONTENT_HTML_TEXT = "text/html";
	const CONTENT_IMG_PNG = "image/png";
	
	public function getFrom(){return $this->m_from;}
	public function setFrom($value){ $this->m_from = $value; }
	public function getTitle(){return $this->m_title;}
	public function setTitle($value){ $this->m_title = $value; }
	
	
	public function getSocketType(){return $this->m_socketType;}
	public function setSocketType($v){ switch(strtolower($v)){ case "tls": case "ssl":$this->m_socketType = strtolower($v); break; }}
	
	public function getSocketTimeout(){return $this->m_socketTimeout;}
	public function setSocketTimeout($value){ $this->m_socketTimeout = $value; }
	
	public function getReplyTo(){return $this->m_replyto;}
	public function setReplyTo($value){ $this->m_replyto = $value; }
	
	public function getUser(){return $this->m_user;}
	public function setUser($value){ $this->m_user = $value; }
	
	public function getPwd(){return $this->m_pwd;}
	public function setPwd($value){ $this->m_pwd = $value; }
	
	public function getSmtpHost(){return $this->m_smtphost;}
	public function setSmtpHost($value){ $this->m_smtphost = $value; }
	
	public function getPort(){return $this->m_smtp_port;}
	public function setPort($value){ $this->m_smtp_port = $value; }
	
	public function setHtmlCharset($v){ $this->html_charset = $v;  }
	public function setTextCharset($v){ $this->text_charset = $v;  }
	
	public function getHtmlCharset(){ return $this->html_charset;  }
	public function getTextCharset(){ return $this->text_charset;  }
	
	
	public function __construct()
	{
		$this->m_files = array();
		$this->m_to = array();
		$this->m_tocc = array();
		$this->m_toBcc = array();
	}
	public function setTextMsg($content)	{		$this->m_textmsg = $content;	}
	public function setHtmlMsg($content)	{		$this->m_htmlmsg = $content;	}
	public function getHtmlMsg() { return $this->m_htmlmsg ;}
	public function getTextMsg(){return $this->m_textmsg; }
	public function getUseAuth(){return $this->m_useAuth; }
	
	public function setUseAuth($value){ $this->m_useAuth = $value; }
	
	
	public function attachFile($file, $contentType="text/plain", $cid=null)
	{
		$attach = new IGKMailAttachement();
		$attach->Link = $file;
		$attach->ContentType = $contentType;
		$attach->CID = $cid;
		$attach->Type  = "Uri";
		$this->m_files[] = $attach;
		return $attach;
	}
	public function attachContent($content, $contentType="text/plain", $cid=null)
	{
		$attach = new IGKMailAttachement();
		$attach->Content = $content;
		$attach->ContentType = $contentType;
		$attach->CID = $cid;
		$attach->Type  = "Content";
		$this->m_files[] = $attach;
		return $attach;
	}
	public function addTo($to)
	{
		$this->m_to[] = $to;
	}
	public function ClearTo()
	 {
		$this->m_to = array();
	 }
	public function addToCC($to)
	{
		$this->m_tocc[] = $to;
	}
	public function addToGCC($to)
	{
		$this->m_toBcc[] = $to;
	}
	public function getToString(){
		return self::GetMailList($this->m_to);
	}
	static function GetMailList($tab)
	{
			$o = IGK_STR_EMPTY;
		foreach($tab as $k=>$v)
		{
			if ($k>0)
				$o.=",";
			$o .= self::MailEntry($v);
		}
		return $o;
	}
	static function MailEntry($c)
	{
		$out = IGK_STR_EMPTY;
		if (is_numeric($c) || (is_string($c) &&  !empty($c)))
		{
			$out.=$c;
		}
		else if (is_object($c) && (method_exists(get_class($c),"getValue")) )
		{
			$out .= $c->getValue();
		}
		return $out;
	}
	private function _getHeader($boundary)
	{
		$header = IGK_STR_EMPTY;
		if ($this->m_from)
		$header .= "From: ".$this->m_from."\r\n";
		if ($this->m_replyto)
		$header .= "Reply-To: ".$this->m_replyto."\r\n";
		$CC  = self::GetMailList($this->m_tocc);
		if (!empty($cc))
		{
			$header .= "CC: ".$cc."\r\n";	
		}
		$CC  = self::GetMailList($this->m_toBcc);
		if (!empty($cc))
		{
			$header .= "Bcc: ".$cc."\r\n";	
		}
		$header .= "MIME-Version: 1.0\r\n";
		//cause problem with thunderbird
		//$header .= "Content-Type: multipart/mixed; boundary=$boundary\n";
		//correct problem with thunderbird
		$header .= "Content-Type: multipart/related; boundary=$boundary\r\n";
		
		return $header;
	}
	public function sendMail()
	{
		
		$boundary = igk_new_id();
		$to = $this->getToString();
		$title = $this->getTitle();
		$header = $this->_getHeader($boundary);
	
		$message = "\n";
		$message .= "This is a multi-part message in MIME Format.\n";
		$message .= "--$boundary\n";			
		
		$j1 = $this->TextMsg;
		$j2 = $this->HtmlMsg;
		
		if (!((empty($j1) && empty($j2))))
		{
		$message .= "Content-Type: multipart/alternative; boundary=sub_$boundary\n";
		
		if (!empty($j1))
		{
			
			$message .= "\n\n--sub_$boundary\n";
			$message .="Content-Type: text/plain; charset=\"".$this->text_charset."\"\n\n";
			$message .= $j1;
		}		
		
		if(!empty($j2))
		{
			$message .= "\n\n--sub_$boundary\n";			
			$message .= "Content-Type:text/html; charset=\"".$this->html_charset."\"\n\n";		
			$message .= $j2;
		}
		$message .= "\n\n--sub_$boundary--\n";		
		}
			
		
		foreach($this->m_files as $k=>$v)
		{
		// attach files
		$data = $v->Data;//chunk_split(base64_encode( file_get_contents($v->Link)));	
		//$message .= "Content-Type: image/gif; name=\"attachment.txt\"\n";//with name
		$message .= "\n\n--$boundary\n";	
		$message .= "Content-Type: ".$v->ContentType.";";
		if ($v->Name){
			$message .= "name=\"".$v->Name."\"";
		}
		$message .= "\n";//with name
		$message .= "Content-Transfer-Encoding: base64\n";
		if (!$v->Visible)
			$message .= "Content-Disposition: attachment\n"; //suppress view
		if ($v->CID)
			$message .= "Content-ID: <".$v->CID.">\n"; //les crochet sont important pour ajouter une image 
		
		$message .= "\n".$data;
		
		}
		$message .= "\n--$boundary--\n";
		$message .= "end of the multi-part";
	
		if ($this->UseAuth)
		{		
			if (extension_loaded("openssl"))
			{
				$v = $this->__sendMailTLS($header, $message);
				return $v;
			}
			else{
				igk_wln("no openssl extension loaded");
			}
			return false;
		}
		else{			
			if (@mail($to, $title, $message,$header) == true)
			{			
				return true;
			}
		}
		return false;
	}
	
	
	
	
	//Function to Processes Server Response Codes
	private function server_parse($socket, $expected_response)
	{
		if (igk_getv(socket_get_status($socket), "eof"))
		{			
			return false;
		}		
		$server_response = '';
		while (substr($server_response, 3, 1) != ' ')
		{
			if (!($server_response = fgets($socket, 256)))
			{			
			  igk_debug_wln('Error while fetching server response codes.');
			  return false;
			}            
		}
		igk_debug_wln('OK : "'.$server_response.'"');
		if (!(substr($server_response, 0, 3) == $expected_response))
		{
		  igk_debug_wln('Unable to send e-mail."'.$server_response.'"');
		  return false;
		}
		return true;
	}
	private function _closeSocket($socket)
	{
		fwrite($socket, 'QUIT'."\r\n");
		fclose($socket);
	}
	private function __sendMailTLS($headers, $message)
	{
			$errno = IGK_STR_EMPTY;
		$errstr=IGK_STR_EMPTY;
		$host = $this->m_smtphost;
		$user = $this->m_user;
		$pass = $this->m_pwd;
		$port = $this->m_smtp_port;
		$timeout = $this->m_socketTimeout;
	
	  $socket = @fsockopen($host , $port, $errno, $errstr, $timeout);
	  if(!$socket)
	  {
		igk_debug_wln("ERROR: ".$host." ".$port." - $errstr ($errno)");
		return false;
	  }
	  else
	  {
		igk_debug_wln("SUCCESS: ".$host." ".$port." - ok");

	$recipients = $this->m_to;
	$subject = $this->Title;
		
		

		if (!$this->server_parse($socket, '220')) { $this->_closeSocket($socket); return false;}   
		
		fwrite($socket, 'EHLO '.$host."\r\n");				
		if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
		
		if ($this->SocketType =="tls")
		{
			 
			fwrite($socket, 'STARTTLS'."\r\n");		
			if (!$this->server_parse($socket, '220')) { $this->_closeSocket($socket); return false;}    
			
			if(false == @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT))
			{
				$this->_closeSocket($socket);
				igk_debug_wln("unable to start tls encryption");
				return false;
			}

			
				fwrite($socket, 'HELO '.$host."\r\n");		
				if (!$this->server_parse($socket, '250')) return false;

		}	
			igk_debug_wln("AUTH LOGIN");
			fwrite($socket, 'AUTH LOGIN'."\r\n");    
			if (!$this->server_parse($socket, '334')) { $this->_closeSocket($socket); return false;}    


			igk_debug_wln("AUTH USER " .$user);
			fwrite($socket, base64_encode($user)."\r\n");    
			if (!$this->server_parse($socket, '334')) { $this->_closeSocket($socket); return false;}    

			igk_debug_wln("AUTH pass " .IGKApp::getInstance()->Configs->mail_password);
			fwrite($socket, base64_encode($pass)."\r\n");    
			if (!$this->server_parse($socket, '235')) { $this->_closeSocket($socket); return false;}    

			igk_debug_wln("AUTH USER " .$this->FROM);
			fwrite($socket, 'MAIL FROM: <'.$this->From.'>'."\r\n");    
			if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
			foreach ($recipients as $email)
			{
				fwrite($socket, 'RCPT TO: <'.$email.'>'."\r\n");
				if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
			}
			fwrite($socket, 'DATA'."\r\n");    
			if (!$this->server_parse($socket, '354')) { $this->_closeSocket($socket); return false;}

			fwrite($socket, 'Subject: '
			.$subject."\r\n".'To: <'.implode('>, <', $recipients).'>'
			."\r\n".$headers."\r\n\r\n".$message."\r\n");
			//end
			fwrite($socket, '.'."\r\n");
			
			if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}
			
			$this->_closeSocket($socket);
			return true;

	  }
	}
	
	
	
}


final class IGKDocumentController extends IGKControllerBase{//represent the document renderer. used with AJX to render a document 
	private $m_r; //document to render
	public function setDocument($r)
	{
		$this->m_r = $r;
	}
	public function getName(){
		return "document";
	}
	public function render_document_ajx(){
		echo $this->m_r;
	}
	public function getIsVisible(){return false;}
}
///<summary>return script data</summary>
final class IGKScriptController extends IGKControllerBase{
	
	public function getScript(){//get the script content
		
		$tab  = $this->App->Doc->ScriptManager->getMergedContent();
		header('Content-type: Application/javascript;  charset=\"utf-8\";');
		if (!empty($tab->data))		
			igk_wl($tab->data);
		igk_exit();
	}
	public function getIsVisible(){return false;}
}


//for script managemenent
final class IGKArticlesCtrl extends IGKControllerBase
{
	public function getQueryArticle(){
		$q = base64_decode(igk_getr("q"));
		igk_wln($q);
		igk_wln(igk_io_basePath($q));
		igk_exit();
	}
	public function getIsVisible(){return false;}
}

class IGKCountryCtrl extends IGKControllerBase
{
	private $m_countries;
	
	public function getIsVisible(){return false;}
	
	public function __construct()
	{
		parent::__construct();
		$this->_loadData();
	}
	public function getCountries()
	{
		return $this->m_countries;
	}
	public function getDataTableName(){return "tbcountries"; }
	public function getDataAdapterName(){return "CSV"; }
	
	private function _loadData()
	{
		$r = IGKCSVDataAdapter::LoadData(igk_io_syspath("Data/tbcountries.csv"));
		if ($r)
		{
			$this->m_countries = array();
			foreach($r as $l)
			{		
				$this->m_countries[$l[0]] = $l[0];
			}
		}
	}
	
}
// - user variables

final  class IGKUserVarsCtrl extends IGKConfigCtrlBase
{
	private $m_vars;
	private $m_searchkey;
	public function getName(){return IGK_USERVARS_CTRL; }
	public function getdataFileName(){return igk_io_baseDir(IGK_DATA_FOLDER.DIRECTORY_SEPARATOR."usersvar.csv");}
	public function getConfigPage()
	{
		return "uservarctrl";
	}
	public function getVars()
	{
		return $this->m_vars;
	}
	public function regVars($name, $value,$comment)
	{
		if (empty($name))
			return;
		$this->m_vars[$name] = 
						array(
							"value"=> $value,
							"comment"=> $comment
						);
	}
	public function __construct(){
		parent::__construct();
		
		$this->__loadVars();
	}
	private function __loadVars()
	{
		$this->m_vars = array();
		$e = IGKCSVDataAdapter::LoadData($this->dataFileName);
		if ($e)
		{
			foreach($e as $k=>$v)
			{
					$this->m_vars[$v[0]] = 
						array(
							"value"=> igk_getv($v, 1),
							"comment"=> igk_getv($v, 2)
						);
			}
		}
	
	}
	public function vc_addvars()
	{
		$obj = igk_get_robj();
		$this->m_vars[$obj->clName] = array("value"=>$obj->clValue, "comment"=>$obj->clComment);
		$this->__storeVars();
	}
	public function vc_dropvars()
	{
		$obj = igk_getr("n");
		if (isset($this->m_vars[$obj]))
		{
		unset($this->m_vars[$obj]);		
		$this->__storeVars();
		$this->View();		
		}
		igk_navtocurrent();
	}
	public function vc_Clearvars($store=true)
	{	
		$this->m_vars = array();
		if ($store)
			$this->__storeVars();
	}
	public function __storeVars()
	{
		$f = igk_io_baseDir(IGK_DATA_FOLDER.DIRECTORY_SEPARATOR."usersvar.csv");
		$out = IGK_STR_EMPTY;
		foreach($this->m_vars as $k=>$v)
		{
			$v_cv = igk_getv($v, "value");
			$v_cc = igk_getv($v, "comment");
			if (!empty($out))
			{
				$out .= "\n";
			}
			$out .= $k.",".igk_csv_getvalue($v_cv).",".igk_csv_getvalue($v_cc);
		}
		if (igk_io_save_file_as_utf8($f, $out)){	
			igk_notifyctrl()->addMsgr("msg.uservarsctrl.varsaved");			
		}
		else{
			igk_wln($out);
			igk_exit();
		}
		$this->View();
	}
	public function search_var()
	{
		$this->m_searchkey = igk_getr("q");
		$this->View();
	}
	public function View()
	{
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_html_add_title($t, "title.uservariables");
		
		$t->addHSep();
		igk_add_article($this, "uservariableinfo" , $t->addDiv(), null, true);
		$t->addHSep();
		
		$t->add(new IGKHtmlSearchItem($this->getUri("search_var"), $this->m_searchkey));
		
		
		
		$frm = $t->addForm();
		$frm["action"] = $this->getUri("vc_saveAllVars");
		igk_notify_sethost($frm->addDiv());
		$table = $frm->addTable();
		$tr = $table->add("tr");
		IGKHtmlUtils::AddToggleAllCheckboxTh($tr);
			$tr->add("th")->Content =R::ngets(IGK_FD_NAME);
			$tr->add("th")->Content =R::ngets("clValue");
			$tr->add("th")->Content =R::ngets("clComment");
			$tr->add("th")->Content = IGK_HTML_SPACE;
		
		if (is_array($this->m_vars))
		{
			foreach($this->m_vars as $k=>$v)
			{
				$obj = (object)$v;				
				if ($this->m_searchkey && !strstr(strtolower($k), strtolower($this->m_searchkey)))
					continue;
				$tr = $table->add("tr");
				$td = $tr->add("td");
				$td->addInput("clName[]", "checkbox",$k);
				$td->addInput("clHName[]", "hidden", $k);
				$tr->add("td")->Content = $k;
				
				$tr->add("td")->addInput("clValue[]", "text", $obj->value);
				$tr->add("td")->addInput("clComment[]", "text", $obj->comment);	
				IGKHtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("vc_dropvars&n=".$k), "drop");
				
			}
		}
		$frm->addHSep();
		$frm->addInput("btn_save", "submit", R::ngets("btn.save"));		
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.addvars"), igk_js_post_frame($this->getUri("vc_addvarframe_ajx")));
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.rmSelection"), "#", array("onclick"=>igk_js_a_postform($this->getUri("vc_rm_selection"))));
		igk_html_toggle_class($table);
	}
	public function vc_rm_selection()
	{
	
		$n = igk_getr("clName");
		if (is_array($n))
		{
		foreach($n as $k=>$v)
		{
			unset($this->m_vars[$v]);
		}
		$this->__storeVars();
		}
		$this->View();
		igk_navtocurrent();
		
	}
	public function vc_addvarframe_ajx()	
	{
		$frame = igk_add_new_frame($this, __FUNCTION__);
		$frame->Title = R::ngets("title.addsystemvariable");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("vc_addvars");
		$ul = $frm->add("ul");
		
		$ul->add("li")->addSLabelInput(IGK_FD_NAME);
		$ul->add("li")->addSLabelInput("clValue");
		$ul->add("li")->addSLabelInput("clComment");
		$frm->addHSep();
		$frm->addInput("btn_savevar", "submit", R::ngets("btn.savevar"));
		igk_wl($frame->Render());
	}
	public function vc_saveAllVars()
	{
		$tn = igk_getr(IGK_FD_NAME);
		$tv =igk_getr("clValue");
		$tc = igk_getr("clComment");
		
		if(igk_getr("btn_save"))
		{
			$tn = igk_getr("clHName");
		}
		
		for($i = 0; $i< igk_count($tn);$i++)
		{
			$n = $tn[$i];
			$v = igk_getv($tv, $i);
			$c = igk_getv($tc, $i);
			
			$this->regVars($n, $v, $c);
		}
		$this->__storeVars();
		igk_navtocurrent();
	}
	
	
	protected function InitComplete(){
		parent::InitComplete();
		$file = igk_io_baseDir(IGK_MODS_FOLDER."/register_uvar.phtml");
		if (file_exists($file ))
		{
			include($file);
		}
	}
}

//---------------------------------------------------------------------------
// - template ...
//---------------------------------------------------------------------------
final class IGKTemplateCtrl extends IGKConfigCtrlBase
{
	
	public function getConfigPage()
	{
		return "template";
	}
	public function gettemplateFolder()
	{
		return igk_io_baseDir(IGK_TEMPLATES_FOLDER);
	}
	public function View(){
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		
		
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_html_add_title($t, "title.template");
		
		$t->addHSep();
		igk_add_article($this, "template" , $t->addDiv(), null, true);
		$t->addHSep();
		$frm = $t->addForm();
		$frm["action"]=$this->getUri("loadTemplate");
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.loadTemplate"), igk_js_post_frame($this->getUri("loadTemplateFrame_ajx")));
			
		
		$t->addBr();
		
		
		$frm = $t->addForm();
		$frm["action"]=$this->getUri("saveTemplate");
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.saveTemplate"), igk_js_post_frame($this->getUri("saveTemplateFrame_ajx")));
		$t->addHSep();		
		$frm = $t->addForm();
		igk_html_add_title($frm, "title.templates");
		$frm->addDiv()->addScript()->Content = "(function(q){window.igk.ajx.post('".$this->getUri("tm_gettemplates_ajx")."',null,function(xhr){if (this.isReady()){ this.setResponseTo(q); }}); })(window.igk.getParentScript());";
		
	}
	public function getTemplateImg(){
		$n = igk_getr("n");
		$v_file = $this->templateFolder."/".$n.".template";
		
		header("Content-type: image/png");
		$f = false;
		if (is_file($v_file))
		{			
			
			$hzip = zip_open($v_file);
			if (is_resource($hzip))
			{
				while( ($e = zip_read($hzip)))
				{
				$n = zip_entry_name($e);				
				if ($n == "__image.png")
				{
					igk_wl(zip_entry_read($e,zip_entry_filesize($e)));
					$f =true;
					break;
				}
				}
				zip_close($hzip);
			}
		}
		if (!$f){			
			igk_wl(IGKIO::ReadAllText(igk_io_baseDir("R/notemplatepic.png")));
		}
		igk_exit();
	}
	//<summary>get templates</summary>
	public function tm_gettemplates_ajx($uri=null)
	{
		//::: get template list
		$ul =  IGKHtmlItem::CreateWebNode("ul");
		$ul["class"] = "igk_templates_list";
		$v_tfiles = IGKIO::GetFiles($this->templateFolder, "/\.template$/i", false);
		if ($v_tfiles)
		{
		foreach($v_tfiles as $f)
		{
			$li = $ul->add("li");
			$li["class"] = "dispib floatl";
			
			$div = $li->addDiv();
			
			$n = igk_io_basenamewithoutext($f);
			$div->addDiv(array("class"=>"title"))->Content =  $n;
			$cdiv = $div->addDiv();
			$cdiv->setClass("floatl");
			$cdiv->add("img", array("src"=>igk_io_baseUri().$this->getUri("getTemplateImg&n=".$n), "width"=>"100%"));
			$cdiv = $div->addDiv();
			
			IGKHtmlUtils::AddBtnLnk($cdiv, "btn.installTemplate", $this->getUri("tm_installTemplate&n=".$n));			
			IGKHtmlUtils::AddBtnLnk($cdiv, "btn.uninstallTemplate", $this->getUri("tm_uninstallTemplate&n=".$n));
		}}
		else
			$ul->add("li")->Content = R::ngets("tip.notemplates");
		igk_wl($ul->Render());
	}
	public function tm_installTemplate()
	{
		$n = igk_getr("n");
		if ($n){
			$this->__installTemplate($this->templateFolder. "/". $n.".template");
			$this->View();
		}
	}
	public function tm_uninstallTemplate()
	{
		$n = igk_getr("n");
		if ($n){
			$v_f = $this->templateFolder. "/". $n.".template";
			if (file_exists($v_f))
			{
				//remove all item installe in the template
			
				@unlink($v_f);
			}
			$this->View();
		}
	}
	public function loadTemplateFrame_ajx($tempfile=null){
		$frame = igk_add_new_frame($this,"new_template_frame");
		$frame->Title = R::ngets("title.loadtemplate");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("loadTemplate");
		$frm->addInput("clTemplateFile", "file");
		$frm->addHSep();
		$frm->addInput("btn_savetemplate", "submit", R::ngets("btn.loadtemplate"));
		igk_wl($frame->Render());		
	}
	private function __installTemplate($file)
	{
		if( !file_exists($file))
			return;
		$hzip = zip_open($file);
		$outdir =  igk_io_baseDir();
		
		if (is_resource($hzip))
		{
			
			while( ($e = zip_read($hzip)))
			{
				$n = zip_entry_name($e);				
				if ($n == "__template.def")
				{
					//load environment
					$this->__loadEnvironment(zip_entry_read($e,zip_entry_filesize($e)));
				}
				else{				 
					//extract zip
					if (igk_zip_entry_isdir($e))
					{	
						igk_zip_create_dir($outdir, $n);
					}
					else{
						if (!(strpos($n, "/")===FALSE))
							igk_zip_extract($outdir, $hzip , $e);
					}
				}
			}
			zip_close($hzip);
			igk_notifyctrl()->addMsgr("msg.templateloaded");			
			igk_getctrl(IGK_CONF_CTRL)->reconnect();
			igk_exit();
			
		}
		else{
			igk_notifyctrl()->addErrorr("e.templatefilenotvalid");			
		}		
	}
	public function loadTemplate($tempfile=null){
		$f = igk_getv($_FILES, "clTemplateFile");
		if ($f && isset($f["tmp_name"]) && ($f["error"]===0))
		{
			$this->__installTemplate($f["tmp_name"]);
			
			$this->ConfigCtrl->reconnect();
			igk_exit();
		}		
		else
			igk_notifyctrl()->addError("Msg.TemplateLoadTemplateError");
	}
	private function __loadEnvironment($env)
	{
		//load environemnt
		$e =  IGKHtmlItem::CreateWebNode("env");
		$e->Load($env);
		$n = IGK_STR_EMPTY;
		$v = IGK_STR_EMPTY;
		
		
		$t = igk_getv($e->getElementsByTagName("Template"), 0);	
		$this->App->Configs->templateLoad = true;
		$this->App->Configs->templateName = $t["name"];
		$this->App->Configs->templateVersion = $t["version"];
		
		
		$t = igk_getv($e->getElementsByTagName("TemplateInfo"), 0);
		foreach($t->Childs as $k=>$v)
		{
			switch(strtolower($v->TagName))
			{
				case "defaultctrl":
					$this->App->Configs->web_pagectrl = trim($v->innerHTML);
				break;
			}
		}
		
		igk_save_config();
		
		//load colors
		$cls = igk_getv($e->getElementsByTagName("Colors"), 0);		
		foreach($cls->Childs as $k)
		{
			$this->App->Doc->Theme->cl[$n] = $v;
		}
		$cls = igk_getv($e->getElementsByTagName("Styles"), 0);		
		foreach($cls->Childs as $k)
		{
			$this->App->Doc->Theme[$n] = $v;
		}
		//save theme
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		
		//load menu
		$cls = igk_getv($e->getElementsByTagName("Menus"), 0);		
		$ctrl = igk_getctrl(IGK_MENU_CTRL);
		$ctrl->__ClearConfigMenu(false);
		foreach($cls->Childs as $k)
		{
			$t = $ctrl->getDefaultEntry();
			
			foreach($k->Attributes as $s=>$r )
			{
				$t[$s] = $r;
			}
			
			$ctrl->reg_menu($t,false);
		}
		$ctrl->__saveConfigMenu();
		
		$cls = igk_getv($e->getElementsByTagName("UserVariables"), 0);		
		$ctrl  = igk_getctrl(IGK_USERVARS_CTRL);
		$ctrl->vc_Clearvars(false);
		foreach($cls->Childs as $k)
		{			
			$ctrl->regVars($k["name"], $k["value"], $k["description"]);
		}
		$ctrl->__storeVars();
	}
	public function getCurrentTemplateDefinition($name= null, $desc=null, $cat = null, $image=null)
	{
		$e =  IGKHtmlItem::CreateWebNode("Template");
		$e["name"] = $name;
		$e["version"] = IGK_VERSION;
		$e["description"] = $desc;
		$e["category"] = $cat;
		$e["created"] = igk_date_now();
		
		//template info
		$v_ti = $e->add("TemplateInfo");
		$v_ti->add("DefaultCtrl")->Content = igk_getv($this->App->Configs, "web_pagectrl");	
		$v_ti->add("Image")->Content = $image;
		$menu = $e->add("Menus");
		
		//save menu
		
		foreach(igk_getctrl(IGK_MENU_CTRL)->UserMenu as $k)
		{
			$m = $menu->add("menu");
			foreach($k as $s=>$sv)
			{
				$m[$s] = trim($sv);
			}
		}
		
		$ctrls = $e->add("Controllers");		
		//
		foreach($this->App->getControllerManager()->getUserControllers() as $k)
		{
				$ctrls->add("Ctrl", array(
					IGK_FD_NAME=>$k->Name,					
				));
		}
		$ctrls = $e->add("UserVariables");				
		foreach(igk_getctrl(IGK_USERVARS_CTRL)->getVars() as $k=>$v)
		{
			$obj = (object)$v;
				$ctrls->add("var", array(
					"name"=>$k,
					"value"=>$obj->value,
					"comment"=>$obj->comment
				));
		}		
		$theme = $e->add("Themes");
		$clt = $theme->add("Colors");
		foreach($this->App->Doc->Theme->cl->Attributes as $k=>$v)
		{
		
			if (empty($v))continue;
			$clt->add("Color", array(
				"name"=>$k,
				"value"=>$v
			));
		}
		$clt = $theme->add("Styles");
		foreach($this->App->Doc->Theme->def->Attributes as $k=>$v)
		{
			if (empty($v))continue;
			$clt->add("css", array(
				"name"=>$k,
				"value"=>$v
			));
		}		
		$option = (object)array("Indent"=>true);
		return igk_ansi2utf8(utf8_encode($e->Render($option)));
	}
	public function saveTemplate()
	{
		$tname = igk_getr("clTemplateName");
		$inc = igk_getr("clTemplateAllowInc");
		$desc = igk_getr("clTemplateDesc");
		$img = igk_getv($_FILES, "clTemplateImage");
		
		$e =  IGKHtmlItem::CreateWebNode("error");
		$val = "IGKValidator";		
		IGKValidator::Init();
		if (IGKValidator::IsStringNullOrEmpty($tname)){ IGKValidator::Error()->add("li")->Content = "string is null or empty"; }
		if (($img==null) || !igk_io_fileIsPicture($img["type"])){ IGKValidator::Error()->add("li")->Content = "image not specified"; }
		
		if (!IGKIO::CreateDir($this->templateFolder))
		{
			igk_notifyctrl()->addError(R::ngets("Msg.TemplateFolderCantBeCreated"));
			igk_frame_close("new_template_frame");
			return;
		}		
		if (IGKValidator::Error()->HasChilds)
		{
			igk_notifyctrl()->addWarning(R::ngets("Msg.ErrorWhenTemplate"));
			return;
		}
		
		$file = IGKIO::GetDir($this->gettemplateFolder()."/".$tname.".template");
		
		
	
		$zip = new ZipArchive();
		
		if ($zip->open($file, ZIPARCHIVE::CREATE))
		{
		
			$zip->addFromString("__template.def", $this->getCurrentTemplateDefinition($tname, $desc, igk_getr("clTemplateCat")));
			$zip->addFromString("__image.png", IGKIO::ReadAllText($img["tmp_name"]));
			//save Mods folder
			
			$dir = igk_io_baseDir(IGK_MODS_FOLDER);//."/".$tname.".template");
			igk_zip_dir($dir, $zip, "Mods");
			igk_zip_dir(igk_io_baseDir(IGK_RES_FOLDER), $zip, "R", "/\.(gkds)$/i");
			
			if ($inc)
			{
				igk_zip_dir(igk_io_baseDir(IGK_INC_FOLDER), $zip, "Inc");
			}
			
			$zip->close();	
			igk_frame_close("new_template_frame");	
			igk_notifyctrl()->addMsgr("Msg.TemplateSaved");					
		}	
		else{
			igk_notifyctrl()->addError(R::ngets("Msg.TemplateNotSaved"));
		}
		$this->View();
		
	}
	public function saveTemplateFrame_ajx()
	{
		$frame = igk_add_new_frame($this,"new_template_frame");
		$frame->Title = R::ngets("title.newtemplate");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("saveTemplate");
		
		$frm->addDiv(array("class"=>"hide"))->Content= IGK_HTML_SPACE;
		$ul = $frm->add("ul");
		//($id, $text, $type="text",$value=null, $attributes=null, $require=false){	
		$ul->add("li")->addSLabelInput("clTemplateName", "text", null, null, true);
		$ul->add("li")->addSLabelInput("clTemplateAllowInc", "checkbox");
		$ul->add("li")->addSLabelInput("clTemplateCat", "text", null, null, true);
		$ul->add("li")->addSLabelInput("clTemplateDesc");
		$ul->add("li")->addSLabelInput("clTemplateImage", "file", null,null, true);
		$frm->addHSep();
		$frm->addInput("btn_savetemplate", "submit", R::ngets("btn.savetemplate"));
		
		$frame->RenderAJX();
	}
	

	
}

//class used to register global user in system
class IGKUsersCtrl extends IGKConfigCtrlBase
{
	private $m_Users;
	
	public function getUsers(){ return $this->m_Users; }
	
	public function getDataTableInfo(){
		return array(
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clId", IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true, "clIsPrimary"=>true)),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLogin", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60", "clIsUnique"=>true)),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clPwd", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60",
			"clInsertFunction"=>"MD5", "clUpdateFunction"=>"MD5",
			"clInputType"=>"password")), //md5 passwd
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clFirstName", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLastName", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLevel", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>"1")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clStatus", IGK_FD_TYPE=>"Int", "clDefault"=>"-1", "clDescription"=>"state of the account, -1 = not activated, 1=activated, 0or2=blocked" ))
			);
	}
	//init - 
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->insert($n, array("clLogin"=>"bondje.doue@gmail.com","clPwd"=>md5("test123"), "clFirstName"=>"Charles", "clLastName"=>"BONDJE DOUE", "clLevel"=>-1, "clStatus"=>-1));
		$db->insert($n, array("clLogin"=>"admin@".$this->app->Configs->domain, "clPwd"=>md5("test123"), "clFirstName"=>"admin", "clLastName"=>"Administrator", "clLevel"=>-1, "clStatus"=>1));
	
	}
	public function getConfigPage()
	{
		return "users";
	}
	public function getDataAdapterName()
	{
		return IGK_MYSQL_DATAADAPTER;
	}
	
	
	public function us_lockuser()
	{
		$email = igk_getr("email");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>igk_getr("email")));
		if ($t && is_object($t))
		{			
			$t->clStatus = 2;
			$this->update($t);
			igk_navtocurrent("userlocked");
		}	
		
			else{
		igk_navtocurrent();
		}
	}
	public function us_activate(){
		
		$email = igk_getr("email");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>igk_getr("email")));
		if ($t && is_object($t))
		{
			$t->clStatus = 1;
			$this->update($t);
			igk_navtocurrent("confirmregistration");	
		}	
		else{
		igk_navtocurrent();
		}
			
	}
	public function us_resetpwd()
	{
		$npwd = igk_getr("clNewPwd");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clPwd"=>igk_getr("clLogin")));
		if ($t && is_object($t))
		{
			$t->clStatus = 1;
			$this->update($t);
			igk_navtocurrent("pwdchanged");
		}	
		else{
			igk_navtocurrent();
		}
		
	}
	public function getDataTableName(){return "tbigk_users" ;}
	
	//connect to user
	public function connect($log, $pwd){//connection for users
		if ($this->m_User != null)
			return false;
		
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>$log, "clPwd"=>md5($pwd)));
		if ($t){
			if (is_object($t))
			{
				
				if ($t->clStatus == 1)
				{//active user
					$t = igk_sys_create_user($t);
					$this->m_User = $t;
					$this->App->Session->User = $t;	
					return true;
				}
				else{
					$this->app->Session->ErrorString = "connectfailed : status of the requested user is not activated";
					return false;
				}
			}
		}
		return false;
	}
	public function logout()
	{
		$this->App->Session->User = null;
		return true;
	}
	
	public function uc_add_user_frame(){	
		if (igk_qr_confirm())
		{
			$o = igk_get_robj();
			if ($o->clPwd)
				$o->clPwd = md5($o->clPwd);
			igk_db_insert($this, $this->getDataTableName(), $o);
			igk_notifyctrl()->addMsg("msg.useradded");
			$this->View();
			igk_navtocurrent();
		}
		else{
			$frame = igk_add_new_frame($this, __FUNCTION__);
			$frame->Title = R::ngets("title.addusers");		
			$frm = $frame->Content->addForm();
			$frm["action"] = $this->getUri(__FUNCTION__);
			$ul = $frm->add("ul");
			$ul->add("li")->addSLabelInput("clFirstName");
			$ul->add("li")->addSLabelInput("clLastName");
			$ul->add("li")->addSLabelInput("clLogin","email");
			$ul->add("li")->addSLabelInput("clPwd","password");
			$ul->add("li")->addSLabelInput("clLevel","text")->input->setAttribute("igk-data-role","number");
			$frm->addInput("confirm", "hidden", 1);
			$frm->addHSep();
			$frm->addInput("btn.add", "submit");
			$frame->RenderAJX();
		}
		igk_exit();
	}
	private function uc_options($frm)
	{	
		IGKHtmlUtils::AddImgLnk($frm->add("span"), igk_js_post_frame($this->getUri("uc_add_user_frame")), "add");
	}
	public function View(){
		if (!$this->getIsVisible())
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_html_add_title($t, "title.users");
		
		$t->addHSep();
		igk_add_article($this, "users" , $t->addDiv(), null, true);
		$t->addHSep();
		$frm = $t->addForm();		
		
		igk_notify_sethost($frm->addDiv());
		//: view users
		$this->uc_options($frm);
		$table = $frm->addTable();
		$this->uc_options($frm);
		$table["class"] = "igk-table igk-table-hover";
		$r = igk_db_table_select_where($this->getDataTableName() , null, $this);
		
		//options
	
		
		if ($r){
		$tr = $table->add("tr");
			$tr = $table->add("tr");
			$tr->add("th")->addSpace();
			$tr->add("th")->setClass("fitw-2")->Content = R::ngets("lb.clFirstName");
			$tr->add("th")->setClass("fitw-2")->Content = R::ngets("lb.clLastName");
			$tr->add("th")->Content = R::ngets("lb.clLogin");
			$tr->add("th")->Content = R::ngets("lb.clLevel");
			
			$tr->add("th")->addSpace();
			$tr->add("th")->addSpace();
		foreach($r->Rows as $k=>$v){
			$tr = $table->add("tr");
			$tr->add("td")->addSpace();
			$tr->add("td")->Content = $v->clFirstName;
			$tr->add("td")->Content = $v->clLastName;
			$tr->add("td")->Content = $v->clLogin;
			$tr->add("td")->Content = $v->clLevel;
			
			IGKHtmlUtils::AddImgLnk($tr->add("td"), IGK_STR_EMPTY, "edit");
			IGKHtmlUtils::AddImgLnk($tr->add("td"), IGK_STR_EMPTY, "block");
		}
		}
	}
	public function IsFunctionExposed($func)
	{
		return true;
	}
}
///used to register controls
//--------------------------------------------------------------------------------
final class IGKCtrlTypeManager
{
	static  $tabManager;
	//get all available controller byte
	public static function GetControllerTypes()
	{
	

		if ( self::$tabManager == null){
		$tab = array();
		$exp = "/^(IGK){0,1}(?P<name>[\w_-]+)Ctrl$/i";
		foreach(get_declared_classes() as $k=>$v)
		{
			if (igk_reflection_class_extends( $v,  "IGKCtrlTypeBase") && igk_reflection_class_isabstract($v) && preg_match($exp, $v) )
			{
				preg_match_all($exp, $v, $t);
				$tab[$t["name"][0]] =$v;
			}
		}
		self::$tabManager = $tab;
		return $tab;
		}
		return self::$tabManager;
		
	}
	
}

//TEMP : Preload Images
final class IGKPics extends IGKNonVisibleControllerBase
{	
	public function IsFunctionAvailabele($f)
	{
		return $f == 'view_alls';
	}
	public function view_alls()
	{
		//for shortcut
		$doc = IGKHtmlDoc($this->App, true);			
		$t = $doc->addBodyBox()->addDiv();
		$pics = igk_getctrl(IGK_PIC_RES_CTRL)->getAllPics();
		$t->ClearChilds();
		$out ="igk.ready(function(){var v =null;";
		foreach($pics as $k=>$v)
		{
			$out .= "v = document.createElement('img'); v.src='".R::GetImgUri($k)."'; document.body.AppendChild(v);\n";
		}
		$t->addScript()->Content = $out. "});";
		
		$doc->RenderAJX();
	}
}

final class IGKCacheCtrl extends IGKNonVisibleControllerBase
{
	public function getName(){return "cachectrl"; }
	public function getCacheFile($name)
	{
		return igk_io_baseDir(IGK_CACHE_FOLDER."/".$name);
	}
	public function __construct()
	{
		parent::__construct();
	}
	public function __toString(){ return "cacheController"; }
	
	protected function InitComplete(){//cache controller
		parent::InitComplete();
		$meta =  IGKHtmlItem::CreateWebNode("meta");
		$meta["http-equiv"] = "Cache-control";
		$meta["content"]="public";
		$this->App->Doc->Metas->addMeta("CacheControl", $meta); //"Cache-control" content="public">
	}
	public function storeCache($name, $out)
	{
			$f = $this->getCacheFile($name);
			ob_start();						
			igk_wl($out);
			ob_end_clean();
			igk_io_save_file_as_utf8($f, utf8_decode($out));				
			igk_wl($out);
	}
	
	public function loadCache($name, $ctrl=null)
	{
		$t = igk_getdv($this->App->Configs->cache_file_time, 3600);
		$expire = time()-$t;
		$f = $this->getCacheFile($name);
		
		if (file_exists($f) && (filemtime($f) > $expire))
		{
			
			//header("HTTP/1.1 304 Not Modified");			
			readfile($f);
			return true;
		}
		else{
			if (($ctrl!=null))
			{
				ob_start();
				$ctrl->View();				
				$o = $ctrl->TargetNode->Render();
				igk_wl($o);
				ob_end_clean();
				igk_io_save_file_as_utf8($f, utf8_decode($o));				
				igk_wl($o);
			}
		}
		return false;
	}
	
	
}

abstract class IGKCatachableViewCtrl extends IGKControllerBase
{
	public function getisCachable(){
		return true;
	}
	public function View(){
		if ($this->isCachable)
		{
			if (!igk_getctrl("cache")->loadCache($this->Name))
			{
				parent::View();
				igk_getctrl("cache")->storeCache($this->Name, $this->TargetNode->Render());
			}
		}
		else{
			parent::View();
		}
	}
}

///<summary>system uri actions provider used with igk_redirection.php to provide web redirection according to given url</summary>
final class IGKSystemUriAction extends IGKConfigCtrlBase
{
		private $m_actions;
		private $m_patterInfo;
		public function getName(){return IGK_SYSACTION_CTRL; }
		//public function getIsVisible(){return false;}
		public function getCanAddChild(){return false;}
		public function getConfigPage(){
			return "systemuri";
		}
		public function getDataTableInfo()
		{
			return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clId", IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255, "clIsUnique"=>true, "clIsPrimary"=>true)),			
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clUri", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255))
			);
		}
		public function getDataTableName(){
			return "tbigk_systemUri";
		}
		public function getDataAdapterName()
		{
			return IGK_MYSQL_DATAADAPTER;
		}
		public function gotoconfig(){
			igk_navtocurrent("Configs");			
		}
		public function getmailto(){
			//echo "<meta http-equiv='refresh' content='0;URL=mailto:bondje.doue@igkdev.com'>";
			header("Location: mailto:bondje.doue@gmail.com");
			igk_exit();
		}
		protected function InitComplete(){
			parent::InitComplete();
			$this->App->Session->addInitializeSessionEvent($this, "_initializeCtrl");
			$this->m_actions =array();
			$this->m_actions["/config(.php)?$"] = parent::getUri("gotoconfig");
			$this->m_actions["/clr$"] = "?c=".IGK_SESSION_CTRL."&f=clearS";
			$this->m_actions["/reconnect$"] = igk_getctrl(IGK_CONF_CTRL)->getUri("reconnect");
			$this->m_actions["^/initsdb$"] = "?c=igkdbctrl&f=pinitSDb";			
			$this->m_actions["^/getmailto$"] = parent::getUri("getmailto");
			
			//register page actions
			$tab = igk_sys_pagelist();
			foreach($tab as $k=>$v)
			{
				$this->m_actions["^/".$v."(/:lang)?$"] = parent::getUri("sys_ac_navigateto");
			}	
			//register for db
			$e = $this->getDbEntries();
			if ($e && ($e->RowCount>0))
			{
				foreach($e->Rows as $k=>$v)
				{
					if (is_object($v))
					{
						$this->sys_ac_register($v->clName, $v->clUri);				
					}
					else 
						igk_wln($v);
				}
			}
		}
		public function _initializeCtrl(){
			$this->m_patterInfo = null;
		}
		public function IsFunctionExposed($k){
			return true;
		}
		
		public function sys_ac_navigateto(){
			
			if (isset($_REQUEST["p"]))
			{
				header("Location: ".igk_io_baseUri()."/".$_REQUEST["p"]);	
				igk_exit();
			}
			$k =igk_sys_ac_getpatterninfo();
			$tab = $k->getParams();
			$l = igk_getv($tab, "lang");
			$s= "?p=".igk_getv($tab, "page");
			if ($l){
				$s .= "&l=".$l;
			}
			$this->App->getControllerManager()->InvokeUri($s);
		}
		public function contains($key)
		{
			if (is_array($this->m_actions))
				return array_key_exists($key, $this->m_actions);			
			return false;
		}
		public function matche($uri)
		{
			//get regex pattern
			if ($this->m_actions){
			foreach($this->m_actions as $k=>$v)
			{
				$pattern = $this->getPattern($k);				
				if (preg_match($pattern , $uri))
				{
					return new IGKSystemUriActionPatternInfo( array(
					"action"=>$k,
					"value"=>$v,
					"pattern"=>$pattern,
					"uri"=>$uri,
					"keys"=> $this->getKeysPattern($k)));
				}
			}			
			}
			return null;
		}
		public function getPattern($s)
		{
			$s = preg_replace_callback(
				"#:(?P<name>([a-z0-9]+))\+?#i", 
				array($this, "matchPattern"),
				$s
			);			
			return "/".str_replace("/","\/", $s)."/i";
		}
		private function getKeysPattern($s)
		{
			$tab = array();
			$t = array();
			$s = preg_match_all(
				"#:(?P<name>([a-z0-9]+))\+?#i", 				
				$s,
				$t
			);
			for($i=0; $i<$s; $i++)
			{
				$tab[] = $t["name"][$i];
			}
			return $tab;
		}
		function matchPattern($m){			
			$n = $m["name"];
			if (substr($m[0],-1) == "+")
			{
				$tm =  "(?P<".$n.">([^/]+/?)+)";
			}
			else{
				$tm =  "(?P<".$n.">[^/]+)";
			}
			return $tm;
		}
		public function getSystemUri($key=null)
		{
			if ($this->contains($key))
				return $this->m_actions[$key];				
			return null;
		}
		public function invokeUri($key)
		{
			$this->App->getControllerManager()->InvokeUri($this->getSystemUri($key));
			//if necessary 
			igk_render_doc();
			igk_exit();
		}
		public function getPatternInfo(){
			return $this->m_patterInfo;
		}
		public function invokeUriPattern($pattern)
		{
			$this->m_patterInfo=$pattern;			
			$ck = igk_getv($this->m_actions, $pattern->action);
			$this->App->getControllerManager()->InvokeUri($ck);	
			//if necessary 			
			$this->m_patterInfo = null;
			igk_render_doc();
			igk_exit();
		}
		public function sys_ac_register($p, $uri)
		{
			if (isset($this->m_actions[$p])){
				igk_debug_wln("Action name ".$p." already register "); return;
			}
			$this->m_actions[$p] = $uri;
		}
		public function sys_ac_unregister($uripattern){
			if (isset($this->m_actions[$uripattern])){
				unset($this->m_actions[$uripattern]);
			}
		}
		
		public function View(){
			
			if (!$this->getIsVisible())
			{
				igk_html_rm($this->TargetNode);
				return;
			}
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();
		igk_html_add_title($c, "title.SystemUriView");
		$c->addHSep();
		igk_add_article($this, "systemuri", $c->addDiv(), null, true);		
		$c->addHSep();		
		
		$div = $c->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("update_bootstrap_setting");
		
		$d = $frm->addDiv();
		$d["class"]="form-group";
			$ul  = $d->add("ul");
				foreach($this->m_actions as $k=>$v)
				{
					$li = $ul->add("li");
					$li->add("label", array("class"=>"col-ms-3 no-overflow igk-text-ellipis"))->Content = $k;
					$li->add("label", array("class"=>"col-ms-3"))->Content = $v;
				}
		
		}
}

final class IGKSystemUriActionPatternInfo
{
		var $action;
		var $value;
		var $pattern;
		var $uri;
		var $keys;
		
		public function __construct($tab)
		{
			foreach($tab as $k=>$v)
			{
				$this->$k = $v;
			}
		}
		public function getParams(){
			//get parameters
			preg_match_all($this->pattern, $this->uri, $tab);
			$t = array();
			foreach($this->keys as $k=>$v)
			{
				$s = $tab[$v][0];
				if (strstr($s, "/"))
					$s = explode("/", $s);
				if (!isset($t[$v]))
					$t[$v] = $s;
				else{
					if (is_array($t[$v]))
						$t[$v][] = $s;
					else{
						$t[$v] = array($t[$v], $s);
					}
				}
			}
			return $t;
		}

		public function matche($uri){
			return preg_match($this->pattern, $uri );
		}
}
//-------------------------------------------------------------------------------
//<summary>REPRESENT THE EDITOR OF A PAGE</summary>
//-------------------------------------------------------------------------------
final class IGKControllerPageEditor extends IGKControllerBase
{
	private $m_script;	
	public function getDataAdapterName(){ 
		return IGK_MYSQL_DATAADAPTER; 
	}	
	protected function InitComplete(){
		parent::InitComplete();
		igk_getctrl(IGK_MENU_CTRL)->addPageChangedEvent($this, "View");
	}
	//<summary>override the page folder changed definition</summary>
	public function pageFolderChanged(){
		$this->View();		
	}
	protected function initTargetNode()
	{		
		$node = parent::initTargetNode();
		$node["class"] = "igk-configpage-editor";			
		return $node;
	}
	private function _editor_ca_script($uri)
	{
		return "javascript: var f = \$igk(this).getParentForm(); \$igk(this).$.ajx.post('{$uri}&n='+f.clCtrls.value,null,function(xhr){if (this.isReady()){ igk.$.ctrl.frames.appendFrameResponseToBody(xhr.responseText);}}); return false;";
	}
	private function _build_view($node){
				
		$frm = $node->addForm();
		$frm["action"] = $this->getUri("editor_update");
		//add page editor action
		$d = $frm;//->add("span");
		$d->addLabel("lb.page", "clPages");
		$s = $d->add("select");
		$s->setId("clPages");
		$s["onchange"] = "javascript: window.igk.navigator.navTo('?p='+this.value); return false;";///, null, function(xhr){ if(this.isReady()){this.replaceBody();}})";
		//get available page
		$t = igk_sys_pagelist();
		foreach($t as $k=>$v)
		{
			$opt = $s->add("option");
			$opt->Content = $v;
			$opt["value"] = $v;
			if ($this->CurrentPage == $v)
			{
				$opt["selected"]=1;
			}
		}
		
		$d  = $frm;//->add("span");
		$d->addLabel("lb.ctrls", "clCtrls");
		$t = igk_sys_getuserctrls();				
		$setting = igk_html_build_select_setting();		
		$setting->resolvtext = false;
		$setting->keysupport = true;
		$setting->valuekey = "Name";
		$setting->displaykey = "Name";	
		igk_html_build_select($d, "clCtrls", $t, (array)$setting,null);
		$edit = igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_ajx");
		IGKHtmlUtils::AddImgLnk($d, $this->_editor_ca_script($edit), "edit");
		$edit = igk_getctrl(IGK_CA_CTRL)->getUri("ca_edit_ctrl_properties_ajx");
		IGKHtmlUtils::AddImgLnk($d,  $this->_editor_ca_script($edit), "setting");
		
		IGKHtmlUtils::AddAnimImgLnk($frm, igk_js_post_frame($this->getUri("editor_add_ctrl_ajx")), "editor_add", "32px", "32px");		
		IGKHtmlUtils::AddAnimImgLnk($frm, igk_js_post_frame($this->getUri("editor_menu_ajx")), "editor_menu", "32px", "32px");	
		IGKHtmlUtils::AddAnimImgLnk($frm, igk_js_post_frame($this->getUri("editor_font_ajx")), "editor_form", "32px", "32px");
		IGKHtmlUtils::AddAnimImgLnk($frm, igk_js_post_frame($this->getUri("editor_xcss_ajx")), "editor_xcss", "32px", "32px");
		IGKHtmlUtils::AddAnimImgLnk($frm, igk_js_post_frame($this->getUri("editor_db_ajx")), "editor_db", "32px", "32px");
		IGKHtmlUtils::AddAnimImgLnk($frm, "javascript: window.igk.ctrl.show_ctrl_options(); return false;", "editor_viewc", "32px", "32px");
		IGKHtmlUtils::AddAnimImgLnk($frm, "javascript: window.igk.ctrl.show_article_options(); return false;", "editor_viewa", "32px", "32px");	
		$frm->addDiv()->setClass("igk-cleartab");
		$frm->addDiv()->setStyle("+/height:4px; [bgcl:igk-btn-success-bg]")
		->setAttribute("onclick", "javascript: \$igk(this).getParentCtrl().fc.hide();")
		->addSpace();
		$this->m_script = $node->addScript();
		$this->m_script->Content  = "(function(){var p=igk.getParentScript();  window.igk.ready(function(){window.igk.callfunction('igk.ctrl.pageeditor.init', new Array(p));});})();";
	}
	public function editor_menu_ajx()
	{
		$frame = igk_add_new_frame($this, "editor_menu_frame");
		$frame->Title =R::ngets("title.primaryMenuEditor");
		$c = $frame->Content;
		$c->ClearChilds();
		$d = $c->addDiv();
		igk_getctrl(IGK_MENU_CTRL)->MenuConfig($d);
		
		igk_getctrl(IGK_CA_CTRL)->__viewMenuHostCtrl($d);
		
		
		$s = $frame->regView;
		if (!$s)
		{
			igk_getctrl(IGK_MENU_CTRL)->regView($this, "editor_menu_ajx");
			$frame->regView = true;
			$frame->addCloseCallBackEvent($this,"editor_menu_frame_closed");
			$frame->RenderAJX();	
		}	
		igk_notifyctrl()->setNotifyHost($d->addDiv());
	}
	public function editor_menu_frame_closed($frame)
	{
		$frame = igk_get_frame("editor_menu_frame");
		igk_getctrl(IGK_MENU_CTRL)->unregView($this);
		$frame->regView=false;
		$frame->removeCloseCallBackEvent($this, "editor_menu_frame_closed");
		igk_notifyctrl()->setNotifyHost(null);		
	}
	
	public function editor_article_ajx(){		
	}
	public function editor_language_ajx(){
	}
	public function editor_font_ajx(){
		$frame = igk_add_new_frame($this, "editor_font_frame");
		$frame->Title = R::ngets("title.font-editor");
		$d = $frame->Content ;
		$d->ClearChilds();
		
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("editor_font_validate");		
		$frm["style"]="position:relative; border:1px solid black; height:100%;";
		$frm->Content["style"]="position:relative; height:100%; margin-bottom:56px;";
		$ftview = $frm->addDiv();
		$ftview["class"]= "fitw fith posr";
		
		$table = $ftview->addTable();
		$ul = $ftview->add("ul", array("id"=>"font_list", "class"=>"font_list"));
		igk_getctrl(IGK_THEME_CTRL)->theme_buildFontTable($table, $ul);
		$p = $ftview->addDiv();
		$p["style"]="position:absolute; bottom:0px; right:0px; width:100%; height: 56px;";
		$p->addHSep();
		
		$i = $p->addInput("btn.validate", "submit");	
		$i["style"]="position:absolute; bottom:4px; right:4px;";
		
		$frame->RenderAJX();		
	}	
	public function editor_font_validate(){
		//validate font
	}
	public function editor_db_validate(){
		//validate db
		igk_notifyctrl()->addMsgr("msg.databaseupdated");
		igk_getctrl("igkdbctrl")->pinitSDb();
	}
	public function editor_db_ajx(){
		$frame = igk_add_new_frame($this, "editor_db_frame");
		$frame->Title = R::ngets("title.initdatabase");
		$d = $frame->Content ;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("editor_db_validate");		
		
		$frm->addHSep();
		$frm->addInput("btn.validate", "submit", R::ngets("btn.initdb"))->setClass("-clsubmit igk-btn igk-btn-default");
		$frame->RenderAJX();		
	}
	public function editor_xcss_ajx($render=true){
		$frame = igk_add_new_frame($this, "editor_css_frame");
		$frame->Title = R::ngets("title.AddOrModClassed");
		$frame->ClearChilds();
		$d = $frame->Content;
		
		$frm = $d->addForm();
		$frm["action"]= $this->getUri("editor_xcssvalidate_ajx&navigate=0");
		$ul = $frm->add("ul");
		$lk = $ul->add("li")->addSLabelInput("clName","text",  igk_getr("clName"));
		$lk->input["autocomplete"] = "off";
		
		$input = $ul->add("li")->addSLabelTextarea("clValue", igk_getr("clValue"));		
		$input->textarea["class"] = "+igk-css-textarea";
		$frm->addHSep();
		$frm->addInput("btn.submit", "submit", R::ngets("btn.addormod"));
		IGKHtmlUtils::AddBtnLnk($frm, R::ngets("btn.dropstyle"), "javascript: (function(q){if (q.clName.value)window.igk.ajx.post('".$this->getUri("editor_xcss_drop_ajx&n=")."'+q.clName.value, null, function(){if (this.isReady()){q.reset(); }});})(\$igk(this).getParentForm()); return false;");//.igk_js_post_frame_cmd($this->getUri(
		$frm->addScript()->Content = "(function(p){ igk.ctrl.pageeditor.xcssInit(p,'".IGK_THEME_CTRL."' );})(igk.getParentScript());";		
		if ($render)
		$frame->RenderAJX();
	}
	public function editor_xcss_drop_ajx()
	{
		$n = igk_getr("n");
		if ($n){
			igk_getctrl(IGK_THEME_CTRL)->theme_rmkey($n);
		}
	}
	public function editor_xcssvalidate_ajx()
	{
		$obj = igk_get_robj();
		//=====
		$this->editor_xcss_ajx(false);
		igk_getctrl(IGK_THEME_CTRL)->theme_addKey();
		
	}
	
	public function editor_langvalidate()
	{
		$obj = igk_get_robj();
		R::AddLang($n, $v);
		R::SaveLang();
		igk_navtocurrent();
	}
	
	public function editor_add_ctrl_ajx(){
		//update the current editor
		igk_getctrl(IGK_CA_CTRL)->ca_add_ctrl_frame_ajx(true);
	}
	public function editor_update_ajx(){
		//update the current editor
	}
	public function editor_drop_ajx(){
		//update the current editor
	}
	
	public function getIsVisible(){
		return ($this->App->CurrentPageFolder != IGK_CONFIG_PAGEFOLDER) && ($this->App->ConfigMode && $this->App->Configs->allow_article_config);
	}
	public function getCanAddChild(){
		return false;
	}
	public function info_ajx(){
		$r = igk_new_response();
		$r->add("item", array("name"=>"test_1"))->Content = "se";
		for($i=0; $i< 30; $i++){
			$r->addItem("text".$i, "text".$i, null);
		}
		$r->RenderAJX();
	}
	public function View()
	{
		if ($this->getIsVisible())
		{
			$this->TargetNode->ClearChilds();
			$this->_build_view($this->TargetNode);
			igk_html_add($this->TargetNode, $this->App->Doc->body);
			$this->_onViewComplete();
			$this->App->Doc->body["class"] = "+igk-page-editor";
		}
		else{
			igk_html_rm($this->TargetNode);
			$this->App->Doc->body["class"] = "-igk-page-editor";
		}
		
	}
	
}


final class IGKCtrlInfo extends IGKObject
{
	private $m_addNew;
	private $m_typeCreated;
	private $m_name;
	private $m_type;
	private $m_childs;
	private $m_SupportMultiple;
	
	public function __construct($name, $type)
	{	
		$this->m_childs = array();
		$this->m_name = $name;
		$this->m_type = $type;
		$this->m_addNew = true;
		$this->_initInfo();
	}
	public function getName(){return $this->m_name;}
	public function getType(){return $this->m_type;}
	
	public function getCanAddNew()
	{
		return $this->m_addNew;
	}
	public function getCreated(){
		return $this->m_typeCreated;
	}
	private function _initInfo()
	{
		//load childs
		foreach(get_declared_classes() as $k=>$v)
		{
			if ( igk_reflection_class_extends($v, $this->Type) && !igk_reflection_class_isabstract($v))
			{
				$this->m_childs[] = $v;
			}
		}
		if (method_exists($this->Type, "SupportMultiple"))
		{
			$this->m_SupportMultiple =  call_user_func_array(array($this->Type,"SupportMultiple"),array()); 
			$this->m_addNew = $this->m_SupportMultiple || (count($this->m_childs) <1);
			
		}
	}
	
}

final class IGKCustomControllerManager extends IGKNonVisibleControllerBase //used to get custom controller argument info
{
	public function getName(){return IGK_CUSTOM_CTRL_MAN_CTRL;}
	
	public function getInfo($name){
		//get list of type
		$m = IGKCtrlTypeManager::GetControllerTypes();
		array_keys(IGKCtrlTypeManager::GetControllerTypes());
		if (isset($m[$name]))
		{
		
			$type = $m[$name];
			$i = new IGKCtrlInfo($name, $type);
			return $i;;
		}
		return null;
	}
}

final class IGKComponentManagerCtrl extends IGKNonVisibleControllerBase {
	public function getName(){ return IGK_COMPONENT_MANAGER_CTRL;}
	
	private $m_objs;
	private $m_ids;
	
	public function __construct(){
		parent::__construct();		
		$this->m_objs = array();
		$this->m_ids = array();
	}
	public function InitComplete(){
		parent::InitComplete();
	}
	public function Register($obj){
	
		if (($obj == null) || igk_array_value_exist($this->m_objs, $obj))
			return;
			
		$this->m_objs[] = $obj;
		$s = igk_new_id();
		$this->m_ids[$s] = $obj;	
		$obj->setParam(__CLASS__.":id", $s);
		//igk_log_write_i("RegisterController", $s. " ");
	}
	public function Unregister($obj){
		if ($obj == null)
		{
			return; 
		}
		$t = array();
		foreach($this->m_objs as $k=>$v)
		{		
			if ($obj === $v)
				continue;
			$t[] = $v;
		}		
		$this->m_objs = $t;
		$r = $this->getId($obj);				
		unset($this->m_ids[$r]);
		$obj->unsetParam(__CLASS__.":id");	
		//igk_log_write_i("UnRegisterController", $r. " ");		
	}
	public function inv(){
		//invoke uri
		$f = base64_decode(igk_getr("p"));
		
		$tab = igk_getquery_args($f);		
		$k = $tab["id"];	
		$obj = igk_getv($this->m_ids,$k);
		if ($obj)
		{
			$m =  igk_getv(explode("&", $tab["f"]), 0);
			if (method_exists(get_class($obj), $m))
			{							
				$obj->$m();
			}		
		}			
		igk_exit();
	}
	public function getUri($f=null, $obj=null)
	{
		if ($obj==null)
			return parent::getUri($f);
		return parent::getUri("inv&p=".base64_encode("f=".$f."&id=".$this->getId($obj)));
	}
	public function getId($obj)
	{
		if ($obj == null)
			return null;
		$r  = $obj->getParam(__CLASS__.":id");
		if ($r)
			return $r;
		foreach($this->m_ids as $k=>$v)
		{
			if ($v===$obj)
				return $k;
		}
		return null;
	}
	
}

///<summary>represent a controllertype manager attribute</summary>
class IGKControllerTypeAttribute extends IGKAttribute{

}

///<summary>Android Style manager controlleur</summary>
final class IGKAndroidStyleManager extends IGKControllerBase
{
	private $m_fromsession;
	protected function InitComplete(){
		parent::InitComplete();
		$this->App->Session->addUpdateSessionEvent($this, "sessionView");		
		$this->App->addNewDocumentCreatedEvent($this, "bindDocumentSetting");
	}
	
	public function bindDocumentSetting($target, $document)
	{
		if (igk_agent_isAndroid())
		{			
			$meta = $document->getMetas()->getMetaById("android:viewport");		
			if ($meta==null){
					$meta =  IGKHtmlItem::CreateWebNode("meta");
					$meta["name"]="viewport";
					$meta["content"]="width=device-width, initial-scale=1";							
			}
			$document->getMetas()->addMeta("android:viewport", $meta);			
		}		
		else{
			$document->getMetas()->rmMeta("android:viewport");
		}
	}
	public function sessionView()
	{		
		$this->bindDocumentSetting($this, $this->App->Doc);
		
		if ($this->m_fromsession)
		{
			$this->View();
		}
		else{
			$this->m_fromsession= true;
		}
	}
	public function getIsVisible(){
		return igk_agent_isAndroid();
	}
	public function View(){
		if (igk_agent_isAndroid())
		{
			$this->App->Doc->body["class"] = "+igk-android";			
		}		
		else{
			$this->App->Doc->body["class"] = "-igk-android";			
		}
	}
}
//<summary>system management class</summary>
final class IGKSysCtrl extends IGKNonVisibleControllerBase
{
	private $m_fontList;
	
	public function getFontDir(){ //get font directory
		return igk_io_syspath(IGK_RES_FONTS);
	}
	public function __construct(){
		parent::__construct();
		$m_fontList = null;
	}
	protected function InitComplete(){
		parent::InitComplete();
		$this->App->getControllerManager()->register("sys", $this);		
		igk_getctrl(IGK_CONF_CTRL)->addConfigUserChangedEvent($this,"init_sys_config");
	}
	public function init_sys_config(){		
		if (igk_getctrl(IGK_CONF_CTRL)->getIsConnected())
		{
			$this->m_fontList = $this->_getFontList();	
		}
		else 
			$this->m_fontList = null;
	}
	public function getFontList(){//get font list
		return $this->m_fontList;
	}
	public function _getFontList(){
		$count= 0;
		$source = igk_post_uri(igk_io_baseUri()."/".igk_html_uri(igk_io_basePath(IGKIO::GetDir(dirname(__FILE__)."/cgi-bin/fontlist.cgi"))));
		$node = IGKHtmlReader::Load($source);
		if ($node){
		$tab =array();
		foreach($node->getElementsByTagName("item") as $k)
		{
			$tab[$k["name"]] = $k->getinnerHTML();
		}
		
		return (object)array("fonts"=>$tab, "count"=>count($tab));
		}
		return null;
	}
	public function installfont($name=null){
		$n = ($name==null)? base64_decode(igk_getr("n")) : $name;
		if ($this->m_fontList && isset($this->m_fontList->fonts[$n]))
		{
			$file = $this->m_fontList->fonts[$n];
			$target  = igk_io_currentRelativePath("R/Fonts/".basename($file));
			copy($file, $target);
			$this->App->Doc->Theme->addFont($n, IGKIO::GetDir(igk_io_basePath($target)));
			igk_notifyctrl()->addMsgr("msg.fontinstalled");
			return true;
		}
		return false;
	}
	public function installfont_ajx(){
		if (igk_parsebool($this->installfont()))
		{
			$node = $this->getParam("sys:viewnode");		
			$item = $this->getParam("sys:binding");				
			$frm = $item["form"];
			$ctrl = $item["ctrl"];
			if ($ctrl){
				$ctrl->View();
				$id = $ctrl->TargetNode["igk-type-id"];				
				igk_js_render_script("window.igk.ajx.ageturi('".$ctrl->getUri("ViewAJX")."', window.igk.ctrl.getCtrlById('".$id."'));");				
			}
			$this->_buildForm($frm);			
			$frm->RenderAJX();
		}
		
	}
	public function viewInstallFontForm($node, $ctrl=null)
	{
		$frm = $node->addForm();
		$this->setParam("sys:binding", array("form"=>$frm,"ctrl"=>$ctrl));
		$this->_buildForm($frm);		
	}
	private function _buildForm($frm)
	{
		$frm->ClearChilds();
		$frm["action"] = $this->getUri("installfont_ajx");
		$div = $frm->addDiv();
		$div["style"] = "max-height: 300px; overflow-x:none; overflow-y:auto;";
		$i = 0;
		if ($this->m_fontList!=null){
		foreach($this->m_fontList->fonts as $k=>$v)
		{
			$f = IGKIO::GetDir($this->getFontDir()."/".basename($v));
				$uri = $this->getUri("installfont_ajx");
			$cdiv = $div->addDiv(
			array(
			"style"=>"font-family: '".$k."';",
			"class"=>"igk-menu-item", 
			"igk-js-click"=>IGK_STR_EMPTY,
			"id"=>"font_".$i,
			"igk-font-name"=>base64_encode($k),
			"onclick"=>"javascript:window.igk.system.fonts.installFont(this, '{$uri}'); return false;"));
			
			if (file_exists($f))
				$cdiv["style"] .="color:#9A9A9A;";
			else
				$cdiv["style"] .="color:#3A3A3A;";
			$cdiv->setContent($k);
			$i++;
		}
		}
	}

	
}

//log controller
final class IGKLogController extends IGKNonVisibleControllerBase
{
	public function getName(){return IGK_LOG_CTRL; }
	public function getLogFile(){
		return igk_getv($this->App->Configs, "LogFile", igk_io_basePath("Data/Logs.txt"));
	}
	public function write($msg){
		$this->write_i("IGKLOG", $msg);
	}
	public function write_i($tag, $message)
	{
		$f = $this->getLogFile();
		$r = null;		
		$r = fopen($f, file_exists($f)?"a+":"w+");					
		fwrite($r, date("h:i:s").": - [".$tag."] - ".$message."\n");
		fclose($r);			
	}
	public function ClearLog(){
		$f = $this->getLogFile();
		$r = fopen($f,"w+");					
		fclose($r);			
	}
}

///------------------------------------------------------------------------------
/// who used controller
///------------------------------------------------------------------------------
final class IGKWhoUseCtrl extends IGKNonVisibleControllerBase
{
	
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	protected function InitComplete(){
		parent::InitComplete();
		$uri = igk_io_baseUri();
		//update uri to system
		if(strtolower(IGK_ROOT_SERVER) != strtolower($uri))
		{			
			$d = IGK_ROOT_SERVER."/".$this->getUri("register_site&uri=".base64_encode($uri));
			$sc = IGKHtmlItem::CreateWebNode("script");			
			$rep = igk_post_uri($d);			
		}
	} 
	public function register_site(){
		$uri = base64_decode(igk_getr("uri"));
		if ($uri == null){
			return;
		}
		$tab = array("clWebSite"=>$uri);		
		if(igk_db_table_select_row(IGK_TB_WHO_USES, $tab, $this) == null)
		{
			igk_db_insert($this, IGK_TB_WHO_USES,$tab);
			igk_mail_sendmail("info@igkdev.be", "no-reply-balafon@igkdev.be", "A Web Site registrated to balafon ".$uri);
			IGKHtmlItem::CreateWebNode("response")
			->setContent("site added : ".$uri)
			->RenderAJX();
			
		}
		else{
			IGKHtmlItem::CreateWebNode("response")			
			->setContent("site already register : ".$uri)			
			->RenderAJX();
		}
		igk_exit();
	}	
}
final class IGKCtrlValue extends IGKObject 
implements IIGKHtmlGetValue
{
	private $m_uri;
	private $m_type;
	
	public function __construct($uri, $type="posted"){
		$this->m_uri = $uri;
		$this->m_type = $type;
	}
	public function getValue(){//ctrl get value
		 return igk_post_uri($this->m_uri);
	}
}
final class IGKPluginConfigMenuItem extends IGKMenuItem
{
	public function __construct($ctrl, $uri){
		parent::__construct(
			"plugins", 
			"plugins", 
			 $uri,
			500, 
			"plugins",
			null,
			"files"
		);
		$this->Node = IGKHtmlItem::CreateWebNode("li");
		$this->Node->addA($uri)->setClass("floatl dispib no-wrap")
		->setAttribute("style", "width:auto;")
		->setContent ("Plugins")
		->add("span")->setClass("badge floatr dispi alignc alignm")	
		->Content = new IGKCtrlValue(igk_io_baseUri()."/".$ctrl->getUri("number_of_plugins_installed"));
	}
}
///<summary>publings controller manager</summary>
final class IGKPluginCtrl extends IGKConfigCtrlBase
{
	private $m_pluginBody;
	public function getConfigPage(){ return "plugins"; }
	public function initConfigMenu(){			
		return  array(new IGKPluginConfigMenuItem($this, $this->getUri("showConfig")));
	}
	public function number_of_plugins_installed(){
		if(strtolower(IGK_ROOT_SERVER) == strtolower(igk_io_baseUri()))
		{			
			$tab = igk_db_table_select_where("tbigk_plugins");
			igk_wl($tab->RowCount);
		}
		else 
			igk_wl(IGK_HTML_CHAR_ZERO);
		igk_exit();
	}
	public function IsFunctionExposed($name)
	{
		return true;
	}
	public function getPluginsList($type="html")
	{
		$r = IGKHtmlItem::CreateWebNode("response");
		$r["responseType"] = $type;
		
		if(strtolower(IGK_ROOT_SERVER) == strtolower(igk_io_baseUri()))
		{			
			$tab = igk_db_table_select_where("tbigk_plugins");
			$r["count"] = $tab->RowCount;
			$r->addDataEntry()->LoadData($tab);		
		}
		else{
			$re = igk_post_uri(IGK_ROOT_SERVER."/".$this->getUri("getPluginsList/".$type));
			if (empty($re)){
				$r["status"] = "error";
				$r->add("message")->Content	= R::ngets("msg.cangetpluginslistform.server");
			}			
			else{
				$r->Load($re);
			}
		}
		switch($type)
		{
			case "xml":
				$r->RenderXML();
				break;
			case "xmlview":
				$d = new IGKHtmlXmlViewerItem();
				$d->Load($r->Render(null));
				$d->RenderXML();
				break;
			default:
				$r->RenderAJX();
				break;
		}
		igk_exit();
	}
	
	
	public function getPlugins($name){
		$p = igk_db_table_select_row("tbigk_plugins", array("clName"=>$name));		
		if ($p){
			$f = igk_io_currentRelativePath(IGK_PLUGINS_FOLDER."/".$p->clName.IGK_PLUGIN_ZP_FILE_EXTENSIONS);			
			if (file_exists($f))
			{
				igk_wl(IGKIO::ReadAllText($f));
			}
		}
		igk_exit();
		
	}
	public function getInstalledPlugins($options=null){
		$r = IGKHtmlItem::CreateWebNode("response");
		$tab = igk_io_getfiles(igk_io_currentRelativePath(IGK_PLUGINS_FOLDER) , "/\\.pbal/i") ;
		$r["version"] = "1.0";
		$r["number"]  = igk_count($tab);
		$r->addComment()->Content = "installed plugins list";
		foreach($tab as $k=>$v)
		{		
			$b = igk_getv(IGKHtmlReader::LoadFile($v)->Childs, 0);
			if ($b !=null){
			$r->add("plugin")
			->setAttribute("file", igk_io_basePath($v))
			->setAttribute("name", igk_io_basenamewithoutext($v))
			->setAttribute("version", $b["version"])
			->setAttribute("author", $b["author"])
			->setAttribute("description", $b["description"]);
			;
			}
			else{
			$r->add("error")->Content = "not define";
			}
		}		
		switch($options)
		{
			case "xmlview":
			$d = new IGKHtmlXmlViewerItem();
			$d->Load($r->Render(null));
			$d->RenderXML();
			break;
			default:
			$r->RenderXML();
			break;
		}
		igk_exit();
	}
	public function createPlugins($name,   $files, $author = IGK_AUTHOR_CONTACT)
	{
		$f = igk_io_currentRelativePath(IGK_PLUGINS_FOLDER)."/$name".IGK_PLUGIN_ZP_FILE_EXTENSIONS;		
		if (file_exists($f) || (count($files) == 0))
		{
			return false;
		}
		$df = IGKHtmlItem::CreateWebNode("plugin");
		$df["version"] = "1.0";
		$df["author"] = $author;
		$df["name"] = $name;
		$df["file"] = igk_io_basePath(IGK_PLUGINS_FOLDER)."/".basename($f);
		$zip = new ZipArchive();
		$zip->open($f, ZIPARCHIVE::CREATE);	
		$dfi = $df->add("files");		
		foreach($files as $k=>$v){
			$zip->addFile($v);
			$dfi->add("file")->Content = $v;
		}
		$zip->addFromString($name.IGK_PLUGIN_FILE_EXTENSIONS, $df->Render(null));
		$zip->close();		
		return true;
	}
	public function installPlugins($name)
	{
		$f = igk_io_baseDir(IGK_PLUGINS_FOLDER)."/$name".IGK_PLUGIN_ZP_FILE_EXTENSIONS;
		if (!file_exists($f))
		{
			return false;
		}
		$hzip = zip_open($f);
		$outdir =  igk_io_baseDir();
		$def =  $name.IGK_PLUGIN_FILE_EXTENSIONS;
		$defnode = null;
		if (is_resource($hzip))
		{
			
			while( ($e = zip_read($hzip)))
			{
				$n = zip_entry_name($e);				
				if ($n == $def)
				{
					//load environment
					$defnode = IGKHtmlReader::Load(zip_entry_read($e,zip_entry_filesize($e)));
					
				}
				else{				 
					//extract zip
					if (igk_zip_entry_isdir($e))
					{	
						igk_zip_create_dir($outdir, $n);
					}
					else{
						if (!(strpos($n, "/")===FALSE))
						{
							igk_zip_extract($outdir, $hzip , $e);
						}
						else{
							if(IGKIO::CreateDir($outdir))
							{
								igk_zip_extract($outdir, $hzip , $e);
							}
						}
					}
				}
			}
			zip_close($hzip);
			igk_notifyctrl()->addMsgr("msg.pluginsinstalled");			
			igk_io_save_file_as_utf8_wbom(igk_io_currentRelativePath(IGK_PLUGINS_FOLDER)."/$name".IGK_PLUGIN_FILE_EXTENSIONS, $defnode->Render());	
		}					
		return true;
	}
	
	public function uninstallPlugins($name){
		$fs= igk_io_currentRelativePath(IGK_PLUGINS_FOLDER)."/$name".IGK_PLUGIN_FILE_EXTENSIONS;
		if (file_exists($fs) == false)
			return false;
		$defnode = IGKHtmlReader::LoadFile($fs);	
		
		foreach($defnode->getElementsByTagName("file") as $k)
		{
			$f = igk_io_currentRelativePath(trim($k->innerHTML));
			
			if (file_exists($f))
			{
				unlink($f);				
				$dir = dirname($f);
				while(IGKIO::RmDir($dir, false)){
					//dictory was empty remove hierarchi
					$dir = dirname($dir);
					if (igk_io_basePath($dir) == "")
						break;
				}
			}
		}	
		unlink($fs);
		return true;
	}

	public function View(){
		$this->TargetNode->ClearChilds();
		
		$t = $this->TargetNode->addRow();
		
		igk_html_add_title($t->addDiv(),"title.PluginsManager");
		$t->addHSep();
		$d = $t->addDiv();
		$menu = $d->addHMenu();
		$menu->addItem("Installed", $this->getUri("plugins/installed"), R::ngets("menu.plugins.installed"));
		$menu->addItem("Plugins", $this->getUri("plugins/search"), R::ngets("menu.plugins.get"));
		$this->m_pluginBody = $d->addDiv();
		$this->plugins();
	}
	public function plugins($page="installed"){
		$m = __FUNCTION__."_".$page;
		if (method_exists(__CLASS__, $m))
		{
			$tab =  array_slice(func_get_args(), 1);
			call_user_func_array(array(__CLASS__,$m), $tab);			
		}				
	}
	public function plugins_installed(){
		$this->m_pluginBody->ClearChilds();
		$this->m_pluginBody->addDiv()->addAJXView()->setUri($this->getUri("getInstalledPlugins/xmlview"));
		
	}
	public function plugins_search(){
		$this->m_pluginBody->ClearChilds();
		$this->m_pluginBody->addDiv()->addAJXView()->setUri($this->getUri("getPluginsList/xmlview"));//->setScript("alert(this);");	
	}
}


///<summary>uses to sort value contains in tab by attribute keys</summary>
final class IGKSorter
{
	var $key;	
	var $asc;
	public function __construct(){
		$this->asc = true;
	}
	public function Sort(& $tab)
	{
		if (is_array($tab))
		{
			usort($tab, array($this, "SortValue"));
		}
		else {
			if (method_exists(get_class($tab), "SortValueBy"))
			{
				$tab->SortValueBy($this->key);				
			}
		}
	}
	public static function SortByDisplay($tab, $key, $asc=true){
	
		return self::__SortValue($tab, $key, $asc, "SortKeyValue");
	
	}
	public static function SortByValue($tab, $key, $asc=true){
	
		return self::__SortValue($tab, $key, $asc, "SortValue");
	
	}
	private static function __SortValue( & $tab, $key, $asc=true, $funcname){
			$t = new IGKSorter();
		$t->key = $key;
		$t->asc = $asc;
		if (is_array($tab))
		{			
			usort($tab, array($t, $funcname));
		}
		else {
			if (method_exists(get_class($tab), "SortValueBy"))
			{
				$tab->SortValueBy($key, $asc , array($t, $funcname) );				
			}
		}		
		return $tab;
	}
	public function SortValue($a, $b){
		$k = $this->key;
		$s1 = strtolower($a->$k);
		$s2 = strtolower($b->$k);
		
		$i = strcmp($s1, $s2);		
		return $i;
	}
	public function SortKeyValue($a, $b){
		$k = $this->key;
		$s1 = strtolower(R::gets($a->$k));
		$s2 = strtolower(R::gets($b->$k));		
		$i = strcmp($s1, $s2);		
		return $i;
	}
}




//HTML Item declaration
final class IGKHtmlSelectItem extends IGKHtmlItem
{
	private $m_keys;
	public function __construct(){
		parent::__construct("select");
		$this->m_keys = array();
		$this["class"]="clselect";
	}
	public function addOptions($tabarray){
		if (is_array($tabarray))
		{
			foreach($tabarray as $k=>$v)
			{
				$this->addOption($k)->setContent($v);
			}
		}
		
	}
	public function addOption($value){
		
		if (!isset($this->m_keys[$value]))
		{
			$p = $this->add("option");
			$p["value"] = $value;
			$this->m_keys[$value] = $p;
			return $p;
		}
		return null;
	}
	public function select($value){
		if (isset($this->m_keys[$value]))
		{			
			$this->m_keys[$value]->setAttribute("selected", "selected");			
		}
	}
}

///<summary>represent horizontal menu item</summary>
final class IGKHtmlHMenuItem extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("ul");
		$this["class"] = "igk-horizontal-menu";
	}
	public function addItem($name, $link=null, $content=null){
		$li = $this->add("li");
		
		$li->setId($name);
		if ($link){
			$li->addA($link)->setContent($content);
		}
		else if ($content){
			$li->setContent($content);
		}
		return $li;
	}
}


///<summary>row item</summary>
final class IGKHtmlRowItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
		$this["class"] = "igk-row";
	}
	public function addCell(){
		$d = $this->addDiv();
		$d->setClass("igk-row-cell");
		return $d;
	}
}
final class IGKHtmlPanelItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
		$this["class"] = "igk-panel";
	}
}
final class IGKHtmlNotifyBoxItem extends IGKHtmlDiv
{
	private $m_type;
	public function __construct($type=null){
		parent::__construct();
		$this["class"] = "igk-notify-box";
		 if ($type)
			$this->setType($type);
	}	
	public function setType($type)
	{
		if ($this->m_type)
			$this->setClass("+igk-notify-".$this->m_type);
		$this->setClass("+igk-notify-".$type);
		$this->m_type = $type;
		return $this;
	}
}


final class IGKHtmlContainerItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
		$this["class"] = "igk-container";
	}	
}
final class IGKHtmlResponseNodeItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
		$this["class"] = "igk-response";
	}	
}

final class IGKHtmlDataEntryItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
	}	
	public function Render($options = null)
	{
		return parent::innerHTML($options);
	}
	public function LoadData($r, $visibleName=null){
		if ($r==null)
			return;
		if (method_exists(get_class($r), "getRows"))
		{
			foreach($r->Rows as $k=>$v)
			{
				$i = $this->add("item");
				$i->setAttributes($v);
				if ($visibleName)
					$i->Content = $v->$visibleName;
			}
		}
		else{
			$i = $this->add("item");
			$i->setAttributes($r);
			if ($visibleName)
				$i->Content = $v->$visibleName;
			
		}
	}
}
final class IGKHtmlXmlViewerItem extends IGKHtmlDiv
{
	public function __construct(){
		parent::__construct();
		$this["class"] = "igk-xml-viewer";
	}	
	public function Load($content){		
		if (empty($content))
			return ;
		$r = igk_getv(IGKHtmlReader::Load($content)->Childs,0);		
		if ($r)
		{
			$c = $this->loadItem($r, $this);			
		}
	}
	private function __renderDepth($target, $depth){
		if ($depth>0)
		{
			for($i = 0 ; $i< $depth; $i++)
			{
				$target->add("span")->setClass("t")->addSpace();
			}
		}
	}
	public function loadItem($r, $target, $depth=0)
	{
		$this->__renderDepth($target, $depth);
		
		$target->add("span")->setClass("s")->Content = "&lt;".$r->TagName;		
		
		//render attribute
		if ($r->HasAttributes)	
		{
			
			foreach($r->Attributes->ToArray() as $k=>$v)
			{
				$target->addSpace();
				$target->add("span")->setClass("attr")->Content = $k;
				$target->add("span")->setClass("o")->Content = "=";
				$target->add("span")->setClass("attrv")->Content = "\"".IGKHtmlUtils::GetValue($v)."\"";
			}
		}		
		if ($r->HasChilds)
		{
			
			$target->add("span")->setClass("s")->Content = "&gt;";
			
			foreach($r->Childs as $k=>$v){
				$target->addBr();
				switch($v->NodeType)
				{
					case IGKXMLNodeType::COMMENT:						
						$target->add("span")->setClass("c")->Content = "&lt;!--".IGKHtmlUtils::GetValue($v->Content)."--&gt;";						
						break;
					case IGKXMLNodeType::TEXT:
						$target->add("span")->setClass("tx")->Content = IGKHtmlUtils::GetValue($v->Content);
					break;
					default:
						$c = $this->loadItem($v, $this,$depth+1);
					break;
				}
			}
			$target->addBr();
			$this->__renderDepth($target, $depth);
			$target->add("span")->setClass("e")->Content = "&lt;/".$r->TagName."&gt;";
		}
		else{
			$target->add("span")->setClass("s")->Content = "/&gt;";
		}
	}
}

final class IGKHtmlAJXViewItem extends IGKHtmlDiv
{
	private $m_uri;
	private $m_script;
	private $m_scriptfunction;
	
	public function getUri(){return $this->m_uri;}
	public function setUri($uri){$this->m_uri = $uri; return $this;}
	public function getScript(){return $this->m_scriptfunction;}
	public function setScript($script){$this->m_scriptfunction = $script; return $this;}
	
	public function __construct(){
		
		parent::__construct("div");			
		$this->m_script = $this->addScript();
	}
	public function Render($options = null){
	
		if (!empty($this->m_uri))
		{
			$expr = "";
			if ($this->m_scriptfunction){
				$expr = ", function(xhr) {{{$this->m_scriptfunction}}}";
			}
			$this->m_script->Content = "\$ns_igk.winui.ajxview.init('{$this->m_uri}' $expr);";
		}
		else
			return IGK_STR_EMPTY;
		return parent::Render($options);
	}
	
}
final class IGKHtmlTargetValue extends IGKObject implements IIGKHtmlGetValue
{
	private $m_target;
	public function setTarget($d){
		$this->m_target = $d;
	}
	public function __construct($d){
		$this->m_target = $d;
	}
	public function getValue(){//get target value
		return IGKString::Format("#{1}", $this->m_target["id"]);
	}
}
final class IGKHtmlToggleButtonItem extends IGKHtmlItem
{
	public function getClassProperty(){
		return $this["igk-toggle-class"];
	}
	public function setClassProperty($value){
		return $this["igk-toggle-class"] = $value;
	}
	public function getTarget(){
		return $this["igk-toggle-target"];
	}
	public function setTarget($target){
		if ($target==null)
		{
			$this["igk-toggle-target"] = null;
			return;
		}
		if (is_string($target)){
			$this["igk-toggle-target"] = $target;
		}
		else {
			$h = $this["igk-toggle-target"];
			if (is_object($h) && get_class($h) == "IGKHtmlTargetValue")
			{
				$h->setTarget($target);
			}
			else 
				$this["igk-toggle-target"] = new IGKHtmlTargetValue($target);
		}
	}
	public function __construct(){
		parent::__construct("button");
		$this["class"] = "igk-toggle-button";		
		$this["igk-toggle-button"] = true;
		$this["igk-toggle-state"] = "collapse";
	}
	public function addBar($c=1){

		for($i=0; $i<$c;$i++)
			$this->add("span")->setClass("igk-iconbar");
	}
}

final class IGKHtmlTopNavBarItem extends IGKHtmlItem
{
	public function __construct(){
		parent::__construct("div");
		$this["igk-top-nav-bar"] = "1";
		$this["class"]="posfix fitw loc_t loc_l igk-nav-bar";
	}
	
}

//
final class IGKHtmlPaginationItem extends IGKHtmlItem
{
	var $CurrentPage;
	var $MaxPage;
	var $Offset;
	var $NextUri;
	var $PrevUri;
	private $m_first;
	private $m_last;
	
	public function SetUp($max, $current, $visible, $uri, $shift=0, $tag='form')
	{		
		$this->CurrentPage = $current;
		$this->MaxPage = $max;
		
		if ($current >= $visible){
			$r = (int) round($current % $visible);		
			$shift = $visible * (int)floor($current/$visible);		
			$visible = min($max, $shift+$visible);
		}
			
		for($i = $shift; $i < $visible; $i++)
		{
			$p = $this->addPage($i+1, "javascript: ns_igk.ajx.post('".$uri."&page=".$i."', null, ns_igk.ajx.getResponseNodeFunction(this, '{$tag}') ); return false;");
			if ($i == $current)
			{
				$p["class"] = "igk-active";
			}
		}
	}
	public function __construct(){
		parent::__construct("div");
		$this["class"]="igk-pagination";
		$this->Offset = 10;
		
		$b = $this->add("li");
		$b->addA("")->Content = "&laquo;";
		$b->setIndex(-0x0FFF);
		
		$this->m_first = $b;
		
		$b = $this->add("li");
		$b->setIndex(0xFFFF);
		$b->addA("")->Content = "&raquo;";
		$this->m_last = $b;
	}
	public function addPage($index, $uri){
		$li = $this->add("li");
		$li->addA($uri)->setContent( $index);
		return $li;
	}
	public function Render($options=null){		
		$r = parent::Render($options);
		return $r;
	}
	public function flush(){//generate properties
		if ($this->CurrentPage==0)
			$this->m_first->setClass("igk-inactive");
		else{
			$h = $this->m_first->getChildAtIndex(0);
			$h["href"] = $this->PrevUri;
		}
		if ($this->CurrentPage >= ($this->MaxPage-1)){
			$this->m_last->setClass("igk-inactive");
		}
		else{
			$h = $this->m_last->getChildAtIndex(0);
			$h["href"] = $this->NextUri;
		}
	}
}

final class IGKHtmlGroupControlItem extends IGKHtmlItem{
	public function __construct($name=null){
		parent::__construct("div");
		$this["class"] = "igk-form-group";
	}
}
final class IGKHtmlBreadCrumbsItem extends IGKHtmlItem{
	public function __construct(){
		parent::__construct("ol");
		$this["class"] = "igk-breadcrumbs";
	}
	public function addItem($uri, $content){		
		$li = $this->add("li");
		$li->addA($uri)->Content = $content;
		return $li;
	}
}
//used to render exposed items
final class IGKHtmlExpoItem extends IGKHtmlItem{
	public function __construct(){
		parent::__construct("span");
		$this["class"] = "igk-expo";
	}
}
//used to render progress bar items
final class IGKHtmlProgressBarItem extends IGKHtmlItem{
	private $m_cur;
	public function __construct(){
		parent::__construct("div");
		$this["class"] = "igk-progressbar";
		//define cursor
		$this->m_cur = $this->addDiv()->setClass("igk-progressbar-cur igk-progress-0");
		
	}
}
final class IGKHtmlClearTabItem extends IGKHtmlItem{
	public function __construct(){
		parent::__construct("div");
		$this["class"] = "igk-cleartab";
	}
}
abstract class IGKHtmlWebMasterNodeBase extends IGKHtmlItem{
	public function getIsVisible(){
		 return IGKApp::getInstance()->IsSupportViewMode(IGKViewMode::WEBMASTER);
	}
	public function __construct($tagname){
		parent::__construct($tagname);
	}
	public function Render($options=null){
		if (!$this->getIsVisible()){
			return null;
		}
		return parent::Render($options);
	}
}
//node that will be only render on web master node
class IGKHtmlWebMasterNodeItem extends IGKHtmlWebMasterNodeBase{
	
	public function __construct(){
		parent::__construct("div");
		$this["class"] = "igk-webmasternode";
	}
	
}
//********************************************************
// BINDING
//********************************************************
//node that will be only render on web master node
class IGKHtmlBindDataNodeItem extends IGKHtmlItem{
	private $m_File;
	private $m_Ctrl;
	private $m_Row;
	public function getCtrl(){ return $this->m_Ctrl; }
	public function getFile(){ return $this->m_File; }
	public function getRow(){ return $this->m_Row; }
	
	public function setCtrl($value){ $this->m_Ctrl= $value; }
	public function setFile($value){ $this->m_File= $value; }
	public function setRow($value){  $this->m_Row = $value; }
	
	
	
	public function __construct(){
		parent::__construct("div");		
	}
	public function Render($options=null){	
		$this->ClearChilds();	
		igk_html_binddata($this->Ctrl, $this, $this->File, $this->Row, false);				
		return parent::Render($options);
	}
	public function initProperties($t){
		foreach($t as $k=>$v){
			$this->$k = $v;
		}
	}
}

abstract class IGKHtmlComponentNodeItem extends IGKHtmlItem
{
	private $m_controller;
	public function getController(){
		return $this->m_controller;
	}
	public function __construct($tagname){
		$this->m_controller = igk_getctrl(IGK_COMPONENT_MANAGER_CTRL, true);
		parent::__construct($tagname);
		$this->m_controller->Register($this);
	}
	public function Dispose(){
		if ($this->m_controller !=null){
			$this->m_controller->Unregister($this);
			$this->m_controller = null;			
		}		
	}
	public function setParentNode($n, $from=null)
	{		
		if (($n == null) && ($from == "ClearChilds"))
		{			
			$this->Dispose();
			unset($this);
			return;
		}
		return parent::setParentNode($n, $from);
	}
}

class IGKHtmlBindDataAJXNodeItem extends IGKHtmlComponentNodeItem
{
	var $Ctrl;
	var $Article;
	var $Row;

	public function __construct(){
		$this->m_controller = igk_getctrl(IGK_COMPONENT_MANAGER_CTRL, true);
		parent::__construct("div");
		$this->m_controller->Register($this);
	}
	public function invokeUri(){		
		$d = IGKHtmlItem::CreateWebNode("div");
		igk_html_binddata($this->Ctrl, $d , $this->Article, $this->Row);
		$d->RenderAJX();
		igk_exit();
	}
	public function getCanAddChild(){
		return false;
	}
	public function Render($options =null){
		$this["igk-js-init-uri"] =  $this->getController()->getUri("invokeUri", $this);
		return parent::Render($options);
	}
}


class IGKHtmlcellRowItem extends IGKHtmlItem{
	public function __construct(){
		parent::__construct("div");
	} 
}

final class IGKHtmlCtrlViewNodeItem extends IGKHtmlItem
{
	private $m_optionsTag;
	private $m_content;
	private $m_ctrl;
	
	public function getCtrl(){ return $this->m_ctrl; }
	public function setCtrl($value){ $this->m_ctrl = $value; }
	
	public function __construct($tagName=null){
		if ($tagName == null)
			$tagName = igk_sys_getconfig("app_default_controller_tag_name", "div");
		
		parent::__construct($tagName);	
		$this->m_content = IGKHtmlItem::CreateWebNode("div");
		$this->m_optionsTag = new IGKHtmlWebMasterNodeItem();
		$this->m_optionsTag->setClass("igk-ctrl-view-node-options");
		parent::add($this->m_optionsTag);
		parent::add($this->m_content);
		
	}
	public function attachChild($child){
		$this->m_content->attachChild($child);
	}
	public function detachChild($child){
	$this->	m_content->detachChild($child);
	}
	public function ClearChilds(){//override clear content child
		$this->m_content->ClearChilds();
	}
	public function add($nameorchilds, $attributes=null, $index=null){
		return $this->m_content->add($nameorchilds, $attributes, $index);
	}
	public function remove($childs){
		$this->m_content->remove($childs);
	}
	protected function innerHTML(& $options=null){
		$o = "";
		$o .= $this->m_content->getinnerHTML($options);
		if ($this->m_optionsTag->getIsVisible()){
			$o .= $this->m_optionsTag->getinnnerHTML($options);
		}
		return $o;
	}
}

final class IGKHtmlActionBarItem extends IGKHtmlItem
{
	public function __construct(){		
		parent::__construct("div");	
		$this->setClass("+igk-action-bar");
	}
}

final class IGKHtmlLinkBtnItem extends IGKHtmlItem
{
	private $m_img;
	private $m_w;
	private $m_h;
	private $m_img_src;
	public function getHref(){ return $this["href"]; }
	public function setHref($v){  $this["href"] = $v; }
	public function getWidth(){ return $this->m_w; }
	public function setWidth($v){  $this->m_w= $v; }
	public function getHeight(){ return $this->m_h; }
	public function setHeight($v){  $this->m_h = $v; }
	
	public function getImgSrc(){ return $this->m_img_src; }
	public function setImgSrc($v){  $this->m_img_src = $v; }
	
	public function __construct($tagName=null){		
		parent::__construct("a");	
		$this->m_img = parent::add("img");
	}
	public function add($a,$n=null,$v=null){
		return false;
	}
	protected function  innerHTML(&$options = null){
		
		$this->setStyle("width: ".$this->m_w."; height: ".$this->m_h.";");
		$this->m_img["src"] = $this->m_img_src;
		$this->m_img["width"]  = $this->m_w;
		$this->m_img["height"]  = $this->m_h;
		return parent::innerHTML($options);
	}
}

final class IGKHtmlArticleConfigNode extends IGKHtmlItem{
	private $m_target;
	private $m_ctrl;
	private $m_filename;
	
	public function __construct($ctrl=null, $target=null, $filename=null){
		
		parent::__construct("div");
		$this->m_filename = $filename;
		$this->m_target = $target;
		$this->m_ctrl = $ctrl;
		$f = $filename;
		
		$this["class"]="igk-article-options";
		$this["igk-article-options"] = "true";
		
		$config = igk_getctrl(IGK_CA_CTRL);
		if ($config)
		{
		IGKHtmlUtils::AddImgLnk($this, igk_js_post_frame($config->getUri("ca_edit_article_ajx&navigate=1&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($f)), $ctrl), "edit");
		$s = IGKHtmlUtils::AddImgLnk($this, igk_js_post_frame($config->getUri("ca_edit_articlewtiny_f_ajx&navigate=1&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($f)), $ctrl), "tiny");
		
		// if($ctrl->App->CurrentPageFolder != IGK_CONFIG_PAGEFOLDER)
		// {
			IGKHtmlUtils::AddImgLnk($this, igk_js_post_frame($config->getUri("ca_add_article_frame_ajx&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($f)), $ctrl), "add");
			if (file_exists($f)){
				IGKHtmlUtils::AddImgLnk($this, igk_js_post_frame($config->getUri("ca_drop_article_ajx&navigate=1&ctrlid=".$ctrl->Name."&n=".base64_encode(basename($f)))),"drop")->img["alt"]="droparticle";
			}
		}
		else{
			$this->Content = "no config article found";
		}
		// }
		//add
		$target->add($this);
		//igk_wln("create article +".$this->getChildCount());
		$this->setIndex(-1000);
	}
	public function getIsVisible(){	
		return parent::getIsVisible() && IGKApp::getInstance()->IsSupportViewMode(IGKViewMode::WEBMASTER);
	}
	public function innerHTML(&$options =null){
		return parent::innerHTML($options);
	}
}

final class IGKHtmlRollOwnerItem extends IGKHtmlItem
{
	private $m_content;
	private $m_rollin;
	
	public function getRoll(){
		return $this->m_rollin;
	}
	public function __construct(){		
		parent::__construct("div");
		$this->setClass("igk-roll-owner");		
		$this->m_rollin = parent::add("div")->setClass("igk-roll-in");
		$this->m_content = parent::add("div");
	}
	public function ClearChilds(){//override clear content child
		$this->m_content->ClearChilds();
	}
	public function add($s,$t=null,$b=null){
		return $this->m_content->add($s,$t,$b);
	}
	public function getContent(){
		return $this->m_content->Content;
	}
	public function setContent($value){
		$this->m_content->setContent($value);
		return $this;
	}
	public function innerHTML(& $options = null ){
		$o  = "";
		$o .= $this->m_rollin->Render($options);
		$o .= $this->m_content->Render($options);
		return $o;
	}
}


final class IGKHtmlTouchRollOwnerItem extends IGKHtmlItem
{
	private $m_content;
	private $m_rollin;
	
	public function getRoll(){
		return $this->m_rollin;
	}
	public function __construct(){		
		parent::__construct("div");
		$this->setClass("igk-touch-roll-owner");		
		$this->m_rollin = parent::add("div")->setClass("igk-roll-in");
		$this->m_content = parent::add("div");
	}
	public function ClearChilds(){//override clear content child
		$this->m_content->ClearChilds();
	}
	public function add($s,$t=null,$b=null){
		return $this->m_content->add($s,$t,$b);
	}
	public function getContent(){
		return $this->m_content->Content;
	}
	public function setContent($value){
		$this->m_content->setContent($value);
		return $this;
	}
	public function innerHTML(& $options = null ){
		$o  = "";
		$o .= $this->m_rollin->Render($options);
		$o .= $this->m_content->Render($options);
		return $o;
	}
}


final class IGKHtmlLabelInputItem extends IGKHtmlItem
{
	private $m_lb;
	private $m_input;
	public function __construct(){
		parent::__construct("div");		
		$this->m_lb = parent::add("label");
		$this->m_input = parent::add("input");
		$this->m_input->setClass("igk-form-control");
	}
	public function setId($id){
		$this->m_input->setId($id);
		$this->m_lb["for"] = $id;
		$this->m_lb->Content = R::ngets("lb.".$id);
	}
	public function setvalue($v){
		$this->m_input["value"] = $v;		
	}
	public function settype($v){
		$this->m_input["type"] = $v;
	}
	
}

///<summary>center cellbox</div>
final class IGKHtmlCenterBoxItem extends IGKHtmlItem
{
	private $m_c;
	
	public function __construct(){		
		parent::__construct("div");
		$this->setClass("igk-centerbox disptable fitw");		
		//$this->m_c = IGKHtmlItem::CreateWebNode("div");
		$this->m_c = parent::add("div");
		$this->m_c->setClass("disptabc alignc alignm");
		$this->m_c->setParentHost($this);
		
	}
	public function ClearChilds(){//override clear content child
		$this->m_c->ClearChilds();
	}
	public function add($s,$t=null,$b=null){
		return $this->m_c->add($s,$t,$b);
	}
	public function getContent(){
		return $this->m_c->Content;
	}
	public function setContent($value){
		$this->m_c->setContent($value);
		return $this;
	}
	public function innerHTML(& $options = null ){
		return $this->m_c->Render($options);
	}
}
//
final class IGKHtmlHSepItem extends IGKHtmlSeparatorItem
{
	public function __construct(){	
		parent::__construct();
	}
}

final class IGKHtmlFixedActionBarItem extends IGKHtmlItem
{
	public function __construct(){		
		parent::__construct("div");
		$this->setClass("igk-fixed-action-bar");
		$this->setAttribute("igk-fix-loc-scroll-width",1);
		$this->m_c = parent::add("div");
		$this->m_c->setClass("disptabc alignc alignm")->setStyle("border:1px solid black");		
	}
	public function getTargetId(){
		return $this["igk-fixed-action-bar-target"] ;
	}
	public function setTargetId($v){//value is a value expression
		$this["igk-fixed-action-bar-target"]  = $v;
		return $this;
	}
}
//required system files
include_once("igk_api.php");
//include_once("igk_jquery.php");
//include_once("igk_bootstrap.php");

// include extensions	
include_once("igk_extensions.phtml");
?>