<?php

final class IGKWebPageMailCtrl extends IGKConfigCtrlBase
{
	public function getConfigPage(){ return "mailpages"; }
	
	public function View(){
		parent::View();
		if (!$this->IsVisible)return;
		
		$t = $this->TargetNode;
		igk_add_title($t, "title.mailsystem");
		$t->addHSep();
		
		$frm = $this->TargetNode->addDiv()->addForm();
		$tab = $frm->addDiv()->addTable();
		$tr = $tab->add("tr");
		HtmlUtils::AddToggleAllCheckboxTh($tr);
		$tr->add("th")->Content = R::ngets("clName");
		$tr->add("th",array("class"=>"tab_btn"))->Content = IGK_HTML_SPACE;
		$tr->add("th",array("class"=>"tab_btn"))->Content = IGK_HTML_SPACE;
		
		$ctrl = igk_getctrl(IGK_CA_CTRL);
		
		
		foreach($this->getAllArticles() as $k=>$v)
		{
			$tr = $tab->add("tr");
			$tr->add("td")->addInput("clArticles[]", "checkbox", basename($v));
			$tr->add("td")->Content = basename($v);
			HtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($ctrl->getUri("ca_edit_article_ajx&ctrlid=".$this->Name."&n=".basename($v)), $this), "edit");
			HtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($ctrl->getUri("ca_edit_articlewtiny_f_ajx&ctrlid=".$this->Name."&n=".basename($v)), $this), "tiny");
			
		}
		igk_html_toggle_class($tab);
		$frm->addHSep();
		$d = $frm->addDiv();
		HtmlUtils::AddBtnLnk($d, R::ngets("btn.sendmail") , $this->getURI(""));
		
	}
	public function showConfig(){
		parent::showConfig();
	}
	
	public function getConfirmationMail(){
	}
	
	public function getIsSystemController(){return true;} 
}
?>