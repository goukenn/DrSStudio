<?php
//controller code class declaration
//file is a part of the controller tab list
abstract class PageZoneCtrl extends IGKCtrlTypeBase
{
	private $m_viewZone;
	public function getName(){return get_class($this);}
	public function getViewZone(){return $this->m_viewZone;}
	public function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}
	public static function GetAdditionalConfigInfo()
	{
		return null;
	}
	//@@@ init target node
	public function initTargetNode(){
		$node =  parent::initTargetNode();
		$node["class"]="alignc alignt dispb";
		$this->m_viewZone = $node->addDiv();
		$this->m_viewZone["class"]="page_zone";
		return $node;
	}
	public function getCanAddChild(){
		return true;
	}
	public function View()
	{
		parent::View();
	}
	protected function _showChild()
	{	
	
		//maintain the view
		igk_html_add($this->m_viewZone,$this->TargetNode);
		if ($this->hasChild){			
			foreach($this->getChilds() as $k=>$v)
			{			
				if ($v->isVisible)
				{
					igk_html_add($v->TargetNode, $this->m_viewZone);
					$v->View();
				}
				else {
					igk_html_rm($v->TargetNode);
				}
			}
		}
	}

}
?>