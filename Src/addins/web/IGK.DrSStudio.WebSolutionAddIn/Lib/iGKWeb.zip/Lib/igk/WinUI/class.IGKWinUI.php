<?php
//UTILITY FUNCTION

//----------------------------------------------------------------
//represent a base winui control
//----------------------------------------------------------------
class IGKWinUIControl extends HtmlItem
{
	private $m_id;
	
	public function Render($options = null)
	{
		parent::Render($options);
	}
	public function __construct($tagname)
	{
		$this->m_id = igk_new_id();
		parent::__construct($tagname);
	}
	
}

// CONTROL
//represent a winUI Control
// class IGKWinUIControl extends HtmlItem
// {
	// private static $sm_controls;
	
	
	// public function __construct()
	// {
		// parent::__construct("div");
		
	// }
	// public static function initControl($control)
	// {
		// if ($control == null)
			// return;
		// $id = igk_new_id();
		// $control["id"] = $id;
		
		// if (self::$sm_controls ==null)
		// {
			// self::$sm_controls = array();
		// }
		// self::$sm_controls[$id] = $control;
	// }
// }
?>