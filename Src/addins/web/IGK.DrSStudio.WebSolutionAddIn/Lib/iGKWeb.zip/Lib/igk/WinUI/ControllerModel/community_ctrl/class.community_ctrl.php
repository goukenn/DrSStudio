<?php
//controller code class declaration
//file is a part of the controller tab list
abstract class CommunityCtrl extends IGKCtrlTypeBase {
	public function getName(){return get_class($this);}
	public function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}
	//@@@ init target node
	public function initTargetNode(){
		$node =  parent::initTargetNode();
		return $node;
	}	
	public function getCanAddChild(){
		return false;
	}
	public function getCanEditDataTableInfo()
	{
		return false;
	}
	public function getDataTableName(){
		return "tbigk_community";
	}
	public function getDataTableInfo()
	{
		return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clName", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>25, "clIsUniqueColumnMember"=>true  )),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clLink", IGK_FD_TYPE=>"Text"))
			);
	}
	protected function getConfigFile()
	{
		$s = dirname(__FILE__)."/".IGK_DATA_FOLDER."/".IGK_CTRL_CONF_FILE;	
		return igk_io_getdir($s);		
	}
	protected function getDBConfigFile()
	{
		return igk_io_getdir(dirname(__FILE__)."/".IGK_DATA_FOLDER."/".IGK_CTRL_DBCONF_FILE);
	}	
	//----------------------------------------
	//Please Enter your code declaration here
	//----------------------------------------
	//@@@ parent view control
	public function View(){
			$this->TargetNode->ClearChilds();
			$f = $this->_getViewfile("default");
			extract($this->getSystemVars());
			if (file_exists($f))
				include($f);
			$ul = $t->addDiv()->add("ul");
			//try{
				$e = $this->getDbEntries();
				if ($e)
				{
					foreach($e->Rows as $k=>$v)
					{
						$ul->add("li")->add("a", array("href"=>$v->clLink, "target"=>"_blank"))->add("img", array("src"=>"?vimg=com_".$v->clName));
					}
				}
			// }
			// catch(Exception $ex){
				//igk_wln("error = ".$ex);
			// }
			
			
	}
	
}
?>