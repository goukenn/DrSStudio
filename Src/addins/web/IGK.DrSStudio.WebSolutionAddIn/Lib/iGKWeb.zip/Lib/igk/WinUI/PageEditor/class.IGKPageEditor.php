<?php
/*
*
*class.IGKPageEditor.php
*used to manage page in presentation view. by edititin adding article an so on
*/
class IGKPageEditor extends IGKControllerBase
{

	public function __construct(){
		parent::__construct();
	}
	public function InitComplete(){
		parent::InitComplete();
		$c = $this->TargetNode["class"]->getValue();
		igk_css_regclass($c, "{sys:posr} top:32px; margin-bottom: 48px; min-height:260px; background-color:#4C4C4C; color:white;");		
		
	}
	
	public function View(){
		parent::View();		
		
		if ($this->IsVisible)
		{
			extract($this->getSystemVars());
			igk_html_add($this->TargetNode, $sessionctrl->TargetNode);
			$this->TargetNode->setIndex(3000);
		}
		else
			igk_html_rm($this->TargetNode);
		
	}
	//is system controller
	public function getIsSystemController(){return true; }
	
	public function getIsVisible(){
		return true; 
	}
}
?>