<?php
//error
require_once("igk_framework.php");

$dir = igk_getv($_REQUEST, "folder");
// igk_wln("page not found");
$file =dirname(__FILE__)."/../../index.php";
$args = igk_getquery_args(igk_getv($_SERVER,"REDIRECT_QUERY_STRING"));
$_REQUEST = array_merge($_REQUEST, $args);
if (file_exists($file))
{

	chdir(dirname($file));	
	//transform to good status
	//header("Location: ./",TRUE,200);
	
	header("Status: 200 OK"); // for fast cgi
	header($_SERVER['SERVER_PROTOCOL'] . " 200 OK");
	
	//header("Location: ./",TRUE, 301);
	//found
	//header("Location: ./",TRUE, 302);
	include_once($file);
	$app = igk::getInstance();
	
	
	if ($dir)
	{	
		header("Location: ".igk_io_currentRelativeUri($dir));
		exit;
	}	
	$v_ruri = igk_io_baseRequestUri();
	if (IGKString::EndWith($v_ruri , '/'))
	{
		$v_buri  = igk_str_rm_last($v_ruri,'/');
		header("Location: ../".$v_buri);
		exit;
	}
	$v_buri  = igk_str_rm_last($v_ruri,'/');	
	igk::setErrorQuery(true, $v_buri);	
	
	$c = explode("/", $v_buri);
    
	$page = "default";
	$lang = "fr";
	$actionctrl = igk_getctrl(IGK_SYSACTION_CTRL);
	switch(igk_count($c))
	{
		case 1:
			$ts = explode("?",$c[0]);
			
			if ((igk_count($ts) == 1 ) && $actionctrl->contains($c[0]))
			{			
				header("Status: 200 OK"); // for fast cgi
				header($_SERVER['SERVER_PROTOCOL'] . " 200 OK");
				$actionctrl->invokeUri($c[0]);				
				return;
			}
			else
			{
				header("Status: 200 OK"); // for fast cgi
				header($_SERVER['SERVER_PROTOCOL'] . " 200 OK");
				header("Location: ./?".$ts[1]."&c=".igk_count($ts)."&uri=".$v_ruri);
				exit;
			}
			break;
		default:
			$p = igk_array_last($c);
			if ($actionctrl->contains($p))
			{
				//$actionctrl->invokeUri($p);
				igk_navtocurrent();
				exit;
			}
		break;
	}
	
	//Requested URI ERROR 
	if (!$app->Session->URI_ERROR)
		$app->Session->URI_ERROR = array();
	$app->Session->URI_ERROR[] = "URI : ".igk_getv($_SERVER,"REDIRECT_QUERY_STRING") . " : ".$v_ruri;
	
	igk_getctrl(IGK_ERROR_CTRL)->addError($v_ruri);
	
}
?>