<?php
//controller code class declaration
//file is a part of the controller tab list
abstract class HorizontalNavigatorCtrl extends IGKCtrlTypeBase {
	public function getName(){return get_class($this);}
	public function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}
	//@@@ init target node
	public function initTargetNode(){
		$node =  parent::initTargetNode();
		return $node;
	}	
	public function getcanAddChild(){
		return false;
	}
	public static function GetAdditionalDefaultViewContent(){
		return null;
	}
	public static function GetAdditionalConfigInfo()
	{
		return array("clShowBullet"=> new IGKAdditionCtrlInfo("bool", true));
	}
	//----------------------------------------
	//Please Enter your code declaration here
	//----------------------------------------
	//@@@ parent view control
	public function View(){
		
		$this->TargetNode->ClearChilds();
		$c = new IGKJS_horizontalPane($this->TargetNode);
		$this->buildPage($c);
		$c->AnimInterval  = igk_get_uvar(strtoupper($this->Name."_NAV_ANIMFREQUENCY"), 20, true,"rate time in (ms > 0)");
		$c->AnimDuration  = igk_get_uvar(strtoupper($this->Name."_NAV_ANIMDURATION"), 1000, true, "time in (ms > 0)");
		$c->IsAutoAnimate = igk_get_uvar(strtoupper($this->Name."_NAV_AUTOANIMATE"), 1, true, "0 or 1");
		$c->AnimPeriod    = igk_get_uvar(strtoupper($this->Name."_NAV_AUTOPERIOD"), 10000, true, "");
		$c->AnimType      = igk_get_uvar(strtoupper($this->Name."_NAV_ANIMTYPE"), "translation", true, "translation,fade,rotation");
		$c->flush();
		$this->_incViewfile("default");
		
	}
	protected function buildPage($c)
	{		
		$t = $this->getAllArticles();
		sort($t);
		foreach($t as $k=>$v)
		{
			igk_add_article($this, basename($v), $c->addPage());
		}
	}
}
?>