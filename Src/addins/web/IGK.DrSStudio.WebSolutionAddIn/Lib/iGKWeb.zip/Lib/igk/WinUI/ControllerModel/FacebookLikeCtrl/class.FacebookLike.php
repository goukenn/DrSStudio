<?php
abstract class IGKFacebookLikeCtrl  extends IGKCtrlTypeBase
{	
	public function getcanAddChild(){
		return false;
	}
	public static function GetAdditionalConfigInfo()
	{
		return array("clFacebookUri");
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clFacebookUri"] = igk_getr("clFacebookUri");
	}
	public static function GetCtrlCategory(){
		return "COMMUNITY";
	}
	
	protected function getConfigFile()
	{
		$s = dirname(__FILE__)."/".IGK_DATA_FOLDER."/".IGK_CTRL_CONF_FILE;	
		return igk_io_getdir($s);		
	}
	protected function getDBConfigFile()
	{
		return igk_io_getdir(dirname(__FILE__)."/".IGK_DATA_FOLDER."/".IGK_CTRL_DBCONF_FILE);
	}	
	
	public function View()
	{
	
		extract($this->getSystemVars());
		$t->ClearChilds();
		$c = $t->Add("div");
$c->Content = <<<EOF
<iframe src="http://www.facebook.com/plugins/like.php?href={$this->Configs->clFacebookUri}&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
EOF;

	}
}
?>