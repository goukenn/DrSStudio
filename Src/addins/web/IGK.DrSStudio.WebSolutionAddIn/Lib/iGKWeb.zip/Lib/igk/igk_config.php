<?php

define("IGK_ENCODINGTYPE", "text/html; charset=utf-8");
define("IGK_SERVERNAME", "IGKDEV");

define("IGK_MAX_CONFIG_PWD_LENGHT", 4);
define("IGK_DEFAULT_FOLDER_MASK", 0755);
define("IGK_DEFAULT_FILE_MASK", 0755);
define("IGK_LF","\n");//line field
define("IGK_DATA_FOLDER", "Data"); //data folder
define("IGK_CONF_DATA", IGK_DATA_FOLDER."/configs.csv"); //config data file
define("IGK_CHANGE_CONF_DATA",IGK_DATA_FOLDER."/changes.csv");
define("IGK_UPLOAD_DATA", "Data/upload.csv"); //upload data file
define("IGK_TEMPLATES_FOLDER", "Data/Templates");
define("IGK_LAYOUT_FOLDER", "R/Layouts");

define("IGK_MENU_CONF_DATA",IGK_DATA_FOLDER."/menuconf.csv");
define("IGK_MENUS_REGEX", "/menu(?P<name>(.)+)conf.csv/i");
define("IGK_ISIDENTIFIER_REGEX", "/^([a-z]|[_])([a-z0-9_]*)$/i");

define("IGK_CONFIG_MODE", "Configs");
define("IGK_CONFIG_PAGEFOLDER", "Configs");

define("IGK_HOME_PAGEFOLDER","home");
define("IGK_HOME_PAGE","home");
define("IGK_FIELD_PREFIX","cl");
define("IGK_TABLE_PREFIX","tb");

define("IGK_JS_VOID", "javascript:void();");

define("IGK_FD_ID", IGK_FIELD_PREFIX."Id");
define("IGK_FD_NAME", IGK_FIELD_PREFIX."Name");
define("IGK_FD_TYPELEN", IGK_FIELD_PREFIX."TypeLength");
define("IGK_FD_TYPE", IGK_FIELD_PREFIX."Type");

define("IGK_CTRLBASECLASS", "IGKControllerBase");
define("IGK_CTRLWEBPAGEBASECLASS", "IGKDefaultPageCtrl");

define("IGK_CSV_SEPARATOR", "IGK_CSV_SEPARATOR");
define("IGK_CSV_SEPARATORS", ",|.|\t|;");
define("IGK_CSV_FIELD_SEPARATORS", "'|\"");
define("IGK_HTML_WHITESPACE","&nbsp;");
define("IGK_HTML_ENCTYPE","multipart/form-data");
define("IGK_MYSQL_DATAADAPTER","MySQL");
define("IGK_CSV_DATAADAPTER","CSV");

define("IGK_CTRL_CONF_FILE", "config.xml");
define("IGK_CTRL_DBCONF_FILE", "data.xml");

//----------------------------------------------------------------
// FOLDERS
//----------------------------------------------------------------
define("IGK_BACKUP_FOLDER", IGK_DATA_FOLDER."/Backup");
define("IGK_ARTICLES_FOLDER", "Articles");
define("IGK_VIEW_FOLDER", "View");
define("IGK_PAGE_FOLDER", "Pages");
define("IGK_MODS_FOLDER", "Mods");
define("IGK_RES_FOLDER", "R");
define("IGK_INC_FOLDER", "Inc");
define("IGK_LIB_FOLDER", "Lib");
define("IGK_SCRIPT_FOLDER","Scripts");
define("IGK_RES_FONTS",IGK_RES_FOLDER."/Fonts");
define("IGK_DEFAULT_THEME_FOLDER", IGK_LIB_FOLDER."/igk/Default/Themes");
define("IGK_CACHE_FOLDER", "Caches");
define("IGK_CACHE_LIBFILE", IGK_CACHE_FOLDER."/lib.files.inc");
define("IGK_CACHE_DATAFILE",IGK_DATA_FOLDER."/cache_libfile");


define("IGK_PIC_EXTENSIONS", ".png;.jpeg;.jpg;.bmp;.tiff;.gif;.ico;.ani");
define("IGK_ALLOWED_EXTENSIONS", IGK_PIC_EXTENSIONS.";.avi;.mov;.flv;");
define("IGK_HTML_SPACE", "&nbsp;");
define("IGK_DEFAULT_VIEW_FILE","default.phtml");

//controlleur names
define("IGK_MENU_CTRL", "igkmenuctrl");
define("IGK_FRAME_CTRL", "igkframedialogctrl");
define("IGK_PIC_RES_CTRL", "igkpicresctrl");
define("IGK_CONF_CTRL", "igkconfigctrl");
define("IGK_NOTIFICATION_CTRL","igknotificationctrl");
define("IGK_CHANGE_MAN_CTRL", "igkchangemanagerctrl");
define("IGK_CTRL_MANAGER", "igkctrlmanager");
define("IGK_SESSION_CTRL","sessionctrl");
define("IGK_ERROR_CTRL","errorctrl");
define("IGK_THEME_CTRL", "igkthemectrl");
define("IGK_FILE_MAN_CTRL", "igkfilemanagerctrl");
define("IGK_LANGUAGE_CTRL","igklanguagectrl");
define("IGK_PALETTE_CTRL", "igkpalettectrl");
define("IGK_USERVARS_CTRL", "igkusersvariablectrl");
define("IGK_CA_CTRL","igkcontrollerandarticlesctrl");
define("IGK_SYSACTION_CTRL", "sysuriactionctrl");
define ("IGK_LANG_CTRL", "lang");

//AJX CONSTANT
define("IGK_AJX_METHOD_SUFFIX","_ajx");
//ERROR MESSAGE


define("IGK_CONFIRM_TITLE","title.confirm");
define("IGK_PAGE_TITLE","title.default.webpage");
//QUESTION MESSAGE
define("IGK_MSG_DELETEALLFONT_QUESTION", "Msg.DeleteAllFontQuestion");
define("IGK_MSG_DELETEFILE_QUESTION","Msg.DELETEFILEQUESTION");
define("IGK_MSG_DELETEDIR_QUESTION","Msg.DELELETEDIRQUESTION");
define("IGK_MSG_DELETECTRL_QUESTION", "Msg.DELETECTRLQUESTION");
define("IGK_MSG_ALLPICS_QUESTION", "Msg.DELETEALLPICSQUESTION");
define("IGK_MSG_DELETEMENU_QUESTION", "Msg.DELETEALLMENUQUESTION");
define("IGK_DELETEALLTABLE_QUESTION", "Msg.DELETEALLTABLEQUESTION");
define("IGK_MSG_DELETEALLDATABASEBACKUP_QUESTION", "Msg.DELETEALLDATABASEBACKUPQUESTION");
define("IGK_MSG_DELETESINGLETABLE_QUESTION","Msg.DELETESINGLETABLEQUESTION");
define("IGK_MSG_DELETEABACKUPFILE_QUESTION", "Msg.DELETEABACKUPFILEQUESTION");
define("IGK_MSG_RESTOREBACKUPFILE_QUESTION", "Msg.RESTOREBACKUPFILEQUESTION");
define("IGK_MSG_DROPALL_QUESTION", "Msg.DROPALLQUESTION");
define("IGK_CONF_PAGE_TITLE", "title.CONFIGPAGE");

define("ALL_LANG","all-lang");


define ("IGK_CSS_CHILD_EXPRESSION_REGEX", "/^\s*\(:(?P<name>([a-z0-9_\-])+)\)\s*$/i");

$igk_error_codes = array(); 

if (!function_exists("igk_define_error"))
{	
	function igk_define_error($msg, $code, $msg_key=null){
		global $igk_error_codes;
		$igk_error_codes[$msg] = array("Key"=>$msg,"Code"=>$code, "Msg"=> ($msg_key==null)?str_replace("_",".", $msg):$msg_key );
		define($msg, $msg);
	}
}
function igk_error($code){
	global $igk_error_codes;
	return $igk_error_codes[$code];
}
function igk_geterror_code($code){
	global $igk_error_codes;
	return $igk_error_codes[$code]["Code"];
}
function igk_geterror_key($code){
	global $igk_error_codes;
	return $igk_error_codes[$code]["Msg"];
}
igk_define_error("IGK_ERR_USERERROR", 10400);
igk_define_error("IGK_ERR_NOUSERFOUND",igk_geterror_code(IGK_ERR_USERERROR)+1, "ERR.NoUserFOUND");
igk_define_error("IGK_ERR_PAGENULLOREMPTY", igk_geterror_code(IGK_ERR_USERERROR)+0x0002, "ERR.PAGENULLOREMPTY");
igk_define_error("IGK_ERR_LOGORPWDNOTVALID",igk_geterror_code(IGK_ERR_USERERROR)+0x0003, "ERR.LoginOrPWDNotValid");


igk_define_error("ERR_FILE_NOT_SUPPORTED",10080);
igk_define_error("ERR_SCRIPT_ERROR", 110100)


?>