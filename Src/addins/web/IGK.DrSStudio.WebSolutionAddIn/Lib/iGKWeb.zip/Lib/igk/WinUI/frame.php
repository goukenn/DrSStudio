<?php
//frame utility functions
function igk_frame_new($ctrl, $id, $closeuri=".", $target=null, $reloadcallback=null)
{
	$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame($id, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = igk::getInstance()->Doc->body;
	igk_html_add($frm,  $target);
	$frm->Script->Content = new IGKFrameScript($frm, "confirm");
	return $frm;
}

function igk_frame_confirm($ctrl, $id, $title=null, $closeuri=".", $target=null, $reloadcallback=null)
{
	$frame = igk_getctrl(IGK_FRAME_CTRL)->createFrame($id, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = igk::getInstance()->Doc->body;
	igk_html_add($frm,  $target);
	
	$frame->Title = ($title==null)? R::ngets(IGK_CONFIRM_TITLE) : $title;
	$d = $frame->Content;
	$d->ClearChilds();
	
	$igk = $ctrl->App;
	$frame->Form = $d->addForm();
	$frame->Form["action"] = $frame->closeUri;
	$frame->Form["igk-confirmframe-response-target"] = $ctrl->TargetNode["id"];
	$frame->Form->Div = $frame->Form->addDiv();
	$frame->Form->addHSep();	
	$frame->Form->addInput("confirm", "hidden",1);
	$frame->Form->addInput("frame-id", "hidden",$id);
	$frame->Form->addInput("frame-close-uri", "hidden", igk_getctrl(IGK_FRAME_CTRL)->getUri("closeFrame_ajx&navigate=false&id=".$id));
	$frame->Form->addScript()->Content ="igk.winui.framebox.init_confirm_frame(igk.getlastscript(), '".$frame->closeUri."&cancel=1"."', ".
	($igk->Session->URI_AJX_CONTEXT?'true':'false')
	.")";
	
	$canceluri = $frame->closeUri."&cancel=1";
	switch($buttonmodel){
	case 0:
		$btn = $frame->Form->addBtn("btn_yes", R::ngets("btn.yes"), "submit");			
		$btn["onclick"] = $igk->Session->URI_AJX_CONTEXT?"javascript: return IGK.winui.framebBox.btn.yes(this);":null;		
		HtmlUtils::addBtnLnk($frame->Form, R::ngets("btn.no"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close(); ");
	break;
	case 1:
		$frame->Form->addBtn("btn_ok", R::ngets("btn.ok"), "submit", array("onclick"=>$igk->Session->URI_AJX_CONTEXT?"javascript:return IGK.winui.frameBox.btn.yes(this);":null) );			
		HtmlUtils::addBtnLnk($frame->Form, R::ngets("btn.cancel"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close()" );
		break;
	}
	
	$frm->Script->Content = new IGKFrameScript($frm, "c");	
	return $frm;
}
final class IGKFrameScript implements IHtmlGetValue {
	var $owner;
	private $m_type;
	
	public function __construct($owner, $type="f"){
		$this->owner = $owner;		
		$this->m_type = $type;
	}

	public function getValue()
	{
		$n ="";
		switch($n)
		{
			case "c":
				$n = "initconfirm";
				break;
			case "f":
			default:
				$n = "init";
				break;				
		}
		return  igk_get_string_format("IGK.winui.frameBox.{$n}([[0]],[[1]]);",
		igk_getsv($this->owner->Width?'"'.$this->owner->Width.'"':null,'null'),
		igk_getsv($this->owner->Height?'"'.$this->owner->Height.'"':null,'null'));
	}
}

function igk_frame_js_postform_ref($ctrl){
	return  "javascript: return (function(q,s){ IGK.winui.frameBox.postForm(q.form, q.form.action, s); return false;})(this, '".$ctrl->TargetNode["id"]."');";
}
?>