<?php
//google Talk community type

abstract class IGKGoogleTalkCtrl extends IGKCtrlTypeBase
{
	public function getcanAddChild(){
		return false;
	}
	
	public static function GetAdditionalConfigInfo()
	{
		return array("clLink");
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clLink"] = igk_getr("clLink");
	}
	
	public function View()	
	{
		if (!$this->isVisible)
		{		
			igk_html_rm($this->TargetNode);
			return;
		}		
		$t = $this->TargetNode;		
		$t->ClearChilds();		
		$this->addGooglePlus($t);
	}
	public function addGooglePlus($target){
		$lnk = $this->app->Doc->addLink("googleplus:uri");
		$lnk["rel"] = "canonical";
		$lnk["href"] = $this->Configs->clLink;
		$src = $this->app->Doc->addScript("https://apis.google.com/js/plusone.js");
		$gdiv = $target->add("span");
		$gdiv->add("g:plusone")->addNothing();
	}
}
?>