<?php

class IGKJS_HorizontalPane extends IGKObject
{
	private $m_target;
	private $m_script;
	private $m_pageNode;
	private $m_bulletZone;
	private $m_AnimDuration;
	private $m_AnimInterval;
	private $m_IsAutoAnimate;
	private $m_AnimType; //translation or fade
	private $m_AnimPeriod;
	
	private $m_rootNode;
	
	
	public function getpageNode(){return $this->m_pageNode; }
	public function getTarget(){return $this->m_target;}
	public function getScript(){return $this->m_script; }
	public function getbulletZone(){return $this->m_bulletZone; }
	public function getAnimInterval(){return $this->m_AnimInterval; }
	public function getAnimDuration(){return $this->m_AnimDuration; }
	public function getAnimPeriod(){return $this->m_AnimPeriod;}
	public function getIsAutoAnimate(){return $this->m_IsAutoAnimate; }
	public function getAnimType() { return $this->m_AnimType;}
	public function setAnimType($value){$this->m_AnimType = $value;}
	
	public function setAnimInterval($value){ $this->m_AnimInterval = $value; }
	public function setAnimDuration($value){ $this->m_AnimDuration = $value; }
	public function setAnimPeriod($value){$this->m_AnimPeriod =$value;}
	
	public function setIsAutoAnimate($value){ $this->m_IsAutoAnimate = $value; }
	
	public function __construct($target)
	{
		$this->m_AnimDuration = 500;
		$this->m_AnimInterval = 20;
		$this->m_AnimPeriod = 5000;
		$this->m_target = $target;
		$this->m_IsAutoAnimate = true;
		$this->m_AnimType = "translation";
		//fit parent
		
		$this->m_pageNode = $target->addDiv();
		$this->m_pageNode["class"]="igk_horizontal_page_js overflow_none";				
		$this->m_pageNode["igk-control-type"]="horizontalpane_panel";
		
		
	}
	public function addPage($attribute=null)
	{
		$p = $this->m_pageNode->addDiv($attribute);		
		$p["igk-control-type"]="horizontalpane_page";
		return $p;
	}
	public function flush()
	{
	
		if ($this->m_bulletZone == null)
		{
			$this->m_bulletZone  =  $this->m_target->addDiv();	
			$this->m_bulletZone["igk-control-type"]="horizontalpane_bulletzone";
			$this->m_bulletZone["class"]="horizontalpane_bulletzone";
		}    
		
		if ($this->m_script == null)
			$this->m_script = $this->m_target->addScript();	
		$b = igk_parsebool($this->m_IsAutoAnimate);
		$this->m_script->Content = <<<EOF
igk.winui.horizontalScrollPane.init(igk.getlastscript().parentNode, {autoanimate: {$b}, animtype: '{$this->m_AnimType}', period: {$this->m_AnimPeriod}},  {duration:{$this->m_AnimDuration}, interval: {$this->m_AnimInterval}, orientation:'horizontal'});
EOF;
		
		
	}
}


?>