<?php


//STATIC METHOD START WITH CAPITAL LETTER.
//INSTANCE METHOD START WITH LOWER LETTER
//
//library
//
define("IGK_WEBFRAMEWORK", "8.6");
define("IGK_FRAMEWORK","iGKWeb");
define("IGK_AUTHOR", "C.A.D. BONDJE DOUE");
define("IGK_AUTHOR_CONTACT", "bondje.doue@igkdev.be");
define("IGK_VERSION", "8.6.0.1305");
define("IGK_RELEASE_DATE", "03/04/14");
define("IGK_COPYRIGHT", "IGKDEV &copy; 2008-2014 all rights reserved");
define("IGK_WEB_SITE", "http://www.igkdev.be");

include_once("igk_autorisation.php");
include_once("igk_config.php");
require_once("igk_gd.phtml");
require_once(dirname(__FILE__)."/../Fpdf/fpdf.php");


//------------------------------------------------------------------------
//global utility functions
//------------------------------------------------------------------------
//get regex from pattern
function igk_regex_get($pattern , $key, $value, $index = 0)
{
	$t = array();
	$c = preg_match_all($pattern, $value,$t); 
	
	if ($c>0)
	{
		if ($c==1){
		return $t[$key][0];
		}
		else{
			return $t[$index][$key];	
		}
	}
	return null;
}
///<summary>
///used to parse string value to compatible xml value.
///</summary>
function igk_parsexmlvalue($value)
{
	$value = str_replace("&", "&amp;" , $value);
	
	return $value;
}

///ssend mail to from
function igk_mail_sendmail($to, $from, $title, $message, $replyto=null)
{
	return igk_getctrl("igkmailctrl")->sendmail($from, $to, $title, $message, $replyto);
}

//@ check if the name if a valid identifier
function igk_isidentifier($name)
{
	return preg_match(IGK_ISIDENTIFIER_REGEX, $name);
}

//----------------------------------------------------
//VALIDATOR 
//----------------------------------------------------
function igk_val_init()
{
	IGKValidator::Init();
}
function igk_val_cbcss($e, $name)
{
	if ($e && isset($e[$name]))
		return "err_c";//error cibling
}

function igk_val_regParam($ctrl, $name)
{
	
	$ctrl->setParam($name.":error", igk_val_node());
	$ctrl->setParam($name.":errorcibling", igk_val_cibling());
}
function igk_val_unregParam($ctrl, $name)
{
	$ctrl->setParam($name.":error", null);
	$ctrl->setParam($name.":errorcibling",null);
}
function igk_val_cibling(){
	return IGKValidator::Cibling();
}
function igk_val_node(){
return IGKValidator::Error();
}
function igk_val_haserror(){
	return IGKValidator::Error()->HasChilds;
}
function igk_val_isStrNullOrEmpty($tname, $msg){
		if (IGKValidator::IsStringNullOrEmpty($tname)){ IGKValidator::Error()->add("li")->Content = $mg; }
}
function igk_val_ispic($type, $msg){
		if (!igk_io_fileIsPicture($type)){ IGKValidator::Error()->add("li")->Content = $msg; }
}
function igk_val_add_error($msg, $cibling=null)
{
	$li = igk_val_node()->add("li");
	$li->Content = $msg;
	IGKValidator::AddCibling($cibling);
	$li->cibling = $cibling;
	return $li;
}
function igk_val_check($callback, $object, $name, $msg)
{
	
	if (is_bool($callback))
	{
		if ($callback)
		{
			igk_val_add_error($msg, $name);			
		}
		return;
	}	
	$v = call_user_func_array(array("IGKValidator",$callback), array($object->$name));	
	if ($v)
	{
		igk_val_add_error($msg, $name);
	}
}


function igk_sort_byNodeIndex($a,$b)
{
	if ($a->TargetNode && $b->TargetNode)
	{
		$i = $a->TargetNode->Index;
		$j = $b->TargetNode->Index;
		return ($i == $j)? 0: (($i<$j) ? -1 : 1); 
	}
	return strcmp($a->Name, $b->Name);
}

function igk_add_loading_frame($t)
{
	$t->addDiv(array("class"=>"dispib"))->addScript()->Content = "igk.media.webplayer.init(igk.getParentScript(),'?vimg=waitcursor');";
}
//Comparaison func
function igk_cmp_refobj($o,$i)
{
	if (($o==null) && ($i==null))
		return true;
	if ((($o==null) && ($i!=null)) || (($o!=null) && ($i==null)) )
		return false;
	$cmp = igk_new_id();
	igk_debug_wln($cmp);
	$o->$cmp = true;
	igk_debug_wln(" : ". $o->$cmp);
	igk_debug_wln(" : ". $i->$cmp);
	$r = (!empty($i->$cmp));
	//clean up
	unset($o->$cmp);
	return $r;
}

function igk_sys_ctrl_type($ctrl)
{
	$s = get_class($ctrl);
	if (is_subclass_of($s, "IGKCtrlTypeBase"))
	{
		$t = class_parents($s);
		$ht = IGKCtrlTypeManager::GetControllerTypes();
		$ht = igk_array_key_value_toggle($ht);
		
		foreach($t as $k=>$v)
		{
			if (isset($ht[$v]))
				return $ht[$v];
		}
	}
	return "unknow";
}

function igk_sys_buildconfirm_ajx($ctrl, $id,  $uri, $callback, $message, $hiddenEntries=null)
{	
	if (igk_qr_confirm())
	{						
		$ctrl->call($callback);		
	}
	else{
		$frame = igk_add_confirm_frame($ctrl,$id, $uri);
		$frame->Form->Div->Content = $message;
		if ($hiddenEntries)
		{
			foreach($hiddenEntries as $k=>$v)
			{
				$frame->Form->addInput($k, "hidden",$v);	
			}
		}
		igk_wl($frame->Render());
	}	
}
//return that requrest in on ajx context. to enable ajx context function name must end with "_ajx" or the requested uri must add a ajx=1 variable
function igk_sys_isAJX()
{
	return igk::getInstance()->Session->URI_AJX_CONTEXT;
}
function igk_sys_ispagesupported($key)
{
	$tab = igk_getctrl(IGK_MENU_CTRL)->getPageList();
	$tab = igk_array_tokeys($tab);	
	return isset($tab[$key]);	
}
function igk_sys_islanguagesupported($key)
{
 	$tab = igk_getctrl(IGK_LANGUAGE_CTRL)->Languages;
	$tab = igk_array_tokeys($tab);	
	return isset($tab[$key]);
}

//------------------------------------------------------------------------------------------------------------------------------
//javascript utility functions
//------------------------------------------------------------------------------------------------------------------------------

//<summary>used to post frame to uri. used in href of <a></a> element </summary>
///<remark>if frame need to be shown used ajax mecanism</remark>
//@uri: to post
//@ctrl: controller to where response must be send in ajax syntax
function igk_js_ctrl_posturi($ctrl, $uri)
{
	$q = "";
	if ($ctrl!=null)
	{
		$q = ",'".$ctrl->TargetNode["id"]."'";
	}
	else
		$q = ",null";	
	return "javascript:window.igk.ctrl.frames.postframe(this, '".$ctrl->getUri($uri)."&ajx=1'".$q.");";
}

//<summary>javascript get post frame uri.</summary>
//post une frame avec un mécanism de post. tout ce fait dans une procedure ajax.
//@@@<summary>used to get javascript uri component to post frame on the javascript context</summary>
function igk_js_post_frame($uri, $ctrl =null, $global=true)
{
	return "javascript:".igk_js_post_frame_cmd($uri, $ctrl, $global);
}
function igk_js_post_frame_cmd($uri, $ctrl =null, $global=true)
{
	$q = "";
	if ($ctrl!=null)
	{
		$q = ",'".$ctrl->TargetNode["id"]."'";
	}
	else
		$q = ",null";
	if ($global)
		$q .=",true";
	else 
		$q .=",false";
	return "window.igk.ctrl.frames.postframe(this, '".$uri."&ajx=1'".$q.");";
}
//<summary>used to post uri from link</summary>
//@uri: uri to post
//@method: method response. for view
function igk_js_ajx_post_auri($uri, $method=null)
{
	return "javascript: window.igk.web.a_posturi(this,'".$uri."', ".(($method==null)?'null': $method).");";
}
//post a link uri
function igk_js_ajx_post_luri($parentTag){
	return "javascript: return window.igk.ajx.a_postResponse(this, '".$parentTag."');";
}
function igk_js_ajx_aposturi($uri, $targetNodeId)
{
	return "javascript: window.igk.ajx.aposturi('".$uri."', '".$targetNodeId."');";
}
///<summary> send link uri contain in a form </summary>
function igk_js_a_postform($uri){
	return "javascript: return (function(q){var f = window.igk.getParentByTagName(q, 'form');  if (f){f.action ='".$uri."'; f.submit();return false;}})(this);";
}

//------------------------------------------------------------------------------------------------------------------------------
//ZIP Utility functions
//------------------------------------------------------------------------------------------------------------------------------
function igk_zip_entry_isdir($e) 
{
	return ((zip_entry_compressionmethod($e) == "stored") || IGKString::EndWith(zip_entry_name($e),"/"));	
}
function igk_zip_create_dir($outdir, $name)
{
	$t = explode('/',$name);
	
	if (is_dir($outdir))
	{
		$d = $outdir;
		foreach($t as $k)
		{
			if (empty($k))continue;
			$d = $d.DIRECTORY_SEPARATOR.$k;
			if (!is_dir($d))
				@mkdir($d);
		}
	}
}
function igk_zip_extract($outdir,$hzip, $e)
{
	if (!is_dir($outdir))
		return;
		
	$d = IGKIO::GetDir($outdir.DIRECTORY_SEPARATOR.zip_entry_name($e));
	
    //touch($d);
	
	$hfile = @fopen($d, 'w+');
	if ($hfile)
	{
		zip_entry_open($hzip, $e, 'r');
        fwrite($hfile, zip_entry_read($e,zip_entry_filesize($e)));
		zip_entry_close($e);		
        fclose($hfile); 
	}
}

function igk_zip_content($file, $name,  $content)
{
	$zip = new ZipArchive();
	$zip->open($file, ZIPARCHIVE::CREATE);		
	$zip->addFromString($name, $content);
	$zip->close();		
	
}


//get the number of items



function igk_count($item)
{
	if (is_array($item))
		return count($item);
	if (is_object ($item) && method_exists(get_class($item), "getCount"))
		return $item->getCount();
	return 0;
}
function igk_render_doc()
{
	igk::RenderDocument();
}
///@@@ return the base index.php content
function igk_getbaseindex()
{
$showError = <<<EOF
//Display ERRORS
ini_set("display_errors", "1");
error_reporting(E_ALL);
EOF;

return <<<EOF
<?php
$showError
//
//require framework
//
\$IGK_APP_DIR = dirname(__FILE__);
require_once("Lib/igk/igk_framework.php");
try{
//------------------------------------------------------------------------------------------
//call init environment method before start the session to load and create all required file
//------------------------------------------------------------------------------------------
igk_initenv(dirname(__FILE__));
//Start SESSION
session_start();
//SET DEFAULT HEADER
header("Content-Type: text/html; charset=utf-8");
//start Application. file is require to check if is included
igk::Init(__FILE__);
}
catch (Exception \$Ex)
{
	// show some errors
	igk_show_exception(\$Ex);
	igk_wln("<a href=\"?c=sessionctrl&f=clearS\" >Clear session</a>");
}
?>
EOF;
}
//return -1 not a class 
function igk_reflection_class_isabstract($name)
{
	if (class_exists($name))
	{
		$v_rc = new ReflectionClass($name);
		return $v_rc->isAbstract();
	}
	return -1;
}
function igk_reflection_getclass_var($obj)
{
	if (is_object($obj))
		return get_class_vars( get_class( $obj));
	if (is_string($obj))
	{
		if (class_exists($obj))
		{
			return get_class_vars($obj);
		}
	}
	return null;
}

//sort array
function igk_usort(& $item, $params)
{
	if (is_array($item))
		usort($item, $params);
	else{
		$item->Sort($params);
	}
}

//SYSTEM FUNCTION 
//<summary>used to register other class to system controller manager.</summary>
//<remark>by default all controller defined in this file will be a system controller</remark>

//return the global page list
function igk_sys_pagelist(){
	return igk_getctrl(IGK_MENU_CTRL)->getPageList();
}

///register a system controller
function igk_sys_regSysController($className)
{
	if (class_exists($className))
	{
		IGKControllerBase::RegSysController($className);
	}
}

function igk_sys_viewctrl($name)
{
	$ctrl = igk_getctrl($name);
	if ($ctrl!=null)
		$ctrl->View();
}

//to manage changement
function igk_sys_regchange($key, & $state)
{
	return igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange($key, $state);
}
function igk_sys_ischanged($key, & $state)
{
	return igk_getctrl(IGK_CHANGE_MAN_CTRL)->isChanged($key, $state);
}
///register a method for view call back
function igk_sys_regview($ctrlname, $ctrl, $callback)
{
	$c = igk_getctrl($ctrlname , false);
	if (($c == null) || ($ctrl == null) && ($c!== $ctrl))
		return;
	$c->regView($ctrl, $callback);
}
function igk_sys_unregview($ctrlname, $ctrl)
{
	$ctrl = igk_getctrl($ctrlname , false);
	if (($ctrl == null) || ($ctrl == null) )return;
	$ctrl->unregView($ctrl);
}


function igk_sys_regpagefolderChanged($name, $ctrl , $method)
{ 
	igk::getInstance()->registerPageFolderChangedMethod($name, array($ctrl, $method));
}
function igk_sys_unregpagefolderChanged($name)
{
	igk::getInstance()->unregisterPageFolderChangedMethod($name);
}
function igk_sys_getall_ctrl(){
	return igk::getInstance()->ControllerManager->getControllers();
}

function igk_sys_getdefaultCtrlConf()
{
				
	return array(
			"clTargetNodeIndex"=>0,
			"clDisplayName"=>null,
			"clDataAdapterName"=>"CSV",
			"clParentCtrl"=>null,
			"clVisiblePages"=>"*",
			"clDescription"=>null
			);
}

//CONFIG FUNCTION
function igk_conf_canconfigure()
{
	return igk_getcltrl(IGK_CONF_CTRL)->getCanConfigure();
}
//String function UTILITY
function igk_str_join($str1, $str2, $pattern)
{
	return $str1.$pattern.$str2;
}
function igk_str_remove_line($str)
{	
	$t = preg_split("/(\r\n)|(\n)/i", $str);
		//$t = explode("\r\n", $str);
		$o = "";
		$i = 0;
		foreach($t as $k=>$v)
		{
			if (($v==null) || empty($v) || (strlen(trim($v)) == 0))
				continue;
			if ($i==1)
				$o .="\r\n";
			$o .= $v;
			$i= 1;
		}
		return $o;
		
}
///<summary>remove magic cote from message</summary>
function igk_str_quotes($content){

	if (ini_get("magic_quotes_gpc") && is_string($content))
	{
		 $content = stripcslashes($content);
	}	
	return $content;
}

function igk_str_rm_last($str, $pattern)
{
	$c = strlen($pattern);
	while(IGKString::EndWith($str,$pattern))
	{
		$str = substr($str, 0, strlen($str)- $c);
	}
	return $str;
}
function igk_str_rm_start($str, $pattern)
{
	if ($pattern!=null) 
	{	
	$c = strlen($pattern);
	while( ($c >0) && IGKString::StartWith($str,$pattern))
	{
		$str = substr($str, $c);
	}
	}
	return $str;
}

function igk_is_debuging()
{
	$App = igk::getInstance();
	return (igkServerInfo::IsLocal() && ($App->Configs->AllowDebugging ?$App->Configs->AllowDebugging : false));	
}


//@@@ create and generate new id
function igk_new_id()
{
	 return md5(uniqid(rand()));
}
//MENU FUNCTION
//@@@ retrive menu by name
function igk_menu_getmenu($name)
{
	return igk_getctrl(IGK_MENU_CTRL)->getMenu($name);
}
//@@@ get the root menu of this item
function igk_menu_getRootMenu($name){
	return igk_getctrl(IGK_MENU_CTRL)->getRootMenu($name);
}
//retruve alla roots menus for special purpose
function igk_menu_getRoots(){
	return igk_getctrl(IGK_MENU_CTRL)->getRoots();
}
function igk_show_exception($Ex)
{
	if (!$Ex)
		return;
	// show some errors
	igk_wln("Error Append");
	igk_wln("Message: ".$Ex->getMessage());
	igk_wln("File : ".$Ex->getFile());
	igk_wln("Line : ".$Ex->getLine());
	igk_wln("<h2>Trace :</h2>");
	foreach($Ex->getTrace() as $k=>$v)
	{
		if (isset($v["file"])){
			igk_wln("File : ".$v["file"] . ", ".$v["line"]);
		}
	}
	igk_wln("<a href=\"?c=sessionctrl&f=clearS\" >Clear session</a>");
}
function igk_support_noextension_script()
{
//write this in a htaccess files so that server will excecute file 
//without extension as php script
//NOTE: server must support allow override property
$o = <<<EOF
AddHandler server-parsed .php
SetHandler Application/x-httpd-php
AddHandler Application/x-httpd-php .php
EOF;

$o = <<<EOF
   <FilesMatch "[^\.]+|(\.ph(p3?|tml)$)">
        SetHandler Application/x-httpd-php
    </FilesMatch>
EOF;
return $o;

}




//register default class value
function igk_css_regclass($classname, $defaultvalue)
{
	$igk = igk::getInstance();
	if ($igk===null)return;
	if (empty($igk->Doc->Theme[$classname]))
	{
		$igk->Doc->Theme[$classname] = $defaultvalue;
	}
}
function igk_css_regcolor($clname, $value)
{
	
	$igk = igk::getInstance();
	if ($igk===null)return;
	
	
	if ($igk->Doc->Theme->cl[$clname] === null)
	{
		$igk->Doc->Theme->cl[$clname] = $value;
	}
}
//@@ set or replace Append theme
function igk_css_Append($name, $value)
{
	$igk = igk::getInstance();
	if ($igk===null)return;	
	$igk->Doc->Theme->Append[$name] = $value;
	
}
//used to get a real value of a color
function igk_css_treatcolor($colors , $value)
{
	//pattern {window_text_color} = will be replaced by it real color
	$reg2 = '/{s*(?P<name>[\w_-]+)\s*\}/i';
	if ( ($c = preg_match_all($reg2,$value, $match)))
	{		
		for($i = 0; $i<$c ; $i++)
		{
			$v_m = $match[0][$i];
			$type = $match['name'][$i];
			for($i = 0; $i<$c ; $i++)
			{
				$v_m = $match[0][$i];
				$v_n = trim($match["name"][$i]);
				$value = str_replace($v_m, igk_css_treatcolor($colors, $colors[$v_n]), $value);				
			}			
		}
	}	
	//FOR PALETTE COLOR
	
	return $value;

}

function igk_css_treat($theme, $v)
{
	//\s*(\w+)\s*:\s*([a-zA-Z0-9_]+)\s*\
	$reg = '/\[\s*(?P<name>\w+)\s*:\s*(?P<value>[a-zA-Z0-9_\/\\\.\-]+)\s*\]\s*(;)*(,)*/i';
	$reg2 = '/\{\s*(?P<name>[\w:\-_,\s]+)\s*\}\s*(;)*/i';
	$reg3 = IGK_CSS_CHILD_EXPRESSION_REGEX;
	$match = array();
	$c = 0;
	//child expression
	if ($c = preg_match_all(IGK_CSS_CHILD_EXPRESSION_REGEX, $v, $match))
	{
		for($i = 0; $i<$c ; $i++)
		{
			$n = $match[0][$i];
			//remove parent expression
			$v = str_replace($n, "", $v);
		}
	}
	
	if ( ($c = preg_match_all($reg,$v, $match)))
	{
		for($i = 0; $i<$c ; $i++)
		{
		$v_m = $match[0][$i];
		
		$type = $match['name'][$i];
		$value = $match['value'][$i];
		switch(strtolower($type))
		{
			case "res":
				$v = str_replace($v_m, 
				"background-image: url('".igk_io_baseuri( "?vimg=".$value."&css=1")."');",$v);
			break;
			case "bgres":
					$v = str_replace($v_m, 
				"background-image: url('".igk_io_baseuri()."/".igk_html_uri($value)."');",$v);
				break;
			case "uri":
			$v = str_replace($v_m, 
				"url('".igk_io_baseuri()."/".igk_html_uri($value)."')",$v);
				break;
			case "fcl":
				$v = str_replace($v_m, 
				igk_css_getfcl($theme->cl[$value]), $v);
				
			break;
			case "bgcl": //return bg color
				$v = str_replace($v_m, igk_css_getbgcl($theme->cl[$value]), $v);
			break;
			case "cl":
				$v = str_replace($v_m, $theme->cl[$value], $v);
				break;
			case "ft"://return font-family
				$v = str_replace($v_m, $theme->ft[$value]?igk_css_getfont($value):null, $v);
			break;
			case "ftn"://return only the font name
				$h  = $theme->ft[$value]?$theme->ft[$value]: null;
				if ($h)
					$v = str_replace($v_m, "\"".$h."\"", $v);
				else 
					$v = str_replace($v_m, "", $v);
				break;
			case "pr":
				$v = str_replace($v_m, $theme->properties[$value].";", $v);
				break;
			default:
				$v = str_replace($v_m, "", $v);
			break;
		}
		}
		
	}
	
	if ( ($c = preg_match_all($reg2,$v, $match)))
	{		
		for($i = 0; $i<$c ; $i++)
		{
			$v_m = $match[0][$i];
			$type = $match['name'][$i];
			for($i = 0; $i<$c ; $i++)
			{
				$v_m = $match[0][$i];
				$v_n = trim($match["name"][$i]);
				if (isset($theme[$v_n])){
					//for single item
					$v = str_replace($v_m, igk_css_treat($theme, $theme[$v_n]), $v);				
				}				
				else{
					$rtab = explode(':', $v_n);
				
					if (count($rtab) == 2)
					{
						$v_from = strtolower(trim($rtab[0]));
						
						switch($v_from){
							case "sys":
								//retrive sys params 
								//comma separator expected
								$v_nn  = explode(',',trim($rtab[1]));								
								$sk = "";
								foreach($v_nn as $r){									
									//replace with value
									$sk .= $theme->Doc->SysTheme->def[".".trim($r)];
								}
								$v = str_replace($v_m, $sk, $v);
								break;
							default:
								//make null
								$v = str_replace($v_m, null, $v);				
								break;
						}
					}
					else {
						//no definition
						//for default item 
							$v_nn  = explode(',',trim($v_n));								
							$sk = "";							
							foreach($v_nn as $r){									
									$sk .= $theme->Doc->Theme->Attributes[trim($r)];									
							}
							$v = str_replace($v_m, $sk, $v);								
							//$v = str_replace($v_m, null, $v);				
					}
				}
			}			
		}
	}	
	return $v;
}



//@@@ get request value
function igk_getr($key, $value=null)
{
	if (is_object($key))
		return $value;
	if (isset($_REQUEST[$key]))
	{
		$t = $_REQUEST[$key];
		if (!is_array($t))
			return igk_str_quotes($t);
		return $t;
	}
	return $value;
}
///get request object value
function igk_getru($key, $value=null)
{
	if (is_object($key))
		return $value;
	if (isset($_REQUEST[$key]))
			return str_replace("-","_", igk_str_quotes($_REQUEST[$key] ));
	return $value;
}
//get default value
function igk_getdv($v, $default=null)
{
	if (isset($v))
		return $v;
	return $default;
}
//retreive requested object as object
function igk_getr_obj()
{
	$t = array();	
	foreach($_REQUEST as $k=>$v)
	{
		if (IGKString::StartWith($k,"cl"))
		{
			$t[$k] = igk_str_quotes($v);
		}
	}	
	return (object)$t;
}
//reset request
function igk_resetr()
{
	$_REQUEST = array();
}
//load request uri
function igk_loadr($uri)
{
	if (count($uri) == 0)
		return;
	//uri
	$tab = array();
	$t = parse_url($uri);	
	$q  = $t["query"];	
	parse_str($q, $tab);
	$_REQUEST = $tab;
}
//@@@ get request array
function igk_getrs(){
	return $_REQUEST;
}
function igk_qr_confirm()
{
	return (igk_getr("confirm", 0) == 1);
}
//@@@ get object property value
function igk_getprop($obj, $prop)
{
	if ($obj == null)
		return;
	return $obj->$prop;	
}
//@@@ set a request key=>$value
function igk_setr($key,$value)
{
	$_REQUEST[$key] = $value;
}




function igk_ansi2utf8($text)
{
$text = str_replace("¡","\xc2\xa1",$text);
$text = str_replace("¢","\xc2\xa2",$text);
$text = str_replace("£","\xc2\xa3",$text);
$text = str_replace("¤","\xc2\xa4",$text);
$text = str_replace("¥","\xc2\xa5",$text);
$text = str_replace("¦","\xc2\xa6",$text);
$text = str_replace("§","\xc2\xa7",$text);
$text = str_replace("¨","\xc2\xa8",$text);
$text = str_replace("©","\xc2\xa9",$text);
$text = str_replace("ª","\xc2\xaa",$text);
$text = str_replace("«","\xc2\xab",$text);
$text = str_replace("¬","\xc2\xac",$text);
$text = str_replace("­","\xc2\xad",$text);
$text = str_replace("®","\xc2\xae",$text);
$text = str_replace("¯","\xc2\xaf",$text);
$text = str_replace("°","\xc2\xb0",$text);
$text = str_replace("±","\xc2\xb1",$text);
$text = str_replace("²","\xc2\xb2",$text);
$text = str_replace("³","\xc2\xb3",$text);
$text = str_replace("´","\xc2\xb4",$text);
$text = str_replace("µ","\xc2\xb5",$text);
$text = str_replace("¶","\xc2\xb6",$text);
$text = str_replace("·","\xc2\xb7",$text);
$text = str_replace("¸","\xc2\xb8",$text);
$text = str_replace("¹","\xc2\xb9",$text);
$text = str_replace("º","\xc2\xba",$text);
$text = str_replace("»","\xc2\xbb",$text);
$text = str_replace("¼","\xc2\xbc",$text);
$text = str_replace("½","\xc2\xbd",$text);
$text = str_replace("¾","\xc2\xbe",$text);
$text = str_replace("¿","\xc2\xbf",$text);
$text = str_replace("À","\xc3\x80",$text);
$text = str_replace("Á","\xc3\x81",$text);
$text = str_replace("Â","\xc3\x82",$text);
$text = str_replace("Ã","\xc3\x83",$text);
$text = str_replace("Ä","\xc3\x84",$text);
$text = str_replace("Å","\xc3\x85",$text);
$text = str_replace("Æ","\xc3\x86",$text);
$text = str_replace("Ç","\xc3\x87",$text);
$text = str_replace("È","\xc3\x88",$text);
$text = str_replace("É","\xc3\x89",$text);
$text = str_replace("Ê","\xc3\x8a",$text);
$text = str_replace("Ë","\xc3\x8b",$text);
$text = str_replace("Ì","\xc3\x8c",$text);
$text = str_replace("Í","\xc3\x8d",$text);
$text = str_replace("Î","\xc3\x8e",$text);
$text = str_replace("Ï","\xc3\x8f",$text);
$text = str_replace("Ð","\xc3\x90",$text);
$text = str_replace("Ñ","\xc3\x91",$text);
$text = str_replace("Ò","\xc3\x92",$text);
$text = str_replace("Ó","\xc3\x93",$text);
$text = str_replace("Ô","\xc3\x94",$text);
$text = str_replace("Õ","\xc3\x95",$text);
$text = str_replace("Ö","\xc3\x96",$text);
$text = str_replace("×","\xc3\x97",$text);
$text = str_replace("Ø","\xc3\x98",$text);
$text = str_replace("Ù","\xc3\x99",$text);
$text = str_replace("Ú","\xc3\x9a",$text);
$text = str_replace("Û","\xc3\x9b",$text);
$text = str_replace("Ü","\xc3\x9c",$text);
$text = str_replace("Ý","\xc3\x9d",$text);
$text = str_replace("Þ","\xc3\x9e",$text);
$text = str_replace("ß","\xc3\x9f",$text);
$text = str_replace("à","\xc3\xa0",$text);
$text = str_replace("ý","\xc3\xbd",$text);
$text = str_replace("þ","\xc3\xbe",$text);
$text = str_replace("ÿ","\xc3\xbf",$text);
$text = str_replace("ä","\xc3\xa4",$text);
$text = str_replace("å","\xc3\xa5",$text);
$text = str_replace("æ","\xc3\xa6",$text);
$text = str_replace("ç","\xc3\xa7",$text);
$text = str_replace("è","\xc3\xa8",$text);
$text = str_replace("é","\xc3\xa9",$text);
$text = str_replace("ê","\xc3\xaa",$text);
$text = str_replace("ë","\xc3\xab",$text);
$text = str_replace("ì","\xc3\xac",$text);
$text = str_replace("í","\xc3\xad",$text);
$text = str_replace("î","\xc3\xae",$text);
$text = str_replace("ï","\xc3\xaf",$text);
$text = str_replace("ð","\xc3\xb0",$text);
$text = str_replace("ñ","\xc3\xb1",$text);
$text = str_replace("ò","\xc3\xb2",$text);
$text = str_replace("ó","\xc3\xb3",$text);
$text = str_replace("ô","\xc3\xb4",$text);
$text = str_replace("õ","\xc3\xb5",$text);
$text = str_replace("ö","\xc3\xb6",$text);
$text = str_replace("÷","\xc3\xb7",$text);
$text = str_replace("ø","\xc3\xb8",$text);
$text = str_replace("ù","\xc3\xb9",$text);
$text = str_replace("ú","\xc3\xba",$text);
$text = str_replace("û","\xc3\xbb",$text);
$text = str_replace("ü","\xc3\xbc",$text);
return $text;
}

/*
//retrieve all default page controller
*/
function igk_get_default_pagesctrl()
{
	$igk = igk::getInstance();
	if ($igk==null)return;
	$t = array();
	foreach($igk->ControllerManager->getControllers() as $k)
	{
		//get controllers
		$cl = get_class($k);
		$v_rc = new ReflectionClass($cl);
		if ($v_rc->isAbstract() || !is_subclass_of($cl, IGK_CTRLWEBPAGEBASECLASS ) )
			continue;
		$t[] = $k;
	}
	return $t;
}
function igk_csv_sep()
{
	$s = igk_get_uvar(IGK_CSV_SEPARATOR,",", true);
	if (!empty($s))
		return $s;
	return ",";
	
}
function igk_csv_getvalue($v)
{
	return IGKCSVDataAdapter::GetValue($v);
}
//format the string by retreive the [[index]] with args
function igk_get_string_format($str)
{
	$n = null;
	$tab = func_get_args();
	if (defined("__NAMESPACE__"))
		$n =  __NAMESPACE__ .'IGKFormatString::Create';		
	else
		$n = 'IGKFormatString::Create';
		
	return call_user_func_array($n, $tab) ;

}
function igk_get_string_propvalue($obj, $property)
{
	return IGKFormatGetValueString::Create($obj, $property);
}
//<summary>get user variables</summary>
function igk_get_uvar($name, $default=null, $reg=false, $comment=null)
{
	if (empty($name))
		return $default;
	$ctrl = igk_getctrl(IGK_USERVARS_CTRL);
	if ($ctrl == null)
		return $default;
	$t = igk_getv($ctrl->Vars, $name);
	if ($t)
		return $t["value"];
	if ($reg && $ctrl)
	{
		$ctrl->regVars($name,$default,$comment);
		$ctrl->__storeVars();
	}
	return $default;
}

function igk_notify_error($msg)
{
	$ctrl = igk_notifyctrl();
	if ($ctrl)
	{
		$ctrl->addError($msg);	
	}
	else{
		igk_wln("<div style=\"background-color:#FcA1A1; \" >".$msg."</div>");
	}
}
///@@ get value in array
function & igk_getv($array, $key, $default= null)
{	
	if (is_array($array))
	{
		if (isset($array[$key]))
			return $array[$key];
	}
	else if (is_object($array))
	{
		$t =get_class_vars(get_class($array));
		if (method_exists(get_class($array), "__get"))
		{		
			$s= $array->__get($key);				
			return $s;
		}
		if (isset($array->$key))
			return $array->$key;		
	}
	return $default;
}
///@@@ get the setted-value
function igk_getsv($value, $default=null)
{
	if (isset($value))
	{
		return $value;
	}
	return $default;
}
//get the value between value and value
function igk_gettv($value, $default)
{
	if (empty($value))
		return $default;
	if ($value==null)
		return $default;
	return $value;
}
//@@@ clear config session and restart Application
function igk_clear_config_session()
{
	$ctrl = igk_getctrl(IGK_CONF_CTRL);		
	$uri = $ctrl->getUri("startconfig&q=".base64_encode(
	'?'.http_build_query(array(
	"u"=>$ctrl->User->Login,
	"pwd"=>$ctrl->User->Pwd,
	"selectedCtrl"=>$ctrl->getSelectedConfigCtrl()->getName(),
	"selectPage"=>$ctrl->getSelectedMenuName()
	)
	)));				
	igk_getctrl(IGK_SESSION_CTRL)->clearS(false);
}

function igk_file_chmod($dirorfile, $mode, $recursif=false)
{
	$out = true;
	if ($recursif && is_dir($dirorfile))
	{
		
		$hdir = @opendir($dirorfile);
		if ($hdir)
		{
			
			while($r=readdir($hdir))
			{
				if (($r==".") || ($r==".."))
					continue;
				$f = igk_io_getdir( $dirorfile."/".$r);
				
				// igk_wln($dirorfile ."=== ". is_file($f));
				if (is_dir($f))
				{
					// igk_wln($f. " : Dir file : ".$out);
					$out = igk_file_chmod($f, $mode, $recursif) && $out;
				}
				else if (file_exists($f))
				{
					// igk_wln($f. " : ".$out);
					if (!@chmod($f, $mode))
						$out = false;
					// else{
						// igk_wln($f. " : Change mode : ".$out);
					// }
				}
				// igk_wln($f. " : ".$out);
			}
			closedir($hdir);
		}
	}
	$out = @chmod ($dirorfile , $mode) && $out;
	// igk_wln( " : ".$out);
	// exit;
	return $out;
}

//<summary> parse bool to str string</summary>
function igk_parsebool($bool)
{
	return ($bool)?"true": "false";
}
function igk_parsebools($b)
{
	return R::ngets("V.".igk_parsebool($b));
}
//<summary>parse numéric number to string</summary>
function igk_parse_num($num)
{
	if (is_numeric($num))
	{
		if ($num == 0)
			return "0";
		return trim($num)."";
	}	
	return "0";
}
function igk_getquery_args($uri)
{
	$q = parse_url($uri);
	if (isset($q["query"]))
	{	
		$tab  = array();
		parse_str($q["query"], $tab);
		return $tab;
	}
	else{
		$tab  = array();
		parse_str($uri, $tab);
		return $tab;
	}
	return null;
}
//@ get the article extension
function igk_get_article_ext($lang=null){
	if ($lang)
	{
		return strtolower(".".$lang.".phtml");
	}
	return strtolower(".".R::GetCurrentLang().".phtml");
}
//get the article of a controller
function igk_get_article($ctrl, $name)
{
	return $ctrl->getArticle($name);
}

function igk_get_frame_ext(){
	return strtolower(".frame.phtml");
}

function igk_get_current_base_uri($dir=null, $secured = false)
{
	$igk = igk::getInstance();
	if ($igk->CurrentPageFolder!=IGK_HOME_PAGEFOLDER)
		$out = igk_io_baseuri($igk->CurrentPageFolder,$secured);
	else 
		$out = igk_io_baseuri(null,$secured );
	if ($dir)
		$out .= "/".$dir;
	return $out;	
}
//return the dir from document root
function igk_getbase_serverdir($dir=""){

	return IGKIO::GetRootBaseDir($dir);
}

function igk_php_check_and_savescript($file, $content, & $error, & $code)
{
		$f = $file;
		$v_c = $content;
		$v_old = null;
		if (file_exists($f))
		{
			$v_old = IGKIO::ReadAllText($f);
		}
		IGKIO::WriteToFileAsUtf8WBOM($f, $v_c, true);					
		$code =0;
		$error=array();
		
		@exec("php -l \"".$f."\"",$error,$code);		
		igk_wln($v_old);
		
		if ($code != 0)
		{		
			unlink($f);
			//write old value
			IGKIO::WriteToFileAsUtf8WBOM($f, $v_old,true);			
			return false;
		}	
		return true;
}
//write debug message
function igk_debug( $msg ){
	if (!igk::IsInit())
		return;
	if (igkServerInfo::IsLocal())	
	{	
		$tab = explode(':', $msg);
		$ctrl = igk_getctrl("igkdebugctrl" ,false);
		if ($ctrl == null)
			return;
		$lb = HtmlItem::CreateWebNode("div");
		
		if (count($tab) > 1)
		{
			$args  = array();
			preg_match_all('/((?P<name>([^:]+)):(?P<value>(.)*))$/i', $msg, $args);						
			$n = strtolower(trim($args["name"][0]));
			switch($n)
			{
				case "warning":					
				case "error":
				case "notice":
				case "info":
					$lb["class"]="debug".$n;
					$lb->Content = $args["value"][0];
					$ctrl->addMessage($lb);
					break;
				default:
					$lb["class"]="debugsmg";
					$lb->Content = $msg;
					$ctrl->addMessage($lb);
					break;
			}
		}
		else{
			$lb["class"]="debugsmg";
			$lb->Content = $msg;
			$ctrl->addMessage($lb);
		}
		
	}
}
function igk_debug_wln($msg)
{
	if (igk::$DEBUG) igk_wln($msg);
}
function igk_debug_wl($msg)
{
	if (igk::$DEBUG) igk_wln($msg);
}
function igk_server_is_refreshing()
{
	return igk_getctrl("igkpagectrl",false)->isRefreshing;
}

//-------------------------------------------------------------------------------------------------------------------------
//CURRENCY FUNCTION
//-------------------------------------------------------------------------------------------------------------------------
function igk_currency_getamount($amout)
{
		$c = $amout."";
		if (!strstr($c,"."))
			$amout = $c.".00";		
	return $amout;
}

function igk_download_file($name , $filename)
{
	if (file_exists($filename))
	{
		$size = @filesize($filename);
		igk_download_content($name, $size,  IGKIO::ReadAllText($filename));	
		exit;
	}
	return false;
}
function igk_download_content($name, $size,  $content, $encoding="binary")
{
	header("Content-Type: Application/force-download; name=\"" . $name . "\"");
	header("Content-Transfer-Encoding: ".$encoding);
	header("Content-Length: $size");
	header("Content-Disposition: attachment; filename=\"" . $name . "\"");
	header("Expires: 0");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	igk_wl( $content);
	exit;
}
//---------------------------------------------------------------------
//DATE UTILS FUNCTION
//---------------------------------------------------------------------
//
//return: 	-2 on error
//			1 if date1 > date2
//			0 if equal
//			-1 if date1 < date2
//---------------------------------------------------------------------
function igk_date_now($format =null)
{
	if ($format)
		return date($format);
	return date("Y-d-m_h:i:s");
}
function igk_date_compare($date1, $date2)
{
	try{
		$d1 = new DateTime($date1);
		$d2 = new DateTime($date2);
		if ($date1 > $date2)
			return 1;
		if ($date1 < $date2)
			return -1;
		return 0;
		}
		catch(Exception $ex){
			return -2;
		}	
}
function igk_html_treatinput($node)
{
	if ($node==null)return;
	$d = $node->getElementsByTagName("input");	
	if ($d && (igk_count($d)>0))
	{
		foreach($d as $k)
		{
			$k["class"] = "cl".strtolower($k["type"]);
		}		
	}					
}

//@@@
// @attributes array of  [allowEmpty, valuekey, displaykey]
///@attr is html attributes
function igk_html_build_select($target, $name, $tab, $attributes=null, $selectedvalue = null, $attr=null)
{
			$sel = $target->add("select");	
			$sel["id"]=$sel["name"] = $name;
			if ($selectedvalue == null)
			{
				$selectedvalue = igk_getr($name,null);
			}
			if (igk_getv($attributes,"allowEmpty"))
				$sel->add("option", array("value"=>""))->Content = IGK_HTML_SPACE;
			$kv = igk_getsv(igk_getv($attributes,"valuekey"));
			$dv = igk_getsv(igk_getv($attributes,"displaykey"));
			$ksu = igk_getv($attributes, "keysupport");
			$resolvtext = igk_getv($attributes, "resolvtext");
			if (is_array($tab))
			{
				foreach($tab as $v)
				{	
					$opt = $sel->add("option");
					$opt["value"] = $ksu? igk_getv($v, $kv): $v;
					$s = $ksu? igk_getv($v, $kv) : $v;
					if ($resolvtext )
						$opt->Content = R::ngets("enum.".($ksu? igk_getv($v, $dv) : $v));				
					else
						$opt->Content =  $ksu? igk_getv($v, $dv) : $v;				
					if ($s == $selectedvalue){
						$opt["selected"] = true;
					}
				}
			}
			$sel->AppendAttributes($attr);
			return $sel;
}

//create a frame that will contain a form 
function igk_html_buildframe_ajx($ctrl, $id, $title, $uri, & $form, $closed=false)
{
	$frame = igk_add_new_frame($ctrl, $id);
	$div = $frame->Content;
	$div->ClearChilds();
	$frame->Title = $title; 
	$frm = $div->addForm();
	$frm["action"]=$uri;
	$frm["igk-ajx-target-response"] = $ctrl->TargetNode["id"];
	if ($closed)
		$frm["igk-frame-close"] = "1";
	$form = $frm;
	
	return $frame;
}
function igk_html_buildform($ul, $param, $targettagname="li")
{
	foreach($param as $k)
	{
		$id = $k[0];
		$type = strtolower($k[1]);
		$required = igk_getv($k,2);		
		$args = igk_getv($k,3);		
		
		$li = $ul->add($targettagname);
		$a = null;
		$li->add("label", array("for"=>$id))->Content = R::ngets("lb.".$id)->getValue() . ($required?"*":"");
		
		switch($type)
		{
			case "textarea":
				$a = $li->addTextArea($id);
				$a->Content = $args;
				break;
			case "radio":
			case "checkbox":
				$a = $li->addInput($id, $type);
				if (igk_getr($id)){
				$a["checked"] = "true";
				}
				break;
			case "hidden":
			case "text":			
			case "password":
			default:
				$a = $li->addInput($id, $type);
				$a["type"]=strtolower($type);
				$a["value"] = $args? igk_getv($args, "value", igk_getr($id)) :  igk_getr($id);
				break;
		}
		$a["id"]=$a["name"] = $id;
		$args = igk_getv($k,3);	
		if ($args !=null)
		{
			$a->AppendAttributes($args);
		}
		
	}
}
function igk_html_uri($uri)
{
	return str_replace("\\", "/",$uri);
}
//unscape text area content
function igk_html_unscape($out)
{
	$reg = "/(?P<name>([\\\][\"\'\\\]))/i";
	$c = preg_match_all($reg,$out, $t);

	for($i = 0; $i< $c;$i++)
	{
		switch($t["name"][$i])
		{
			case '\\"':
					$out = str_replace('\\"','"', $out);
					break;
			case "\\'":
					$out = str_replace("\\'",'\'', $out);
					break;
			case '\\':
					$out = str_replace('\\',"\\", $out);
					break;
		}
	}
	return $out;
}

function igk_html_toggle_class($target, $childtag="tr", $startindex=1,  $class1="table_darkrow", $class2="table_lightrow")
{
	HtmlUtils::ToggleTableClassColor($target, $childtag, $startindex, $class1, $class2);
}
//add item to target
function igk_html_add($item, $target, $index = null)
{
	HtmlUtils::AddItem($item, $target, $index);
}
//add a link items
function igk_html_a_link($target, $hrefuri, $clickuri=null)
{
	$a = $target->add("a");
	if ($a)
	{
		$a["href"] = $hrefuri;
		if ($clickuri)
		$a["onclick"] = "javascript:".$clickuri." return false;";
	}
	return $a;
}
//remove item
function igk_html_rm($item, $dispose=false){
	HtmlUtils::RemoveItem($item, $dispose);
}
function igk_html_new($node, $attributes = null)
{
	return HtmlItem::CreateWebNode($node, $attributes);
}

function igk_is_conf_connected()
{
	return igk_getctrl(IGK_CONF_CTRL)->IsConnected;
			
}
//----------------------------------------------------------------------------------------
//igk javascript utiliy
//----------------------------------------------------------------------------------------
function igk_js_enable_tinymce($target, $mode='textareas', $elements=null)
{
$element_txt = 'null';
if ($elements)
{
	if (is_array($elements)){
		$element_txt = "{elements: \"".implode(',', $elements)."\"}";
	}
	else
		$element_txt = "{elements: \"".$elements."\"}";
}
$script = <<<EOF
igk.tinyMCE.init('{$mode}',{$element_txt});
EOF;
$sc = $target->add("script");
$sc->Content = $script;
return $sc;
}

//JAVASCRIPT FUNCTION
function igk_js_get_posturi($target, $uri, $func =null, $saveState=false){

$func = ($func==null)?"function(xhr){ if (this.isReady()){ this.setResponseTo(self);}}":$func;
$out = "javascript: (function(a){ var self = a; var q = igk.getParentById(self, '".$target["id"]."'); igk.ajx.post('".$uri."', null, ".$func.", ".igk_parsebool($saveState)."); })(this); ";
return $out;
}
function igk_js_lnk_confirm($text){
	return "igk.form.confirmLink(this, '$text'); return false;";
}
//-----------------------------------------
//igk utility function
//-----------------------------------------
function igk_loadcontroller($dirname)
{
	$files = igk_loadlib($dirname, "php");	
	return $files;
}
function igk_wln($msg)
{
	igk_wl( $msg. "<br />");
}
function igk_wl($msg){
	echo $msg;
}
function igk_prln($msg)
{
	igk_wl( $msg . "\n");
}
function igk_print($msg)
{
	igk_wl( $ms);
}
//post data in uri script a return data
function igk_post_uri($uri, $args=null, $content="Application/x-www-form-urlencoded")
{
$postdata = null;

if ($args!=null)
	$postdata = http_build_query(
    $args
);

$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: '.$content,
        'content' => $postdata
    )
);
$context  = stream_context_create($opts);
$result = @file_get_contents($uri, false, $context);
return $result;
}
function igk_show_prev($obj)
{
	igk_wl( "<pre>");
	print_r($obj);
	igk_wl( "</pre>");
}
function igk_show_prevTo($target, $obj)
{
	$s = "";
	ob_start();
	igk_show_prev($obj)	;	
	$s = ob_get_contents();
	ob_end_clean();
	$target->addDiv()->Content = $s;
	
}
function igk_show_code($obj)
{
	igk_wl( "<code>");
	igk_wl($obj);
	igk_wl( "</code>");
}
function igk_show_textarea($obj)
{
	igk_wl( "<textarea>");
	igk_wl($obj);
	igk_wl( "</textarea>");
}

function igk_show_keytype($array)
{
	igk_wl( "<pre>");
	$out = "";
	if (is_array($array))
	{
	foreach($array as $k => $v)
	{
		$out .= $k . " =&gt; ".$v."\n"; 
	}
	}
	igk_wl( $out);
	igk_wl( "</pre>");
}
function igk_regtowebpage($ctrl)
{
		$c = igk_getwebpagectrl();
		if ($c)
			$c->regController($ctrl);
}
//<summary>Add article to view for this controller</summary>
function igk_add_article($ctrl ,$name, $target, $tagname = null, $forcecreation=false)
{
	
	if ($target==null)
		throw new Exception("target is null" );
	
	$f = $ctrl->getArticle($name);	
	$n = null;
	
		if ($forcecreation && !file_exists($f))
		{
			igk_io_save_file_as_utf8($f, "", true);
		}
		if ($tagname == null){
			$n = $target;
		}
		else{
			$n = $target->add($tagname);
		}
		if (file_exists($f))
		{
		
			
			if ($tagname == null){		
				$target->Load(file_get_contents($f));
				igk_html_treatinput($target);
			}
			else 
			{				
				if ($n!=null)
				{
				$n->Load(file_get_contents($f));
					igk_html_treatinput($n);						
				}				
			}
			
		}
		if ($ctrl->App->ConfigMode && $ctrl->App->Configs->allow_article_config && ($n!=null) )
		{
			$div = $n->addDiv();
			$div["class"]="alignl dispb posr loc_l loc_t z_50";
			$div->Index = -100;
			$config = igk_getctrl(IGK_CA_CTRL);
			HtmlUtils::AddImgLnk($div, igk_js_post_frame($config->getUri("ca_edit_article_ajx&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($f)), $ctrl), "edit");
			HtmlUtils::AddImgLnk($div, igk_js_post_frame($config->getUri("ca_edit_articlewtiny_f_ajx&ctrlid=".$ctrl->Name."&m=1&fc=1&fn=".base64_encode($f)), $ctrl), "tiny");
		}
		return $n;		
}



/*add article and treat image source link*/
function igk_in_article($ctrl ,$name, $target, $tagname = null)
{
	if ($target==null)
		throw new Exception("target is null" );
		$f= $ctrl->getArticle($name);		
		if (file_exists($f))
		{
			$uri = igk_io_baseuri()."/". igk_io_basePath($f);
			if ($tagname == null)
			{
				$target->Load(file_get_contents($uri));
			}
			else{ 
				$s = $target->add($tagname);
				$s->Load(file_get_contents($uri));
			}
		}
		$m = $target->getElementsByTagName("image");
		if ($m){
		$dir = dirname(igk_io_basePath($f));
		foreach($m as $k=>$v)
		{
			if (!IGKValidator::IsUri($v->lnk) && is_file( IGKIO::GetDir($dir."/".$v->lnk)))
			{
				$v->lnk = igk_io_baseuri()."/". $dir."/".$v->lnk;	
			}			
		}
		}
	return null;
}


/*
*CHECK if the name is a reserved name
*/
function igk_ctrl_is_reservedname($name)
{
	if (preg_match("/^((a(bstract|nd|rray|s))|(c(a(llable|se|tch)|l(ass|one)|on(st|tinue)))|(d(e(clare|fault)|ie|o))|(e(cho|lse(if)?|mpty|nd(declare|for(each)?|if|switch|while)|val|x(it|tends)))|(f(inal|or(each)?|unction))|(g(lobal|oto))|(i(f|mplements|n(clude(_once)?|st(anceof|eadof)|terface)|sset))|
(n(amespace|ew))|(p(r(i(nt|vate)|otected)|ublic))|(re(quire(_once)?|turn))|(s(tatic|witch))|(t(hrow|r(ait|y)))|(u(nset|se))|
(__halt_compiler|break|list|(x)?or|var|while))$/i", trim($name)))
		return true;
	return false;

}


/*-------------------------------------------------------------------------------------
//io shortcut
/-------------------------------------------------------------------------------------*/
function igk_io_getdir($dir)
{
	return IGKIO::GetDir($dir);
}
//@@ use to remove empty line from file
function igk_io_removeEmptyLine($file)
{	
	if (!file_exists($file))
		return;
		$f = IGKIO::ReadAllText($file);
		$o = igk_str_remove_line($f);
		igk_io_save_file_as_utf8($file, $o, true);		
}
function igk_io_getrelativepath($source, $target)
{
			$o = "";
			$v = $target;
			$mdir = $source;
			$i = strpos($target, $source);
			if ($i!== false)
			{
				//child of current dir
				$o = "./". igk_str_rm_start( substr($v,$i + strlen($mdir)), '/');
			}			
			else{
				$o = $v;
				//retrieve the parent at
				 $sdir = $mdir;
				 $i = strpos($v, $sdir);
				 
				 $p = "../";
				 while( ($sdir = dirname($sdir)) &&  ($i = strpos($v, $sdir)) === false)
				 {
					$p .= "../";
					
				 }				 
				 if ($sdir)
				 {
					$o = $p.igk_str_rm_start( substr($v,$i + strlen($sdir)), '/'); 
				 }
			}
			return $o;
}
function igk_io_getfiles($dir, $match, $recursive=true)
{
	return IGKIO::GetFiles($dir, $match,$recursive);
}

function igk_io_fullrequestUri()
{
	return igk_html_uri(igk_str_rm_last(IGKIO::GetRootUri(), "/")."/".igk_str_rm_start($_SERVER["REQUEST_URI"],'/'));
}
function igk_io_baseRequestUri()
{
	$s = igk_io_baseuri();
	$d = igk_io_fullrequestUri();
	return igk_str_rm_start(substr($d, strlen($s)), '/');
}

function igk_io_save_file_as_utf8($filename, $content, $override=true)
{
	$r = igk_ansi2utf8(utf8_encode($content));
	return IGKIO::WriteToFile($filename, $r, $override);
}
function igk_io_baseuri($dir=null, $secured=null)
{
	return igk_html_uri(IGKIO::GetBaseUri($dir, $secured));
}

//store array data to xml property value
function igk_io_store_dataXml($filename, $rootname, $t)
{

	$conf = HtmlItem::CreateWebNode($rootname);
	//function in function . allowed in php strange behaviour
	function getData($node, $t)
	{
		foreach($t as $k=>$v)	
		{
			if (is_array($v))
			{
				getData($node->add($k), $v);
			}	
			else{
				$node->add($k)->Content = $v;
			}
		}
	}
	getData($conf, $t);
	
	IGKIO::WriteToFileAsUtf8WBOM($filanem, 	$conf->Render(), true);
}
//@@@ retourn le chemin complet . si chemin relatif fournit c'est le cwd qui intervient
function igk_io_getfullpath($path)
{
	return realpath($path);
}
//@@@ retourne le chemin absolut par rapport à la racine de site. 
// a utiliser avec des fichiers contenus dans le site.
function igk_io_currentbasePath($file)
{
	//igk_wln($file . "#".igk_io_baseRelativePath($file));
	//igk_debug_wln($file);
	return igk_io_currentRelativePath(igk_io_baseRelativePath($file));
}
//@@@ retourne le chemin relatif à  partir de la racine du site. si le repertoire existe.
function igk_io_basePath($dir)
{
	return igk_io_baseRelativePath(realpath($dir));
}
//retourne un chemin relatif à  partir de la racine du site spécifier par igk::BaseDir
function igk_io_baseRelativePath($dir, $separator=DIRECTORY_SEPARATOR)
{
	if ($separator =="\\")
	{
		$dir = str_replace("/","\\",$dir);		
	}	
	return IGKIO::GetChildRelativePath(igk::$BASEDIR, $dir, $separator);
}
///@@@ : retrieve the current relative path according to "Basedir"
///@$dir : sever absolute path or basedir relative path
function igk_io_currentRelativePath($dir)
{	
	return IGKIO::GetCurrentDirRelativePath($dir);
}
//@@@ get the current relative uri //dir according to web page base index
function igk_io_currentRelativeUri($dir="")
{
	return igk_html_uri(IGKIO::GetCurrentRelativeUri($dir));
}
function igk_io_cwdRelativePath($dir)
{
	return IGKIO::GetRelativePath($dir, getcwd());
}
//return the relative uri according to BASEDIR
function igk_io_fullpath2Uri($dir)
{
	return igk_io_currentRelativeUri(igk_io_currentbasePath($dir));
}
//
//<summary>@@@ return the system full path according to BASEDIR.</summary>
//<code>exemple: in window will return c://wamp/website/[$relativepath]</code>
function igk_io_syspath($relativepath=null)
{
	return igk_io_getdir(igk::$BASEDIR."/".$relativepath);
}

/*
*
*move uploaded file to destination
*/
function igk_io_move_uploaded_file($file, $destination)
{
	if (!@move_uploaded_file($file, $destination))
	{
		return false;		
	}
	return true;
}
//@@ remove extension from filename @name file name
function igk_io_remove_ext($name)
{
	if (empty($name))
		return null;
	$t = explode(".", $name);
	if (count($t)>1){
		$s = substr($name, 0, strlen($name) - strlen($t[count($t)-1])-1);
		return $s;
	}
	return $name;
}
function igk_io_path_ext($fname)
{
	if (empty($name))
		return null;
	$t = explode(".", $name);
	if (count($t)>0){
		return $t[count($t)-1];
	}
	return null;
}
//@@@ get basename without extension
function igk_io_basenamewithoutext($file)
{
	return igk_io_remove_ext(basename($file));
}

function igk_io_saveContentFromTextArea($file, $content, $overwrite=true)
{
	if (ini_get("magic_quotes_gpc")){
		 $content = stripcslashes($content);
	}
	return igk_io_save_file_as_utf8($file, $content, $overwrite);  //IGKIO::WriteToFileAsUtf8WBOM($file,  $content, $overwrite);
}
function igk_io_fileIsPicture($type)
{
	$t = array(
		"image/png"=>1,
		"image/jpeg"=>1,
		"image/svg+xml"=>1,
		"image/tiff"=>1
	);
	return isset($t[$type]);
}

//-----------------------------------------------------------------------------------
//UTITLITY
//-----------------------------------------------------------------------------------
function igk_add_title($node, $title){
	if ($node==null)
		return;
		$d = $node->addDiv();
		$d["class"] ="config_title";
		$d->Content = R::ngets($title);
		return $d;
}
//@close uri : uri when closing
//@target: receive the frame
function igk_add_new_frame($ctrl, $name, $closeuri =null, $target=null, $reloadcallback=null)
{
	$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame($name, $ctrl, $closeuri, $reloadcallback);
	if ($target === null)
		$target = igk::getInstance()->Doc->body;
	HtmlUtils::AddItem($frm,  $target);
	return $frm;
}
function igk_close_confirm_frame_callback($frame)
{
	if (igk_qr_confirm())
		return $frame->Owner->App->ControllerManager->InvokeUri($frame->closeMethodUri);
}
function igk_add_confirm_frame($ctrl, $id, $uri=null, $closeuri = ".", $title=null,$target=null, $buttonmodel= 0)
{
 
	$frame = igk_add_new_frame($ctrl, $id, $closeuri,$target);
	$frame->Title = ($title==null)?R::ngets(IGK_CONFIRM_TITLE):$title;
	$frame->closeMethodUri = $uri;
	$frame->callbackMethod = "igk_close_confirm_frame_callback";
	$d = $frame->Content;
	$d->ClearChilds();
	
	$igk = igk::getInstance();
	$frame->Form = $d->addForm();
	$frame->Form["action"] = $frame->closeUri;
	$frame->Form["igk-confirmframe-response-target"] = $ctrl->TargetNode["id"];
	$frame->Form->Div = $frame->Form->addDiv();
	$frame->Form->addHSep();	
	$frame->Form->addInput("confirm", "hidden",1);
	$frame->Form->addInput("frame-id", "hidden",$id);
	$frame->Form->addInput("frame-close-uri", "hidden", igk_getctrl(IGK_FRAME_CTRL)->getUri("closeFrame_ajx&navigate=false&id=".$id));
	$frame->Form->addScript()->Content ="window.igk.winui.framebox.init_confirm_frame(igk.getlastscript(), '".$frame->closeUri."&cancel=1"."', ".
	($igk->Session->URI_AJX_CONTEXT?'true':'false')
	.")";
	
	$canceluri = $frame->closeUri."&cancel=1";
	switch($buttonmodel){
	case 0:
		$btn = $frame->Form->addBtn("btn_yes", R::ngets("btn.yes"), "submit");			
		$btn["onclick"] = $igk->Session->URI_AJX_CONTEXT?"javascript: return window.igk.winui.framebox.btn.yes(this);":null;
		
		HtmlUtils::AddBtnLnk($frame->Form, R::ngets("btn.no"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close(); ");
	break;
	case 1:
		$frame->Form->addBtn("btn_ok", R::ngets("btn.ok"), "submit", array("onclick"=>$igk->Session->URI_AJX_CONTEXT?"javascript:return window.igk.winui.framebox.btn.yes(this);":null) );			
		HtmlUtils::AddBtnLnk($frame->Form, R::ngets("btn.cancel"), "javascript: ".igk_js_post_frame_cmd($canceluri)." this.frame.close()" );
		break;
	}
	
	return $frame;
}
function igk_frame_close($name, $navigate=false)
{
	return igk_getctrl(IGK_FRAME_CTRL)->closeFrame($name, $navigate);
}
function igk_get_frame($name){
	return igk_getctrl(IGK_FRAME_CTRL)->getFrame($name);
}
///get new relative html relative uri value
function igk_get_nhru($value)
{
	return new HtmlRelativeUriValueAttribute($value);
}

function igk_show_qresult_astable($target, $res)
{
	$target->add("table");
	$td = null;
	$tr = null;
}
//controller of name
function igk_getdata_adapter($controllerOrAdpaterName, $throwException=false)
{
	if (is_string($controllerOrAdpaterName))
		return IGKDataAdapter::CreateDataAdapter($controllerOrAdpaterName, $throwException);
	return IGKDataAdapter::CreateDataAdapter($controllerOrAdpaterName->getDataAdapterName(), $throwException);
}

function igk_notifyctrl(){
	return igk_getctrl(IGK_NOTIFICATION_CTRL,false);
}
//return the default web page ctrl

function igk_getwebpagectrl(){
	$igk = igk::getInstance();	
	return igk_getctrl($igk->Configs->web_pagectrl);
}
function igk_getwebpagecontent(){
	if (igk::getInstance()->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER)
	{
		return igk_getctrl(IGK_CONF_CTRL)->ConfigNode;
	}
	else{
	 $c = igk_getwebpagectrl();
	 if ($c)
		return $c->page_content;
	else{
		$igk = igk::getInstance();	
		return $igk->Doc->bodycontent;
	}
	}
	return null;
}
//return t he default config page ctrl
function igk_getconfigwebpagectrl(){
	$igk = igk::getInstance();
	return igk_getctrl(IGK_CONF_CTRL);
}
//sort functions
function igk_key_sort($k, $v)
{
	return strcmp($k,$v);	
}
function igk_array_sortkey(& $tab)
{
	if (!is_array($tab))
		return false;
	$ckey = array_keys($tab);
	igk_usort($ckey, "igk_key_sort");
	$t = array();
	foreach($ckey as $k)
	{
		$t[$k] = $tab[$k];
	}
	$tab = $t;
	return true;
}
function igk_array_first($c)
{
	if (is_array($c) && (igk_count($c)>0))
	{
		return $c[0];
	}
	return null;
}
function igk_array_last($c)
{
	if (is_array($c) && (igk_count($c)>0))
	{
		return $c[igk_count($c)-1];
	}
	return null;
}

//used to convert array to values to value = > value
function igk_array_tokeys($d)
{
	$b = array();
		foreach($d as $k=>$v)
		{
			$b[$v] = $v;
		}
	return $b;
}
function igk_array_key_value_toggle($d){
	
	$b = array();
	foreach($d as $k=>$v)
		{	if (isset($b[$v]))continue;
			$b[$v] = $k;
		}
	return $b;
}

function igk_save_config()
{
	igk_getctrl(IGK_CONF_CTRL)->saveConfig();	
}

function igk_fileIsNotincluded($file)
{
$tab = get_included_files();
return $tab[0] == $file;
}

function igk_db_select_all($ctrl)
{
	$db = igk_getdata_adapter($ctrl);
	if ($db){
	$db->connect();
	$r = $db->selectAll($ctrl->DataTableName);
	$db->close();
	return $r;
	}
	return null;
}
//filter object entries to fit data base column info
function igk_db_objentries($ctrl, $tab)
{
			$ttab = $ctrl->getDataTableInfo();
			if( !$tab)
				return null;
			$v_otab = array ();
			$s = IGK_FD_NAME;
			foreach($ttab as $k=>$v)
			{				
				$tk = igk_getv($v,IGK_FD_NAME);
				$v_otab[$tk] = igk_getv($tab, $tk);
			}
			return $v_otab;
}

function igk_navtobase($path=null)
{
	$s = null;
	
	if ($path==null){
		$s = igk_io_currentRelativePath("","/");
	}
	else 
		$s = igk_io_currentRelativePath($path,"/");
	
		if (empty($s))
		{
			header("Location: ./");
		}
		else{
			header("Location: ".igk_html_uri($s));
		}
}
//navigate to current uri
function igk_navtocurrent($uri=null){
		$page = igk::getInstance()->CurrentPageFolder;
		$t = "";	
		if (strtolower($page)!=IGK_HOME_PAGEFOLDER)
		{			
			$t = ($uri)? "".($page)."/".$uri : $page;
		}
		else 
			$t = $uri;	
		igk_navtobase($t);
		exit;	
}
//load javascript documenet from directory
function igk_js_load_script($doc, $dirname)
{	
	if ($doc == null)
		return;
	$hdir = @opendir($dirname);
	if (!$hdir)
	{
		igk_debug("scripts dirname can not be opened [".$dirname."]");
		return false;
	}

	$f = null;
	$fd = null;
	$scriptFolder = array();
	while($fd = readdir($hdir))
	{
	
		if (($fd==".") || ($fd==".."))
			continue;
			
		$f = $dirname."/".$fd;
		if (is_dir($f)){
			$scriptFolder[] = $f;
			
		}
		else {
			if (IGKString::EndWith($f,".js"))
			{
				$doc->addScript(realpath($f));
			}
		}
	}
	foreach($scriptFolder as $f)
	{
		igk_js_load_script($doc, $f);
	}
	closedir($hdir);
	return true;
}

//controller function
function igk_getctrl($ctrlname, $throwex = false)
{
	if (igk::IsInit())
		return null;
	if (is_string($ctrlname))
	{
		try{

			$cc = igk::getInstance()->ControllerManager;			
			if ($cc==null)
				return null;			
			$v = $cc->$ctrlname;
			if ($throwex && ($v==null))
			{
				throw new Exception("controller [".$ctrlname."] not found");
			}
			return $v;
		}
		catch(Exception $ex)
		{
			//igk_wln("error: no controlleur [".$ctrlname."] found");
			//exit;
		}
	}
	else{
		if (is_object($ctrlname) && igk_is_ctrl($ctrlname))
		{
			return $ctrlname;
		}
	}
	return null;
}
function igk_ctrl_isactive($ctrlname){
	//get non active controller from "Data/igk_nonactive.csv";
	return true;
}
function igk_is_ctrl($ctrl)
{
	if (is_subclass_of(get_class($ctrl), IGK_CTRLBASECLASS))
	{
	return true;
	}
	return false;
}
//-------------------------
// init igk environement
//-------------------------
function igk_initenv($dirname){
	$hdir = null;
	if (is_dir($dirname))	
		$hdir = opendir($dirname);
	if (!$hdir)
		return;	
	igk::$BASEDIR = $dirname;
	$confFILE = $dirname."/Data/configure"; //configure file
	$Rfile = $dirname."/R/R.class.php"; //resources class 
	$v_access = $dirname."/.htaccess";
	$access = "deny from all";//default htacess
	$old = umask(0);	
	IGKIO::CreateDir($dirname."/Configs");	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Configs/index.php",igk_getconfigIndex(), false);

	if (file_exists($confFILE))
	{
		
		IGKIO::WriteToFileAsUtf8WBOM($v_access, igk_getbase_access(), false);
		if (file_exists($Rfile))
			include_once($Rfile);
			
		if (!igk::LoadCacheLibFiles())
		{
			$t_files = igk_loadcontroller($dirname."/Inc");
			$t_c = igk_loadcontroller($dirname."/Mods");
			
			$t_files = ($t_c==null)? $t_files :  array_merge($t_files, $t_c);		
			igk_reglib($t_files);	
			igk::CacheLibFiles();
		}
	}
	else{
	igk::SetIsInit(true);
	//----------------------------------------------------------------------------------------------
	//create and init framework environment
	//----------------------------------------------------------------------------------------------
	//write default access
	IGKIO::WriteToFileAsUtf8WBOM($v_access, igk_getbase_access(), false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Lib/.htaccess", $access, false);
	IGKIO::CreateDir($dirname."/R");
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/.htaccess", "allow from localhost",false);
	IGKIO::CreateDir($dirname."/R/Img"); //folder that will contain image folder
	IGKIO::CreateDir($dirname."/R/Layouts");//folder that will contain layout
	IGKIO::CreateDir($dirname."/R/Styles"); //folder that will contain primary styles
	IGKIO::CreateDir($dirname."/R/Styles/Fonts"); //folders that will contain fonts
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/ie.css", "@import url(\"base.css\");", false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/mod.css", "@import url(\"base.css\");", false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/base.css", igk_css_getdefaultstyle(), false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Styles/base.php", igk_getbasestyle(), false);
	
	IGKIO::CreateDir($dirname."/R/Themes");
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/R/Themes/default.phtml", IGKIO::ReadAllText(igk_io_syspath(IGK_DEFAULT_THEME_FOLDER."/default.themes")), false);
	
	//create mod folder
	
	IGKIO::CreateDir($dirname."/".IGK_MODS_FOLDER, 0777);	
	IGKIO::CreateDir($dirname."/".IGK_PAGE_FOLDER, 0722);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_PAGE_FOLDER."/.htaccess", $access,false);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Mods/.htaccess", $access,false);
	IGKIO::CreateDir($dirname."/Data");
	IGKIO::CreateDir($dirname."/Data/Lang");
	//restore default lang
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/Lang/lang.fr.resources", IGKIO::ReadAllText(dirname(__FILE__)."/Default/Lang/lang.fr.resources"), true);
	
	//init default data. by copying data to output folder
	
	IGKIO::CopyFiles(dirname(__FILE__)."/Default/Data",	$dirname."/Data", false);
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/.htaccess", $access,false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_CONF_DATA, igk_getdefaultconfigData(),false);
	IGKIO::CreateDir($dirname."/".IGK_SCRIPT_FOLDER);
	IGKIO::CreateDir($dirname."/Inc");
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Inc/.htaccess", "deny from all");
	
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/Lang/lang.fr.resources", "<?php ?>", false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/Lang/lang.en.resources", "<?php ?>", false);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/Data/Lang/lang.nl.resources", "<?php ?>", false);	
	
	//caches folder
	IGKIO::CreateDir($dirname."/".IGK_CACHE_FOLDER);
	IGKIO::WriteToFileAsUtf8WBOM($dirname."/".IGK_CACHE_FOLDER."/.htaccess", "deny from all");
	
	
	igk_loadcontroller($dirname."/Inc");	
	igk_loadcontroller($dirname."/Mods");	
	IGKIO::WriteToFileAsUtf8WBOM($confFILE,"1", false);
	igk::SetIsInit(false);
	}
	//require db configuration	
	closedir($hdir);	
	umask($old);
}
function igk_getbase_access()
{
$error_404 = "\"".igk_getbase_serverdir()."/Lib/igk/igk_error.php?code=404\"";
	$out = <<<EOF
SetEnv PHP_VER 5_3
Options -Indexes
ErrorDocument 404 {$error_404}

# Use UTF-8 encoding for anything served as text/plain or text/html
AddDefaultCharset utf-8
<IfModule mod_mime.c>
    # Force UTF-8 for certain file types
    AddCharset utf-8 .css .js .json .vtt .nex .webapp .xml
</IfModule>
EOF;
return $out;

}

//-------------------------------------------------------
///retrieve base.css file
//--------------------------------------------------------


function igk_css_getbgcl($v)
{
	if (empty($v))
		return null;
	return "background-color: ".$v.";";
}
function igk_css_getfcl($v)
{

	if (empty($v))
		return null;
	return "color: ".$v.";";
}
function igk_css_getfont($v)
{
	if (empty($v))
		return null;
	return "font-family: \"".$v."\";";
}
//return all style definition
function igk_css_getbasedef()
{
$theme = igk::getInstance()->Doc->Theme;
$o = "";
$o .= "/* GLOBAL APP APP THEME */\n";
$o .= igk::getInstance()->Doc->SysTheme->get_css_def() ."\n";


$o .= "/* CUSTOM THEME */\n";
$o .= $theme->get_css_def();

$o.= "/* APPICATION THEME STYLES */\n";
$c = igk_getctrl(IGK_THEME_CTRL);
if ($c)
	$o .= $c->themeGetCss();

return $o;
}


function igk_getbasestyle()
{
$v = <<<EOF
<?php
define("IGK_FORCSS", 1);
define("IGK_NO_WEB", 1);
include("../../index.php");
header('content-type: text/css');
igk_wl(igk_css_getbasedef());
?>
EOF;
return $v;
}

function igk_css_getdefaultstyle()
{
	$v = <<<ETF
*{ margin : 0px; padding: 0px; }
ETF;
return $v;
}
function igk_getconfigIndex()
{
$cfavicon= "Lib/igk/Default/R/Img/cfavicon.ico";
$v = <<<ETF
<?php
require_once(dirname(__FILE__)."/../index.php");
\$igk = igk::getInstance();
if (\$igk){
\$doc = \$igk->Doc;
\$doc->Title = R::gets("title.igkwebconfig");
\$doc->Favicon = new HtmlRelativeUriValueAttribute("$cfavicon");
igk_wl( \$doc->Render());
}
?>
ETF;
return $v;
}


function igk_getdefaultconfigData()
{
$v = <<<EOF
admin_login,admin
admin_pwd,21232f297a57a5a743894a0e4a801fc3
show_powered,1
show_debug,0
menu_defaultPage,default
allow_article_config,0
allow_auto_cache_page,0
cache_loaded_file,0
website_domain,igkdev.be
website_title, igkdev.be
mail_server,relay.skynet.be
mail_port,25
mail_admin,contact@igkdev.be
mail_contact,contact@igkdev.be
db_server,localhost
db_user,igkdev
db_name,igkdev
web_pagectrl,defaultpagectrl
db_pwd,test
meta_description,default page description
meta_copyright,igkdev@copyright.com
meta_enctype,text/html; charset=utf-8
meta_keysword,"igkdev, .NET Developper"
meta_title, igkdev.be
website_prefix, igk
EOF;
return $v;
}

function igk_reglib_once($file)
{
	$f = realpath($file);
	
	if (!empty($f) && file_exists($f))
	{	
		require_once($f);
		igk_reglib(array($f=>$f));
	}
}
function igk_reglib($files)
{
	if (($files==null)  || (igk_count($files)==0))
		return;
	if (igk::$LibFiles == null)
		igk::$LibFiles = array();
	
	foreach($files as $k=>$v)
	{
		if (!isset(igk::$LibFiles[$v]))
			igk::$LibFiles[$v] = $v;
	}
}
function igk_loadlib($dir, $ext="php")
{
	$hdir = @opendir($dir);
	if (!$hdir)return;
	
	$file = "";
	$dirs = array();
	$files = array();
	while($fdir = readdir($hdir))
	{
		if (($fdir == ".") || ($fdir==".."))
			continue;
		$file  = $dir.DIRECTORY_SEPARATOR.$fdir;
		
		if (is_dir($file)){
			$dirs[] = $file;
		}
		else {
			if (strstr($file, ".phtml") || !IGKString::EndWith($file,$ext))
				continue;						
			include_once($file);			
			$files[] = igk_html_uri($file);
		}
	}	
	closedir($hdir);
	if (count($dirs>0))
	{
		foreach($dirs as $k)
		{
			$t = igk_loadlib($k, $ext);
			$files = array_merge($files, $t);
		}
	}	
	return $files;
}

//--------------------------------------------------------------------------------------------------------
// AGENT FUNCTIONS
//--------------------------------------------------------------------------------------------------------

//get if client user agent is microsoft internet explorer
function igk_agent_isIE(){
	return IGKUserAgent::IsIE();
}
function igk_agent_ieVersion()
{
	if (igk_agent_isIE())
	{
		$tab = array();
		preg_match_all("/MSIE\s*(?P<version>[0-9\.]+)/i", $_SERVER["HTTP_USER_AGENT"], $tab);
		return $tab["version"][0];
	}
	return null;
}
function igk_agent_isAndroid()
{
	return IGKUserAgent::IsAndroid();
}
function igk_agent_androidVersion()
{
	return IGKUserAgent::GetAndroidVersion();
}



//--------------------------------------------------------------------------------------------------------
// GLOBAL VARIABLE
//--------------------------------------------------------------------------------------------------------

//defining system variable
$igk_App =null; //

//--------------------------------------------------------------------------------------------------------
// INTERFACES
//--------------------------------------------------------------------------------------------------------
interface IIGKSystemUser
{
	function getLogin();	
}
interface IIGKConfigController
{
	function showConfig();
}
interface IIGKWebController extends IIGKController
{
	//return an array of childs controller 
	function getChilds(); //get childs		
	function regController($ctrl);//reg child controller
	function unregController($ctrl);//unreg child controller
}
interface IIGKWebPageController extends IIGKWebController
{

	function manageErrorUriRequest($uri);//manage error request	
	function getpage_content(); //get page content
	function getheader_content();//get header content
	function getfooter_content();//get footer content
	function getmenu_content();//get menu base container
	
	
	function getheaderNode();
	function getbodyNode();
	function getfooterNode();
	
	function loadWebTheme($file);//load web structure
}
interface IIGKWebPageChildCtrontroller{
	function getWebParentCtrl();
	
}
interface IIGKWebAdministrativeCtrl
{
	function getConfigNode();	
}

//--------------------------------------------------------------------
// R Class clas 
//--------------------------------------------------------------------
final class R extends IGKObject
{
	static $sm_instance;
	var $m_lang;
	var $langRes;
	var $LangChangedEvent;
	var $KeysAdded;	
	var $PageLangChangedEvent;
	
	
	static $sm_keyVAR;
	
	private $m_langChangedDate;
	//@@@ get the current language file
	public function _getlangpath(){	
		return igk_io_syspath("Data/Lang/lang.".$this->m_lang.".resources");
	}
	public static function getInstance(){ 
			if (self::$sm_instance === null)
			{
				if (isset($_SESSION["R"] )){
					self::$sm_instance = $_SESSION["R"];
				}
				else{
					self::$sm_instance = new R();
					$_SESSION["R"]= self::$sm_instance;
					self::LoadLang();
				}
			}
			return self::$sm_instance;
	}
	private function __construct()
	{
			$this->m_lang = "fr";
			$this->LangChangedEvent = new IGKEvents($this, "LangChangedEvent");
			$this->PageLangChangedEvent = new IGKEvents($this, "PageLangChangedEvent");
			$this->KeysAdded = new IGKEvents($this,"KeysAdded");
	}
	public  static function LoadLang()
	{			
			$v = self::getInstance();
			//clear lang
			$v->langRes = array();
			$f = $v->_getlangpath();
			if (file_exists($f)){
				include($f);				
			}
			else{
				include(dirname(__FILE__)."/Default/Lang/lang.".$v->m_lang.".resources");
			}
	}
	public static function AddLang($key, $value){	
		if (!empty($key))
			self::getInstance()->langRes[strtolower(trim($key))]=$value;
	}
	protected function OnKeyAdded($key)
	{//raise event
		$this->KeysAdded->Call($this, $key);
	}
	protected function OnLangChangedEvent($key)
	{
		if ($this->LangChangedEvent !=null)
			$this->LangChangedEvent->Call($this, null);
	}
	public static function gets($key)
	{
	
		$i = self::getInstance();
		
			$key = strtolower($key);
			if (isset($i->langRes[$key]))
			{
			    $s = $i->langRes[$key];
				$match = array();
				$c = 0;			
				$c = preg_match_all("/{(?P<value>[a-zA-Z0-9_\.]+)}/i",$s, $match);
				if ($c > 0)
				{
					for($i = 0; $i < $c ; $i++)
					{
					
						$ckey = $match["value"][$i];
						if (strtolower($ckey) == strtolower($key))
							continue;
						
						$s = str_replace( $match[0][$i],R::gets($ckey),$s);
						
					}		
				}		
			
				return $s;
			}
			else{
				if (!empty($key))
				{
					$i->langRes[$key] = $key;
					$i->OnKeyAdded($key);
				}
			}
			return $key;
	}
	
	public static function ngets($key)
	{
		if (self::$sm_keyVAR == null)
			self::$sm_keyVAR = array();
		$T = strtolower($key);	
		if (isset(self::$sm_keyVAR[$T]))
		{
			return self::$sm_keyVAR[$T];
		}
			//register
			$default = self::gets($key);
			$args = array();
			if (func_num_args() > 1)
			{
				$t = func_get_args();
				for($i=1; $i< count($t) ; $i++)
				{
					$args[] = $t[$i];
				}
			}
			self::$sm_keyVAR[$T] = new IGKLangKey($key, $default,$args);			
			return self::$sm_keyVAR[$T];
	}
	public static function ChangeLang($lang = "fr"){
		$v = self::getInstance();
		
		if ($lang=="Img")
			throw new Exception("change lang changed by unknown");
		if ($v->m_lang != $lang)
		{
			$v->m_lang = $lang;
			self::LoadLang();
			$v->onPageLangChangedEvent();
		}		
	}	
	public function onPageLangChangedEvent()
	{
		//$v = self::getInstance();
		if ($this->PageLangChangedEvent !=null)
			$this->PageLangChangedEvent->Call($this,null);
	}
	public static function GetLangInfo(){
		return self::getInstance()->langRes;
	
	}

	public static function SaveLang()
	{	
		$v = self::getInstance();		
		$out = "<?php 
";	
		$tab = $v->langRes;
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		foreach($ktab as $k)
		{
			$v = $tab[$k];
			$v = str_replace("\'", "'", str_replace("\"", "&quot;",$v));
			if (!empty($k))
				$out .= "R::AddLang(\"$k\", \"".$v."\");\n " ;
		}
		$out .= "?>";
		$v = self::getInstance();
		$file = $v->_getlangpath();

		if (IGKIO::WriteToFileAsUtf8WBOM($file, $out, true))
		{
			//reload lang files
			self::LoadLang();			
			igk_sys_regchange("LangChanged", $v->m_langChangedDate);
			$v->OnLangChangedEvent(null);	
			return true;
		}
		else{
			igk_notify_error("can't save lang file");
		}
		return false;
	}
	
	public static function GetCurrentLang(){
		$v = self::getInstance();
		return $v->m_lang;
	}
	public static function GetImgUri($name)
	{
		return igk_getctrl(IGK_PIC_RES_CTRL)->getImgUri($name);
	}
	public static function RemoveKey($name){
		$name = strtolower($name);
		$v = self::getInstance();
		if(isset($v->langRes[$name]))
		{
			unset($v->langRes[$name]);
			return true;
		}
		return false;
	}
	public static function ClearLang(){
		$v = self::getInstance();		
		$v->langRes = array();
		self::SaveLang(null);
	}
}


//--------------------------------------------------------------------------------------------------------
//DATA DESCRIPTION
//--------------------------------------------------------------------------------------------------------
final class Vector2f extends IGKObject
{
	private $m_x;
	private $m_y;
	
	public function getX(){return $this->m_x;}
	public function getY(){return $this->m_y;}
	
	public function setX($value){ $this->m_x = $value;}
	public function setY($value){ $this->m_y = $value;}
	
	public function __construct($x=0,$y=0)
	{
		$this->m_x = $x;
		$this->m_y = $y;
	}
	public function __toString(){
		return "Vector2f [x:".$this->X." y:".$this->Y."]";
	}
}
//--------------------------------------------------------------------------------------------------------
//igk Application class
//--------------------------------------------------------------------------------------------------------
final class igk extends IGKObject
{
	public static $BASEDIR;//base directory
	public static $DEBUG;//for debuging purpose
	public static $LibFiles;
	public static $controllerdir;
	public $InitEvent;				//init event
	private $m_CurrentPageFolderEvent;		//current page event
	
	private static $sm_instance;
	
	private $m_Doc; //html document	
	private $m_Validator; //get html the validator object
	
	private $m_ControllerManager; //controller manager objects
	private $m_firstUse; //is first used
	private $m_SelectedController ; //selected controller
	//private $m_cPage ;
	private $m_autorisations;
	private $m_session; //igk session parameters.
	private static $sm_isInit;
	private static $sm_isConfig;
	private $m_configMenuConf; //configuration of the config menu
	
	private $m_queryError;
	private $m_queryErrorUri;
	
	private $m_pageFolderInitMethod;
	
	public function getConfigMenuConfiguration()
	{
		return $this->m_configMenuConf;
	}
	
	public static function GetAppDir(){
		global $IGK_APP_DIR;		
		return $IGK_APP_DIR;
	}
	public static function GetLibFolder(){		
		return dirname(__FILE__);
	}
	
	
	public static function CacheLibFiles($force=false)
	{
		//igk_debug("cache lib files ... :: CacheLibFiles");
		$f =  igk_io_currentbasePath(IGK_CACHE_LIBFILE);		
		//igk_wln($f);
		//exit;
		$t = 3600;
		$expire = time()-$t;
		if (!$force && file_exists($f) && (filemtime($f) > $expire))
		{
			//no cache
			return;
		}		
		$data  ="";
		$mdir = igk_html_uri(dirname(__FILE__));
		
		
		foreach(self::$LibFiles as $k=>$v)
		{
			$o = igk_io_getrelativepath($mdir, $v);		
			$data .= 'include_once("'.$o.'");'."\n";
		}
		
		$out = <<<EOF
<?php
\$bck = getcwd();
chdir(dirname(__FILE__));
\$d = igk_io_getrelativepath(dirname(__FILE__), igk::GetLibFolder());
chdir(\$d);
{$data}
chdir(\$bck);
unset(\$bck);
?>
EOF;
		
		igk_io_save_file_as_utf8($f, $out);
		
		
	}
	public static function LoadCacheLibFiles($dir=null)
	{
		
		$b = igk::$BASEDIR;
		$d = igk::GetAppDir();
		if ($dir==null)
			igk::$BASEDIR = $d;
		$v = false;	
		if (file_exists(igk_io_currentbasePath(IGK_CACHE_DATAFILE)))
		{
			$f = igk_io_currentbasePath(IGK_CACHE_LIBFILE);
			
			if (file_exists($f))
			{
				try{
				include($f);
				}
				catch(Exception $ex){
				}
				$v = true;
			}
		}
		igk::$BASEDIR = $b;
		return $v;
	}
	public static function SetIsInit($value){
		self::$sm_isInit = $value;
	}
	public static function IsInit(){
		return self::$sm_isInit;
	}
	public static function setConfig($v)
	{
		throw new Exception(" Set Config");
		self::$sm_isConfig = $v;
	}
	public function getSelectedController(){return $this->m_SelectedController; }
	public function getAutorisations(){return $this->m_autorisations;}	
	public function getControllerManager(){return $this->m_ControllerManager;}
	public function setControllerManager($value) {$this->m_ControllerManager = $value;}
	public function getDoc(){return $this->m_Doc;}
	public function getFirstUse(){ return $this->m_firstUse; }
	//used to check if this is in configuration mode
	public function getConfigMode(){ return igk_getctrl(IGK_CONF_CTRL)->IsConnected; }
	
	 //get current page folder
	public function getCurrentPageFolder(){
		
		if (IGKIO::GetCurrentDir() == IGKIO::GetBaseDir())
			return IGK_HOME_PAGEFOLDER;
		 else{
			 return IGKIO::GetChildRelativePath(self::$BASEDIR, IGKIO::GetCurrentDir());
		}
	}

	//class::igk system current page return a menu current page
	public function getCurrentPage(){ return igk_getctrl(IGK_MENU_CTRL)->CurrentPage; }
	//set the current page
	public function setCurrentPage($value, $index=0){  
		$index = ($index == 0)?igk_getr("pageindex",$index):$index;		
		igk_getctrl(IGK_MENU_CTRL)->setPage($value, $index);
		
	}	
	 
	public function addCurrentPageFolderEvent($obj, $method){
		$this->m_CurrentPageFolderEvent->add($obj, $method);
	}
	public function removeCurrentPageFolderEvent($obj, $method){
		$this->m_CurrentPageFolderEvent->remove($obj, $method);
	}
	public function addCurrentPageEvent($obj, $method)
	{
		igk_getctrl(IGK_MENU_CTRL)->addPageChangedEvent($obj, $method);
	}
	public function removeCurrentPageEvent($obj, $method)
	{
		igk_getctrl(IGK_MENU_CTRL)->removePageChangedEvent($obj, $method);
	}
	public function getValidator(){return $this->m_Validator;}
	//is configurating
	public function getIsConfigurating(){return $this->getCurrentPage() == IGK_CONFIG_MODE; }
	public function getConfigs(){return igk_getctrl(IGK_CONF_CTRL)->Data; }
	public function getSession(){return $this->m_session;}
	public function getUser(){return $this->getSession()->User; }
	
	
	//reset
	public function reset(){
		$this->m_firstUse = true;
		//$this->m_cPage = null;
		$this->Doc->body->ClearChilds();
	}
	public function __toString(){
		return "igk framework[Version:". IGK_VERSION."]";
	}
	private function __construct()
	{
		//magic function		
		
	}
	//private to call function
	public function __call($name, $arguments)
	{
		if (function_exists("igk_".$name))
		{			
			return call_user_func_array("igk_".$name, $arguments);
		}
		
	}
	//private function get igk m
	public function __get($name)
	{
		if (function_exists("igk_".$name))
		{		
			return call_user_func_array("igk_".$name, $tb);
		}
		return parent::__get($name);
	}
	public function registerPageFolderChangedMethod($pageFolderName, $array_ctrl_method)
	{
		if ($this->m_pageFolderInitMethod== null)
			$this->m_pageFolderInitMethod = array();
		if (!isset($this->m_pageFolderInitMethod[$pageFolderName]))
		{
			$this->m_pageFolderInitMethod[$pageFolderName] = $array_ctrl_method;
		}
		else 
			igk_debug("method already register". $pageFolderName);
	}
	public function unregisterPageFolderChangedMethod($pageFolderName)
	{
		unset($this->m_pageFolderInitMethod[$pageFolderName]);
	}
	public function onCurrentPageFolderEvent()
	{
		//init page folder method
		$f = $this->CurrentPageFolder;	
		if (isset($this->m_pageFolderInitMethod[$f]))
		{
			$t = $this->m_pageFolderInitMethod[$f];
			$this->doc->body->ClearChilds();
			$t[0]->Invoke($t[1], array($this));			
		}		
		if ($this->m_CurrentPageFolderEvent!=null)
				$this->m_CurrentPageFolderEvent->Call($this, null);			
	}
	private static function RegViewPicture()
	{	
		//for getting web resource
		if (igk_getr("c")== IGK_PIC_RES_CTRL)
		{
			if (igk_getr("css")==1)
			{
				$f = igk_getr("f","viewpic");
				if ($f=="viewpic")
				{
					igk_getctrl(IGK_PIC_RES_CTRL)->$f();		
					exit;
				}
			}
		}
	}
	
	public static function setErrorQuery($error, $uri=null)
	{
		igk::getInstance()->m_queryError = $error;
		igk::getInstance()->m_queryErrorUri = $uri;
	}
	public static function Init($file)
	{
		
		if (defined("IGK_NO_WEB"))
		{
			//no web rendering
			return;
		}	
		self::RegViewPicture();
		$v_igk = self::getInstance();		
		$v_ctrlm = IGKControllerManager::getInstance(); 
		$v_raise = true;
		$c = null;

		//for single domain operation
		if ($v_igk->Session->Domain !== igk_io_baseuri())
		{			
			$s = $v_igk->Session->Domain;			
			$v_igk->Session->Domain = igk_io_baseuri();
			if (!empty($s))
			{
				//clear session and reconnect
				igk_getctrl(IGK_CONF_CTRL)->reconnect();
				exit;
			}
		}
	
		//-------------------------------------------------------------
		//init for the first used
		//-------------------------------------------------------------
		if ($v_igk->FirstUse)
		{
			$v_igk->InitEvent->Call($v_igk, null);			
			//call the user init default page
			if(function_exists("InitDefaultPage"))
			{
				InitDefaultPage($v_igk);
			}
			else{
				$v_igk->__initDefaultPage();
			}	
			//raize the page folder change to initialize the document
			$v_igk->onCurrentPageFolderEvent();
			//view controller
			//$v_igk->ViewControllers();
			//change the first use
			$v_igk->m_firstUse = false;
			$v_raise  = false;
		}	
		
		//TODO: REFRESHING PURPOSE
		if (igk_server_is_refreshing())
		{
			igk_debug("Refreshing Navitor is not Allowed");			
		}
		igk_debug("info:invoke uri");
		//TODO: INVOKE URI
		$c = $v_igk->ControllerManager->InvokeUri();
	

		if(!defined("IGK_FORCSS"))
		{//change current page instance
			$v_cpage = $v_igk->CurrentPageFolder;
	
			
			if ($v_igk->Session->PageFolder != $v_cpage)
			{
				$v_igk->Session->PageFolder = $v_cpage;
				if ($v_raise)
				{	
					$v_igk->onCurrentPageFolderEvent();					
				}
			}
		}
		if ($c && ($c  != $v_igk->m_SelectedController ))
			$v_igk->m_SelectedController = $c;
	
	
		if (self::$sm_isConfig){	
		
			
			igk_getctrl("igkdbCtrl")->initSDb(false);
			self::$sm_isConfig = false;
			
		}
		
		//-------------------------------------------------------
		//update session control value
		$v_igk->Session->update();
		//-------------------------------------------------------		
		self::Render($file);
		
		//igk_post_uri("http://www.igkdev.be?c=frameworkmanager&framework_usage=1", array());
		
	}	
	//@@@ init default page rendering system
	private function __initDefaultPage()
	{
		$doc = $this->Doc;		
		//define user entry				
		$doc->bodypage = $doc->body->add("div", array("id"=>"bodypage", "class"=>"web_bodypage"));

		igk_css_regclass("web_body","{sys:fitw,fith} overflow:hidden;");
		igk_css_regclass("web_bodypage","{sys:fitw,fith,posr} overflow:hidden;");
	}

	private static function Render($file=null)
	{	
		
		if (igk_fileIsNotincluded($file))
		{			
			self::RenderDocument();
		}
	}
	public static function RenderDocument()
	{			
			$App = igk::getInstance();
			if (!$App->ConfigMode && $App->Configs->allow_auto_cache_page)
			{				
				$ctrl = igk_getctrl("cache");
				if ($ctrl)
				$ctrl->loadCache($App->CurrentPage.".html",igk::getInstance());
			}
			else{
				igk_wl(igk::getInstance()->Doc->Render());				
			}
	}
	//call document view
	public function View(){
		//do nothing
	}
	public function getTargetNode(){
		return $this->Doc;
	}
	
	public static function getInstance(){
		if (self::$sm_instance === null)
		{
			if (isset($_SESSION["igk"]))
			{
				self::$sm_instance = $_SESSION["igk"];
			}
			else {
				self::$sm_instance = new igk();
				$_SESSION["igk"] = self::$sm_instance;
				self::$sm_instance->_load();
			}
		}
		return self::$sm_instance;
	}

	private function _load()
	{
	
		$this->m_autorisations = new IGKAutorisation($this);
		$this->m_session = new IGKSession($this);
		$this->InitEvent = new IGKEvents($this,"InitEvent");
		$this->m_CurrentPageFolderEvent = new IGKEvents($this,"CurrentPageEvent");
		//create web document
		$this->m_Doc = new HtmlDoc($this);
		$this->m_Doc->setup_document();
		
		$this->m_Validator = new HtmlValidatorItem();		
		$this->m_Doc->addStyle("R/Styles/base.php");
		
		//load all javascript from the basedir script folder
		igk_js_load_script($this->m_Doc,igk::$BASEDIR."/".IGK_SCRIPT_FOLDER);
		$this->m_Doc->addScript(igk::$BASEDIR."/Lib/tiny_mce/tiny_mce.js", false);
		$this->m_configMenuConf = $this->__loadConfigMenu();
		$this->m_firstUse = true;
		
		
	}
	private function __storeConfigMenu()
	{
		$tab = $this->m_configMenuConf;
		$f = dirname(__FILE__)."/Data/config.menu.xml";
		if (file_exists($f))
		{
			$d = HtmlItem::CreateWebNode("configmenu");
			foreach($tab as $k=>$v)
			{
				$s = $d->add($k);
				
				foreach($v as $c=>$cm)
				{
					$s->add($c)->Content = $cm;
				}
			}		
			igk_io_save_file_as_utf8($f, $out, true);
			// header("Content-Type: application/xml");
			// igk_wl($d->Render());
			// exit;
		}		
		
	}
	private function __loadConfigMenu()
	{
		$tab = array();		
		$f = dirname(__FILE__)."/Data/config.menu.xml";
		if (file_exists($f))
		{
			$d = HtmlItem::CreateWebNode("div");
			$d->Load(file_get_contents($f));
			$e = igk_getv($d->getElementsByTagName("configmenu"), 0);
			$t = null;
			foreach($e->Childs as $k=>$v)
			{
				$s = array();
				foreach($v->Childs as $c=>$m)
				{
					$s[$m->TagName] = $m->innerHTML;
				}
				$tab[$v->TagName] = (object)$s;
			}		
		}		
		return (object)$tab;
	}
	
	public function ViewControllers(){
		IGKControllerManager::getInstance()->ViewControllers();
	}

	public static function NavigateTo($url){
		header("Location: ".$url);
		exit;
	}
	
}

//object management
final class igkOb
{
	public static function Start()
	{
		ob_start();
	}
	public static function Clear()
	{
		ob_end_clean();
	}
	public static function Content()
	{
		ob_get_contents();
	}
}

final class igkException 
{
	public static function GetCallingFunction()
	{
		$e = new Exception();
		$trace = $e->getTrace();
		//position 0 would be the line that called this function so we ignore it
		$last_call = $trace[1];
		print_r($last_call);
	}
}


abstract class IGKQueryResult extends IGKObject
{
	//create an empty entry for this query result
	public function createEmptyEntry(){ return null; }
	//
	public function getRows(){return null;}
	//return the number of columns in the result
	public function getColumns(){return null;}
	//return the number of rows in the result
	public function getRowsCount(){return 0;}
}
final class IGKValidator
{
	private $sm_enode;
	private $sm_cibling;
	
	static $sm_instance;
	private function __construct()
	{	
		$this->sm_enode = HtmlItem::CreateWebNode("error");
		$this->sm_cibling = array();
	}
	public static function getInstance()
	{
		if (self::$sm_instance == null)
			self::$sm_instance = new IGKValidator();
		return self::$sm_instance;
		
	}
	public static function Cibling()
	{
		return self::getInstance()->sm_cibling;
	}
	public static function ContainCibling($name)
	{
		$e = self::getInstance();
		return isset($e->sm_cibling[$name]);
	}
	public static function AddCibling($name)
	{		
		$e = self::getInstance();
		$t =explode(",",$name) ;
		
		foreach($t as $k=>$v){
			$e->sm_cibling[$v]=1;
		}
	}
	public static function Error(){
		$e = self::getInstance();
		return $e->sm_enode;
	}
	public static function Init(){
		$e = self::getInstance();
		$e->sm_enode->ClearChilds();
		$e->sm_cibling = array();		
	}
	public static function Assert($condition, & $error, $node = null, $errormsg="")
	{
		if ($condition)
		{
			$error = $error || true;				
			if ($node!=null)
			{
				$node->add("li")->Content = $errormsg;
			}
		}
	}
	public static function IsStringNullOrEmpty($v)
	{
		return (($v==null) || (is_string($v) && (strlen($v)==0)));
	}
	public static function IsEmail($mail)
	{
		if(self::IsStringNullOrEmpty($mail))
			return false;
		
		return preg_match('/[a-z0-9\.\-_]+@[a-z0-9\.\-_]+\.[a-z]{2,6}$/i',  $mail);  
      
	}
	public static function IsInt($v){
		return is_numeric($v);
	}
	public static function IsDate($v){
	}
	public static function IsFloat($v){
		return is_float($v);
	}
	public static function IsDouble($v){
		return is_Double($v);
	}
	public static function IsString($v)
	{
		return is_string($v);
	}
	public static function IsUri($v){
		
		if (empty($v))
			return false;		
		
		$r = preg_match('/^((http(s){0,1}):\/\/([\w\.0-9]+)|(\?))/i',  $v);  
		//igk_wln("check is uri : ". $r . " ".$v);
		return $r;
		
	}
	public static function IsFtpUri($v)
	{}
	public static function IsHtmlUri($v)
	{
	}
}

//@@@ igkServerInfo: Represent the server utility method
final class igkServerInfo
{
	//@@@ get if this server runing on the loal server
	public static function IsLocal()
	{			
		$v_saddr = self::ServerAddress();
		$v_srddr = self::RemoteIp();
		
		$v = ($v_srddr == "::1") || ($v_saddr == $v_srddr ) || IGKString::StartWith($v_srddr, "192.168");
		return $v;
	}
	public static function ServerAddress(){return  igk_gettv( igk_getv($_SERVER,"SERVER_ADDR"), null); }
	public static function RemoteIp(){return igk_gettv(igk_getv($_SERVER, "REMOTE_ADDR"),null); }
	
	public static function IsIGKDEVSERVER(){
		$r = igk_getv($_SERVER, "HTTP_USER_AGENT");
		if (strstr($r, IGK_SERVERNAME))
		{
			return true;
		}
		return false;
	}
}

class IGKUserAgent{
	const REGEX_ANDROID = "android";
	const REGEX_ANDROID_VERSION = "android\s+(?P<version>[0-9\.]+);";
	const REGEX_ANDROID_MODELNUMBER = "android\s+(?P<version>[0-9\.]+);\s*(?P<model>[\w0-9\.]+)\s*";
	const REGEX_ANDROID_BUILDNUMBER = "android\s+(?P<version>[0-9\.]+);\s*(?P<model>[\w0-9\.]+)\s+build\/(?P<buildnumber>[a-z0-9\.]+)";
	
	public static function Agent(){ return igk_getv($_SERVER, "HTTP_USER_AGENT"); }
	public static function IsAndroid(){
		$regex = "/".self::REGEX_ANDROID."/i";
		return preg_match( $regex,  self::Agent());
	}
	
	
	
	public static function GetAndroidVersion(){
		if (self::IsAndroid()){
		
			$regex = "/".self::REGEX_ANDROID_VERSION."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);
				
			return $tab["version"][0];
		}
		return null;
	}
	public static function GetAndroidModel(){
		if (self::IsAndroid()){
			$regex = "/".self::REGEX_ANDROID_MODELNUMBER."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);	
			return $tab["model"][0];
		}
		return null;
	}
	public  static function GetAndroidBuildNumber(){
		if (self::IsAndroid()){
			$regex = "/".self::REGEX_ANDROID_BUILDNUMBER."/i";
			$tab = array();
			preg_match_all( $regex,  self::Agent() ,$tab);	
			return $tab["buildnumber"][0];
		}
		return null;
	}
	public static function GetDefaultLang(){
		$regex = "/^(?P<name>\w+),*/i";
			$tab = array();
			preg_match_all( $regex,  $_SERVER["HTTP_ACCEPT_LANGUAGE"] ,$tab);	
			return $tab["name"][0];
	}
	
	public static function IsIE()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
		{
			if (strstr($_SERVER["HTTP_USER_AGENT"],"MSIE"))
				return true;
			return false;		
		}
		return false;
	}
	public static function IsIOS(){		
		return false;
	}
	public static function IsChrome()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
		{
			if (strstr($_SERVER["HTTP_USER_AGENT"],"Chrome"))
				return true;
			return false;		
		}
		return false;
	}
	public static function GetChromeVersion()
	{
		if (self::IsChrome())
		{
			$v_r= "/Chrome\/\s*(?P<version>[0-9\.]+)\s/i";			
			$tab = array();
			preg_match_all( $v_r,  self::Agent() ,$tab);							
			return $tab["version"][0];
		}
		return null;
	}
	public static function IsSafari()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
			{
				if (strstr($_SERVER["HTTP_USER_AGENT"],"Safari"))
					return true;
				return false;		
			}
			return false;
	}
	public static function GetSafariVersion()
	{
		if (self::IsSafari())
		{
			$v_r= "/Safari\/\s*(?P<version>[0-9\.]+)\s*/i";			
			$tab = array();
			preg_match_all( $v_r,  self::Agent() ,$tab);							
			return $tab["version"][0];
		}
		return null;
	}
	public static function IsMod()
	{
		if (isset($_SERVER["HTTP_USER_AGENT"]))
			{
				if (strstr($_SERVER["HTTP_USER_AGENT"],"Firefox"))
					return true;
				return false;		
			}
			return false;
	}
	
}

///represent a event method pointer
class IGKEvents extends IGKObject
{
	private $m_methods;
	private $m_singlemethod;
	private $m_owner;
	private $m_name;
	
	var $DEBUG ;
	public function getOwner(){return $this->m_owner;}
	public function getName(){return $this->m_name; }
	public function __toString(){
		return "Events ".$this->m_name." for [". get_class($this->m_owner)."]";
	}
	///@@@ get the number of method in this events
	public function getCount()
	{
		return count($this->m_methods);
	}
	public function __construct($owner, $name, $single=false)
	{
		$this->DEBUG = false;
		$this->m_owner = $owner;
		$this->m_methods =  array();
		$this->m_singlemethod = $single;
		$this->m_name = $name;
	}
	public function Clear()
	{
		unset($this->m_methods);
		$this->m_methods = array();
	}
	public function add($class, $method)
	{
		if ($this->m_singlemethod)
		{
			if ($this->Count() >= 1)
			{
				$this->Clear();
			}
		}
		$_info  = IGKAppMethod::Create($class, $method);
		if ($_info)
		{
			if (!$_info->IsRegistered($this->m_methods))
			{
				$this->m_methods[]= $_info;
				$_info->setParentEvent($this);
				return $_info;		
			}
		}
		
	}
	//remove menthod
	public function remove($class, $method)
	{
		for($i = 0 ; $i<count($this->m_methods) ; $i++)
		{
			$k = $this->m_methods[$i];
			if ($k->match($class, $method))
			{
				$meth = $this->m_methods[$i];
				unset($this->m_methods[$i]);
				$this->m_methods = array_values($this->m_methods);
				$k->setParentEvent(null);
				break;
			}
		}
	}
	public function Call($sender, $args)
	{
		
		if ($this->m_methods)
		{
			foreach($this->m_methods as $k=>$v)
			{
				igk_debug("call method for ".$v);				
				$v->Invoke($sender, $args);
			}
		}
	}
	
	
}
///<summary>
///represent a language key entries. it support IHtmlGetValue for getting and setting the values
///<summary>
final class IGKLangKey implements IHtmlGetValue
{
	var $key;
	var $default;
	var $args;
	
	public function __construct($key,$default, $args=null)
	{
		$this->key = $key;
		$this->default = $default;
		$this->args = $args;
	}
	public function __toString(){
		return $this->key;
	}
	public function getValue(){
			
		$s = R::gets($this->key);
		$c = 0;
		if ($this->args != null)
		{
			$macth = array();
			$c = preg_match_all("/\[(?P<value>[0-9]+)\]/i",$s, $match);
			for($i = 0; $i < $c ; $i++)
			{
				$index = $match["value"][$i];
				if (is_numeric($index))
				{
					if (isset($this->args[$index]))
					{
						///TOTOT
						$s = str_replace( $match[0][$i], HtmlUtils::GetValue($this->args[$index]),$s);
					}
				}
			}
		}
			// $c = 0;			
			// $c = preg_match_all("/{(?P<value>[a-zA-Z0-9_\.]+)}/i",$s, $match);
			// if ($c > 0){
			// for($i = 0; $i < $c ; $i++)
			// {
			
				// $key = $match["value"][$i];
				// if (strtolower($key) == strtolower($this->key))
					// continue;
				
				// $s = str_replace( $match[0][$i],R::gets($key),$s);
				
			// }		
			// }
			
		
		return $s;
	}
	
}

final class IGKFormatString implements IHtmlGetValue 
{
	private $m_args;
	private $m_value;
	private function __construct()
	{		
	}
	public static function Create($string)
	{		
			$args = array();
			if (func_num_args() > 1)
			{
				$t = func_get_args();
				for($i=1; $i< count($t) ; $i++)
				{
					$args[] = $t[$i];
				}
			}
			$cfrm = new  IGKFormatString();
			$cfrm->m_args = $args;
			$cfrm->m_value = $string;			
			
			return $cfrm;
	}
	public function getValue()
	{
		$s = $this->m_value;
		if ($this->m_args != null)
		{
			$macth = array();
			$c = preg_match_all("/\[\[(?P<value>[0-9]+)\]\]/i",$s, $match);			
			for($i = 0; $i < $c ; $i++)
			{
				$index = $match["value"][$i];
				if (is_numeric($index))
				{
					if (isset($this->m_args[$index]))
					{
						$m = $this->m_args[$index];
						if (is_string($m))
						{
							$s = str_replace( $match[0][$i], $m ,$s);
						}
						else if (is_object($m) && method_exists(get_class($m), "getValue"))
						{
							$s = str_replace( $match[0][$i], $m->getValue() ,$s);
						}
						else {
							$s = str_replace( $match[0][$i], '' ,$s);
						}
					}
					else{
						$s = str_replace( $match[0][$i], '' ,$s);
					}
				}
			}
			
		}		
		return $s;
	}
	
	public function __toString(){
		return $this->getValue();
	}
}

final class IGKFormatGetValueString extends IGKObject implements IHtmlGetValue
{
	private $m_obj;
	private $m_member;
	private function __construct(){
	}
	public static function Create($obj, $property)
	{
		if (!is_object($obj))
			return null;
		
		$out = new IGKFormatGetValueString();
		$out->m_obj = $obj;
		$out->m_member = $property;
		return $out;
	}
	public function getValue()
	{
		$c = $this->m_member;
		$v = $this->m_obj->$c;
		return HtmlUtils::GetValue($v);
	}
	public function __toString(){
		return "IGKFormatGetValueString::"+$this->getValue();
	}
}

//--------------------------------------------------------------------
//### Represent a APP METHOD.
//--------------------------------------------------------------------
final class IGKAppMethod
{
	private $_class;
	private $_object;
	private $_methodname;
	private $_index;
	private $_type;
	private $_parentEvent;
	private $_func; // for closure function
	
	const OBJECT_METHOD =  1;
	const CLASS_METHOD = 2;
	const FUNCTION_METHOD = 3;
	const OBJECT_METHOD_CLOSURE = 4;
	public function getParentEvent(){return $this->_parentEvent; }
	public function setParentEvent($event){ $this->_parentEvent = $event; }
	
	private function _typeToString()
	{
		switch($this->_type)
		{
			case self::OBJECT_METHOD:
					return "OBJECT_METHOD";
			break;
			case self::CLASS_METHOD:
					return "CLASS_METHOD";
			break;
			case self::FUNCTION_METHOD:
					return "FUNCTION_METHOD";
			break;
			case self::OBJECT_METHOD_CLOSURE:
				return "CLOSURE_METHOD";
				break;
				
		}
	}
	public function __toString(){
		$v_pattern = "";
		switch($this->_type)
		{
			case self::OBJECT_METHOD:
					return "IGKAppMethod[".$this->_type."::".$this->_object."::".$this->_methodname."]";
			break;
			case self::CLASS_METHOD:
					return "IGKAppMethod[".$this->_type."::".$this->_class."::".$this->_methodname."]";
			break;
			case self::FUNCTION_METHOD:
					return "IGKAppMethod[".$this->_type."::".$this->_methodname."]";
					break;
			case self::OBJECT_METHOD_CLOSURE:
					$v_pattern = "CLUSURE =&gt; ".$this->_type;
					break;
		}
		return "IGKAppMethod[".$v_pattern ."]";
	}
	private  function __construct()
	{
		$this->_class =null;
		$this->_methodname= null;
	}
	public function match($class_or_object, $method)
	{
			switch($this->_type)
		{
			case self::OBJECT_METHOD:
				return (($class_or_object === $this->_object) &&  ($this->_methodname == $method));
			break;
			case self::CLASS_METHOD:
				//return call_user_func(array($this->_class, $this->_methodname), $sender, $args);
			break;
			case self::FUNCTION_METHOD:
				return ($this->_methodname == $method);
			break;
			case self::OBJECT_METHOD_CLOSURE:
						
					break;
		}
		return (($class_or_object === $this->_class) &&  ($this->_methodname == $method));
	}
	public static function Create($class_or_object,& $method)
	{
	
		$c = $class_or_object;
		$out = null;
		if (is_object($c))
		{
		
			if (is_string($method))
			{
				if (method_exists($c, $method))
				{
					//create a objet IGKAppMethod
					$out = new IGKAppMethod();
					$out->_type = self::OBJECT_METHOD;
					$out->_methodname = $method;
					$out->_class = get_class($c);
					$out->_object = $c;
				}
			 }
			
		}
		else {
			if (class_exists($c))
			{
				
				if (method_exists($c, $method))
				{
				
					$out = new IGKAppMethod();
					$out->_type = self::CLASS_METHOD;
					$out->_methodname = $method;
					$out->_class = $c;
				}
			
			}
			else if (function_exists($c))
			{
					$out = new IGKAppMethod();
					$out->_type = self::FUNCTION_METHOD;
					$out->_methodname = $method;
					
			}
		}
			
		return $out;
	}
	public function Invoke($sender, $args)
	{
		
		//----------------------------------------------------------------------------
			try{
				switch($this->_type)
				{
					case self::OBJECT_METHOD:						
						return call_user_func_array(array($this->_object, $this->_methodname), array($sender, $args));
						
					break;
					case self::CLASS_METHOD:
						return call_user_func_array(array($this->_class, $this->_methodname), array($sender, $args));
					break;
					case self::FUNCTION_METHOD:
						return call_user_func($this->_methodname, $sender, $args);
					break;
				}
		}
				catch(Exception $ex){
					igk_show_exception($ex);
					igk_wln("IGKAppMethod::Invoke exception raised Method:[".$this->_typeToString()." ; ".$this->_methodname."]" . $this->__toString());
					igk_wln("error .... ");
					exit;
				}
	}
	public function IsRegistered($tab)
	{
	if ($tab==null)return false;
		foreach($tab as $k=>$v)
		{
			if ($v === $this)
			{
				return true;
			}
		}
		return false;
	}
}

class igkSetting extends IGKObject
{
	public $m_setting;
	
	public static function IsConfigured(){
		return true;
	}
	public static function LoadSetting(){
		
	}
	public function initSetting(){
		
	}
}

//--------------------------------------------------------------------------------------------------------
//IO utils class
//--------------------------------------------------------------------------------------------------------
final class IGKIO{


	public static function CopyFiles($inputDir, $outputDir , $recursive=false, $overwrite=false)
	{
		$hdir = opendir($inputDir);
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;	
				$f = self::GetDir($inputDir . DIRECTORY_SEPARATOR . $r);
				$p  = self::GetDir($outputDir .DIRECTORY_SEPARATOR . $r);
				
				if (file_exists($p) ==false)
					copy($f, $p);
				
			}
			closedir($hdir);
		}
	}
	public static function GetFiles($dir, $match, $recursive=false)
	{
		if (is_dir($dir) === false)
			return null;
		
		$v_out = array();
		
		$hdir = @opendir($dir);
		
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;
				$f = $dir . DIRECTORY_SEPARATOR . $r;
				if (is_file($f) && (($match==null) || (($match!=null) && ( preg_match($match, $f)))))
				{
						$v_out[] = $f;				
				}
				else if(is_dir($f) && $recursive)
				{
					foreach(IGKIO::GetFiles($f, $match, $recursive) as $k)
					{
						$v_out[] = $k;				
					}
				}
			}
			closedir($hdir);
			
		}	
		
		return $v_out;
		
	}
	//utility fonction get picture files
	public static function  GetPictureFile($dir, $recursive=true)
	{
		if (is_dir($dir) === false)
			return null;
		$tab = array();
		$tdir = array();
		$hdir = opendir($dir);
		if ($hdir)
		{
			while(($r = readdir($hdir)))
			{
				if ($r=="." || ($r==".."))continue;
				$f = $dir . DIRECTORY_SEPARATOR . $r;
				if (is_file($f) )
				{
					$ext = strtolower(IGKIO::GetFileExt($f));
					
					switch($ext)
					{
						case "png":
						case "jpeg":
						case "jpg":
						case "ico":
							$tab[] = $f;
							break;
						
					}
				}
				else if(is_dir($f))
				{
					$tdir[] = $f;
				}
			}
			closedir($hdir);
		}
		if ($recursive){
			foreach($tdir as $k)
			{
				$m= self::GetPictureFile($k);
				if ($m!=null){
					$tab = array_merge($tab, $m);
				}				
			}
		}		
		return $tab;
	}
	public static function GetFileSize($size)
	{
		if ($size == 0)
			return "0 Bytes";
		$sizes = array('Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
		return (round($size/pow(1024, ($i = floor(log($size, 1024)))), 2) . ' ' . $sizes[$i]);

	}
	public static function IsDirEmpty($dir)
	{
		if (!is_dir($dir))
			return true;
		
		$hdir = @opendir($dir);
		if ($hdir)
		{
			$empty = true;
			while( $s = readdir($hdir))
			{
				if (($s==".") || ($s==".."))
					continue;
				$empty = false;
				break;
			}
			closedir($hdir);
			return $empty;
		}
		else{
			igk_debug("warning:impossible d'ouvir le repertoire : ".$dir);
		}
		return true;
	}
	//return a directory list
	public static function GetDirList($folder)
	{
		if (!is_dir($folder))
			return false;
		$dirs = array();
			$hdir = opendir($folder);
			if ($hdir)
			{
				while( ($cdir=readdir($hdir)))
				{
					if (($cdir== ".") || ($cdir==".."))
						continue;
					$f = self::GetDir($folder."/".$cdir);
					if (is_dir($f))
					{
						$dirs[] = $f;
					}
				}
				closedir($hdir);
			}
		return $dirs;
	}
	
	//return a directory file list
	public static function GetDirFileList($folder)
	{
		if (!is_dir($folder))
			return false;
		$dirs = array();
			$hdir = opendir($folder);
			if ($hdir)
			{
				while( ($cdir=readdir($hdir)))
				{
					if (($cdir== ".") || ($cdir==".."))
						continue;
					$f = self::GetDir($folder."/".$cdir);
					if (is_file($f))
					{
						$dirs[] = $f;
					}
				}
				closedir($hdir);
			}
		return $dirs;
	}
	public static function GetCurrentDir()
	{
		// $tb = get_included_files();
		// return dirname($tb[0] );
		return getcwd();
	}
	public static function RemoveFirstDirectorySeparator($dir)
	{
		while((!empty($dir) && ($dir[0] == DIRECTORY_SEPARATOR)))
		{
			$dir = substr($dir, 1);
		}
		return $dir;
	}
	public static function CreateDir($dirname, $mode=0777){
		if (is_dir($dirname) === true)
			return true;
		//try to create the directory
		if (@mkdir($dirname, $mode))
		{
			//try to chane chmod dir to creation mask
			@chmod($dirname, IGK_DEFAULT_FOLDER_MASK);
			return true;
		}
		else{
			$d = dirname($dirname);
			if (is_dir($d)){
				//parent create can't create on directory
				return false;
			}
			else{
				if (self::CreateDir($d, $mode))
				{
					//create the current directory
					if (@mkdir($dirname, $mode))
					{
						//try to chane chmod dir to creation mask
						@chmod($dirname, IGK_DEFAULT_FOLDER_MASK);
						return true;
					}
				}
			}
			
		}
		igk_notifyctrl()->addEror( R::ngets("ERR.CANTCREATEDIR",$dirname));
		throw new Exception("error when creating directory:CreateDir failed : ".$dirname);
		exit;
		
	}
	///<summary> Create a directory recursivily</summary>
	///<dir>directory to create</dir>
	///<root>mus add a as directory separator </root>
	///<return>-1 if dir is empty, </return>
	public static function CreateRDir($dir, $root=false)
	{
		if (empty($dir))
		{
			return -1;
		}
		if (is_dir($dir))
			return 1;
		$d = explode(DIRECTORY_SEPARATOR, igk_io_getdir($dir));
		$s = "";
		for($i=0 ; $i<count($d);$i++)
		{
			if ($root || ($i>0))
			{
				$s .= DIRECTORY_SEPARATOR;
			}
			$s.=$d[$i];
			//igk_wln($s);
			if ( empty($s)  || is_dir($s))
				continue;				
			if(!@mkdir($s))
				return false;
		}
		return true;
	}
	public static function WriteToFileAsUtf8WBOM($filename, $content, $overwrite = true, $chmod = IGK_DEFAULT_FILE_MASK)
	{
		$r = igk_ansi2utf8(utf8_encode($content));
		return self::WriteToFile($filename, $content, $overwrite, $chmod);
	}
	///<summary>write text to a file</summary>
	///<remarks>return true if success. or throw exception</remarks>
	public static function WriteToFile($filename, $content, $overwrite = true, $chmod = IGK_DEFAULT_FILE_MASK)
	{	
		$filename = igk_io_getdir($filename);
		
		if (!is_dir (dirname($filename)))
		{
			if (!IGKIO::CreateDir(dirname($filename)))
				return false;
		}
		
		
		if (is_file($filename) && !$overwrite){
			return false;
		}
		$hf = @fopen($filename, "w+");
		if (!$hf)
		{
			return false;
		}
		
		//write content as utf-8
		fwrite($hf, $content);
		fflush($hf);
		fclose($hf);	
		if ($chmod)	{	
			if (!@chmod($filename, $chmod))			
			{
				igk_notify_error("chmodfailed: " . $filename. " : ".$chmod);
			}
			
		}
		return true;
	}
	public static function ReadAllText($filename)
	{
		if (file_exists($filename) == false)
			return null;
		//file size all error
		$fsize = @filesize($filename);
		$str = @file_get_contents($filename);
		return $str;
		
	}
	

	public static function GetFileName($filename)
	{
		$pathinfo = pathinfo($filename);
		$b = $pathinfo["basename"];
		return $b;
	}

	public static function GetFileExt($filename)
	{
		$pathinfo = pathinfo($filename);
		

		try{
		if (isset($pathinfo["extension"]))
			return $pathinfo["extension"];
		}
		catch(Exception $exception)
		{
			die ($filename);
		}
		return null;
	}	

	///@@@ --------------------------------------------------------------------
	///@@@ tranforme le repertoire passer en paramà¨tre en une chemin compatible
	///@@@ celon le systeme d'exploitation serveur
	///@@@ --------------------------------------------------------------------
	public static function GetDir($dir)
	{
		$d = DIRECTORY_SEPARATOR;
		$r = '/';
		$out = "";
		
		if (ord($d) == 92)
			$out =preg_replace("/\//", '\\', $dir);
		else
			$out =preg_replace('/[\\\]/', '/', $dir);
		return $out;
	}
	
	///----------------------------------------------------------
	///return the formatted base directory according to base path
	///----------------------------------------------------------
	///DIRECTORY FUNCTION 
	public static function GetBaseDir($dir=null)
	{
		if ($dir)
		{
			return self::GetDir(igk::$BASEDIR.DIRECTORY_SEPARATOR.$dir);
		}
		return self::GetDir(igk::$BASEDIR);
	}
	//get the base uri according to local specification
	public static function GetBaseUri($dir=null, $secured=false)
	{
		$out = "";
		$v_dir = self::GetBaseDir($dir);
		$root = $_SERVER["DOCUMENT_ROOT"];
		$t = substr($v_dir, strlen($root));
		if ($secured){
			$out = 'https://';
		}
		else{
			$out = 'http://';
		}
		
		$out .= igk_str_join(igk_str_rm_last($_SERVER["SERVER_NAME"],'/').self::GetPort(),igk_str_rm_start(igk_html_uri($t), '/'),'/');
		
		//sample		
		$out = str_replace('\\','/', $out);
		return $out;
	}
	private static function GetPort(){
	
		$port = "";
		$port = igk_getv($_SERVER, "SERVER_PORT");
		if (!empty($port))
			$port = ":".$port;
		return $port;
	}
	//get root uri
	public static function GetRootUri($uri="", $secured=false )
	{		
		$root = $_SERVER["DOCUMENT_ROOT"];
		if ($secured){
		$out = 'https://';
		}
		else{
		$out = 'http://';
		}
		$out .= igk_str_join(igk_str_rm_last($_SERVER["SERVER_NAME"],'/').self::GetPort(),igk_str_rm_start($uri, '/'),'/');
		//sample
		
		$out = str_replace('\\','/', $out);
		return $out;
	
	}
	//return relative uri from server requested URI
	/*
	Exemple : GetCurrentRelativeUri("test") will return 
	
	*/
	public static function GetCurrentRelativeUri($dir= "")
	{
		//event from uri		
		$r_uri = igk_getv(explode("?",$_SERVER["REQUEST_URI"]),0);
		$v_isdir = IGKString::EndWith($r_uri, '/');
		$cdir = IGKIO::GetDir(IGKIO::GetRootUri(igk_str_rm_last($r_uri,'/')));
		$bdir = IGKIO::GetDir(igk_io_baseuri());
		$dir = IGKIO::GetDir($dir);
		$i = -1;
		
		if ($bdir == $cdir)
			return self::GetRootRelativePath($dir);

		//get the current directory according to BASEDIR
		$i = IGKString::IndexOf($cdir, $bdir);
		if ($i!= -1){
			$cdir = substr($cdir, $i + strlen($bdir));
		}	
		//build dir according to path
		$i = IGKString::IndexOf($dir, $bdir);
		if ($i!= -1){
			$dir = substr($dir, $i + strlen($bdir));
		}		
		//remove the first directory separator
		$dir = IGKIO::RemoveFirstDirectorySeparator($dir);
		$cdir = IGKIO::RemoveFirstDirectorySeparator($cdir);
		
		$t = count(explode(DIRECTORY_SEPARATOR, $cdir));
		if (($t>0 ) && (!$v_isdir))
		{
			$t--;
		}
		for($i = 0; $i< $t; $i++)
		{			
			$dir= "..".DIRECTORY_SEPARATOR.$dir;			
		}	
		
		return $dir;
	}
	//@get the root dir according to document root. uses for css script file
	//@@@ dir : dir according to
	//<exemple>(test) == SERVER["Document_ROOT"]-/+ test</exemple>
	public static function GetRootBaseDir($dir=null)
	{
		//get the current base directory
		$s = self::GetBaseDir();
		$s  = str_replace("\\","/", $s);
		$doc = str_replace("\\","/",$_SERVER["DOCUMENT_ROOT"]);		
		$dir =  str_replace("\\","/", $dir);		
		
		if (strlen( $s) >0)
		{
		if ($s[0] == "/")
		{
			//linux implementation
			$s = strstr($s, $doc);
			$s  = trim(substr($s, strlen($doc)));
			if((strlen($s) > 0) && ($s[0] != "/"))
				$s = "/".$s;							
		}
		else{		
			$s  = "/".substr($s, strlen($doc));		
			
		}
		}
		if ($dir)
		{
			if ($s == "/")
				$s = "";
		
			if (IGKString::StartWith("/",$dir))
				$s .= $dir;					
			else
				$s .= "/".$dir;								
		}
		return $s;
	}
	//retrieve the relative path according the directory
	public static function GetChildRelativePath($source, $destination, $separator  = DIRECTORY_SEPARATOR)
	{
		$doc_root = $source;
		$dir = $destination;
		$i = IGKString::IndexOf($dir,$doc_root);
		if ($i!= -1)
		{
			//root document found in dir path 
			$dir = substr($dir, $i + strlen($doc_root));
		}	
		//not found 
		$dir = str_replace(self::GetRootBaseDir(),"", $dir);		
		while( (strlen($dir)>0) && ($dir[0] == DIRECTORY_SEPARATOR))
		{
			$dir = substr($dir, 1);
		}
		return empty($dir)?null:self::__fixPath($dir);
	}
	private static function __fixPath($path, $separator = DIRECTORY_SEPARATOR)
	{
		if ($separator == "/")
		{
			$path = preg_replace('/([\/]+)/i', '/', $path);
			
		}
		else 
			$path = preg_replace('/([\\'.$separator.']+)/i', ''.$separator.'', $path);
		return $path;
	}
	//@@@ get relative path according to the DOCUMENT_ROOT
	//@@@ dir = must be a full path to an existing file or directory 
	public static function GetRootRelativePath($dir, $separator = DIRECTORY_SEPARATOR)
	{
		// if (!is_dir($dir) && is_file($dir))
			// return null;
		$doc_root = self::GetDir( $_SERVER["DOCUMENT_ROOT"]);		
		$i = IGKString::IndexOf($dir,$doc_root);

		
		if ($i!= -1)
		{
			//root document found in dir path 
			$dir = substr($dir, $i + strlen($doc_root));
		}
		//not found 
		$dir = str_replace(self::GetRootBaseDir(),"", $dir);		
		while( (strlen($dir)>0) && ($dir[0] == DIRECTORY_SEPARATOR))
		{
			$dir = substr($dir, 1);
		}
		return empty($dir)?null:self::__fixPath($dir);
	}
	//@@@ get relative path according to igk::BASEDIR from base dir
	//@@@ @dir: absolute path or basedir relative path
	public static function GetCurrentDirRelativePath($dir, $separator = DIRECTORY_SEPARATOR)
	{
	$doc = IGKIO::GetDir( $_SERVER["DOCUMENT_ROOT"]);
		$cdir = IGKIO::GetCurrentDir();
		$bdir = IGKIO::GetBaseDir();
		$dir = IGKIO::GetDir($dir);
		$i = -1;
		
		if ($bdir == $cdir)
			return self::GetRootRelativePath($dir);
		
		//get the current directory according to BASEDIR
		$i = IGKString::IndexOf($cdir, $bdir);//$doc);
		if ($i!= -1){
			$cdir = substr($cdir, $i + strlen($bdir));
		}	
		//build dir according to path
		$i = IGKString::IndexOf($dir, $bdir);
		if ($i!= -1){
			$dir = substr($dir, $i + strlen($bdir));
		}		
	
		//remove the first directory separator
		$dir = IGKIO::RemoveFirstDirectorySeparator($dir);
		$cdir = IGKIO::RemoveFirstDirectorySeparator($cdir);
		
		$t = count(explode(DIRECTORY_SEPARATOR, $cdir));
		
		for($i = 0; $i< $t; $i++)
		{			
			$dir= "..".DIRECTORY_SEPARATOR.$dir;			
		}
		//remove dual separator		
		return empty($dir)?null:IGKIO::__fixPath($dir);
		
	}

	//retrieve the relative page
	public static function GetRelativePath($sourcepath, $targetdir, $separator = DIRECTORY_SEPARATOR)
	{
		$dir = $sourcepath;
		$cdir = $sourcepath;
		$bdir = $targetdir;
		$i = -1;		
		$c = 0;
		$tsdir = explode(DIRECTORY_SEPARATOR, $cdir);
		$tbdir = explode(DIRECTORY_SEPARATOR, $bdir);
		$rstep = false;
		while(($c< count($tbdir)) && ($c< count($tsdir)))
		{
			if ($tbdir[$c]!=$tsdir[$c])
			{
				$rstep = true;
				break;
			}
			$c++;
		}
		$s = "";
		if ($rstep)
		{	
			for($h = $c; $h< count($tbdir) ; $h++)
			{
				$s .= "..".DIRECTORY_SEPARATOR;
			}
			
		}
		for($h = $c; $h< count($tsdir) ; $h++)
			{
				if ($h>$c)
					$s .= DIRECTORY_SEPARATOR;
				$s .= $tsdir[$h];
			}			
		return $s;
		
	}
	
	/*
	GET BASE FOLDER FULLPATH
	Exemple: GetBaseFolderFullpath("test") == BASEDIR+"/test"
	*/
	public static function GetBaseFolderFullpath($dir)
	{
		$d = igk::getInstance()->CurrentPageFolder;
		if (!empty($d) && ($d!=IGK_HOME_PAGEFOLDER))
			return igk_io_getdir(igk_io_currentRelativePath(igk::$BASEDIR ."/".$d."/".$dir));
		return igk_io_getdir(igk_io_currentRelativePath(igk::$BASEDIR ."/".$dir));
	}


	/*
	REMOVE FOLDER
	*/
	public static function Rmdir($dir, $recursive=true)
	{
		if (!is_dir($dir))
			return false;
		if (@rmdir($dir))
			return true;
		if (!$recursive)
			return false;
		$hdir = opendir($dir);
		if (!$hdir)
			return false;
		while( ($f =  readdir($hdir)))
		{
			if (($f=="." ) || ($f==".."))
				continue;
			$v = igk_io_getdir($dir."/".$f);
			if (is_dir($v))
			{
				if (self::Rmdir($v,$recursive) == false)
				{				
					return false;
				}
			}
			else if (is_file($v))
			{
				unlink($v); //remove file
			}	
		}
		closedir($hdir);
		return @rmdir($dir);
	}



}
//-----------------------------------------------------------------------
//represent a string utility class
//-----------------------------------------------------------------------
class IGKString{
	public static function IndexOf($chaine, $research, $offset=0)
	{
		if (empty($chaine) || empty($research))
			return -1;	
		$i = strpos($chaine, $research, $offset);
		if ($i === false)
		return -1;
		return $i;
	}
	//@personal sub
	public static function Sub($chaine, $start, $length=null)
	{
		if ($length)
		{
			return substr($chaine, $start, $length);
		}
		else 
			return substr($chaine, $start);
	}
	public static function StartWith($chaine, $pattern)
	{
		return (self::IndexOf($chaine, $pattern) == 0);
	}
	public static function EndWith($chaine, $pattern)
	{
		$chaine=trim($chaine);
		$c = strlen($chaine);
		$p = strlen($pattern);
		$i = strripos($chaine, $pattern);
		if ($i === false)
		{
			return false;
		}
		if (($i != -1) && ( ($i+$p)=== $c))
			return true;
		return false;
	}
	public static function Trim($chaine)
	{
		return trim($chaine);
	}
	public static function Contains($text, $pattern){
		if (!empty($pattern))
			return (strstr($text, $pattern) != null);
		return true;
	}
}

//------------------------------------------------------------------------------------------
//IGK Object Definition
//------------------------------------------------------------------------------------------
///
///<summary>Represent the base IGK object class </summary>
///
class IGKObject
{
	private $m_cmpObj;
	
	//used to dispose and release element
	public function Dispose(){
		
	}
	public function CompareTo($obj)
	{
		$this->m_cmpObj = igk_new_id();
		$r  = ($this->m_cmpObj == $obj->m_cmpObj);
		$this->m_cmpObj = null;
		return $r;
	}
	
	//override this method to filter call of global method
	//used to call internal function 
	public function Invoke($method, $args=null)
	{
		if (method_exists($this, $method))
		{
			if (($args == null) || (is_array($args )))
			{
				$this->$method($args);
			}
			else{
				call_user_func_array(array($this, $method), array($args));
			}
		}
	}
	
	protected function _setIn($name, & $value)
	{
		if (method_exists($this, "set".$name) )
		{					
				call_user_func(array($this, "set".$name), $value);
				return true;
		}
		return false;
	}
	public function __set($name,$value)
	{
		$this->_setIn($name, $value);
	}
	
	public function __get($key)
	{
		if (method_exists($this, "get".$key) )
		{					
				return call_user_func(array($this, "get".$key), null);
		}
		return null;
	}
	public function __toString(){
		return get_class($this);
	}
	public function regEvent($name, $value)
	{
		//add event
		if (AppString::IndexOf($name, "add") == 0)
		{
			$event = substr($name,3)."Event";					
			if ($this->ContainVars($event))
			{
				if ($this->$event == null)
				{
					$this->$event = new IGKEvents($this, $event);
				}
				$this->$event->add($value[0],$value[1]); 
				return true;
			}				
		}
		//remove event
		if (AppString::IndexOf($name, "remove") == 0)
		{
			$event = substr($name,6)."Event";					
			if ($this->ContainVars($event))
			{
				if ($this->$event != null)
				{
				$this->$event->remove($value[0],$value[1]); 	
				}						
				return true;
			}				
		}
	}

	public function callEvent($event, $method)
	{
		if (($event!=null) && ($event->Owner==$this))
		{
			$this->$method();
		}
	}
}

//color float
class IGKColorf extends IGKObject
{
	private $m_R;
	private $m_G;
	private $m_B;
	private $m_A;
	
	
	public function getR(){ return $this->m_R; }
	public function getG(){ return $this->m_G; }
	public function getB(){ return $this->m_B; }
	public function getA(){ return $this->m_A; }
	
	public function setR($value){ if (($value>=0) && ($value<=1.0)) $this->m_R = $value; }
	public function setG($value){ if (($value>=0) && ($value<=1.0)) $this->m_G = $value; }
	public function setB($value){ if (($value>=0) && ($value<=1.0)) $this->m_B = $value;}
	public function setA($value){ if (($value>=0) && ($value<=1.0)) $this->m_A = $value; }
}
//color byte
class IGKColor extends IGKObject
{
	private $m_R;
	private $m_G;
	private $m_B;
	private $m_A;
	
	public static function Black(){ return self::FromFloat(0.0);}
	public static function White(){ return self::FromFloat(1.0);}
	
	public function getR(){ return $this->m_R; }
	public function getG(){ return $this->m_G; }
	public function getB(){ return $this->m_B; }
	public function getA(){ return $this->m_A; }
	
	public function setR($value){ if (($value>=0) && ($value<=255)) $this->m_R = $value; }
	public function setG($value){ if (($value>=0) && ($value<=255)) $this->m_G = $value; }
	public function setB($value){ if (($value>=0) && ($value<=255)) $this->m_B = $value;}
	public function setA($value){ if (($value>=0) && ($value<=255)) $this->m_A = $value; }
	public function __construct($r, $g, $b, $a)
	{
		$this->m_R = $r;
		$this->m_G = $g;
		$this->m_B = $b;
		$this->m_A = $a;
	}
	public static function FromFloat($rgb, $g=null, $b=null,$a=null)
	{
		if ($g==null)
			return new IGKColor($rgb * 255,$rgb*255, $rgb*255, 255);
		return new IGKColor($rgb * 255,$g*255, $b*255, $a);
	}

}


//------------------------------------------------------------------------------------------
//HTML DEFINITION
//------------------------------------------------------------------------------------------

//represent a html options
class HtmlOptions
{
	//indicate that the tag must be closed with  "/>"
	static $MustCloseTag = array(
	"br"=>"br",
	"link"=>"link",
	"input"=>"input",
	"meta"=>"meta",	
	"img"=>"img",
	//"script"=>"script"	
	"source"=>"source",
	"embed"=>"embed"
	);
	static $DualCloseTag = array("option"=>"option", "object");
	
	static $closeWithCloseTags =array(
		"div"=>"div",
		"form"=>"form",
		"script"=>"script",
		"noscript"=>"noscript",
		"html"=>"html",
		"body"=>"body",
		"head"=>"head"
	);
	
}
class HtmlAttributeCollections 
extends IGKObject
implements ArrayAccess, Iterator
{
	private $m_attributes;
	private $m_owner;
	// get the total number of attributes
	
	public function Dispose()
	{//dispose elements 
		igk_debug_wln("dispose attributes");
		//$t = $this->ToArray();
		// foreach($t as $k)
			// $k->Dispose();
		//unset($this->m_attributes);
		//init empty array
		
		//$this->m_attributes = array();
	}
	public function getCount(){return count($this->m_attributes);}
	public function __construct($owner){
		if (($owner === null) || !is_object($owner) || (is_object($owner) && !is_subclass_of(get_class($owner), "HtmlItemBase")))
			throw new Exception("owner must be a HTML Item Base");
		$this->m_owner = $owner;
		$this->m_attributes = array();
	}
	public function toArray(){		
			return $this->m_attributes;		
	}
	//clear attribute
	public function clear()
	{
		$this->m_attributes = array();
	}
	//iterator
	public function __toString(){
		return "HtmlAttributeCollections [".$this->getcount()."] ";
	}
	private $it_index;//value tab index
	private $it_key; //key index
	private $it_vtab;//keys value tab
	function current(){ return $this->m_attributes[$this->it_key];}
	function next(){
		$this->it_index++;
		if ( $this->it_index < count($this->it_vtab))
		{		
			$this->it_key  = $this->it_vtab[$this->it_index]; 
		}
	}
	function key(){ return $this->it_key;}
	
	function valid(){
	
		$v = (($this->it_index >= 0) && ($this->it_index < count($this->it_vtab)));	
		
		return $v;
	
	}
	function rewind(){ 
		
		$this->it_vtab = array_keys($this->m_attributes);
		$this->it_index = 0;
		if (count($this->it_vtab)>0)
		$this->it_key = $this->it_vtab[0];		
		else
		$this->it_key  = null;
		
	}
	
	//arrayaccess
	function offsetExists($key){
	return isset($this->m_attributes[$key]);
	}
	function offsetGet($key){
	if (isset($this->m_attributes[$key]))
		return $this->m_attributes[$key];
	}
	function offsetSet($key, $value){
	if (strtolower($key) == "class")
	{
		if ($value ===null)
		{
				unset($this->m_attributes[$key]);
		}
		else{
			if (!isset($this->m_attributes[$key]) || !is_object($this->m_attributes[$key]))
			{
				 $this->m_attributes[$key] = new HtmlClassValueAttribute($this);
			}
			
		    $this->m_attributes[$key]->add($value);
		}
	}
	else {
		if (isset($this->m_attributes[$key]))
		{
			if ($value ===null)
				unset($this->m_attributes[$key]);
			else
				$this->m_attributes[$key] = $value;
		}
		else if ($value !== null)
		{
			$this->m_attributes[$key] = $value;
		}
	}
	}
	function offsetUnset($key){
	unset($this->m_attributes[$key]);
	}	
}

abstract class HtmlItemBase extends IGKObject implements ArrayAccess
{
	private $m_tagName;
	private $m_content;	
	private $m_parent;
	private $m_index;
	
	private $m_IsVisible;

	public function getNodeType(){return XMLNodeType::ELEMENT; }
	public function getIsVisible(){return $this->m_IsVisible;}
	public function setIsVisible($value){$this->m_IsVisible = $value;}
	
	public function getIndex(){return $this->m_index; }
	public function setIndex($value){ $this->m_index = $value; }
	
	public function getTagName(){return $this->m_tagName;}
	public function getContent(){return $this->m_content;}
	public function setContent($value){$this->m_content = $value;}
	public function & getHtmlItemParent(){ return  $this->m_parent;}
	protected function setHtmlItemParent($value){
		$this->m_parent = $value;
	}
	public function __construct($tagname=null)
	{
			$this->m_tagName = $tagname;
			$this->m_IsVisible = true;
			$this->m_content = null;
			$this->m_index = null;
	}
	
	protected function indentLine($option=null){
		if (($option==null) || (!$option->Indent))
			return null;		
		return "\n";
	}
	protected function getDepthIndent(& $options)
	{
		if (($options==null) || (!$options->Indent))
			return null;		
			
		
		$q = $this;
		$s = "";
		$c = -1;
		if (isset($options->ParentDepth)){
			
			while(($q = $q->Parent) && !($options->ParentDepth->CompareTo($q)))
			{
				
				$s .= "\t";
			}			
			
		}
		else{		
			while($q = $q->Parent)
			{
				$s .= "\t";
			}
		}
		return $s;
	}
	///indicate that the element must be closed with close tag. <i></i> not <i /> if empty
	protected function closeWithCloseTag()
	{
		return isset(HtmlOptions::$closeWithCloseTags[$this->getTagName]);
		//return false;
	}
	//@@@ must be overrided
	public function Render($options=null){
	}
	public function RenderAJX(){
		igk_wl($this->Render());
	}
	public function getinnerHTML($options=null){return $this->innerHTML($options);}
	protected function innerHTML(& $options=null){return null;}
	public function addBr($style=null){
		$br =  $this->add("br", $style);		
		return $br;
	}
	//@@@ add horizontal separator
	public function addHSep(){
		return $this->add(new HtmlSeparatorItem());
	}
	//@@@ add vertical separator
	public function addVSep(){
		return $this->add(new HtmlSeparatorItem("vertical"));
	}
	public function addSpace(){
		$this->add(new HtmlText("&nbsp;"));
	}
	public function addForm($attributes = null, $index=null){
		return $this->add("form", $attributes, $index);
	}
	public function addTable($attributes = null, $index=null){		
		return $this->add("table", $attributes, $index);
	}
	public function addDiv($attributes=null, $index= null){
		return $this->add("div", $attributes, $index);
	}
	public function addA($href, $attributes = null, $index=null)
	{
		$a = $this->add("a", array("href"=>$href), $index);
		if ($a){
			$a->AppendAttributes($attributes);
		}
		return $a;
	}
	
	public function addIFrame($id,$uri,  $attributes = null, $index=null){
		$frm = $this->add("iframe", null, $index);
		if ($frm == null) return null;
		
		$frm["id"] = $id;
		$frm["src"] = $uri;		
		$frm["class"] = "cliframe";
		$frm->AppendAttributes($attributes);
		return $frm;
	}
	public function addObject($uri, $attributes = null)
	{
		$obj = $this->add("object");
		if ($obj ==null)return null;
		
		$obj["data"] = $uri;		
		$obj->AppendAttributes($attributes);
		return $obj;
	}
	//add a label
	public function addLabel($key, $for=null, $attributes=null)
	{
		$lb = $this->add("label");
		$lb["for"] = $for;		
		$lb->Content = R::ngets($key);
		$lb->AppendAttributes($attributes);
		return $lb;
	}
	public function addInput($id, $type="text",$value=null, $attributes=null)
	{
			$i = $this->add("input");
			if ($i){
			$i["type"]=$type;
			$i["value"]= ($value==null)? igk_getr($id, null): $value; 
			$i["id"]=$i["name"]=$id;
			$i["class"] = "cl".$type;
			$i->AppendAttributes($attributes);
			}
			return $i;
	}
	public function addFile($id , $multiselect = false, $attributes=null)
	{
			$i = $this->add("input");
			if ($i){
			$i["type"]="file";
			$i["id"]=$id;
			$i["name"]= $multiselect? $id."[]": $id;
			$i["class"] = "clfile";
			$i["multiple"]="true";
			$i->AppendAttributes($attributes);
			}
			return $i;
	}
	public function addScript($file= null, $canBeMerged = true ){
		$s = $this->add("script");
		$s["src"] = $file;
		$s->canBeMerged = $canBeMerged;
		return $s;
	}
	public function addNothing(){
		$c = new HtmlNothingItem();
		$this->add($c);
		return $c;
	}
	public function addSLabelCheckbox($id, $text, $value=false, $attributes =null, $require=false)
	{
		
		$tab = $this->addLabelInput($id, R::ngets($text), $type="checkbox",$value, $attributes, $require);
		if ($value)
		{
			$tab[1]["checked"] = true;
		}		
		return $tab;
	}
	//add system label input
	public function addSLabelInput($id, $text, $type="text",$value=null, $attributes=null, $require=false, $description=null){	
		return $this->addLabelInput($id, R::ngets($text?$text:"lb.".$id), $type, $value, $attributes, $require, $description);
	}
	public function addSLabelSelect($id, $text, $values, $valuekey = false, $defaultCallback=null, $required=false)
	{
			$i = $this->add("label");
			$i["for"]=$id;
			if ($required)
			$i->add("span", array("class"=>"clrequired"))->Content = "*";
			$i->Content =  R::ngets($text?$text:"lb.".$id);
			$h = $this->add("select");
			$h["id"] =$id;
			if (is_array($values))
			{
				
				foreach($values as $k=>$v)
				{
					$opt = $h->add("option");
					$opt->Content = $valuekey? R::ngets("option.".$v) :$v;
					if (($defaultCallback ) && $defaultCallback($k,$v))
						$opt["selected"] = true;
				}
			}
			return array($i, $h);
	}
	public function addLabelInput($id, $text, $type="text",$value=null, $attributes=null, $require=false, $description=null){
			$i = $this->add("label");
			$i["for"]=$id;
			
			if ($require)
			{
				$i->Content = $text;
				$i->add("span", array("class"=>"clrequired"))->Content = "*";
			}
			else 
				$i->Content = $text;
			switch($type)
			{
				case "checkbox":
				case "radio":
						$h = $this->addInput($id, $type,$value, $attributes);
						if ($value){
							$h["checked"]="true";
						}
				break;
			default:
					$h = $this->addInput($id, $type,$value, $attributes);
				break;
			}
			
			$desc = null;
			if ($description){
				$desc = $this->add("span");
				$desc->Content = $description;
			}
			return array($i, $h, $desc);
	}
	
	public function addSLabelTextarea($id, $text, $attributes, $require=false, $description=null)
	{
			$i = $this->add("label");
			$i["for"]=$id;
			
			$i->Content = R::ngets($text);
			if ($require)
			{
				$i->add("span", array("class"=>"clrequired"))->Content = "*";
			}			
			$h = $this->addTextArea($id);
			$h->AppendAttributes($attributes);
			$desc = null;
			if ($description){
				$desc = $this->add("span");
				$desc->Content = $description;
			}
			return array($i, $h, $desc);
	}
	
	public function addBtn($name, $value, $type="submit", $attributes=null){
		$btn = self::CreateWebNode("input");
		$btn["id"] = $btn["name"] = $name;
		$btn["value"] = $value;
		$btn["type"]=$type;
		$btn["class"]="cl".$type;		
		$this->add($btn, $attributes);
		return $btn;
	}
	public function addTextArea($name, $content =null, $attributes =null){
		$tx = self::CreateWebNode("textarea");		
		$tx["id"] = $tx["name"] = $name;
		$tx["class"] ="cltextarea";
		$this->add($tx, $attributes);
		if ($content == null)
			$tx->Content = igk_getr($name);
		else 
			$tx->Content = $content;
		return $tx;
	}

	public function addText($string)
	{
		$this->add(new HtmlText($string));
	}
	
	//create a web node with is value
	public static function CreateWebNode($name, $attributes=null)
	{
		$c = null;
		if (!empty($name))
		{
			switch(strtolower($name))
			{
				case "a":
					$c = new HtmlA();
					break;
				case "textarea":
					$c = new HtmlTextarea();
					break;
				case "script":
					$c = new HtmlScript();
					break;
				case "meta":	
					$c=  new HtmlMeta();
					break;
				case "input":
					$c =  new HtmlInput();
					break;
				case "img":
					$c =  new HtmlImg();
					break;
				case "ul":
					$c = new HtmlUl();
					break;
				case "form":
					$c = new HtmlForm();
					break;
				case "label":
					$c =  new HtmlItem($name);
					$c["class"]="cllabel";
					break;
				case "div":
					$c = new HtmlDiv();
					break;
				case "select":
					$c =  new HtmlItem($name);
					$c["class"]="clselect";
					break;
				default:
					$c =  new HtmlItem($name);
					break;
			}			
		}
		else 
			$c = new HtmlText();
	
		
		if (method_exists($c, "AppendAttributes") && $attributes)
		{
			$c->AppendAttributes($attributes);
		}
		return $c;
	}
	
	
	///Load node a single node if found 
	public static function LoadNode($text)
	{
		if(empty($text))
			return null;
			
		$v_dummy = HtmlItem::CreateWebNode("dummy");
		$v_dummy->Load($text);
		if ($v_dummy->HasChilds)
		{
			return $v_dummy->Childs[0];
		}
		return null;
	}
	//return attribute that match the html requirement for rendering
	public static function GetStringAttribute($value)
	{
		if (empty($value))
			return null;
		if (is_object( $value)&& method_exists(get_class($value), "getValue"))
		{
			return self::GetStringAttribute($value->getValue());
		}
		else if (is_string($value))
		{
		if (IGKString::StartWith($value, "\""))
		{			
			return $value;
		}
		if (IGKString::StartWith($value, "\'"))
			return $value;
		
		}
		return "\"".$value."\"";
	}
	
	public function & getElementsByTagName($name){$tab = array(); return $tab;
	}
	public function getElementById($name){return null;
	}
	public function __toString(){
		return "HtmlItemBase [".$this->Render()."]";
	}
	//@@@public load content
	public function Load($content){
		$d = IGKHTMLReader::Load($content);
		if ($d){
			$d->CopyTo($this);
			return true;			
		}
		return false;
	}
	//@@@@ load file content
	public function LoadFile($file)
	{
		if (file_exists($file))
		{
			return $this->Load(IGKIO::ReadAllText($file));
		}
		return false;
	}
	
	public function __set($key, $value){
		if (!$this->_setIn($key, $value))
		{
			$this->$key = $value;
		}
	}	
	function offsetExists($key){
	}
	function offsetGet($key){
	}
	function offsetSet($key, $value){	
	}
	function offsetUnset($key){
	}	
}

class HtmlChildElementCollections 
extends IGKObject
implements ArrayAccess, Iterator
{
	private $m_owner;
	private $m_childs;
	private $it_index;
	public function toArray(){
		$t = array_values($this->m_childs); 
		return $t;
	}
	public function getCount(){return count($this->m_childs); }
	public function getKeys(){ return array_keys($this->m_childs); }
	
	public function clear(){
			$this->m_childs = array();
	}
	public function Sort($params)
	{
		igk_usort($this->m_childs, $params);
	}
	public function __construct($owner)
	{
		$this->m_owner = $owner;
		$this->m_childs = array();
		$this->it_index = 0;
	}
	public function & __get($key)
	{
		if (is_numeric($key))
		{
			return $this->m_childs[$key];
		}
		return $this->m_owner->getElementById($key);
	}
	//iterator
	function current(){ 
		return $this->m_childs[$this->it_index];
	}
	function next(){	
		$this->it_index++;
	}
	function key(){ return $this->it_index;}
	
	function valid(){
		return ($this->it_index>=0) && ($this->it_index< count($this->m_childs)) && isset($this->m_childs[$this->it_index]);
	}
	function rewind(){ 
		$this->it_index = 0;		
	}
	
		//arrayaccess
	function offsetExists($key){	
			$v= ($key>=0) && ($key< count($this->m_childs)) && isset($this->m_childs[$key]);		
			return $v;
	}
	function offsetGet($key){					
		
		return $this->m_childs[$key];
	}
	function offsetSet($key, $value){		
		
		if (empty($key))
			$this->m_childs[] = & $value;
		
	}
	function offsetUnset($key){ 
		if( isset($this->m_childs[$key]))
		{
			$this->m_childs[$key]->Dispose();
			unset($this->m_childs[$key]);		
		}
		$this->m_childs = array_values($this->m_childs);
	}
	public function __toString() {
		return "HtmlChilds [ ".count($this->m_childs)." ]";
	}
	
	public function Dispose()
	{//dispose elements 
		$t = $this->ToArray();
		foreach($t as $k)
			$k->Dispose();
		//unset($this->m_childs);
	}
}

//@@@ represent a html item
class HtmlItem extends HtmlItemBase
implements ArrayAccess
{
	private $m_childs;
	private $m_attributes;
	private $m_sortRequired;
	
	public function Dispose()
	{
		if ($this->m_childs)
		$this->m_childs->Dispose();
		if ($this->m_attributes)
		$this->m_attributes->Dispose();
	}
	public function getHasAttribute(){return ($this->m_attributes->getCount()>0); }
	public function getChilds(){return $this->m_childs;}
	public function getAttributes(){return $this->m_attributes;}
	public function getChildAtIndex($index){
		$e = igk_getv($this->m_childs, $index);		
		return $e;
	}
	
	public function getChildCount(){return igk_count($this->m_childs); }
	public function getHasChilds(){return ($this->ChildCount > 0);}
	public function getSortRequired(){return $this->m_sortRequired;}
	
	public function __toString(){
		return "HtmlItem[ ".$this->TagName." ] ; Attributes : [".($this->m_attributes?$this->m_attributes->getCount():0)."] ; Childs : [ ".$this->ChildCount." ]";
	}
	//---------------------------------------------------------------------------------------------
	//child functions 
	//---------------------------------------------------------------------------------------------
	public function ClearChilds()
	{
		foreach($this->m_childs as $k){
			$k->setHtmlItemParent(null);			
		}
		
		$this->m_childs->Clear();
	}
	public function Clear()
	{
		$this->Content = null;
		$this->ClearChilds();
	}
	protected function _AddChild($child, $index=null)
	{ 
		if (isset(HtmlOptions::$MustCloseTag[$this->TagName]))
		       return false;
		//push childs
		$this->m_childs[] = $child;  
		$child->setHtmlItemParent($this);
		$this->_setUpChildIndex($child, $index);
		$this->m_sortRequired = true;
		return true;
	}
	private function _setUpChildIndex(
		$childs, 
		$index=null)
	{				
		if ($index === null)
		{
			$i = $childs->Index;
			if (!is_numeric($i))
			{				
				$childs->setIndex($this->ChildCount-1);
			}
		}
		 else if(is_numeric($index)){ 		
			$childs->setIndex($index);
		}		
	
	}
	public function AddRange($arrayChilds)
	{
		if (is_array($arrayChilds))
		{
		foreach($arrayChilds as $k){
			$this->add($k);
		}
		return true;
		}
		return false;
	}
	public function addTo($target)
	{
		if ($target){
			$target->add($this);
		}
	}
	
	public function addPrev($itemorarray)
	{
		
		$i = $itemorarray;
		if ($i==null)return;
		
		if (is_array($i))
		{
			$ul = $this->add("ul");
			if ($ul){
				foreach($i as $k=>$v)
				{
						$li = $ul->add("li");
						$li->add("label")->Content = $k;
						$li->add("span")->Content = $v;
				}
			}
			
		}
	}
	///<summary>
	///add child to this node.
	///<args0>tagname or HtmlItem element</arg0>
	///<args1>array of attribute</args>
	///<args2>Required index</args>
	///</summary>
	public function add($nameorchilds, $attributes =null, $index = null)
	{
		$node = null;
		
		if ($nameorchilds === null)
			return null;
		if (is_string($nameorchilds))
		{
			$node =  self::CreateWebNode($nameorchilds);
			if (!$this->_AddChild($node))
			{
				$node = null;
			}
			
		}
		else if(is_object($nameorchilds) && is_subclass_of(get_class($nameorchilds), "HtmlItemBase"))
		{			
		    $b = $nameorchilds->parent;
			if (($b !== $this) &&
			    $this->_AddChild($nameorchilds))
			{
				$node = $nameorchilds;
				if ($b!=null){
					$b->remove($node);
				}
			}
		}
		else 
		{
			
			igk_wln("Something wrong forchild = ". $nameorchilds);
			throw new Exception("Exception:::Tag not valid");
			exit;
		}
		if($node)
		{
			if ($attributes)
			{
				$node->AppendAttributes($attributes);
			}
			if ($index)
			{
				$node->setIndex($index);
			}
		}
		return $node;
	}
	///add attribute array
	public function AppendAttributes($attributes =null)
	{	
		if (is_array($attributes)){
			foreach($attributes as $k=>$v)
			{
				$this[$k]=$v;
			}
		}
	}
	protected function __sortChild()
	{
		if ($this->SortRequired)
		{		
			igk_usort($this->m_childs, array("HtmlItem", "SortChild" ));
			$this->m_sortRequired = false;
		}
	}
	public static function SortChild($a, $b){
		
		if ($a->Index == $b->Index)
			return 0;
		return ($a->Index < $b->Index)? -1 : 1;
	}
	public function __construct($tagname)
	{
		parent::__construct($tagname);
		$this->m_childs = new HtmlChildElementCollections($this);// array();
		$this->m_IsVisible = true;
		$this->m_attributes = new HtmlAttributeCollections($this);		
	}
	protected function innerHTML(& $options=null)
	{
		
		$out = "";
		$c = $this->Content;
		if (empty($c) && isset(HtmlOptions::$MustCloseTag[$this->TagName]) &&($this->ChildCount == 0))
		{	
			return null;
		}
		else {
			$s =HtmlUtils::GetValue($c);
			if ($s == "0")
			{
				$out .= "&#48;";
			}			
			else{
				if (!empty($s))
				{
					$v_depth = $this->getDepthIndent($options);
					$v_iline = $this->indentLine($options);
					$out .= $v_iline.($v_depth?$v_depth."\t":null).$s;
				}
			}
			
			$out .= $this->__renderChild($options);		
		}
		return $out;
	}
	private function __renderChild(& $options = null)
	{
			
			$out = "";
			$this->__sortChild();		
			foreach($this->m_childs as $k=>$v)
			{
				if ($v->IsVisible){
					$out .= $v->Render($options);
				}
			}	
			return $out;
	}
	public function getAttributeString()
	{
	
	if ($this->HasAttribute)
		{
			$out = "";
			foreach($this->Attributes as $k=>$v)
			{
				
				$c = self::GetStringAttribute($v);
				if (!empty($c)){
					if (!empty($out))
						$out .= " ";
					$out .= $k."=".$c;
				}
			}
			return $out;
		}
		return null;
	}
	
	public function Render($options = null){
		$v_depth = $this->getDepthIndent($options);
		$v_iline = $this->indentLine($options);
		$out = "";
		if ($this->HtmlItemParent !==null)
			$out.= $v_iline;
		$out.= $v_depth;
		$out .= "<".$this->TagName;
		if ($this->HasAttribute)
		{
			$s = trim($this->getAttributeString());
			if (!empty($s))
			$out.= " ".$s;
		}	
		if (empty($c) && !$this->closeWithCloseTag()  && isset(HtmlOptions::$MustCloseTag[$this->TagName]) &&($this->ChildCount == 0) )
		{
			$out .=" />".$v_iline;			
		}
		else {
			$out .= ">";
			$s= $this->innerHTML($options);
			if (!empty($s))
			{
				$out .= $s.$v_iline.$v_depth;
			}
			$out .= "</".$this->TagName.">";	
		}
		return $out;
	}
	public function & getElementsByTagName($name)
	{
			$tab = array();
			$s = strtolower($name);
			if( $this->m_childs )
			{
				
				if ($name == "*")
				{
					$tab = array_merge ($tab , $this->m_childs->ToArray());
					foreach($this->m_childs as $k)
					{
						$c = $k->getElementsByTagName($s);						
						if (is_array($c) && (count($c)>0))
							$tab = array_merge($tab, $c);
					}
				}
				else{
				foreach($this->m_childs as $k)
				{
					if (strtolower($k->TagName) == $s){						
						$tab[] = $k;
					}
					$c = $k->getElementsByTagName($s);						
					if (is_array($c) && (count($c)>0))
						$tab = array_merge($tab, $c);
				}
				}
			}
			return $tab;
	}
	//retrieve all element that match the current attribute value
	public function getElementByAttribute($name, $value)
	{
		if ($this->m_childs==null)
			{
				return null;
			}
			$tab = array();
			$s = strtolower($value);
			foreach($this->m_childs as $k)
			{
				if (strtolower($k[$name]) == $s)
					$tab[] = $k;
				$r = $k->getElementById($s);
				if (is_array($r))
					$tab = array_merge($tab, $r);
				else if ($r)
					$tab[] = $r;
			}
			if (count($tab)== 1)
				return $tab[0];
			return $tab;
	}
	//get element by id
	public function getElementById($id)
	{	
		if ($this->m_childs==null)
		{
			return null;
		}
				$tab = array();
				$s = strtolower($id);
			foreach($this->m_childs as $k)
			{
				if (strtolower($k["id"]) == $s)
					$tab[] = $k;
				$r = $k->getElementById($s);
				if (is_array($r))
					$tab = array_merge($tab, $r);
				else if ($r)
					$tab[] = $r;
			}
			if (count($tab)== 1)
				return $tab[0];
			return $tab;
	}
	//Remove childs
	public function remove($child)
	{
		$v_deleted = false;
		if (($this->m_childs ==null) ||($child == null))
			return $v_delete;
		
			for	($i = 0; $i< igk_count($this->m_childs); $i++)
			{				
				if (isset($this->m_childs[$i]) )
				{
					if ( ($this->m_childs[$i] === $child) )
					{
						unset($this->m_childs[$i]);				
						$child->setHtmlItemParent(null);
						//igk_wln("hidde element");
						//$child->Index = 0;
						$v_deleted = true;	
						break;
					}
				}
				else{
					igk_wln(" index ".$i." not found ". $child["id"]);
				}
			}
			if ($v_deleted)
			{
				return $this->remove($child);
			}

		return $v_deleted;
	}
	
		
	//arrayaccess
	function offsetExists($key){return $this->m_attributes->offsetExists($key);}
	function offsetGet($key){
		if ($this->m_attributes==null)
		{
			igk_wln("try to get an attribute of null .... ".$key." [".$this."]");
			exit;
		}
	return $this->m_attributes->offsetGet($key);
	}
	function offsetSet($key, $value){$this->m_attributes[$key] = $value;}
	function offsetUnset($key){$this->m_attributes->offsetUnset($key);}
}
//used to render a block node 
final class HtmlBlockNodeItem extends HtmlItem
{
	public function __construct()
	{
		parent::__construct("blockViewItem");		
		
	}
	public function getIsVisible()
	{
		return $this->HasChilds;
	}
	public function Clear(){
		igk_debug_wln("blocknodeitem: clear childs");
	}
	public function ClearChilds(){
		igk_debug_wln("blocknodeitem: clear childs");
	}
		
	public function Render($options=null)
	{		
		$out = $this->getinnerHTML($options);		
		return $out;
	}
}
//------------------------------------------------------------
//only used to render item once
//------------------------------------------------------------
final class HtmlSingleViewItem extends HtmlItemBase
{
	var $targetNode;
	
	public function __construct($node)
	{
		parent::__construct("singleViewItem");
		$this->targetNode = $node;
	}
	public function Render($options=null)
	{
		$out = $this->targetNode->Render($options);
		//remove item after rendering
		$p = $this->Parent;
		igk_html_rm($this);
		$this->targetNode->ClearChilds();
		return $out;
	}
	protected function _AddChild($item, $index=null){ return false;}
}
//using only to clone the content node 
final class HtmlCloneNodeItem extends HtmlItemBase
{
	var $targetNode;
	public function __construct($node){
		if($node == null)
			throw new Exception("HtmlCloneNodeItem ''node'' not valid");
		parent::__construct("cloneNode");
		$this->targetNode = $node;
	}
	public function Render($options = null)
	{
		$out = $this->targetNode->Render($options);
		return $out;
	}
	protected function _AddChild($item, $index=null){ return false;}
}
interface IHtmlGetValue
{
	function getValue();
}

class HtmlItemAttribute extends IGKObject
implements IHtmlGetValue {
	
	public function getValue(){
		
	}
}
///uri relative value
//@@ used to get the current relative link value according to BASEDIR
final class HtmlRelativeUriValueAttribute extends HtmlItemAttribute
{
	private $m_lnk; //relative path according to base dir
	
	public function __construct($uri = null)
	{
			$this->m_lnk = $uri;
	}
	
	public function getValue(){
	
		//$v = igk_io_currentRelativePath(igk_io_syspath($this->m_lnk));
		$v = igk_html_uri(igk_io_currentRelativeUri($this->m_lnk));
		return HtmlItem::GetStringAttribute("./".$v, "/");
	}
	public function __toString(){return get_class($this); }
}
final class HtmlValidatorItem extends HtmlItem
{
	public function __construct(){
		parent::__construct("validator");
	}
	public function add($text,$attributes =null, $index=null)
	{
		parent::Add("div")->Content = $text;
	}
}
final class HtmlTinyMceScript extends HtmlItem
{
	private static $m_instance = null;	
	private  $m_tinyScript;
	private  $m_rendered ;
	
	function __construct(){
		parent::__construct("");
		$this->m_tinyScript = igk_js_enable_tinymce($this);
		$this->m_rendered = false;
	}
	
	public static function getInstance(){
		if (self::$m_instance == null)
			self::$m_instance = new HtmlTinyMceScript();
		return self::$m_instance;
	}
	protected function innerHTML(& $option=null){
		return $this->m_tinyScript->innerHTML($option);
	}
	public function Render($option=null){
		if (!$this->m_rendered)
			$this->m_rendered = true;
		else 
			return null;
		return $this->m_tinyScript->Render($option);
	}
}

final class HtmlA extends HtmlItem
{
	
	public function __construct(){
		parent::__construct("a");
		$this->m_node = new HtmlItem("a");
	}
	public function Render($option=null)
	{		
		$bck = $this["href"];
		if ($this["onclick"] == null)
		{
			if (IGKString::StartWith(trim($this["href"]), "javascript"))
			{	
				$this["onclick"] = $bck." return false;";
				$this["href"] = "javascript:void();";				
			}
		}
		$o =  parent::Render($option);
		//restore
		$this["href"] = $bck;
		return $o;
	}
}
final class HtmlTextarea extends HtmlItem
{
	private  $m_must_escapeChar;
	private  $m_useTinyMce;
	public function getuseTinyMce(){return $this->m_useTinyMce; }
	public function setuseTinyMce($value){ $this->m_useTinyMce = $value; }
	
	public function __construct(){
		parent::__construct("textarea");
		$this->m_useTinyMce = false;
		$this->m_must_escapeChar = false;
	}
	public function getContent(){ return parent::getContent();}
	public function setContent($value){ parent::setContent( htmlentities($value)); }
	
	public function Render($option=null)
	{
		$out = parent::Render($option);
		if ($this->m_useTinyMce)
		{
			$out.= HtmlTinyMceScript::getInstance()->Render($option);
		}
		return $out;
		
	}
}
//current session c lass event
final class HtmlClassSessionOpt extends IGKObject{
	var $regClass; //registered class
	var $regEvent; //used set that property added
	var $regParentClass; //used to store parent of class
	public function __construct(& $tab)
	{
		$this->regClass = & $tab;
		$this->regParentClass = array();
		$this->regEvent = new IGKEvents($this, "regEvent");
	}
	public function onPropertyAdded()
	{
		$this->regEvent->Call($this,null);
	}
}

//@@@ represent classe used
final class HtmlClassValueAttribute extends HtmlItemAttribute{
	private $m_classes ; 
	private $m_expressions; //used to store in expression
	private $m_owner;
	private static $sm_regClass = null;
	
	
	
	public function __construct($owner){
		$this->m_classes = array();
		$this->m_expressions = array();
		$this->m_owner =$owner;
	}
	public function getKeys(){
		return array_keys($this->m_classes);
	}
	//register current class 
	private static function _RegClass($name)
	{	
		
		$v = & self::_GetRegClass();
		$App = igk::getInstance();
		

		if (($App->Doc == null) || 
			isset($App->Doc->SysTheme->def[".".$name])||
			(isset($App->Doc->Theme->def[".".$name])))
			{				
				return;
			}
		
		if (!isset($v[$name]))
		{
			$v[$name] = $name;
			$App->Session->RegClasses->onPropertyAdded();
		}
		
	}
	//@@@ get if this instance contain classe name
	public function contain($name)
	{
		return isset($this->m_classes[$name]);
	}
	private static function _UnRegClass($name)
	{
	
		$v = & self::_GetRegClass();
		if (isset($v[$name]))
		{
			unset($v[$name]);
			igk::getInstance()->Session->RegClasses->onPropertyAdded();
		}
		
	}
	//unregister css class 
	public static function UnRegClass($key){
		self::_UnRegClass($key);
	}	
	//get all registrated css class
	public static function GetRegClass(){
		return self::_GetRegClass();
	}
	//return the reference of this object
	private static function & _GetRegClass(){ 
		if (self::$sm_regClass === null)
		{
			if (igk::getInstance()->Session->RegClasses !==null)
			{
				self::$sm_regClass = & igk::getInstance()->Session->RegClasses->regClass;
			}		
			else{
				self::$sm_regClass = array();	
				igk::getInstance()->Session->RegClasses = new HtmlClassSessionOpt( self::$sm_regClass);
			}
		}		
		return  self::$sm_regClass;
	}
	public function clear(){
		$this->m_expression = array();
		$this->m_classes = array();
	}
	//add class with the add value
	public function add($class)
	{
		if (empty($class))
			return;
		$tab = explode(" ", $class);
		if (count($tab) == 1)
		{	 
			$this->_add($class);
		}
		else{
			foreach($tab as $v)
			{
			 $this->_add($v);
			}
		}
	}
	private function _add($v)
	{
	
				$v = trim($v);
				if (strlen( $v) > 0)
				{
					switch($v[0])
					{
						case '-':			
							$v = substr($v,1);
							$this->remove($v);	
						
						break;
						case '+':
							$v = substr($v, 1);					
							if (!isset($this->m_classes[$v]))
							{
								$this->m_classes[$v] = $v;	
							}
							self::_RegClass($v);
						break;
						case "{":
							$this->m_expressions[] = $v;
							exit;
						break;
						 default:
						if (!isset($this->m_classes[$v]))
						{
							$this->m_classes[$v] = $v;				
						}
						self::_RegClass($v);
						break;
					}
				}
				
	}
	public function remove($class)
	{
		if (empty($class))
			return;
		if (isset($this->m_classes[$class]))
		{
			unset($this->m_classes[$class]);
		}						
	}
	
	//get class presentation value
	public function getValue(){
		$out = "";
		$i = 0;
		//igk_wln("info ".IGK_CSS_CHILD_EXPRESSION_REGEX);
		foreach($this->m_classes as $k=>$v)
		{
			if ($i == 0)
					$i= 1;
			else 
				$out .=" ";
			//replacing parent item
			if (self::IsCssChild($v))
			{
				$out .= self::GetParentClass(igk::getInstance()->Doc->Theme, $v);
			}
			else 
				$out.= $v;			
		}		
		return HtmlUtils::GetValue($out);
	}
	public static function IsCssChild($v)
	{
		$c = igk::getInstance();
		if ($c)
		{
			$s = $c->Doc->Theme[$v];
			if (!empty($s))
			{				
				//check matrix match				
				$r= preg_match(IGK_CSS_CHILD_EXPRESSION_REGEX, trim($s));				
				return $r;
			}			
		}
		return false;
	}
	private static function GetParentClass($theme, $v)
	{
		$s = $theme[$v];
		if (!empty($s))
		{	
				$t = array();
				if (preg_match_all(IGK_CSS_CHILD_EXPRESSION_REGEX, $s, $t))
			    {
				 $vv = $t["name"][0];
				if (self::IsCssChild($vv))
				 {
					return self::GetParentClass($theme, $vv);
				}
				return $vv;
				}
		}
		return $v;
	}
}
final class HtmlSeparatorItem extends HtmlItem
{
	private $m_orientation;
	public function __construct($orientation="horizontal")
	{
		parent::__construct("div");
		switch($orientation)
		{
			case "horizontal":
			$this["class"]="igk-horizontal-separator";
			break;
			case "vertical":
			$this["class"]="igk-vertical-separator";
			break;
		}
	}
}
final class HtmlSearchItem extends HtmlItem
{
	private $m_link;
	private $m_input;
	private $m_ctrl; //controller
	private $m_ajxfunc ;
	public function __construct($uri, $search=null, $prop = "q")
	{	
		parent::__construct("div");
		$this["class"]="clsearch search_fcl";
		$frm = $this->addForm();
		$tab = igk_getquery_args($uri);
		if (isset($tab["c"]))
		{
			$this->m_ctrl = igk_getctrl($tab["c"]);
			$f = igk_getv($tab, "f");
			if ($f && !IGKString::EndWith($f, "_ajx"))
			{
				$this->m_ajxfunc = $f."_ajx";
				if (!method_exists($this->m_ctrl, $this->m_ajxfunc))
				{
					$this->m_ajxfunc  = null;
				}
				else{
					$this->m_ajxfunc =	$this->m_ctrl->getUri($this->m_ajxfunc);
				}
			}	
		}
		$frm["action"] = $uri;
		$frm["id"]="search_item";
		$frm["style"] ="padding:0px;position:relative;background-color:white;";
		$frm->addDiv(array("style"=>"display:block; position:absolute; height:4px; width:100%; background-color:#414141; bottom :0px;"));
		
		$frm->NoTitle = true;
		$frm->NoFoot = true;
		
		$this->m_link = HtmlUtils::AddImgLnk($frm, $uri, "btn_search", "24px", "24px");
		$this->m_link["class"]="alignm";
		$this->m_link["onclick"]=<<<EOF
return (function(i){var q = window.igk.getParentByTagName(i, 'form'); if (q){ q.submit(); return false;} return true;})(this);
EOF;
		$this->m_input = $frm->addInput($prop, "text", igk_getr($prop, $search));
		
		$this->m_input["class"] = "noborder";
		$script =<<<SCR
javascript: return (function(i, event){ var frm = null; if (event.keyCode==13){frm = window.igk.getParentByTagName(i, 'form'); if (frm){ frm.submit(); return false; }}  return true;} )(this, event);
SCR;
		$this->m_input["onkeypress"]=$script;
	}
	
}
//text element
class HtmlText extends HtmlItemBase
{
	public function getTagName(){return "HTMLText"; }
	public function __construct($content = null){
		parent::__construct();
		$this->Content = $content;
	}
	public function Render($options=null)
	{			
		return $this->getDepthIndent($options).HtmlUtils::GetValue($this->Content).$this->indentLine($options);		
	}
	protected function innerHTML(& $option=null){
		return HtmlUtils::GetValue($this->Content);		
	}
	protected function _AddChild($item, $index=null){return false;}
	public function add(){return null;}
	public function getIsVisible(){return true;}
	public function getNodeType(){return XMLNodeType::TEXT; }
	public function __toString(){ return "HtmlText[".$this->Content."]";}
}
class HtmlProcessInstruction extends HtmlItemBase
{
	private $m_content;
	public function getContent(){return $this->m_content;}
	public function __construct($content)
	{
		parent::__construct();
		$this->m_content = $content;
	}
	public function Render($options=null)	
	{
		$out = "<?";
		$out .= $this->Content;
		$out .= "?>";
		return $out ;
	}
	protected function _AddChild($item, $index=null){return false;}
	public function add($item, $attrib =null, $index= null){return null;}
}

///---------------------------------------------------------------------------------------------
///CLASS: HTMLDOC
///---------------------------------------------------------------------------------------------
final class HtmlDoc extends HtmlItem
{
	private $m_parent;
	private $m_metaManager;
	private $m_scriptManager;
	private $m_linkManager;
	private $m_params;
	private $m_docType = "html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\""; 
	private $m_namespase = "http://www.igkdev.be/schema/drs";
	var $m_head;
	var $m_body;
	var $m_title;
	var $m_doctype;
	var $m_sys_theme; //système - theme utiliser pour la configuration
	var $m_theme; //custom - theme
	var $m_favicon;
	var $lang; //set or set the lang of this document default lang is fr
	
	
	public function __toString(){
	return "HtmlDocument";
	}
	public function getMetas(){return $this->m_metaManager; }
	public function getBody(){return $this->m_body; }
	public function getHead(){return $this->m_head;}
	public function getSysTheme(){return $this->m_sys_theme; }
	public function getTheme(){return $this->m_theme;}
	public function setDocType($value){ $this->m_docType = $value;}
	public function getElementById($name){
		$tab = array();
		$r1 = $this->m_head->getElementById($name);
		$r2 = $this->m_body->getElementById($name);
		if (is_array($r1))
			array_merge($tab, $r1);
		else 
			$tab[] = $r1;
			if (is_array($r2))
			array_merge($tab, $r);
		else 
			$tab[] = $r2;
			if (count($tab) == 1)
				return $tab[0];
			return $tab;
		
	}
	
	public function & getElementsByTagName($name){
		$n  = strtolower($name);
		$tab = array();
		if ($n == "head"){ $tab [] = $this->m_head; return $tab;}
		if ($n == "body"){ $tab [] = $this->m_body; return $tab;}
		$tab1 = $this->m_head->getElementsByTagName($name);
		$tab2 = $this->m_body->getElementsByTagName($name);
		return array_merge($tab1, $tab2);
	}
	public function __construct($parent)
	{		
		$this->m_parent = $parent;
		$this->m_params = array();		
		$this->m_scriptManager = new HtmlScriptManager($this);
		$this->m_linkManager = new HtmlLinkManager($this);
	}
	public function setup_document()
	{	
		
		$this->_initThemes();
		$this->m_head = self::CreateWebNode("head");
		$this->m_body = self::CreateWebNode("body",array("class"=>"web_body"));
		$this->lang = "fr";
		$this->m_metaManager = new HtmlMetaManager($this);
	}
	private function _initThemes()
	{//init default theme
	
		$this->m_sys_theme = new HtmlDocTheme($this);
		$this->m_theme = new HtmlDocTheme($this);
		$this->m_sys_theme->Name = "igk_system_theme";
		$this->m_theme->Name = "default"; //set the default name
		
		$this->m_sys_theme->def["*"]  = "padding:0px; margin:0px;";
		$this->m_sys_theme->def["html, body, ul, div, p"] = "padding:0px; margin:0px; position:relative;";
		$this->m_sys_theme->def["a"] = "[fcl:link_base_fcl] text-decoration:none;";
		$this->m_sys_theme->def["body li"] = "list-style-type:none;";
		$this->m_sys_theme->def["body a, body img"]= "text-decoration:none; list-style-type:none; border:none;";
		$this->m_sys_theme->def["html, body"] = "width:100%; height:100%;";				
		//define shortcut icon theme
		$this->m_sys_theme->def[".nobgrepeat"] = "background-repeat:no-repeat";
		$this->m_sys_theme->def[".posab"] = "position:absolute;";		
		$this->m_sys_theme->def[".posfix"]="position:fixed;";		
		$this->m_sys_theme->def[".posr"] = "position:relative;";
		$this->m_sys_theme->def[".posstatic"] = "position:static;";
		$this->m_sys_theme->def[".floatl"] = "float:left;";
		$this->m_sys_theme->def[".floatr"] = "float:right;";
		$this->m_sys_theme->def[".floatn"] = "clear:both;";
		$this->m_sys_theme->def[".clearb"] = "clear:both;";
		$this->m_sys_theme->def[".clearl"] = "clear:left;";
		$this->m_sys_theme->def[".clearr"] = "clear:right;";
		$this->m_sys_theme->def[".overflow_none"]= "overflow:hidden;";
		$this->m_sys_theme->def[".overflowy_a"] = "overflow-y:auto;";
		$this->m_sys_theme->def[".overflow_x"] = "overflow-x:scroll;";
		$this->m_sys_theme->def[".overflow_y"] = "overflow-y:scroll;";
		$this->m_sys_theme->def[".auto_y"] = "overflow-y:scroll;";
		$this->m_sys_theme->def[".auto_x"] = "overflow-x:scroll;";
		$this->m_sys_theme->def[".alignl"] ="text-align:left;";
		$this->m_sys_theme->def[".alignr"] ="text-align:right;";
		$this->m_sys_theme->def[".alignb"] ="vertical-align:bottom;";
		$this->m_sys_theme->def[".alignt"] ="vertical-align:top;";		
		$this->m_sys_theme->def[".alignhc"] ="text-align:center;";
		$this->m_sys_theme->def[".alignc"] ="vertical-align:middle; text-align:center;";
		$this->m_sys_theme->def[".alignm"] ="vertical-align:middle; text-align:center;";
		$this->m_sys_theme->def[".ztop"] ="z-index: 9000;";
		$this->m_sys_theme->def[".zback"] ="z-index: -9000;";
		$this->m_sys_theme->def[".fitw"] ="width:100%;";
		$this->m_sys_theme->def[".fith"] ="height:100%;";
		$this->m_sys_theme->def[".hide"] ="display:none;";		
		$this->m_sys_theme->def[".halfw"] ="width:50%;";
		$this->m_sys_theme->def[".halfh"] ="height:50%;";
		$this->m_sys_theme->def[".noborder"] = "border:0px;";
		$this->m_sys_theme->def[".pad4"] = "padding: 4px;";
		$this->m_sys_theme->def[".marg4"] = "margin: 4px;";
		$this->m_sys_theme->def[".nowrap"] = "white-space: nowrap;";
		$this->m_sys_theme->def[".wrapnormal"] = "white-space:normal;";
		$this->m_sys_theme->def[".loc_b"]="bottom:0px;";
		$this->m_sys_theme->def[".loc_l"]="left:0px;";
		$this->m_sys_theme->def[".loc_mid"]="left:50%; top: 50%;";
		$this->m_sys_theme->def[".loc_r"]="right:0px;";
		$this->m_sys_theme->def[".loc_t"] = "top:0px;";
		$this->m_sys_theme->def[".nomargin"] = "margin-top:0px; margin-left:0px;margin-right:0px; margin-bottom:0px;";
		$this->m_sys_theme->def[".nopadding"] = "padding-top:0px; padding-bottom:0px; padding-right:0px; padding-left:0px;";
		$this->m_sys_theme->def[".nodecoration"]="text-decoration:none;";
		$this->m_sys_theme->def[".block_5m"] = "margin:5px;";
		$this->m_sys_theme->def[".block_10m"] = "margin:10px;";
		
		$this->m_sys_theme->def[".z_50"] = "z-index:50;";
		$this->m_sys_theme->def[".z_100"] = "z-index:100;";
		
		$this->m_sys_theme->def[".resizable"] = "resize:both;";
		
		$this->m_sys_theme->def[".scroll_h_x"] = "overflow-x:hidden;";
		$this->m_sys_theme->def[".scroll_h_y"] = "overflow-y:hidden;"; 
		$this->m_sys_theme->def[".scroll_x"] = "overflow-x: scroll;"; 
		$this->m_sys_theme->def[".scroll_y"] = "overflow-y: scroll;"; 
		$this->m_sys_theme->def[".scroll_ay"] = "overflow-y: auto;"; 
		$this->m_sys_theme->def[".scroll_ax"] = "overflow-x: auto;"; 
		$this->m_sys_theme->def[".autoh"] = "height:auto;";
		$this->m_sys_theme->def[".autow"] = "width:auto;";
		$this->m_sys_theme->def[".nowrap"] = "white-space : nowrap;";
		$this->m_sys_theme->def[".nostyle"] = "text-decoration:none; list-style-type:none; border:none;";
		$this->m_sys_theme->def[".puce_circle"]= "list-style-type:disc;";
		
		$this->m_sys_theme->def[".dispn"] = "display:none;";
		$this->m_sys_theme->def[".dispb"] = "display:block;";
		$this->m_sys_theme->def[".dispi"] = " display:inline;"; 
		$this->m_sys_theme->def[".dispib"] = "display:inline-block;";
		$this->m_sys_theme->def[".disptabc"] = " display: table-cell;";
		$this->m_sys_theme->def[".disptable"] = " display:table;";
		$this->m_sys_theme->def[".disptabr"] = " display: table-row;";
		$this->m_sys_theme->def[".floatr"] = "float:right;";
		
		
		
		$this->m_sys_theme->def[".box_16x16"] = "width:16px; height:16px;";
		$this->m_sys_theme->def[".box_24x24"] = "width:24px; height:24px;";
		$this->m_sys_theme->def[".box_32x32"] = "width:24px; height:32px;";
		$this->m_sys_theme->def[".box_48x48"] = "width:48px; height:48px;";
		

		//frame box;
		$this->m_sys_theme->def[".frame_textarea"] = "min-width: 500px; min-height:300px";
		$this->m_sys_theme->def[".msbox_dialog"] = $this->m_sys_theme->def[".framebox_dialog"] = "background-color: white; padding: 4px;"; 
		$this->m_sys_theme->def[".msbox_dialog_title"] = $this->m_sys_theme->def[".framebox_dialog_title"]="position:relative; height:32px; font-size:14pt; [bgcl:framebox_title_bgcl];[fcl:framebox_title_fcl]; cursor:move; padding-right: 64px;"; 
		$this->m_sys_theme->def[".frm_title"]="border:1px solid darkgray; height:24px; line-height:24px; text-indent:24px;"; 
		$this->m_sys_theme->def[".hseparator"]="{sys:fitw} height: 16px; [res:hsep];"; 
		$this->m_sys_theme->def[".hidden"]="display:none;";
	
		$this->m_sys_theme->def[".msboxctrl"] = "z-index: 1000;";
		$this->m_sys_theme->def[".transparent"] ="background-color:transparent; color:transparent;";
		
		$this->m_sys_theme->def[".web_pageinfo"] = "display:none";
		
		$this->m_sys_theme->def[".config_fileviewdir"]="[res:folder]; background-repeat: no-repeat ;text-indent: 24px; display:inline-block;"; 
		$this->m_sys_theme->def[".config_fileviewfile"]="[res:file] ; background-repeat: no-repeat ;text-indent: 24px; display:inline-block;"; 
		
		
		$this->m_sys_theme->def[".horizontalpane_btn"] = "background-color:transparent; background-repeat:no-repeat;";
		$this->m_sys_theme->def[".horizontalpane_btn_prev"] = "[res:navbtn_previous_2]";
		$this->m_sys_theme->def[".horizontalpane_btn_next"] = "[res:navbtn_next_2]";
		
		$this->m_sys_theme->def[".igk-config-page"] = "overflow: hidden; overflow-y: auto; text-align:left; font-size: 0.9em;[res:light_op20]";
		
		$this->m_sys_theme->def[".igk-config-page .igk-config-content_submenu"]="padding:8px;"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-content_submenu li"]="display:inline-block;margin-right : 2px; line-height: 32px; height: auto; vertical-align:top; min-width: 105px; border: 1px solid black;"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-content_submenu li a"]="display: block;  text-align:center; ; padding-left:16px; padding-right:16px;"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-content_submenu li a:hover"]="background-color: #2A52FF; color: white;"; 		
		
		$this->m_sys_theme->def[".igk-config-page .font_list"] = "{sys:posr}";
		$this->m_sys_theme->def[".igk-config-page .font_list li"]="display:inline-block; text-align:center;  padding:4px; border:1px solid #a4A4A4; vertical-align:top; margin: 3px; position:relative;";
		$this->m_sys_theme->def[".igk-config-page .font_list li div"] = "font-size: 30pt; height:40pt;";
		$this->m_sys_theme->def[".igk-config-page .font_list li .tool_tip"] = "height:auto;";
		$this->m_sys_theme->def[".igk-config-page .color_view"] = "padding: 2px; border:1px solid black";
				
		$this->m_sys_theme->def[".framebox"]="[res:framebox_bgimg]; z-index: 1000;"; 
		$this->m_sys_theme->def[".framebox_close_btn"]="position:absolute; top:4px; right:8px;"; 
		$this->m_sys_theme->def[".igk-config-page .framebox_dialog"]= "box-shadow: 0 2px 4px black";
		
		
		$this->m_sys_theme->def[".igk-config-page .config-menu-title"] = "font-size:1.1em; background-color: #389AFF; color:white; padding: 8px;";
		$this->m_sys_theme->def[".igk-config-page .config-menu-description"] = "padding-left:8px;";
		
		
		$this->m_sys_theme->def[".igk-config-page .igk-config-frame"]= "{sys:fitw} padding-bottom: 48px;";		
		$this->m_sys_theme->def[".igk-config-page .igk-config-content"]="min-width:100%; border:1px dotted #6a6a6a; font-family:[ftn:century_gothic], serif, sans-serif ;display:table-cell; padding: 16px; vertical-align: top; height:100%; [res:config_content_bgimg]; [bgcl:config_content_bgcl]; [fcl:config_content_fcl]"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu"]="display:table-cell; width: 180px; min-width:180px; max-width:220px; vertical-align: top; background-color:white;"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-info"] = "display:table-cell;  width:300px; min-width:200px; background-color:white; ";
		
		
		
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu li"]="{sys:dispb} height:32px;  overflow:hidden;"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu li a"]="{sys:dispb,fith,fitw} line-height:32px; vertical-align:middle; cursor:pointer;  [fcl:config_menu_fcl]"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu li a span"]=""; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu li a:hover"]="text-indent: 16px; [bgcl:igk-config-menu_a_hover_bgcl]; [fcl:igk-config-menu_a_hover_fcl];"; 
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu ul"]="margin-bottom:8px;"; 		
		$this->m_sys_theme->def[".igk-config-page .igk-config-menu .igk-config-menu_selected"]="text-indent:16px;background-repeat:no-repeat;[res:config_menu_selected_bgimg];[bgcl:config_menu_selected_bgcl];[fcl:config_menu_selected_fcl]"; 
		$this->m_sys_theme->def[".igk-config-page .igk_db_tableentries"] = "width:600px; max-height:440px; overflow: auto";		
		$this->m_sys_theme->def[".igk-config-page table"] = "border-spacing:0 0; font-size:10pt; border-collapse:collapse;";
		$this->m_sys_theme->def[".igk-config-page table td"]  = "border:1px solid #E7E7E8;";
		$this->m_sys_theme->def[".igk-config-page table th:hover"]  = "color: black;";
		$this->m_sys_theme->def[".igk-config-page table th"] = "color: black; background-color: #E7E7E8; font-weight:bolder; padding:0px; line-height:32px; margin:2px; padding:2px;line-height:normal;";		
		$this->m_sys_theme->def[".igk-config-page .table_lightrow"]=  "[bgcl:table_lightrow_bgcl]";
		$this->m_sys_theme->def[".igk-config-page .table_lightrow:hover"]= "[bgcl:table_row_hover_bgcl];[fcl:table_row_hover_fcl]";
		$this->m_sys_theme->def[".igk-config-page .table_darkrow"]=  "[bgcl:table_darkrow_bgcl]";
		$this->m_sys_theme->def[".igk-config-page .table_darkrow:hover"]= "[bgcl:table_row_hover_bgcl];[fcl:table_row_hover_fcl]";
		$this->m_sys_theme->def[".igk-config-page .table_lightrow a,.igk-config-page .table_darkrow a"] ="{sys:dispb,fitw,fith}";
		$this->m_sys_theme->def[".igk-config-page .table_darkrow a:hover"] = "[fcl:table_row_hover_fcl]";
		$this->m_sys_theme->def[".igk-config-page .table_lightrow a:hover"] = "[fcl:table_row_hover_fcl]";		
		
		$this->m_sys_theme->def[".igk-config-page .db_info"] = "{sys:dispib,alignt, fith} border:1px solid #4A4A4A; padding:4px; margin:5px;";
		
		$this->m_sys_theme->def[".igk-config-page .igk-config-header-node"] = "height: 74px; font-size:1em; {sys:nowrap}";
		$this->m_sys_theme->def[".igk-config-page .igk-config-header-node .config_logo"] = "[res:config_logo] {sys:dispib} -align:top; background-repeat:no-repeat; width : 125px; margin-right:60px; overflow:hidden; height:74px;";
		$this->m_sys_theme->def[".igk-config-page .igk-config-header-node .config_title"] = "{sys:dispib} font-size: 2.3em; line-height: 74px; vertical-align:top; text-shadow: 1px 1px 2px #2A2A2A;";
		
		$this->m_sys_theme->def[".igk-config-page .conf_ctrl_info"] = "margin-top:16px; margin-bottom:16px; border:1px solid gray; padding:4px;";
		$this->m_sys_theme->def[".igk-config-page .conf_ctrl_info table"] = "{sys:disptable,fitw}";
		
		$this->m_sys_theme->def[".igk-config-page .admin_option"] = "background-color: white;";
		$this->m_sys_theme->def[".igk-config-page .admin_option li"] = "width: 150px; height:85px; display:inline-block; padding-right:4px; padding-bottom:4px;"; 
		$this->m_sys_theme->def[".igk-config-page .admin_option li a"] = "display: block; border:1px solid black; height:100%; background-color: white;";
		$this->m_sys_theme->def[".igk-config-page .igk-igk-config-content_submenu_selected"]="color:red; background-color:red;";		
		$this->m_sys_theme->def[".igk-config-page .igk-table-img-action_16x16"] = "width:16px;";
		
		$this->m_sys_theme->def[".igk-config-page .igknotificationctrl"] = "border: #7E7E7E 1px solid; ";
		$this->m_sys_theme->def[".igk-config-page .igk-notify_z"] = "padding:8px;";
		$this->m_sys_theme->def[".igk-config-page .igk-notify_g"] = $this->m_sys_theme->def[".igk-config-page .igk-notify_z"] ." [res:notify_g] [fcl:notify_g_fcl]";
		$this->m_sys_theme->def[".igk-config-page .igk-notify_b"] = $this->m_sys_theme->def[".igk-config-page .igk-notify_z"] ." [res:notify_b] [fcl:notify_b_fcl]";
		$this->m_sys_theme->def[".igk-config-page .igk-notify_i"] = $this->m_sys_theme->def[".igk-config-page .igk-notify_z"] ." [res:notify_i] [fcl:notify_i_fcl]";
		$this->m_sys_theme->def[".igk-config-page .igk-notify_w"] = $this->m_sys_theme->def[".igk-config-page .igk-notify_z"] ." [res:notify_w] [fcl:notify_w_fcl]";
		
		$this->m_sys_theme->def[".igk-config-page .igk-selectdb-row"]= "color:darkblue; background-color: #a2a2a2;";
		$this->m_sys_theme->def[".igk-config-page .clselect"] = "{sys:dispib} min-width : 200px; height:24px;";
		$this->m_sys_theme->def[".igk-config-page .connexion_frame"] = "{sys:fitw,alignc,posr} background-color:#4e4eFF; height: 10px; top: 50%;margin-top:-5px;";
		$this->m_sys_theme->def[".igk-config-page .connexion_frame .igk-config-conexion-div"] = "box-shadow:0px 0px 4px black;";
		$this->m_sys_theme->def[".igk-config-page .igk_language_list"]="";
		$this->m_sys_theme->def[".igk-config-page .igk_language_list li"]="{sys:dispib,alignt} width: 32px; height:24px; padding:1px; margin:1px;";
		$this->m_sys_theme->def[".igk-config-page .igk_language_list li a"]="{sys:dispb, fith}";
		$this->m_sys_theme->def[".igk-config-conexion-div"] = "{sys:posab} left:50%; top:50%; margin-left:-150px; margin-top:-200px;background-color:white; padding:5px;";
		
		
		
		
		$this->m_sys_theme->def[".dark_op20"] = "[res:dark_op20]";
		$this->m_sys_theme->def[".dark_op50"] = "[res:dark_op50]";
		$this->m_sys_theme->def[".dark_op70"] = "[res:dark_op70]";
		$this->m_sys_theme->def[".dark_op80"] = "[res:dark_op80]";
		$this->m_sys_theme->def[".dark_op90"] = "[res:dark_op90]";
		
		$this->m_sys_theme->def[".light_op20"] = "[res:light_op20]";
		$this->m_sys_theme->def[".light_op50"] = "[res:light_op50]";
		$this->m_sys_theme->def[".light_op80"] = "[res:light_op80]";
		$this->m_sys_theme->def[".light_op90"] = "[res:light_op90]";


		$this->m_sys_theme->def[".igk-config-page .cltext"] = "padding:4px; width:180px;";
		$this->m_sys_theme->def[".igk-config-page .clpassword"] = $this->m_sys_theme->def[".igk-config-page .cltext"];
		$this->m_sys_theme->def[".igk-config-page .cltextarea"] = "width:420px; height : 300px; white-space: nowrap; ";
		$this->m_sys_theme->def[".igk-config-page .cllabel"] = "display:inline-block; width: 150px; min-height: 32px; vertical-align:top;  line-height:auto;";
		
		
		
		$this->m_sys_theme->def[".igk-config-page .clreset"]=
		$this->m_sys_theme->def[".igk-config-page .clsubmit"]= 
		$this->m_sys_theme->def[".igk-config-page .btn_lnk"] = 
		$this->m_sys_theme->def[".igk-config-page .clbutton"] = 
		"display:inline-block; margin:2px; padding-left:4px; padding-right:4px; height:32px; line-height:32px; vertical-align: top; border:none; [bgcl:conf_btn_bgcl] color:white; min-width:120px;text-align:center; cursor:pointer; color:white; ";
		$this->m_sys_theme->def[".igk-config-page .clsearch"] = "display:inline-block; border: 1px solid darkgray;  width:auto; min-width:460px;";		
		$this->m_sys_theme->def[".igk-config-page .clsearch div"] = "padding:0px; margin:0px; background-color:transparent;";
		$this->m_sys_theme->def[".igk-config-page .clsearch input"] = "background-color:transparent; vertical-align:top; font-size: 1.5em; min-width: 425px; display:inline-block; line-height:24px;";
		$this->m_sys_theme->def[".igk-config-page .igk-horizontal-separator"]="height:16px; [res:hsep]; background-repeat:repeat-x; {sys:dispib, fitw}";
		$this->m_sys_theme->def[".igk-config-page .igk-vertical-separator"]= "width:16px; [res:vsep]; background-repeat:repeat-y";
		
		
		$this->m_sys_theme->def[".sessionctrl"] = "{sys:posfix, loc_r, loc_t} top:32px; right:32px; box-shadow:1px 1px 4px #3c3c3c; background-color:#EDEDED; z-index: 10000;";
		$this->m_sys_theme->def[".config_page"]="display:table;";// border:1px dotted #8C9191;"; 
		$this->m_sys_theme->def[".config_title"]="font-size:1.3em; font-weight:600;padding-top:8px; margin-bottom:8px;";
		$this->m_sys_theme->def[".igk-powered"] = "font-family: verdana; display:block; position:fixed; right:24px; bottom:0px;z-index: 10000; font-size:0.7em;";
		//init colors
		$this->m_sys_theme->cl["main_fcl"] = "black";
		$this->m_sys_theme->cl["main_bgcl"] = "white";
		$this->m_sys_theme->cl["search_fcl"] = "#A6A6A6";
		$this->m_sys_theme->cl["link_base_fcl"] = "black";		
		$this->m_sys_theme->cl["config_menu_selected_fcl"] = "white"; 
		$this->m_sys_theme->cl["config_menu_fcl"] = "#3a3a3a"; 
		$this->m_sys_theme->cl["igk-config-menu_bgcl"] = "";
		$this->m_sys_theme->cl["config_menu_selected_bgcl"] = "#989898";
		$this->m_sys_theme->cl["igk-config-menu_a_hover_bgcl"] = "#A3A3A3";
		$this->m_sys_theme->cl["igk-config-menu_a_hover_fcl"] = "white";
		$this->m_sys_theme->cl["igk-config-content_bgcl"]= "transparent";
		$this->m_sys_theme->cl["framebox_title_bgcl"] = "#858585";
		$this->m_sys_theme->cl["framebox_title_fcl"] = "#F5F5F5";
		$this->m_sys_theme->cl["search_fcl"]= "#5f5f5f";
		$this->m_sys_theme->cl["notify_g_fcl"] = "white";
		$this->m_sys_theme->cl["notify_b_fcl"] = "white";
		$this->m_sys_theme->cl["notify_i_fcl"] = "white";
		$this->m_sys_theme->cl["notify_w_fcl"] = "white";		
		$this->m_sys_theme->cl["conf_btn_bgcl"] = "#1D57FF";
		$this->m_sys_theme->cl["conf_notifyborder_cl"] = "#AEAEAE";
		
	
		
	}
	
	
	public function initSysTheme()
	{
		$this->m_sys_theme->cl["table_lightrow_bgcl"] = igk_get_uvar("CONFIG_PAGE_LIGHT_ROW_BGCL", "#F4F4F4",true);
		$this->m_sys_theme->cl["table_darkrow_bgcl"] =  igk_get_uvar("CONFIG_PAGE_DARK_ROW_BGCL", "#F1F1F1",true);
		$this->m_sys_theme->cl["table_row_hover_bgcl"]= igk_get_uvar("CONFIG_PAGE_ROW_HBGCL", "#4F4F4F",true);
		$this->m_sys_theme->cl["table_row_hover_fcl"]=  igk_get_uvar("CONFIG_PAGE_ROW_HFCL", "#EFEFEF",true);
		
		//init variable 
		igk_get_uvar("CONFIG_SCHEMA_FONT", "R/Fonts/AGENCYR.TTF", true);
		igk_get_uvar(IGK_CSV_SEPARATOR, ",", true);
		igk_get_uvar("CONFIG_DB_MAX_VISIBLEITEM", "50", true);
		
	}
	public function toString()
	{
		return "HtmlDocument";
	}
	public function getDocType(){
		return "<!DOCTYPE ".$this->m_docType.">";
	}
	public function addScript($file=null, $canbeMerged=true ){
		return $this->m_scriptManager->addScript($file, $canbeMerged);
	}
	public function addLink($name){
		return $this->m_linkManager->addLink($name);
	}
	public function addStyle($file){
		 $ln = new HtmlCssLink($file);
		$this->m_head->add($ln);//"link", array("href"=>$file, "type"=>"text/css", "rel"=>"stylesheet"));
		return $ln;
	}
	public function clearStyle()
	{
		$v_childs = array();
		foreach( $this->m_head->Childs as $k=>$v)
		{
			if ( get_class($v) == "HtmlCssLink")
			{
				$v_childs[] = $v;
			}
		}
		foreach($v_childs as $k)
		{
			$this->m_head->remove($k);
		}
	}

	public function Render( $options=null){
		$out ="";
		$out .= $this->getDocType();
		$out .= "<html lang=\"".$this->lang."\" xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:igk=\"".$this->m_namespase."\">";		
		$out .= $this->innerHTML($options);
		$out .= "</html>";
		return $out;
	}
	protected function innerHTML(& $options=null)
	{
		$out ="";
		$out .= $this->m_head->Render($options);
		$out .= $this->m_body->Render($options);		
		return $out;
	}
	//get the saved params
	public function getParams()
	{
		return $this->m_params;
	}
	public function getbodypage(){
		
		$i =  igk_getv($this->m_params, "bodypage");
		if ($i == null)
		{
			igk_debug("notice: the system bodypage is null");
		}
		return $i;
	}
	public function setTitle($value){
		if (($value) ==null) {igk_html_rm($this->m_title); return; }
		
		
		if ($this->m_title === null)
		{
			$this->m_title = $this->m_head->add("title");			
			$this->m_title->Index = -9999;
		}
		$this->m_title->Content = $value;
	}
	public function getTitle(){
		if ($this->m_title !== null)
		{
		return $this->m_title->Content;
		}
	}
	public function __get($key){
		if (method_exists($this, "get".$key) )
		{					
				return call_user_func(array($this, "get".$key), null);
		}	
		else{			
			return igk_getv($this->m_params, $key);			
		}
	}
	public function __set($key, $value){		
		if (!$this->_setIn($key, $value))
		{
			if ($value==null)
				unset($this->m_params[$key]);
			else 
				$this->m_params[$key] = $value;			
		}
	}
	public function setFavicon($icon)
	{
		if ($icon)
		{
		if ($this->m_favicon == null)
		{
			$this->m_favicon = $this->addLink("favicon");// HtmlItem::CreateWebNode("link");
			$this->m_favicon["title"] = R::ngets("title.favicon");
			$this->m_head->add($this->m_favicon);
			
		}
		$this->m_favicon["rel"]="shortcut icon";
		$this->m_favicon["type"]="image/x-icon";
		$this->m_favicon["href"]=$icon;

		}
		else {
			igk_html_rm($this->m_favicon);
			$this->m_favicon = null;
			exit;
		}
		
	}

	public function clearParams()
	{
		$this->m_params = array();
	}
}

final class HtmlMetaItem extends HtmlItem
{
	public function __construct()
	{
		parent::__construct("metas");
	}
	
	public function Render($options = null)
	{
		$o = $this->innerHTML($options);		
		return $o;
	}
	public function getIsVisible(){ return $this->HasChilds; }
}


final class HtmlMetaManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_managerItem ;
	private $m_node;
	private $m_metas;
	public function RenderNode(){ return $this->m_node->Render(); }
	public function getNode(){return $this->m_node; }
	public function getAuthor(){ return $this->m_metas["author"]["content"];}
	public function getCopyright(){ return $this->m_metas["copyright"]["content"];}
	public function getDescription(){ return $this->m_metas["description"]["content"];}
	public function getKeywords(){ return $this->m_metas["keywords"]["content"];}
	public function getContentType(){ return $this->m_metas["contenttype"]["content"];}
	
	
	public function setAuthor($value){  $this->m_metas["author"]["content"] = $value;}
	public function setCopyright($value){ $this->m_metas["copyright"]["content"]= $value;}
	public function setDescription($value){  $this->m_metas["description"]["content"]= $value;}
	public function setKeywords($value){ $this->m_metas["keywords"]["content"]= $value;}
	public function setContentType($value){  $this->m_metas["contenttype"]["content"]= $value;}
	
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_assocTable = array();
		$this->m_node = new HtmlMetaItem();
		
		
		
		igk_html_add($this->m_node , $this->m_htmlDoc->head);	
		$this->m_metas = array();
		$this->m_metas["author"]  = $this->m_node->add("meta", array("name"=>"author", "content"=>IGK_AUTHOR));
		$this->m_metas["copyright"]  = $this->m_node->add("meta", array("name"=>"copyright", "content"=>IGK_COPYRIGHT));
		$this->m_metas["description"]  = $this->m_node->add("meta", array("name"=>"Description", "content"=>""));
		$this->m_metas["keywords"]  = $this->m_node->add("meta", array("name"=>"keywords", "content"=>""));
		$this->m_metas["contenttype"]  = $this->m_node->add("meta", array("http-equiv"=>"Content-Type", "content"=>"text/html; charset=utf-8"));		
	}
	public function addMeta($name, $meta)
	{
		
	if ($meta){
			$this->m_node->add($meta);
			$this->m_metas[$name] = $meta;
		}
	}
	public function __toString(){ return "HtmlMetaManager";}
}



final class HtmlScriptManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_assocTable;
	private $m_node;
	private $m_managerItem ; 
	
	public function getDoc(){return $this->m_htmlDoc; }
	public function getNode(){return $this->m_node;}
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_assocTable = array();
		$this->m_node = null;
		$this->m_managerItem = new HtmlScriptManagerItem($this);
	}
	public function __toString(){ return "HtmlScriptManager"; }
	
	public function addScript($file, $canbeMerged=true){	
		if (!IGKValidator::IsUri($file))
			$file = igk_io_getdir($file);
		if (isset($this->m_assocTable[$file]))
			return $this->m_assocTable[$file];
		if ($this->m_node == null)
			$this->m_node = new HtmlBlockNodeItem();
		$s = new HtmlScript($file);
		$s->canBeMerged = $canbeMerged;
		igk_html_add($this->m_managerItem, $this->m_htmlDoc->head);		
		$this->m_node->add($s);				
		$this->m_assocTable[$file] = $s;
		return $s;
	}
}
final class HtmlScriptManagerItem extends HtmlItem
{
	private $m_scriptManager;
	
	public function __construct($scriptManager)
	{
		parent::__construct("HtmlScriptManagerItem");
		$this->m_scriptManager = $scriptManager;
	}
	public function Render($options = null)
	{
		return $this->innerHTML($options);
	}
	protected function innerHTML(& $options = null)
	{		
		//MERGE ALL SCRIPT
		$merge_all_script = false;
		if (igkServerInfo::IsIGKDEVSERVER())
		{
			$merge_all_script = true;
		}
		if (!$merge_all_script && igk_is_debuging())
		{
			return $this->m_scriptManager->Node->Render();
		}
		else{
			//merge all files in a single script item
			$txt = "";
			$Append = "";
			foreach($this->m_scriptManager->Node->Childs as $k)
			{
				
				$c = $k->link;
				if(empty($c))continue;
				
				if (($k->canBeMerged == true) && !IGKValidator::IsUri($c) )
				{
					if (file_exists($c))
					{
					$txt .= "/* FILE :  ". $c ."*/\n";
					//transform to ansi text
					$txt .= utf8_decode(file_get_contents($c))."\n";
					}
				}
				else 
					$Append.= $k->Render($options);
				
			}
			igk_getctrl("IGKScriptController")->setScript($txt);
			return "<script language=\"javascript\" type=\"text/javascript\" src=\"".igk_getctrl("IGKScriptController")->getUri("getScript")."\" ></script>".$Append;
		 }
	}
}
final class HtmlLinkManager extends IGKObject
{
	private $m_htmlDoc;
	private $m_links;
	private $m_node;
	public function __construct($htmlDoc)
	{
		$this->m_htmlDoc = $htmlDoc;
		$this->m_links = array();
		$this->m_node = null;
	}
	
	public function addLink($name){
		if (isset($this->m_links[$name]))
			return $this->m_links[$name];
		if ($this->m_node == null)
		{
			$this->m_node = new HtmlBlockNodeItem();
			HtmlUtils::AddItem($this->m_node, $this->m_htmlDoc->head);
		}
		$c = new HtmlLink();
		$this->m_node->add($c);		
		$this->m_links[$name] = $c;		
		return $c;
	}
}

//represent a document themes
final class HtmlDocTheme extends HtmlItem
{
	var $def; // default system	
	var $cl;//custom color
	var $ft; //font 
	var $res;//resources - not currently used
	var $properties; //somme properties
	var $Append; //Append to all
	var $rules;//
	private  $m_medias; //media array
	
	private $m_type;
	private $m_document;
	private $m_lastchanged; //store last theme changed
	
	const REGKEY = "HtmlDocTheme";
	public function ClearChilds(){}
	public function getDoc(){ return $this->m_document; }
	public function getFont(){
		return $this->ft;
	}
	private function reg_media($name = "print")
	{
		$n = null;
		if (!isset($this->m_medias[$name]))		
		{
			$n = new HtmlDocTheme($this->m_document,"media");
			$this->m_medias[$name] = $n;
		}
		else 
			$n = $this->m_medias[$name] ;
		return $n;
	}
	public function getPrintMedia(){
		return $this->reg_media("print");
	}

	public function __construct($document, $type="global"){
		parent::__construct("themes");
		$this->m_document = $document;
		$this->def = $this->add("Default");		
		$this->cl = $this->add("Colors");		
		$this->res = $this->add("Resources");
		$this->ft = $this->add("Fonts");
		$this->properties = $this->add("properties");
		$this->rules = $this->add("rules");
		$this->m_type =$type;
		$this->m_medias = array();
		//--------------------------------------------
		//cutom theme definitions
		//--------------------------------------------
		$this->Append = $this->add("AppendCss");
	}
	
	public function getRegChangedKey(){
		return self::REGKEY."_".$this->Name;
	}
	
	public function addColor($cl, $value)
	{
		$changed = false;
		if (isset($this->cl[$cl]))
		{
			if ($this->cl[$cl] != $value)
			{
				$this->cl[$cl] = $value;
				$changed = true;
			}
		}
		else{
			$this->cl[$cl] = $value;
			$changed = true;
		}
		if ($changed)
		{
			$this->save();
		}
	}
	public function removeColor($cl)
	{
		if (isset($this->cl[$cl]))
		{
			$this->cl[$cl] = null;
			$this->save();
		}
	}
	public function clearFont()
	{
		$tab=  $this->ft->Attributes;
		if (count($tab)> 0)
		{
			foreach($tab as $k=>$v)
			{
				$f = igk_io_currentRelativePath($v);
				if (file_exists($f))
					unlink($f);
				
			}
			$this->ft->Attributes->Clear();
			$this->save();
		}
	}
	public function addFont($name, $path)
	{
		$changed = false;
		if (isset($this->ft[$name]))
		{
			$changed = $this->ft[$name] != $path;
			$this->ft[$name] = $path;
		}
		else{
			$this->ft[$name] = $path;
			$changed = true;
		}
		if ($changed)
		{
			$this->save();
		}
	}
	///remove a specific font
	public function removeFont($name)
	{
		$f = $this->ft[$name];
		if ($f )
		{
			$f = igk_io_currentRelativePath($f);
			
			if (file_exists($f) && (unlink($f)))
			{
				igk_notifyctrl()->addMsg(R::gets("msg.fontfile.removed"));
				
			}
				$this->ft[$name] = null;
					$this->save();
					return true;
				
		}
		return false;
	}
	public function load($file)
	{	
		include($file);
	}
	public function getDeclaration()
	{
		$out = "";
		foreach($this->Attributes as $k=>$v){
	
			$out .= "\$this[\"$k\"]=\"".$v."\";\n";
		}
		foreach($this->getChilds() as $k)
		{
			if ($k->TagName == "Default") 
				continue;
			
			$out .= "\$$k->TagName = igk_getv(\$this->getElementsByTagName(\"$k->TagName\"), 0);\n";
			foreach($k->Attributes as $r=>$s)
			{
				$out .= "\$$k->TagName[\"$r\"]=\"".str_replace("\"","'", $s)."\";\n";
			}
		}
		return $out;
	}
	public function save($file =null)
	{
		
		$f = ($file==null) ? igk_io_syspath("R/Themes/".$this->Name.".phtml") : $file;
		$out ="";
		$out .="<?php\n";
		$out .= $this->getDeclaration();
		$out .="//media properties\n";
		foreach($this->m_medias as $k)
		{
			$out .= $k->getDeclaration();
		}
		$out .="?>";		
		$result =  IGKIO::WriteToFileAsUtf8WBOM($f, $out, true);
//		if ($result)
			igk_sys_regchange(self::REGKEY."_".$this->Name, $this->m_lastchanged);			
		return $result ;
	}
	public function get_css_def()
	{
		$out = $this->_get_css_def();
		
		//write media
		foreach($this->m_medias as $k=>$v)
		{
				$out .="@media ".$k."{\n";
				$out .= $v->_get_css_def();
				$out .="}\n";
		}		
		return $out;
	}
	private function _get_css_def()
	{			
$out ="";
$def = $this->def;//Defigk_getv($theme->getElementsByTagName("Default"),0);
$colors = $this->cl;//igk_getv($theme->getElementsByTagName("Colors"),0);
$fonts = $this->getFont();//$theme->getFont();
$res = $this->res; //igk_getv($theme->getElementsByTagName("Resources"),0);
$rules = $this->rules;

//write fonts
foreach($fonts->Attributes as $k=>$v)
{
	$fdd = igk_io_cwdRelativePath(igk_io_syspath($v));
	
	if (file_exists($fdd))
	{
	$format = "truetype";
	$f = "@font-face{";
	$f .= "font-family: \"$k\"; ";
	$f .= "src: url('".igk_io_baseuri()."/".igk_html_uri($v)."') format(\"$format\")";	
	$f .="}
";	
	$out.= $f;	
	}
	else{
		igk_wl("/* Font file doesn't exist : ".$fdd . "*/\n");
	}
}

//set default property
foreach($def->Attributes as $k=>$v)
{	
	$kv = trim(igk_css_treat($this, $v));
	if (!empty($kv))
	{
	$out .= $k." { ".$kv."} 
";
	}
}

foreach($rules->Attributes as $k=>$v)
{	
	
	if (!empty($v))
	{
	$out .= $k." { ".$v."} 
";
	}
}

//add global attribute
$tab = $this->Attributes->toArray();
$keys = array_keys($tab);
igk_usort($keys, "igk_key_sort");
foreach($keys as $k)
{
	$cc = $def->Attributes[".".$k];
	//already define in definition context continue;
	if (!empty($cc))continue;
	
	$v = $tab[$k];
	$kv = trim(igk_css_treat($this, $v));
	if (!empty($kv))
	{
		if (IGKString::StartWith($k, "#"))
			$out .= $k." { ".$kv."} 
";
		else
			$out .= ".".$k." { ".$kv."}
";
	}
}

foreach($colors->Attributes as $k=>$v)
{
	$v = igk_css_treatcolor($colors, $v);
	if (IGKString::EndWith($k, "_bgcl"))
	{
		$out .= ".".$k." { ".igk_css_getbgcl($v)."} 
";
	}
	else if (IGKString::EndWith($k, "_fcl"))
		$out .= ".".$k." { ". igk_css_getfcl($v) ."} 
";
}
$res = $this->res; //igk_getv($this->res->getElementsByTagName("Resources"),0);
foreach($res->Attributes as $k=>$v)
{
	$out .= ".".$k." { background-image: url('../Img/".$v."') } 
";
}

//render Append theme
$tab = $this->Append->Attributes->toArray();
if (count($tab)>0)
{
$keys = array_keys($tab);
$out .= "/* APPEND THEME */\n";
igk_usort($keys, "igk_key_sort");
foreach($keys as $k)
{	
	$v = $tab[$k];
	$kv = trim(igk_css_treat($this, $v));
	if (!empty($kv))
	{
		if (IGKString::StartWith($k, "#"))
			$out .= $k." { ".$kv."} 
";
		else
			$out .= ".".$k." { ".$kv."}
";
	}
}
}
return $out;
	}
}
///<summary>igk framework form</summary>
final class HtmlForm extends HtmlItem
{
	private $encType;
	private $topdiv;
	private $bodydiv;
	private $footdiv;
	private $owner;
	private $m_notitle;
	private $m_nofoot;
	
	
	public function getNoTitle(){return $this->m_notitle;}
	public function getNoFoot(){return $this->m_nofoot;}
	public function setNoTitle($value){ $this->m_notitle = $value;}
	public function setNoFoot($value){ $this->m_nofoot = $value;}
	public function getAction(){return $this["action"];}
	public function setAction($value){return $this["action"]=$value;}
	public function getMethod(){return $this["method"];}
	public function setMethod($value){return $this["method"] = $value;}
	public function getEncType(){return $this->encType;}
	public function setEncType($value){$this->encType=$value;}
	public function setTitle($value){$this->topdiv->Content = $value;}
	public function getTitle(){return $this->topdiv->Content;}
	public function __construct($notitle=false, $nofoot = false){
		parent::__construct("form");
		$this->Method = "POST";
		$this->Action= ".";
		$this->encType =true;
		$this->m_notitle = $notitle;
		$this->m_nofoot = $nofoot;
		$this["class"]="clbasicform";
		
		
		$owner  = HtmlItem::CreateWebNode("div");
		$this->owner= $owner;
		
		$this->topdiv = $owner->addDiv(array("class"=>"frm_title"));		
		$this->bodydiv = $owner->addDiv();
		$this->footdiv = $owner->addDiv();
		$this->add($owner);
	}
	public function ClearChilds(){
		$this->bodydiv->ClearChilds();
	}
	protected function _AddChild($item, $index=null)
	{
		if ($item === $this->owner)
		{
			return parent::_AddChild($item);
		}
		else{
			return $this->bodydiv->_AddChild($item);
		}
		return false;
	}
	public function add($nameoritem, $attributes=null, $index= null)
	{
		$t = null;
		if ($nameoritem === $this->owner)
		{
			return parent::Add($nameoritem, $attributes, $index);
		}
		else{
			$t = $this->bodydiv->add($nameoritem, $attributes, $index);		
		}
		return $t;
	}
	public function Render($options=null)
	{
		if ($this->encType)
			$this["enctype"]=IGK_HTML_ENCTYPE;
		else 
			$this["enctype"]=null;	
		$e = $this->topdiv->Content ;
		
		$this->topdiv->IsVisible = !empty($e) && !$this->m_notitle;
		$this->footdiv->IsVisible = !$this->m_nofoot;
		
		return parent::Render($options);		
	}
}


class HtmlCssLink extends HtmlItem
{
	var $link;
	private $ln;
	public function __construct($link){
		$this->IsVisible =true;
		$this->link = $link;
		$this->ln = self::CreateWebNode("link");
		$this->ln["type"]="text/css";
		$this->ln["rel"]="stylesheet";
		
	}
	protected function innerHTML(& $option = null)
	{
		return null;
	}
	public function Render($xmlsetting=null){
		$this->ln["href"] = igk_html_uri(IGKIO::GetCurrentRelativeUri($this->link));
		return $this->ln->Render($xmlsetting);
	}
}
final class HtmlLink extends HtmlItem
{
	public function __construct(){
		parent::__construct("link");
	}
}
class HtmlScript extends HtmlItem
{
	var $link;
	var $canBeMerged;
	///private $ln;
	public function __construct($link=null){
		parent::__construct("script");
		$this->link = $link;
		//$this->ln = self::CreateWebNode("script");
		$this["type"]="text/javascript";
		$this["language"]="javascript";
		$this->canBeMerged = true;
		
	}
	
	public function Render($xmlsetting=null){
	
		$src = "";
		if ($this->link !=null)
		{
			if (!IGKValidator::IsUri($this->link)&& file_exists($this->link))
			{
				$src =  igk_io_currentRelativeUri(igk_io_basePath($this->link));
			}
			else{
				$src = $this->link;
			}
		}
		$this["src"] = $src ;
		return parent::Render($xmlsetting);
	}
}
class HtmlDiv extends HtmlItem
{
	protected  function closeWithCloseTag(){
		return true;
	}
	public function __construct(){
		parent::__construct("div");
		
	}
	
}
class HtmlImg extends HtmlItem
{
	var $lnk;
	var $img;

	public function offsetGet($key){
		if (strtolower($key)=="src")
			return $this->lnk;
		return $this->img->offsetGet($key);
	}
	public function offsetSet($key,$value) {
	
		if (strtolower($key) =="src")
		{
			$this->lnk = $value;
		}
		else
			$this->img->offsetSet($key,$value);}
	public function __construct(){
		parent::__construct("igk-html-image");
		$this->img = new HtmlItem("igk-img");
		$this->img["alt"]=R::ngets("tip.picture");		
	}
	public function Render($xmlsetting=null)
	{
	
		if (!empty($this->lnk))
		{
			if (IGKValidator::IsUri($this->lnk))
			{
				$this->img["src"] = $this->lnk;
			}
			else{
				$this->img["src"]= igk_html_uri(igk_io_currentRelativeUri($this->lnk, "/"));
			}
		}
		else
			$this->img["src"]=null;
		return $this->img->Render($xmlsetting);
	}
	public function __toString(){
		return "igkImg[".$this->lnk."]";
	}
}

//
final class HtmlNothingItem extends HtmlItem
{
	public function __construct(){
		parent::__construct("nothingitem");
	}
	//unable to add child to this item
	protected function _AddChild($item, $index=null){return false;}
	public function Render($options=null){
		return null;
	}
}
class HtmlDoctype extends HtmlItem
{
	public function __construct($value){
		$this->Content = $value;
	}
	public function Render($xmlsetting=null){
		$out = "<!DOCTYPE ".$this->Content . " >".$this->indentLine($options);
		return $out;
	}
	protected function _AddChild($item, $index=null){return false;}
}
class HtmlComment extends HtmlItem
{
	public function __construct($value){
		$this->Content = $value;
	}
	public function Render($options=null){
		$out = $this->getIndentDepth($options)."<!-- ".$this->Content . " -->".$this->indentLine($options);		
		return $out;
	}
	public function __toString(){
		return "HtmlComment[".$this->Content."]";
	}
	protected function _AddChild($item, $index=null){return false;}
}
class HtmlMeta extends HtmlItem
{
	public function __construct(){
		parent::__construct("meta");
	}
	public function setContent($v){/*no set content*/ }
	protected function _AddChild($item, $index=null){return false;}
}
class HtmlUl extends HtmlItem
{
	public function __construct(){
		parent::__construct("ul");
	}
	public function addLi($attributes=null){
		return $this->add("li", $attributes);
	}
}
class HtmlInput extends HtmlItem
{
	public function __construct(){
		parent::__construct("input");
	}
	
	protected function _AddChild($item, $index=null){return false;}
}

///<summary>represent html utility </summary>
final class HtmlUtils
{
	public static function AddToggleAllCheckboxTh($tr)
	{
		return $tr->add("th",array("class"=>"box_16x16"))->add("li")->add("input", 
			array("type"=>"checkbox","onchange"=>"window.igk.ctrl.utils.check_all(this, window.igk.getParentByTagName(this, 'table'), this.checked, true);"));
	}
	
	public static function GetTableFromSingleArray($array)
	{
		$tab = HtmlItem::CreateWebNode("table");
		foreach($array as $k=>$v)
		{
			$tr = $tab->add("tr");
			$tr->add("td")->Content  = $k;
			$tr->add("td")->Content  = $v;
		}
		return $tab;
	}
	///get all element childs
	public static function GetAllChilds($t)
	{
		$d = array();
		if (method_exists(get_class($t), "getChilds"))
		{
			$s = $t->getChilds();
			if (is_array($s))
			{
				$d = array_merge($d, $s);
				
				foreach($s as $k){
					$d = array_merge($d, igk_getAllChilds($k));
				}
			}
		}		
		return $d;
	}
	
	///used to create sub menu in category 
	public static function CreateConfigSubMenu($target, $items, $selected =null)
	{
		
		$ul = $target->add("ul", array("class"=>"igk-config-content_submenu"));
		foreach($items as $k=>$v)
		{
			$li = $ul->add("li");
			$li->add("a", array("href"=>$v))->Content = R::ngets("cl".$k);
			if ($selected == $k)
			{
				$li["class"] = "+igk-igk-config-content_submenu_selected";
			}
			else{
				$li["class"] = "-igk-igk-config-content_submenu_selected";
			}
		}
		return $ul;
	}
	public static function ToggleTableClassColor($target, $type="tr",  $startAt=0, $class1="table_darkrow", $class2="table_lightrow")
	{
		if ($target == null)return;
		$k = 0;
		$tab = $target->getElementsByTagName($type);
		
		for	($i = $startAt; $i< count($tab); $i++)
		{
			if (isset($tab[$i])){
			$tr = $tab[$i];
			if ($k == 0)
			{
				$tr["class"] =$class1;
				$k=1;
			}
			else 
			{
				$tr["class"] = $class2;
				$k = 0;
			}
			}
		}
	}
	public static function BuildForm($array)
	{
		$frm = HtmlItem::CreateWebNode("form");
		foreach($array as $k=>$v)
		{
			switch(strtolower($k))
			{
				case "label":
					$lb = $frm->add("label");
					$lb->Content = R::ngets("");
				break;
				case "radio":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "radio");
				break;
				case "checkbox":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "checkbox");
				break;
				case "hidden":
					$frm->addInput($v["id"],igk_getv($v ,"text", null), "hidden");
				break;
				
				case "button":
				case "submit":
				case "reset":
					$frm->addInput($v["id"],strtolower($k),igk_getv($v ,"text", "r") );
				break;
				case "textarea":
					$frm->addTextArea($v["id"]);
				break;
				case "br":
					$frm->addBr();
				break;
			}
		}
		return $frm;
	}
	public static function ShowHierarchi($var){

	$out = "";
	if ($var->HasChilds){
		$out .="<ul>";
	foreach($var->Childs as $k)
	{
		$out .= "<li>".$k->TagName;
		if ($k->TagName == "a")
			$out.= " : ".$k->Content;
		if ($k->TagName == "input")
			$out.= " : ".$k["value"];
		$out .= self::ShowHierarchi($k);
		
		$out .="</li>";
	}
	$out.="</ul>";
	}
	return $out;
}
	//new input
	public static function nInput($id, $value=null, $type="text")
	{
		$btn =  HtmlItem::CreateWebNode("input", array("id"=>$id, "name"=>$id, "type"=>$type, "value"=>$value));
		switch(strtolower($btn["type"]))
		{
			case "button":
			case "submit":
			case "reset":
				$btn["class"]="clbutton";
			break;
		}
		return $btn;
	}
	//
	public static function nTextArea($id, $value){
		return HtmlItem::CreateWebNode("textarea", array("id"=>$id, "name"=>$id, "value"=>$value));
	}
	public static function nBtn($owner, $uri, $img, $width=16, $height=16)
	{
		$node = HtmlItem::CreateWebNode("a", array( "href"=>$uri, "class"=>"btn_lnk", "style"=>"width:".$width."px; height:".$height."px;"));//, "value"=>$value));
		$node->add("img", array("src"=>$img, "width"=>$width."px", "height"=>$height."px"));
		$owner->add($node);
		return $node;
	}
	public static function RemoveItem($item, $dispose=false)
	{
		$p = null;
		if (($item!=null)&&	(($p= $item->getHtmlItemParent()) !=null ))
		{
			$p->remove($item);
			//element is still not null
			if ($item->getHtmlItemParent() !=null)
			{
				throw new Exception("RemoveItem::Element Not removed = ". $item->getHtmlItemParent()->TagName);
			}
			else if($dispose){
				$item->Dispose();
				unset($item);
			}
			
		}
		
	}
	//add items
	
	public static function AddItem($item, $target, $index=null)
	{
		if (($item==null) || ($target==null))
			return false;
		if ($item->Parent === $target)
			return true;
		self::RemoveItem($item);
		return $target->add($item, null, $index);					
	}
	//copy item child to target
	public static function CopyChilds($item, $target)
	{
		if (($item==null)||($target==null)|| !$item->HasChilds)
			return false;
			foreach($item->getChilds() as $k)
			{
				$target->Load($k->Render());
			}
			return true;
	}
	//move instance
	public static function MoveChilds($item, $target)
	{
		if (($item==null)||($target==null)|| !$item->HasChilds)
			return false;
			foreach($item->getChilds() as $k)
			{
				HtmlUtils::AddItem($k, $target);
			}
			return true;
	}
	//return value according to string
	public static function GetValue($c)
	{
		$out = "";
		if (is_numeric($c) && ($c == 0))
			return "0"; 
			if (is_numeric($c) || (is_string($c) &&  !empty($c)))
			{
				$out.=$c;
			}
			else if (is_object($c) && (method_exists(get_class($c),"getValue")) )//&& get_class($c) == "IGKLangKey")
			{
				$out .= $c->getValue();
			}
			
		return $out;
	}
	public static function GetAttributeValue($c)
	{
		$s = self::GetValue($c);
		$q = trim($s);
		if (IGKString::StartWith($q, "\""))
		{
			$q = substr($q,1);
		}
		if (IGKString::EndWith($q, "\""))
		{
			$q = substr($q,0, strlen($q) - 1);
		}
		return $q;
	}
	//@@@ add button link
	public static function AddBtnLnk($target, $langkey,  $uri, $attributes = null)
	{	
		if ($target==null)return;
		$a  = $target->add("a" ,array("class"=>"btn_lnk", 
			  "href"=>$uri));
			  $a->Content = R::ngets($langkey);
		if (is_array($attributes))
		{
			$a->AppendAttributes($attributes);
		}
		return $a;
	}
	//@@@ AddImgLnk add image link
	public static function AddImgLnk($target, $uri, $imgname, $width="16px", $height="16px", $desc=null, $attribs=null)
	{
		if (is_object($target))
		{
			$a  = $target->add("a", array("href"=>$uri, "class"=>"img_lnk"));
			$a->add("img", 
							array(
							"width"=>$width,
							"height"=>$height, 
							"src"=>R::GetImgUri($imgname),
							"alt"=>R::ngets($desc)));
			$a->AppendAttributes($attribs);
			return $a;
		}
		return null;
	}
}

class XMLNodeType
{
	const NONE = -1;
	const ELEMENT = 1;
	const PROCESSOR = 2;
	const COMMENT = 3;
	const ENDELEMENT = 4;
	const CDATA = 5;
	const TEXT = 6;
	const DOCTYPE = 7;
	
	public function GetString($i)
	{
		switch($i)
		{
			case self::NONE: return "NONE";
	case self::ELEMENT : return "ELEMENT";
	case self::PROCESSOR : return "PROCESSOR";
	case self::COMMENT : return "COMMENT";
	case self::ENDELEMENT : return "ENDELEMENT";
	case self::CDATA : return "CDATA";
	case self::TEXT : return "TEXT";
	case self::DOCTYPE : return "DOCTYPE";
		}
		return "UNKNOWN";
	}
}

///@xml render document
class IGKHTMLReaderDocument extends HTMLItem
{
	public function __construct()
	{
		parent::__construct("DocumentToRender");
	}
	public function Render($xmlsetting = null)
	{
		$out = "";
		foreach($this->Childs as $k)
		{
			$out .= $k->Render($xmlsetting);
		}
		return $out;
	}
	public function CopyTo($target)
	{	
		$t = $this->Childs->ToArray();
		$this->ClearChilds();
		foreach($t as $k)
		{
			if ($k == null)
				continue;
			$target->add($k);
		}
	}
	public function add($name, $attributes=null, $index= null)
	{
		$t = parent::Add($name, $attributes);	  
		return $t;
		
	}
}

//@ represent a html/xml reader info
class IGKHTMLReader
{
	private $m_hfile;
	private $m_text;
	private $m_mmodel;
	private $m_offset;
	private $m_name;
	private $m_value;
	private $m_nodetype;
	private $m_isEmpty;
	private $m_hasAttrib;
	private $m_attribs;
	
	public function NodeType()
	{
		return $this->m_nodetype;
	}
	private function __construct($text)
	{
		$this->m_text= $text;
		$this->m_offset =0;
		$this->m_nodetype= XMLNodeType::NONE;
		$this->m_attribs = null;
	}
	public function Name(){ return $this->m_name;}
	public function Value(){ return $this->m_value;}
	public function IsEmpty(){return $this->m_isEmpty;}
	public function HasAttrib(){return $this->m_hasAttrib;}
	public function Attribs(){return $this->m_attribs; }
	public function Read()
	{
		if (!$this->CanRead())
		{//default setting
			$this->m_nodeType  = XMLNodeType::NONE;
			$this->m_value = null;
			$this->m_name = null;
			$this->m_isEmpty = true;
			$this->m_hasAttrib = false;
			$this->m_attribs = null;
			return false;
		}
		
		$v_enter = false;
		$this->m_isEmpty = false;
		$this->m_hasAttrib  = false;
		$v = ""; //value
	
		
		while($this->CanRead())
		{
		$c =$this->m_text[$this->m_offset];
		
		switch($c)
		{
			case "<":
				$v_enter = true;								
			break;
			case "?": //preprocessor instruction
				if ($v_enter)
				{
						//reading process
						$this->m_offset ++;
						$v ="";
						while( $this->CanRead())
						{
							$v .= $this->m_text[$this->m_offset];							
							$this->m_offset++;
							//end comment
							if (substr($v, -2, 2) == "?>")
							{
								$v = substr($v, 0, strlen($v)-3);
								
								$this->m_name = null;
								$this->m_value = $v;
								$this->m_nodetype = XMLNodeType::PROCESSOR;
								return true;								
							}
						}
						
				}
				else{
				//not entered a prepropecessor instruction
					return $this->__readTextValue($v);
				}
				return false;				
			break;
			case "!": 
			
				if ($v_enter)
				{
					if (substr($this->m_text, $this->m_offset+1,2) == "--")
					{
						//reading comment
						$this->m_offset +=3;
						$v ="";
						while( $this->CanRead())
						{
							$v .= $this->m_text[$this->m_offset];							
							$this->m_offset++;
							//end comment
							if (substr($v, -3, 3) == "-->")
							{
								$v = substr($v, 0, strlen($v)-3);								
								$this->m_name = null;
								$this->m_value = $v;
								$this->m_nodetype = XMLNodeType::COMMENT;								
								return true;								
							}
						}						
					}
					else if (strtoupper(substr($this->m_text, $this->m_offset+1,7)) == "[CDATA[")
						{//reading CDATA
							$this->m_offset +=8;
							$v ="";
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//end comment
								if (substr($v, -3, 3) == "]]>")
								{
									$v = substr($v, 0, strlen($v)-3);								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = XMLNodeType::CDATA;								
									return true;								
								}
							}						
					}
					else if (strtoupper(substr($this->m_text, $this->m_offset+1,7)) == "DOCTYPE")
					{//reading DOC TYPE
							$this->m_offset +=8;
							$v ="";
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//end doctype
								if (substr($v, -1, 1) == ">")
								{
									$v = substr($v, 0, strlen($v)-1);								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = XMLNodeType::DOCTYPE;								
									return true;								
								}
							}					
					}
					return false;
				}
			break;			
			case "/": //end element	
				if ($v_enter)
				{		
					$this->m_offset+=1;				
					$this->m_nodetype =  XMLNodeType::ENDELEMENT;
					$this->m_name = $this->ReadName();
					$this->m_value= null;
					$v_enter = false;
					return true;
				}
				break;
			default:	//read default case			
				if (!$v_enter)
				{
					if ($this->m_nodetype ==  XMLNodeType::ELEMENT)
					{
						
						$match = array();
						if (strtolower($this->m_name) == "script")
						{
						
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								
								if (preg_match("/\<\/([\s]*)script([\s]*)\>$/i",$v, $match))
								{
									$this->m_offset-= strlen($match[0]);
									$v = substr($v, 0, strlen($v)-strlen($match[0]));	
									break;
								}
							}
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = XMLNodeType::TEXT;	
									return true;
						}
						else if (strtolower($this->m_name) == "style")
						{//for style
						
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								
								if (preg_match("/(\<\/([\s]*)style([\s]*)>)$/i",$v, $match))
								{
									$this->m_offset-= strlen($match[0]);
									$v = substr($v, 0, strlen($v)-strlen($match[0]));	
									break;
								}
							}
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = XMLNodeType::TEXT;	
									return true;
						}
						else {
						    //
							//read text value	
							//
							return $this->__readTextValue($v);
						}
					}
					else{
							//read text elements
							$v="";
							if ($this->m_nodetype ==  XMLNodeType::ENDELEMENT)
								$this->m_offset++;
							while( $this->CanRead())
							{
								$v .= $this->m_text[$this->m_offset];							
								$this->m_offset++;
								//e
								if (substr($v, -1, 1) == "<")
								{
									$v = substr($v, 0, strlen($v)-1);		
									$this->m_offset--;								
									$this->m_name = null;
									$this->m_value = $v;
									$this->m_nodetype = XMLNodeType::TEXT;		
									return true;								
								}
							}
					}
				}
				else
				{//element requested
				
					$this->m_name = $this->ReadName();
					$this->m_value= null;
					$this->m_nodetype =  XMLNodeType::ELEMENT;		
					$this->m_isEmpty = false;
					$this->m_hasAttrib = false;
					//get attribute
					$v_end = false;
					$v = "";//for xml read attribute contains
					$v_readname =false;
					$v_readvalue=false;
					$v_assoc = array();
					$v_attribname = null;
					$v_ch = null;//character
					
						while( $this->CanRead())
						{
							$v_ch =  $this->m_text[$this->m_offset];													      	
							$v .= $v_ch;
							$this->m_offset++;
							//end comment
							
							
							if (substr($v, -2, 2) == "/>")
							{
								//empty element
								$v = trim(substr($v,0, strlen($v)-2));
								$this->m_isEmpty = true;
								break;
							}
							else if (substr($v, -1, 1) == ">")
							{
								$v = trim(substr($v,0, strlen($v)-1));
								$this->m_isEmpty = false;
								break;
							}
							//for reading the name
							if ($v_readname ==false)
							{
								if (preg_match("/([\s])/",$v_ch))
								{
									$v_attribname=$v_ch;
									$v_readname = true;
									$v_readvalue = false;
								}
							}
							else{
								if (preg_match("/[\s]/", $v_ch))
									$v_attribname .= $v_ch;
								else{
									$v_readname = false;
									$v_assoc[] = $v_attribname;
								}
							}
						}
						
						if (!empty($v))
						{
								$this->m_hasAttrib =true;								
								$m = null;		
								//def: "/(\w+)[\s]*=[\s]*(\"|')(?P<value>(([^\"']*(')?)+))(\"|')/"								
								$machv = "([\"](([^\"]*(')?(\"\")?)+)[\"])";
								$machv .= "|([\'](([^']*(\")?('')?)+)[\'])";
								$machv .= "|(([^\s]*)+)";
								$acount = preg_match_all("/(\w+)[\s]*=[\s]*(".$machv.")/",$v, $m);								
								$this->m_attribs = array();	
								for($cc =0;$cc< $acount; $cc++)
								{
									$this->m_attribs[$m[1][$cc]] =$m[4][$cc];
							
								}
						}					
						return true;
				}
				break;
				
		}
		$this->m_offset+=1;
		
		}
		if (!$v_enter && !empty($v))
		{
			$this->m_name = null;
			$this->m_value = $v;
			$this->m_nodetype = XMLNodeType::TEXT;		
			return true;	
		}
		//exit;
		return false;
	}
	private function __readTextValue($v="")
	{
	
		while( $this->CanRead())
		{
			$v .= $this->m_text[$this->m_offset];							
			$this->m_offset++;
			
			if (substr($v, -1, 1) == "<")
			{
				$v = substr($v, 0, strlen($v)-1);		
				$this->m_offset--;								
				$this->m_name = null;
				$this->m_value = $v;
				$this->m_nodetype = XMLNodeType::TEXT;		
				return true;								
			}
		}
		return false;
	}
	//check if can read
	private function CanRead()
	{
		
		return (($this->m_offset>=0) && ($this->m_offset < strlen($this->m_text)));
	}
	//@@@ read tag name
	private function ReadName()
	{
		$v = "";
		//check reaed cararacter
		while( $this->CanRead() && preg_match("/[0-9a-z\-:]/i",$this->m_text[$this->m_offset]))
		{
			$v .= $this->m_text[$this->m_offset];
			$this->m_offset++;
		}				
		return $v;
	}
	
	public static function Create($file)
	{
		if (is_file)
		{
			$f = fopen($file,"r");
			if ($f)
			{
				$reader = new IGKHTMLReader();
				$reader->m_hfile = $f;
				return $reader;
				
			}
		}
		return null;
	}	
	public function Close()
	{
		fclose($this->hfile);
	}
	
	//@@@ return a array of xml node
	//------------------------------
	public static function Load($text)
	{
		$opentag = false;		
		$tab = null; 
		$cnode = null;
		$pnode = null;
		
		if (is_string($text))
		{
		
			$tab =  new IGKHTMLReaderDocument();			
			$reader = new IGKHTMLReader($text);
			
			//get elements
			while($reader->Read())
			{
			    //igk_wln("NODE TYPE : ".XMLNodeType::GetString($reader->NodeType()) . "[".$reader->Name()."] - ".$reader->Value());
				switch($reader->NodeType())
				{
					case XMLNodeType::ELEMENT :							
						$name = $reader->Name();
						//igk_wln(" : ".$name);
						if(empty($name))
						{
							continue;
						}	
						$v = HTMLItem::CreateWebNode($name);
						
						if ($reader->HasAttrib())
						{
							//buildd attribs
							$cattr = $reader->Attribs();
							foreach($cattr as $k=>$c)
							{											
								$v[$k] = $c;
							}
						}										
				
						if (!$cnode)
						{					
							$tab->add($v);
							$cnode = $v;
						}
						else 
						{
							$cnode = self::_addItem($v, $tab, $cnode);						
						}		
						if ($reader->IsEmpty())
						{
							//move to parent
							$cnode = $cnode->getHtmlItemParent();
							if ($cnode == $tab)
								$cnode = null;
						}
						break;
					case XMLNodeType::TEXT:
						//add only text to current node element		
						$v_sr= $reader->Value();						
						$v_c="";
						if (!empty($v_sr) && (strlen(trim($v_sr))>0))
						{
							$v_c = $v_sr;
						}
						if (!empty($v_c))
						{
							if ($cnode)
							{
								$cnode->addText($v_sr);									
							}	
							else{
								$v = new HtmlText($v_sr);
								$tab->add($v);
								$cnode = $v;
							}
						}						
						break;
					case XMLNodeType::COMMENT:
						$v_v = $reader->Value();					
						$v = new HTMLComment($v_v);	
							
						if (!$cnode)
						{
							$cnode = $v;
							$tab->add($v);
						}
						else{								
							$cnode = self::_addItem($v, $tab, $cnode);
						}						
						break;
					case XMLNodeType::CDATA:
					case XMLNodeType::DOCTYPE;
						$v = self::CreateElement($reader->NodeType()); 
						$v->Content = $reader->Value();
						if (!$cnode)
						{
							$cnode = $v;
							$tab->add($v);
						}
						else{
							$cnode = self::_addItem($v, $tab, $cnode);
						}					
						break;
					case XMLNodeType::ENDELEMENT :
						if ($cnode)
						{
							if ($reader->Name() == $cnode->TagName)
							{
								$cnode = $cnode->getHtmlItemParent();	
							}
							else{
								while( $cnode && ($cnode->TagName != $reader->Name()))
								{
									$cnode = $cnode->getHtmlItemParent();
								}
								if ($cnode)
									$cnode = $cnode->getHtmlItemParent();
								else
									throw new Exception("Bad Html structure can't get parent, cnode is null,\nLine ". __LINE__."\n".$text);
							}
							if ($cnode == $tab)
								$cnode = null;
						}
						else 
							$cnode = null;
					break;
					case XMLNodeType::PROCESSOR:	
							$v = $reader->Value();
							$v_cnode = new HtmlProcessInstruction($v);
						if (!$cnode)
						{
							$cnode = $v_cnode;
							$tab[] = $cnode;							
						}	
						else{
							$cnode->add($v_cnode);
						}							
						break;
				}
			}
		}
		else if (is_resource($text))
		{//loading resources files
			
		}		
		return $tab;
		
	}
	private  static function _addItem($v, $tab, $cnode)
	{
		
		if ($cnode->add($v))
		{
			$cnode = $v;
			
		}
		else if (!self::_AddToParent($tab, $cnode, $v))
		{
			$tab->add($v);
			$cnode = $v;
		}
		else {
			$cnode = $v;
		}
		return $cnode;
	}
	public static function CreateElement($nodetype,$value="")
	{
		$v = null;
		switch($nodetype)
		{
			case XMLNodeType::CDATA:
				$v = new HTMLCData($value);
				break;
			case XMLNodeType::DOCTYPE:
				$v = new HtmlDoctype($value);
				break;
		}
		return $v;
	}
	//@load the  files
	public static function LoadFile($file)
	{
		if (is_file($file))
		{
			$size  = @filesize($file);
			if ($size > 0)
			{
				try{
				$hfile = fopen($file, "r");
				}
				catch(Exception $ex)
				{
				}
				if ($hfile)
				{
				$text  = fread($hfile, $size);
				fclose($hfile);			
				return self::Load($text);
				}
			}
			return null;
		}
		throw new Exception("file : ".$file." doesn't exist");
	}
	
	static function _AddToParent($topnode, $cnode, $node)
	{	
		$p = $cnode->getHtmlItemParent();
		if ($topnode === $p)
			return false;
		if ($p)
		{
			if ($p->add($node)==false)
			{
				return self::_AddToParent($topnode, $p, $node);
			}
			else 
				return true;
		}
		return false;
	}


}

//------------------------------------------------------------------------------------------
//DATABASE MANAGEMENT
//------------------------------------------------------------------------------------------

//db manager interface
interface IIGKdbManager
{
	function connect();
	function close();
}


interface IIGKQueryResult
{
	
}
class IGKDbEntity extends IGKObject
{
	private $m_propertyChangedEvent;
	private $m_db_origin;
	private $m_table_origin;
	
	public function __construct(){
			$this->m_propertyChangedEvent = new IGKEvents($this, "propertyChangedEvent");
	}
	public function __toString(){return "IGKDbEntity";}
	
	public function __set($name, $value)
	{
		parent::__set($name, $value);
		$this->onPropertyChanged($name, $value);
	}
	protected function onPropertyChanged()
	{
		$this->m_propertyChangedEvent->Call($this, null);
	}
}
final class  IGKdbColumnDataType
{
	const VARCHAR = "VarChar";
	const INT32 = "Int";
	const TEXT = "Text";
	const SINGLE = "Float";
	const DOUBLE_SINGLE = "Double";
	const DATE_TIME = "Datetime";
	
	public static function GetDbTypes()
	{
		$t = array(
			self::VARCHAR=>self::VARCHAR,
			self::INT32=>self::INT32,
			self::TEXT=>self::TEXT,
			self::SINGLE=>self::SINGLE,
			self::DOUBLE_SINGLE=>self::DOUBLE_SINGLE,
			self::DATE_TIME=>self::DATE_TIME
			);
		return $t;
		
		
	}
}
//represent column info
class IGKDbColumnInfo extends IGKObject
{
	var $clName;
	var $clType;
	var $clTypeLength;
	var $clAutoIncrement;
	var $clNotNull;
	var $clIsPrimary;
	var $clIsUnique;
	var $clIsUniqueColumnMember;
	var $clDefault;	
	var $clDescription;
	
	var $clIsNotInQueryInsert; //not in insertion query
	
	//for table relation
	var $clLink; //data table relations // array of link relation in a column
	var $clFromTable; //target table
	var $clFromTableDisplay;//array used to display the property
	
	public function __toString(){
		return "IGKdbColumnInfo[".$this->clName."]";
	}
	public static function AssocInfo($array)
	{
		$t = array();
		foreach($array as $k=>$v)
		{
			if ($k !== $v->clName)
			{
				$t[$v->clName] = $v;
			}
			else{
				$t[$k] = $v;
			}
		}
		return $t;
	}
	
	public function __construct($array=null)
	{
		$this->clTypeLength = 25;
		$this->clNotNull = false;
		if (is_array($array))
		{
			foreach($array as $k=>$v)
			{
				
				$this->$k = $v;
			}
		}
		
	}	
	public function __get($key){ 
	$d = get_class_vars(get_class($this)) ; 
	
	if (array_key_exists ( $key, $d)){		
		return $this->$key;
	}
	throw new Exception("Not implements : ".$key);}
	public function __set($key, $value){throw new Exception("variable : [". $key ."] Not Implements");}
	
	public static function GetColumnInfo()
	{
		return get_class_vars("IGKDbColumnInfo");
	}
	public static function NewEntryInfo()
	{
		return new IGKDbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true));
	}
}


//------------------------------------------------------------------------------------------
//INTERFACE: IIGKContolller
//------------------------------------------------------------------------------------------
interface IIGKController{
	
	
	//get the name of the controller
	function getName();
	//init de data menu
	function initMenu();
	//view method that will be call to render the view of this controller
	function View();
	//primary target node
	function getTargetNode();
	function getTargetNodeId();
}
interface IIGKDataController extends IIGKController
{
	//init the data base model
	function initDb();
	function getDataTableName();
	function getDataTableInfo();
	function getDataAdapterName();	
}

interface IIGKUserController{
	function connect();
	function register();
}

//------------------------------------------------------------------------------------------
//CLASS: IGKCONTROLLERBASE
//------------------------------------------------------------------------------------------
abstract class IGKControllerBase extends IGKObject
 implements IIGKController , IIGKWebController , IIGKDataController
{
	private $_visiblePage;
	private $m_targetNode;
	private $m_webParentCtrl;	
	private $m_childsctrl;
	private $m_regviewChilds;
	private $m_configs;	

	private $m_params;   // the params view
	private $m_pageview; // the page view
	private $m_view;     // the current view of this controller. "default" is the default value -> default.phtml
	private $m_visibility; 
	
	public function getVisibility(){return $this->m_visibility; }
	protected function setVisibility($visibility) { $this->m_visibility = $visibility; }
	public function getCurrentView (){ return $this->m_view; } 
	public function setCurrentView($view){ if ( $this->m_view != $view ) {$this->m_view = $view; $this->View(); } }
	//retreive the global application uri
	public static function CurrentUri(){
		return igk_getv($_SERVER, "REQUEST_URI");
	}
	public static function CurrentQueryString()
	{
		return igk_getv($_SERVER, "QUERY_STRING");
	}
	
	
	///<summary>get system variables in this controller. call extract method get var</summary>
	public function getSystemVars(){
		$t = array();
		$t["t"] = $this->TargetNode;
		if (igk_count($_REQUEST)> 0)
			$t= array_merge($t, $_REQUEST);
		$tab  = $this->App->ControllerManager->getControllers();		
		if (is_array($tab))
			$t = array_merge($t, $tab);			
		return $t;
	}
	///<summary>get or set if this items can't add child</summary>
	public function getCanAddChild(){
		return true;
	}
	
	public function getPageView(){ return $this->m_pageview;}
	//is system controller
	public function getIsSystemController(){ return false; }
	
	private static $sm_sysController;
	
	public static function RegSysController($className)
	{
		if (self::$sm_sysController == null)
			self::$sm_sysController = array();
		if (class_exists($className))
		{
			self::$sm_sysController[$className] = $className;
		}
	}
	public static function IsSysController($className)
	{
		return (igk_getv(self::$sm_sysController, $className)!=null);
	}
	
	
	
	public function getWebParentCtrl(){return $this->m_webParentCtrl;	}
	public function setWebParentCtrl($value){
		if (($this->m_webParentCtrl!=null) && ($this->m_webParentCtrl!=$value))
		{
			$this->m_webParentCtrl->unregController($this);
		}
		$this->m_webParentCtrl = $value;	
	}
	public function getChilds(){return $this->m_childsctrl;}
	public function regView($ctrl, $callback){
		if ($ctrl === $this)
			return;
		if ($this->m_regviewChilds == null){
			$this->m_regviewChilds = array();
		}
		$this->m_regviewChilds[$ctrl->Name] =(object) array("ctrl"=>$ctrl,"func"=> $callback);
		
	}
	public function unregView($ctrl)
	{
		if ($ctrl!=null)			
			unset($this->m_regviewChilds[$ctrl->Name]);
	}
	//controller params
	public function setParam($key, $value)
	{
		if ($this->m_params == null)
		{
			$this->m_params = array();
			
		}
		$this->m_params[$key] = $value;
	}
	public function getParam($key, $initcallback = null)		
	{
		$c =  igk_getv($this->m_params, $key);
		
		
		if(($c ==null) && ($initcallback !=null))
		{
			if (is_string($initcallback))
				$c = $initcallback();
			else if ($initcallback !=null)
			{
				$c = $initcallback;
			}			
				
			if ($c!=null)			
			{
				$this->setParam($key, $c);
			}
		}		
		return $c;
	}
	
	//drop the controller used internally to dropo release controller resources
	public function dropController(){
		$this->App->removeCurrentPageFolderEvent($this, "PageChanged");
			//$this->App->addCurrentPageFolderEvent($this, "PageChanged");
		igk_html_rm($this->TargetNode);
		if ($this->hasChilds){
			foreach($this->getChilds() as $k=>$v)
			{
				$v->setWebParentCtrl(null);
				$v->View();
			}
			//clear childs
			$this->m_childsctrl = array();
		}
	}
	public function getcanModify(){return true;}
	public function getcanDelete(){return true;}
	public function functionIsAvailable($function){
		return true;
	}
	//register childs controllers
	public function regController($controller)	
	{
		if (!$this->CanAddChild)return;
		if ($controller == null)return;
		if ($controller->WebParentCtrl === $this)return;
		if ($controller == $this)return;
		$n = strtolower($controller->getName());
		if (!isset($this->m_childsctrl[$n] ))
		{
			$this->m_childsctrl[$n] = $controller;
			$controller->setWebParentCtrl($this);
		}
	}
	public function unregController($controller)
	{
		if ($controller == null)return;		
		if ($controller->WebParentCtrl === $this)return;
		if ($controller == $this)return;
		
		$n = strtolower($this->m_childsctrl[$controller->getName()]);		
		if (isset($this->m_childsctrl[$n]))
		{
			unset($this->m_childsctrl[$n]);
		}
	}
	protected function _showChild()
	{
		if ($this->hasChild){
			foreach($this->getChilds() as $k=>$v)
			{			
				if ($v->IsVisible)
				{
					igk_html_add($v->TargetNode, $this->TargetNode);					
					$v->View();
				}
				else {
					igk_html_rm($v->TargetNode);
				}
			}
		}
	}
	protected function _onViewComplete()
	{
		
		if (($this->m_regviewChilds!=null) && is_array($this->m_regviewChilds))
		{
			//here v is is STDCLASS of "cltr","func" param
			foreach($this->m_regviewChilds as $k=>$v)
			{				
				$m = $v->func;
				$v->ctrl->Invoke($m, $this);				
			}		
		}
		
	}
	
	public function gethasChild(){return (is_array($this->m_childsctrl) && count($this->m_childsctrl)>0); }
	
	//used to identity the controller into the controller index
	public function getName(){		return get_class($this);}
	public function getConfigs(){return $this->m_configs; }
	//display name of the controller
	public function getDisplayName(){return get_class($this); }
	public function getIsVisible(){
		return $this->PageView->getIsVisible($this->CurrentPage);
	}
	public function getisAvailable(){return true;}
	public function initMenu(){ return null;}
	public function initConfigMenu(){return null;}
	public function getCurrentPageFolder(){ return $this->App->CurrentPageFolder;}
	public function getCurrentPage(){ return $this->App->CurrentPage;}
	public function initDb(){
		$v_tab = $this->getDataTableInfo();
		$v_tablename= $this->getDataTableName();
		if (($v_tab == null)|| ($v_tablename==null))return;
		
		$db = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($db){
			if ($db->connect()){
				$db->selectdb($this->App->Configs->db_name);
				$r = $db->createTable($v_tablename, $v_tab);
				$this->initDataEntry($db);
			}
		$db->close();
		}
		
	}
	protected function initDataEntry($dbman)
	{//init default data entry
	}
	
	public function getCanEditDataBase()
	{
		return true;
	}
	public function getDataTableInfo(){
		if (file_exists($this->DBConfigFile ))
		{
			$e = HtmlItem::CreateWebNode("__loadData");
			$e->Load(IGKIO::ReadAllText($this->DBConfigFile));			
			$t = array();
			foreach($e->getElementsByTagName("Column") as $k)
			{
				$t[] = new IGKDbColumnInfo($k->Attributes->ToArray());
			}
			return $t;
		}
		return $this->getDefaultDataTableInfo();
	}
	protected function getDefaultDataTableInfo()
	{
		return null;
	}
	public function getCanEditDataTableInfo()
	{
		return true;
	}
	public function getDataTableName(){
		if (file_exists($this->DBConfigFile ))
		{
			$e = HtmlItem::CreateWebNode("__loadData");
			$e->Load(IGKIO::ReadAllText($this->DBConfigFile));
			$t = igk_getv($e->getElementsByTagName("DataDefinition")	,0);
			if ($t)
			{
				$s = $t["TableName"] ;
				if (!empty($s))
					return $s;
			}
		}
		return IGK_TABLE_PREFIX.$this->Name;		
	}
	
	///-----------------------------------------------------------------------------------------
	///DB FUNCTION
	///-----------------------------------------------------------------------------------------
	public function select($equals){ 
		return $this->getDbEntries()->searchEqual($equals);
	}
	public function selectAndWhere($whereTab)
	{	
		$v = $this->invokeDbFunction(array($this, "__dbselect_andwhere"), $whereTab);	
		return $v;
	}
	
	public function update($entries=null){ 		
		return  $this->invokeDbFunction(array($this, "__dbupdate_entries"), $entries);	
	
	}
	public function delete($entries){ 
	return $this->invokeDbFunction(array($this, "__dbdelete"), $entries);	
	}
	public function selectLastId(){
		$v = $this->invokeDbFunction(array($this, "__dbselectlastid"));			
		return $v;
	}
	//insert to entries
	public function insert($entry){ 		
		$v = $this->invokeDbFunction(array($this, "__dbinsert"), $entry);			
		return $v;
	}
		
	
	public function invokeDbFunction($param)
	{
		$adapt = IGKDataAdapter::CreateDataAdapter($this, true);	
		
		//igk_wln ("invokdeDBFunction");
		// igk_wln(is_object($adapt));
		// igk_wln($adapt);
		// exit;
		if ($adapt == null)
			return null;
		$d = null;
		if ($adapt->connect()){			
			try{
				$p  = array($adapt);
				if (func_num_args()>1)
					$p = array_merge($p, array_slice( func_get_args(), 1));			
				
				$d = call_user_func_array($param, $p);
				
			}
			catch(Exception $ex)
			{
				$d = null;
				igk_debug_wln("error Append ".$ex);
			}
		}
		$adapt->close();
		return $d;
	}
	
	///retrieve all controller db entries
	public function getDbEntries(){
		return $this->invokeDbFunction(array($this, "__dbselectAll"));	
	}
	private function __dbselect_andwhere($adapt, $properties)
	{	
		return $adapt->selectAndWhere($this->getDataTableName(), $properties);		
	}
	private function __dbselectAll($adapt){
		return $adapt->selectAll($this->getDataTableName());		
	}
	private function __dbinsert($adapt,$entry){				
		return $adapt->insert($this->getDataTableName(), $entry);				
	}
	private function __dbselectlastid($adapt){
		return $adapt->selectLastId();
	}
	private function __dbupdate_entries($adapt, $entries=null)
	{
		if ($entries==null)return;
		if (is_array($entries))
		{
			foreach($entries as $k=>$v)
			{
				$this->__dbupdate_entries($adapt, $v);
			}
			return;
		}
		return $adapt->update($this->DataTableName, $entries);
	}
	///delete entries in database
	///@adapt : adapter
	///@entries : array or object of entries to delete
	private function __dbdelete($adapt, $entries)
	{
		if ($entries==null)return;
		if (is_array($entries))
		{
			if (igk_count($entries)> 0)
			{
				foreach($entries as $k=>$v)
				{
					$this->__dbdelete($adapt, $v);
				}
				
			}
			return;
		}
		return $adapt->delete($this->DataTableName, $entries);
	}
	
	//get the target node
	public function getTargetNode(){return $this->m_targetNode;}
	public function getTargetNodeId() { return $this->TargetNode["id"]; }
	//protected set the method
	protected function setTargetNode($node) { $this->m_targetNode = $node; }
	

	//public function get the page document
	public function getdoc(){
		return igk::getInstance()->Doc;
	}
	protected function _getViewfile($view){
		return $this->getCtrlFile(IGK_VIEW_FOLDER."/".$view.".phtml");
	}
	public function getCtrlFile($path)
	{
		return igk_io_getdir(dirname($this->getDeclaredFileName()).DIRECTORY_SEPARATOR.$path);
	}
	protected function _incViewfile($view){
		extract($this->getSystemVars());	
		$v_file = $this->_getViewfile($view);
		if (file_exists($v_file)===true)
		{					
			include($v_file);
		}
	}
	
	//get the view without changing the current view
	public function getView($view=null, $forcecreation=false){
		extract($this->getSystemVars());	
		$v = $view !=null? $view: igk_getr("v", $view);		
		$f = $this->_getViewfile($v);
		$t->ClearChilds();
		if (file_exists($f) || ($forcecreation && igk_io_save_file_as_utf8($f,"")))
		{
			include($f);
		}
	}
	///<summary> call init view file </summary>
	protected function _initPage(){
		$f = $this->_getViewfile("init");
		if (file_exists($f))
		{
			include($f);			
		}
		
	}
	///@@@ override this method to show the controller view.
	public function View(){	
		
		extract($this->getSystemVars());		
		$t->ClearChilds();
		if ($this->IsVisible)
		{
			$v = $this->m_view ? $this->m_view : "default";
			$c = strtolower(igk_getr("c",null));
			
			if ($c ==  strtolower($this->Name))
			{
				$v = igk_getr("v", $v);
			}		
			$f = $this->_getViewfile($v);	
			
			if (!file_exists($f))
			{
			
				if (igkServerInfo::IsLocal())
				{
					if (!IGKIO::WriteToFileAsUtf8WBOM($f, "<?php \n?>", true))
					{
						igk_debug("can't create the file ".$f . " AT ".__LINE__);
						exit;
					}
				}
			}
			if (file_exists($f))
			{			
				//include in this context
				include($f);
			}
			$this->_showChild();
			$this->_onViewComplete();
		}
		else 
			igk_html_rm($t);
		
	}
	/// ask for a view in ajx context
	public function view_ajx(){
		$v = igk_getr("v", "default");
		$this->CurrentView = $v;
		$this->TargetNode->RenderAJX();
	}
	///used to reload a view in ajx context
	public function reload_view_ajx()
	{
		if (igk_sys_isAJX()==1)
		{		
			$this->View();						
			$c = HtmlItem::CreateWebNode("script");
			$c->Content = "if(IGK) window.igk.ajx.post( '".$this->getUri("view_ajx")."',null,  new window.igk.ajx.responseNode('".$this->TargetNodeId."').response )";
			$m = new HtmlSingleViewItem($c);
			$m->RenderAJX();		
		}
	}
	
	///<summary> override to manage the view when page folder changed.</summary>	
	public function pageFolderChanged()
	{	
		//entry point of all view when page folder changed
		//call view if parent is not set
		if (($this->getWebParentCtrl() ==  null)&&($this->IsVisible))
		{	
			$this->View();
		}
	}
	///<summary> override this when page change on a spécific page</summary>
	public function pageChanged(){
	}
	///<summary> override to init controller according to other created controller.</summary>	
	public function InitComplete()
	{	
		$this->_initPage();
		//load private scription
		igk_js_load_script($this->App->Doc, dirname($this->getDeclaredFileName())."/".IGK_SCRIPT_FOLDER);
		if ($this->Configs!=null)
		{
			$this->_conf_regToParent();
		}
		else {
			igk_debug("error ". $this->Name);
		}
		if ($this->PageView == null)
			throw new Exception("No PageView DEFINED FOR ". $this->Name);
		$this->PageView->registerPages();		
		//register page changed event
		$this->App->addCurrentPageFolderEvent($this, "pageFolderChanged");	
		$this->App->addCurrentPageEvent($this, "pageChanged");	
	}
	///@@@ override this method to show the controller view.
	public function getDeclaredFileName()
	{	
		$h = new ReflectionClass ($this);
		return $h->getFileName();
	}
	public function getDeclaredDir(){
		return dirname($this->getDeclaredFileName());
	}
	//get the current article path
	public function getArticle($name)
	{
		$f = $this->getArticlesDir()."/".$name;
		if (file_exists($f))
			return $f;
		return $this->getArticlesDir()."/".$name.igk_get_article_ext();
	}
	public function getAllArticles()
	{
		return IGKIO::GetFiles($this->getArticlesDir(), "/\.phtml$/i",false);
	}
	public function getArticleFull($fullname)
	{
		return $this->getArticlesDir()."/".$fullname;
	}
	public function getArticlesDir()
	{
		return $this->getDeclaredDir()."/".IGK_ARTICLES_FOLDER;
	}
	public function getViewDir()
	{
		return $this->getDeclaredDir()."/".IGK_VIEW_FOLDER;
	}
	public function getDataDir()
	{
		return $this->getDeclaredDir()."/".IGK_DATA_FOLDER;
	}
	public function getApp(){		return igk::getInstance();	}
	public function getmsbox(){
		return $this->App->ControllerManager->msbox;
	}
	//return validator object
	public function getval(){
		return $this->App->Validator;
	}
	
	public function getBody(){
		return $this->App->Doc->Body;
	}
	public function getHeader(){
		return $this->App->Doc->Header;
	}
	//get function uri
	public function getUri($function=null)
	{
		$out = "?c=".strtolower($this->getName());
		if ($function){
			$t = explode("&", $function);
			$t[0] = "&f=".str_replace ('_', '-', $t[0]);
			$out .= implode('&', $t);
		}
		return $out;
	}
	//get value uri
	public function getUriv($page)
	{
		$out = "?c=".strtolower($this->getName());
		if ($page)
			$out .="&v=".$page;
		return $out;
	}
	//get uri link
	public function getUril($uri)
	{
		$out = "?c=".strtolower($this->getName());
		if ($uri)
			$out .="&".$uri;
		return $out;
	}
	//init uri post
	public function initUriPost($form, $uri)
	{
		$uri = $this->getUri($uri);
		$form->addInput("c", "hidden", strtolower($this->getName()));
		
		//explode uri
		$tab = igk_getquery_args($uri);
		foreach($tab as $k=>$v){
			$form->addInput($k, "hidden", sv);
		}
	}
	//-----------------------------------------------------
	//represent a target node
	//-----------------------------------------------------
	protected function initTargetNode(){
		$div =  HtmlItem::CreateWebNode("div");
		$div["class"] = $div["id"] = strtolower($this->Name);						
		return $div;
	}
	
	//Get data ADAPTER NAME
	public function getDataAdapterName(){
		if ($this->Configs)
			return $this->Configs->clDataAdapterName;
		igk_wln("no adapter name defined for ".$this->Name);
	}
	protected function __loadCtrlConfig()
	{
			//default property value
			$t = igk_sys_getdefaultCtrlConf();
			
			//add additional properties
			
			if (method_exists(get_class($this), "GetAdditionalConfigInfo"))
			{
				$s = get_class($this);
				$c = call_user_func( array($s, "GetAdditionalConfigInfo"));
				if (is_array($c))
				{				
					foreach($c as $k=>$v)
					{
						if (is_object($v))
						{
								$t[$k] = null;
						}
						else if( is_string($v) && isset($t[$v]))
						{
							$t[$v] = null;
						}
					}
				}
					
			}
			
			$f = $this->getConfigFile();
			if (file_exists($f) == false)
				return (object)$t;
			
			$div = HtmlItem::CreateWebNode("div");
			$s = file_get_contents($f);
			$div->Load($s);
			$d = igk_getv($div->getElementsByTagName("config"), 0);
			if ($d)
			{
				foreach($d->Childs as $k)
				{
					$t[$k->tagName] = $k->innerHTML;
				}
			}			
			return (object)$t;
	}
	
	
	protected function getConfigFile()
	{
		return igk_io_getdir($this->getDataDir()."/".IGK_CTRL_CONF_FILE);
	}
	protected function getDBConfigFile()
	{
		return igk_io_getdir($this->getDataDir()."/".IGK_CTRL_DBCONF_FILE);
	}
	public function __storeConfig()
	{//store configuration data
		$d = HtmlItem::CreateWebNode("config");
		//store
		foreach($this->m_configs as $k=>$v)
		{
			$d->add($k)->Content = $v;
		}		
		if( IGKIO::WriteToFileAsUtf8WBOM($this->ConfigFile, $d->Render()))
		{
			//reload config setting
			$this->loadConfigSetting();			
			return true;
		}
		return false;
	}
	
	public function __storeDBConfig()
	{
		
		$d = HtmlItem::CreateWebNode("config");
		//store
		foreach($this->m_configs as $k=>$v)
		{
			$d->add($k)->Content = $v;
		}		
		if( IGKIO::WriteToFileAsUtf8WBOM($this->DBConfigFile, $d->Render()))
		{
			//reload config setting
			$this->loadDBConfigSetting();			
			return true;
		}
		return false;
	}
	
	function __toString()
	{
		return "CONTROLLER::".get_class($this);
	
	}
	///<summary>.ctr</summary>
	function __construct()
	{
		$this->m_pageview = new IGKPageView();
		$this->m_pageview->register("default");
		$this->m_childsctrl = array();
		$this->m_methods = array();
		$this->TargetNode = $this->initTargetNode();
		$this->m_configs = $this->__loadCtrlConfig();
		$this->m_visibility = false; 
		$this->reloadConfiguration();
	}
	///<summary>load and init from configuration setting</summary>
	protected function _conf_regToParent()
	{		
		$h = igk_getctrl($this->Configs->clParentCtrl, false);
			if ($h)
			{
				if ($this->WebParentCtrl!=null)
					$this->WebParentCtrl->unregController($this);
				if ($h->CanAddChild)
				{
						$h->regController($this);
				}
				else {
					$this->Configs->clParentCtrl = null;
				}
						
			}
	}
	protected function loadConfigSetting()
	{//load configuration setting
		
		if ($this->m_configs ==null)
			return;
		if ($this->TargetNode !=null)
		{
			$this->TargetNode["igk-type-id"] = $this->Name;
			$this->TargetNode->setIndex($this->m_configs->clTargetNodeIndex);
		}	
		$this->_conf_regToParent();		
	
		if (isset($this->m_configs->clVisiblePages))
		{			
			$this->PageView->register($this->m_configs->clVisiblePages);
		}
		
	}
	///<summary>reload configuration setting</summary>
	public function reloadConfiguration()
	{	
		if ($this->TargetNode==null)
			return;	
		$this->TargetNode["igk-type"] = "controller";		
		$this->loadConfigSetting();
	}
	
}

final class IGKAdditionCtrlInfo extends IGKObject
{
	private $m_Type;
	private $m_DefaultValue;
	private $m_Values; //used when type == select
	
	public function __construct($type, $def, $def1=null)
	{
		$this->m_Type = $type;
		if (strtolower($type) == "select")
		{
			$this->m_Values = $def;
			$this->m_DefaultValue = $def1;
		}
		else{
			$this->DefaultValue = $def;
			$this->m_Values=null;
		}
	}
	public function getclType(){return $this->m_Type; }
	public function getclDefaultValue(){return $this->m_DefaultValue; }
	public function getclValues(){return $this->m_Values; }
	
	public function __toString(){
		return "IGKAdditionalCtrlInfo";
	}
}
//save session parameters
//<remarq> this is uses to free $_SESSION array value</remarq>
final class IGKSession extends IGKObject
{
	private $m_igk;
	private $m_sessionParams;
	private $m_User;
	
	//Events
	private $m_updateSessionEvent;
	private $m_UserChangedEvent;
	
	public function getApp(){return $this->m_igk;}
	public function getUser(){	return $this->m_User;}
	public function setUser($user){ if ( $this->m_User !== $user){$this->m_User = $user; $this->_onUserChanged();} }
	
	public function getUserChangedEvent(){return $this->m_UserChangedEvent; }
	
	public function addUpdateSessionEvent($obj, $method){		$this->m_updateSessionEvent->add($obj, $method);	}
	public function removeUpdateSessionEvent($obj, $method)	{		$this->m_updateSessionEvent->remove($obj, $method);	}
	
	public function addUserChangedEvent($obj , $method){
		$this->m_UserChangedEvent->add($obj, $method);
	}
	
	public function __construct($App)
	{	
		$this->m_igk = $App;
		$this->m_sessionParams = array();
		$this->m_updateSessionEvent = new IGKEvents($this, "UpdateSessionEvent");
		$this->m_UserChangedEvent = new IGKEvents($this, "UserChangedEvent");
	}
	private function _onUserChanged()
	{
		$this->m_UserChangedEvent->Call($this, null);
	}
	//unset a session key
	public function clear($key)
	{
		if (isset($this->m_sessionParams[$key]))
			unset($this->m_sessionParams[$key]);
	}
	public function __get($key){ 
		if (method_exists($this, "get".$key) )
		{					
				return call_user_func(array($this, "get".$key), null);
		}
		else if(isset($this->m_sessionParams[$key])){
			return $this->m_sessionParams[$key];
		}
		return null;
	}
	public function __set($key, $value)
	{
		
		if (!$this->_setIn($key,$value))
		{
			$this->m_sessionParams[$key] = $value;
		}
		
	}
	public function __toString(){ return "SessionParameters"; }
	public function update()
	{
		$this->m_updateSessionEvent->Call($this,null);
	}
	public function setParam($key, $value)
	{
		if (empty($key))
			return;
		if (isset($this->m_sessionParams[$key]))
		{
			if ($value == null)
				unset($this->m_sessionParams[$key]);
			else
				$this->m_sessionParams[$key] = $value;
		}
		else{
			if ($value !=null)
			{
				$this->m_sessionParams[$key] = $value;
			}
		}
	}
	public function getParam($key)
	{
		if (isset($this->m_sessionParams[$key]))
		{
			return $this->m_sessionParams[$key];
		}
		return null;
	}
}
final class IGKAutorisation extends IGKObject
{
	private $App ;
	private $autorisation;
	//internal constructor
	public function __construct($igk)
	{
		$this->App = $igk;
	}
	private function loadAutorisation(){
		$this->autorisation = array();
	}
	public function __toString(){return "IGKAutorisation"; }
	public function __get($key){
		if ($this->App->User)
		{
			if (isset($this->m_autorisatoin[$key]))
			{
				return $this->m_autorisatoin[$key];
			}
		}
		return false;
	}
	public function __set($key, $value){}
}
//----------------------------------------------------------------------
//@ System Controllers Managers. 
//@ add controller
//@ drop controller by Name
//----------------------------------------------------------------------
final class IGKControllerManager extends IGKObject
{
	private static $sm_instance;
	private $m_tbcontrollers;
	private $InitCompleteEvent;
	private $m_registeredCtrl;
	
	//register controller for spécific fonctionnality
	public function register($name, $ctrl)
	{
		if (empty($name) || ($ctrl == null))
			return false;
		if ($this->m_registeredCtrl == null)
			$this->m_registeredCtrl = array();
		if(isset($this->m_registeredCtrl[$name]))
		{
			return false;
		}
		$this->m_registeredCtrl[$name] = $ctrl;
	}
	public function getRegCtrl($name)
	{
				if(($this->m_registeredCtrl != null) && isset($this->m_registeredCtrl[$name]))
					return $this->m_registeredCtrl[$name];
				return null;
	}
	
	
	private function __construct(){
		
		$this->m_tbcontrollers = array();
		$this->InitCompleteEvent = new IGKEvents($this, "InitCompleteEvent");
	}
	///<summary>raise init complete event</summary>
	private function _onInitComplete()
	{
		if ($this->InitCompleteEvent)
			$this->InitCompleteEvent->Call($this, null);
	}
	///<summary>true if controller is a system controller otherwise false</summary>
	///<args name="controller">controller name or controller instance </args>
	public static function IsSystemController($controller)
	{
		//igk_wln("is SysController ".$controller);
		$instance = self::getInstance();
		if (is_string($controller))
		{
			$controller = strtolower($controller);
			$v = $instance->$controller;
			if ($v->getDeclaredFileName() == __FILE__)
				return true;
		}
		//igk_wln("---".$controller);
		if (is_object($controller) && is_subclass_of(get_class($controller),  IGK_CTRLBASECLASS))
		{
			$r  =  ($controller->getDeclaredFileName() == __FILE__) || $controller->getIsSystemController() || IGKControllerBase::IsSysController(get_class($controller));
			//igk_wln("response = ".igk_parsebool($r));
			return $r;
		}
		//igk_wln(" not controller ".$controller);
		return false;
		
	}
	public static function IsIncludedController($controller)
	{
		$instance = self::getInstance();
		$dir = null;
		if (is_string($controller))
		{
			$controller = strtolower($controller);
			$v = $instance->$controller;
			$dir = dirname($v->getDeclaredFileName());
			
		}
		else if (is_object($controller) && is_subclass_of(get_class($controller),  IGK_CTRLBASECLASS)){
			$dir = dirname($controller->getDeclaredFileName());
		}
		//
		//get parent folder
		//
		$o = igk_io_basePath(igk_io_currentRelativePath(IGK_INC_FOLDER));
		$dir = igk_io_basePath($dir);
		
		while( ($dir != '.') && (strlen($dir) > 0))
		{
			if ($dir === $o){
				return true;
			}
			$dir = dirname($dir);
			
		}	
		return false;
	}
	///<summary>get the current instance manager</summary>	
	public static function getInstance()
	{
		if (self::$sm_instance===null)
		{
			if (igk::getInstance()->ControllerManager == null){
				self::$sm_instance = new IGKControllerManager();					
				igk::getInstance()->ControllerManager = self::$sm_instance;
				//init controllers
				self::$sm_instance->InitControllers();
			}
			else {
				self::$sm_instance = igk::getInstance()->ControllerManager;
			}
			
		}
		return self::$sm_instance;
	}
	
	///<summary>init all controller</summary>	
	private function InitControllers(){
	
		foreach(get_declared_classes() as $k=>$v)
		{
			if (is_subclass_of($v, IGK_CTRLBASECLASS) && igk_ctrl_isactive($v))
			{
			
				$v_rc = new ReflectionClass($v);
				if ($v_rc->isAbstract()) 
					continue;
				
				$t = new $v();
				
				$n = $t->Name;
				$this->$n = $t;
				$this->InitCompleteEvent->add($t, "InitComplete");				
			}
		}
		 
		$this->_onInitComplete();
		
		$this->InitCompleteEvent->Clear();
		
		 
	}
	//call View method for all controllers
	public function ViewControllers()
	{
		igk_wln("::::View All Controller");
		$ctrls = self::getInstance()->m_tbcontrollers;
		if ($ctrls){
			// foreach($ctrls as $k)
			// {
				// if ($k->getWebParentCtrl() == null)
				// {
					// $k->View();
				// }
			// }
		}
	}
	public function __toString(){
		return "Controllers [#".count($this->m_tbcontrollers)."]";
	}
	public function __get($key){
	
		$key = strtolower($key);
		if (isset($this->m_tbcontrollers[$key]))
			return $this->m_tbcontrollers[$key];
		throw new Exception("Controller [".$key."] Not founds");
	}
	public function __set($key, $value)
	{
		$key = strtolower($key);
		if ($value===null)
		{
			if (isset($this->m_tbcontrollers[$key]))
				unset($this->m_tbcontrollers[$key]);	
				return;
		}
		else
		{
			if (is_object($value) && is_subclass_of( get_class($value),IGK_CTRLBASECLASS))
			{
				$this->m_tbcontrollers[$key] = $value;
			}
		}
	}
	public function Count() {return count($this->m_tbcontrollers);}
	public function getControllers(){return $this->m_tbcontrollers;}
	
	//@remove controller by name
	public function dropControllerByName($name)
	{

		$k = strtolower($name);
		if (isset($this->m_tbcontrollers[$k]))
		{
			$ctrl = $this->m_tbcontrollers[$k];
			$d = dirname($ctrl->getDeclaredFileName());			
			$ctrl->dropController();
			if (is_dir($d))
			{
				if (IGKIO::Rmdir($d , true))
				{
					unset($this->m_tbcontrollers[$k]);
				}			
			}	
			
		}
	}
	public function reload(){
	
		$d  = igk_io_currentRelativePath("/Mods");
		igk_loadcontroller($d);	
		$classes = get_declared_classes();
		foreach( $classes as $k=>$v)
		{
			if (is_subclass_of($v, IGK_CTRLBASECLASS) && igk_ctrl_isactive($v))
			{
				
				$v_rc = new ReflectionClass($v);
				if ($v_rc->isAbstract()) 
					continue;
				$t = new $v();
				$n = strtolower($t->Name);
				if (!isset($this->m_tbcontrollers[$n]))
				{
					$this->$n = $t;
					$this->InitCompleteEvent->add($t, "InitComplete");
				}
				else{
					unset($t);
				}
			}
		}
		$this->_onInitComplete();
		$this->InitCompleteEvent->Clear();
		
	}
	
	///return the user controller list.
	///there is 2 controller type . framework controller and user controllers
	public function getUserControllers()
	{
		$tab = $this->getControllers();
		$out = array();
		if (count($tab) > 0)
		{
			$tab_k = array_keys($tab);
			igk_usort($tab_k, "igk_key_sort");
			foreach($tab_k as $k)
			{
				$v = $tab[$k];
				if (IGKControllerManager::IsSystemController($v) || IGKControllerManager::IsIncludedController($v) || !$v->canModify)
					continue;
				$out[] = $v;
				
			}		
		}
		return $out;
	}

	private function _sort_byConfigNodeIndex($a, $b)
	{
		if ($a->Configs->clTargetNodeIndex && $b->Configs->clTargetNodeIndex)
		{
			$i = $a->Configs->clTargetNodeIndex;
			$j = $b->Configs->clTargetNodeIndex;
			return ($i == $j)? 0: (($i<$j) ? -1 : 1); 
		}
		return strcmp($a->Name, $b->Name);
	}
	private function renderController($s, $v, $fname, $fsize, $x, $y, $cl, $indexpos= 0)
	{		
		$t = $s->DrawString($v->Name, $fname, $fsize, $x, $y , $cl);
		
		//$s->DrawRectangle($cl, $t);
		
		$s->DrawString($v->Configs->clTargetNodeIndex, $fname, $fsize, $indexpos, $y , $cl);
		
		if ($v->Childs){
			$y+= $t->height;
			$tab = $v->Childs;
			usort($tab, array($this, "_sort_byConfigNodeIndex"));
			$i = igk_count($tab);
			foreach($tab as $k=>$m)
			{
				$i--;
				$tt = $this->renderController($s, $m, $fname, $fsize, $x + 50, $y, $cl, $indexpos);				
				
				$t->height += $tt->height;
				$t->width = max($tt->width + 50, $t->width);
				$y+= $tt->height;				
			}
		}		
		return $t;
	}
	private  function _cm_measure($s , $tab, $fname, $fsize, $x, $y ,$cl)
	{
		$rc = (object)array(
		"x"=>0,
		"y"=>0,
		"width"=>0,
		"height"=>0);
		
		if (is_array($tab))
		{
		
			foreach($tab as $k=>$v)
			{
				if ($v->WebParentCtrl == null)
				{
					$t = $this->_cm_measure($s, $v, $fname, $fsize, $x, $y ,$cl);
					
					$rc->height += $t->height;
					$rc->width  = max($rc->width, $t->x + $t->width);
				}
			}
		}
		else{
			return $this->renderController($s, $tab, $fname, $fsize, $x, $y, $cl);					
		}
		return $rc;
	}
	public function cm_controllerschema()
	{
		//retreive all controller scheam
		if (!defined("IGK_GD_SUPPORT"))
		{
			exit;
		}		
		
		
		$y = 14;
		$x = 0;
		$fname = igk_io_currentRelativePath(igk_get_uvar("CONFIG_SCHEMA_FONT"));
		if (!file_exists($fname))
		{		
			exit;
		}
		$fsize = 14;
		$cl = IGKColor::FromFloat(1.0);	
		
		$tb = $this->getUserControllers();
		
		$s = IGKGD::Create(32,32);
		
		$rect =  $this->_cm_measure($s, $tb, $fname, $fsize, $x, $y ,$cl);
		
		$s->Dispose();
		if (($rect->width<=0) || ($rect->height<=0))
			exit;
		$x =40;
		$y =28;
		
		$s = IGKGD::Create($rect->width  +300+ (2*$x), $rect->height + ($y));
		
		//$s = IGKGD::Create(500,600);
		$s->Clear($cl);
		if (file_exists($fname))
		{
				foreach($tb as $k=>$v)
				{
									
					if ($v->WebParentCtrl == null)
					{
						$t = $this->renderController($s, $v, $fname, $fsize, $x, $y, IGKColor::Black() , $rect->width+150);
						$y += $t->height;
					}					
				}
		}
		header("Content-type: image/png");
		$s->Render();
		$s->Dispose();
		unset($s);
		exit;
		
	}
	///use to invoke system controller method
    public function InvokeUri($uri  = null)
	{
		$c = null; 
		$f = null;
		$igk = igk::getInstance();
		$igk->Session->URI_AJX_CONTEXT = 0;
		if ($uri == null)
		{			
			if (igk_getr("vimg", null)!=null){ 
			
				igk_getctrl(IGK_PIC_RES_CTRL)->viewpic(igk_getr("vimg")); 
				exit;
			}
			
		if (igk_getr("p",null)!=null){ $igk->CurrentPage = igk_getr("p");}
		if (igk_getr("l",null)!=null){ R::ChangeLang(igk_getr("l"));}
		if (igk_getr("history",0)==1){ igk_debug("notice:form history"); }
		//
		//call for controller function
		//
		$c = igk_getru("c",null);
		$f = igk_getru("f", null);
		
	
		}
		else{
			$args = igk_getquery_args($uri);
			$c =str_replace("-","_", igk_getv($args,"c"));
			$f =str_replace("-","_", igk_getv($args,"f"));
			if (igk_getv($args,"p")){  igk_getctrl(IGK_MENU_CTRL)->setPage(igk_getv($args, "p"), igk_getv($args, "pageindex",0)); }
			if (igk_getv($args,"l")){   R::ChangeLang(igk_getv($args, "l"));}
		}
		
		if ($c && $f)
		{	
			//check for requirement before call thme 							
			if ($this->$c &&  $this->$c->functionIsAvailable($f))
			{
				$this->$c->App->Session->URI_AJX_CONTEXT = IGKString::EndWith($f, IGK_AJX_METHOD_SUFFIX) || (igk_getr("ajx") == 1);
				$this->$c->$f();
				if($this->$c->App->Session->URI_AJX_CONTEXT)
				{
					exit;
				}
			}
		}	
		return $c;		
		
	}
	//@@@ used to invoke function and return response. main used in igk_api
	public function InvokeFunctionUri($uri=null)
	{
		$c = null; 
		$f = null;
		if ($uri == null)
		{			
			//
			//call for controller function
			//
			$c = igk_getru("c",null);
			$f = igk_getru("f", null);		
		}
		else{
			$args = igk_getquery_args($uri);
			$c =str_replace("-","_", igk_getv($args,"c"));
			$f =str_replace("-","_", igk_getv($args,"f"));
		}		
		if ($c && $f)
		{	
			//check for requirement before call thme 							
			if ($this->$c &&  $this->$c->functionIsAvailable($f))
			{
				$this->$c->App->Session->URI_AJX_CONTEXT = IGKString::EndWith($f, IGK_AJX_METHOD_SUFFIX) || (igk_getr("ajx") == 1);
				return $this->$c->$f();				
			}
		}	
		return null;	
	}
}


//initialize
final class IGKSessionIdValue implements IHtmlGetValue
{
	var $i ;
	public function getValue(){
	if ($this->i)
			$this->i++; else $this->i = 1;
		$s = "Session ID[" .$this->i." ]: " . session_id ();		
		return $s;
	}
}
//-----------------------------------------------------------------------
//@basics controller
////-----------------------------------------------------------------------
final class IGKSessionController extends IGKControllerBase
{
	private $m_debugginchanged;
	public function getName(){return IGK_SESSION_CTRL;}
	public function View(){	
		
		//for debugging purpose
		if (igkServerInfo::IsLocal() && ($this->App->Configs->AllowDebugging ?$this->App->Configs->AllowDebugging : false))
		{
			$this->TargetNode->ClearChilds();			
			igk_html_add($this->TargetNode, $this->doc->body);
			$this->TargetNode->setIndex(10000);
			$d = $this->TargetNode->add("div");
			$d->Content = "DEBUG INFO";
			$d["class"]= "debug_option_title";
			igk_css_regclass("debug_option_title", "height:32px; line-height:32px; font-size: 1.5em; color:#ececec; background-color:#6a6A6A;");
			$ul = $this->TargetNode->add("ul");						
			$ul->add("li")->Content = "Referrer : " . $_SERVER["REMOTE_ADDR"];
			$ul->add("li")->add("a", array("href"=>$this->getUri("clearS")))->Content = "ClearSession";
			$ul->add("li")->add("a",array("href"=>igk_getctrl(IGK_CONF_CTRL)->getUri("reconnect")))->Content = "Re-connect";
			$ul->add("li")->add("a", array("href"=>new HtmlRelativeUriValueAttribute("Configs")))->Content = "Configs";
			$ul->add("li")->add("a", array("href"=>new HtmlRelativeUriValueAttribute("")))->Content = "Index";
			$ul->add("li")->Content = "CurrentPage : " . $this->App->CurrentPage;
			$ul->add("li")->Content = "CurrentFolder : " . $this->App->CurrentPageFolder;
			$ul->add("li")->Content = new IGKSessionIdValue();			
			$this->TargetNode->addScript()->Content  = "window.igk.ctrl.sessionblock.init()";
		}
		else{
			igk_html_rm($this->TargetNode);
		}
		
	}
	
	public function PageChanged(){
	//do nothing
	}
	public function clearS($navigate = true){
		
		session_destroy();
		if ($navigate)
		igk_navtocurrent();
	}
	public function InitComplete()
	{
		parent::InitComplete();		
		$this->App->Doc->Theme->PrintMedia->def[".igksessioncontroller"] = "display:none;";		
		igk_getctrl(IGK_CONF_CTRL)->addConfigSettingChangedEvent($this, "configPropertyChanged");		
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "changeLoaded");	
	}
	public function changeLoaded($ctrl){		
		if ( $ctrl->isChanged(IGKConfigCtrl::CHANGE_REG_KEY, $this->m_debugginchanged))
		{
			$this->View();
		}
	}
	public function configPropertyChanged()
	{
		$this->View();	
	}
	public function getIsVisible(){return true;}
}

//Controller used to manage and add controller 
final class IGKCtrlManager extends IGKControllerBase
{
	public function getName(){return IGK_CTRL_MANAGER; }
	public function View(){
		//not visible
	}
	//add a controller
	public function add_ctrl($webpagecontent = false, $webparent=null)
	{
		//igk_show_prev($_REQUEST);
		//igk_show_prev(IGKCtrlTypeManager::GetControllerTypes());
		$n = igk_getr(IGK_FD_NAME,null); 
		$ctrl_typename = igk_getr("clCtrlType", null);		
		$response = false;
		
		if (!igk_isidentifier($n))
		{
			igk_notifyctrl()->addWarning("msg.identifiernotvalid",$n);			
		}		
		else if (igk_ctrl_is_reservedname($n))
		{
			igk_notifyctrl()->addWarning("msg.addctrl.nameisreserverd", "[".$n."]");		
		}
		else if (class_exists($n))
		{
			igk_notifyctrl()->addWarning("class already exists. can't create controller");
		}
		else{		
		$type = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $ctrl_typename );

		
		if ($n && ($n !=".") && ($n!=".." ) && (igk_getctrl($n) == null) && ($type!=null)) 
		{	
		   	$clcontent = self::GetDefaultClassContent($n, $type, $webparent);
		
				$folder = igk::$BASEDIR."/".IGK_MODS_FOLDER."/".$n;
		
				
				
				IGKIO::CreateDir($folder);
				IGKIO::CreateDir($folder."/".IGK_VIEW_FOLDER); //view folder
				IGKIO::CreateDir($folder."/".IGK_ARTICLES_FOLDER);//article folder
				IGKIO::CreateDir($folder."/".IGK_DATA_FOLDER);//data folder 
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_DATA_FOLDER."/.htaccess", "allow from all");
				IGKIO::CreateDir($folder."/".IGK_SCRIPT_FOLDER);//script folder
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_SCRIPT_FOLDER."/.htaccess", "allow from all");
			
				//configuration section
				$t = igk_sys_getdefaultCtrlConf();//configs section 
				$t["clDataAdapterName"] = igk_getr("clDataAdapterName", "CSV");
				$t["clDisplayName"] = igk_getr("clDisplayName",null);
				$t["clParentCtrl"] = $webparent==null? $webparent : igk_getr("clParenCtrl");
				$t["clTargetNodeIndex"] = igk_getr("clTargetNodeIndex");
				$t["clVisiblePages"] =igk_getr("clVisiblePages");
				$t["clDescription"] =igk_getr("clDescription");
				
				call_user_func_array( array($type,"SetAdditionalConfigInfo"), array(&$t) );
				
				
				
				if ($type == "IGKDefaultPageCtrl")
				{					
					IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_SCRIPT_FOLDER."/default.js", self::GetDefaultScript());
				}
				
				$file_name = $folder."/class.".$n.".php";
				IGKIO::WriteToFileAsUtf8WBOM($file_name, 	$clcontent );
				//write view
				IGKIO::WriteToFileAsUtf8WBOM($folder."/".IGK_VIEW_FOLDER."/".IGK_DEFAULT_VIEW_FILE, call_user_func(array($type,"GetAdditionalDefaultViewContent")));
				
				
				//store_config data
				include($file_name);
				$cl = new $n();
				$conf = HtmlItem::CreateWebNode("config");
				foreach($t as $k=>$v)
				{
					$conf->add($k)->Content = $v;
				}
				//store configs
				IGKIO::CreateDir(dirname($cl->getConfigFile()));
				IGKIO::WriteToFileAsUtf8WBOM($cl->getConfigFile(), $conf->Render());
				
				if (method_exists($cl, "InitEnvironment"))
					$cl->InitEnvironment();
				//dispose 
				unset($cl);
				
				//reaload all ctrl
				IGKControllerManager::getInstance()->reload();
				
				$ctrl = igk_getctrl($n);
				$nodefaultarticle = igk_getr("nodefaultarticle", 0);
				//save default articles
				if ($ctrl && !$nodefaultarticle)
				{					
					IGKIO::WriteToFileAsUtf8WBOM($ctrl->getArticle("default"), "text for [".$n."]");
				}
				
				$response = true;
				
			}	
		}
	    //igk_wln("Response URI : ".$response);
		// exit;
		return $response;		
	}
	//request remove controller by name
	public function removeController($n)
	{		
		$n = ($n == null)?igk_getr("n"): $n;
		if ($n)
		{
			IGKControllerManager::getInstance()->dropControllerByName($n);
			IGKControllerManager::getInstance()->reload();		
		}
	}
	private static function GetDefaultScript()
	{
	$o = <<<OEF
igk.system.createNS("igk.system", {
	initmenu : function(){
//init your menu mecanism. 
}
});
OEF;
	return $o;
	}
	public static function GetDefaultClassContent($name, $extends, $webparent=null)
	{
	
		if (igk_ctrl_is_reservedname($name))
			return null;
	
		$param = array();
		$param["extend"] =  $extends; // $webpagecontent? IGK_CTRLWEBPAGEBASECLASS :  IGK_CTRLBASECLASS;
		$s = "";
		$s .= !$webparent || (igk_getctrl($webparent) == null) ?null :<<<EOF
igk_getctrl("{$webparent}")->regController(\$this);
EOF;
		$out = <<<EOF
<?php
//controller code class declaration
//file is a part of the controller tab list
class $name extends {$param["extend"]} {
	public function getName(){return get_class(\$this);}
	public function InitComplete(){
		parent::InitComplete();		
		//please enter your controller declaration complete here
		
	}
	//@@@ init target node
	public function initTargetNode(){
		\$node =  parent::initTargetNode();
		return \$node;
	}	
	//----------------------------------------
	//Please Enter your code declaration here
	//----------------------------------------
	//@@@ parent view control
	public function View(){
		parent::View();
	}
	
}
?>
EOF;
return $out;
	}
}

// Page Controller
final class IGKPageCtrl extends IGKControllerBase
{
	private $m_oldPage;
	private $m_newPage;
	private $m_state;
	private $m_currentUri;
	
	var $PageLoadEvent;
	
	const REFRESHING = 5;
	const NAVIGATE = 1;
	const GOTOPREVIOUS = -1;

	public function __construct()
	{
		parent::__construct();
		$this->PageLoadEvent = new IGKEvents($this, "PageLoadEvent");
	}
	public function getName(){return "igkpagectrl";}
	public function getState(){return $this->m_state;}
	public function View(){
	}
	public function checkState(){
		igk_debug("Init called : ".$_SERVER["REQUEST_URI"]);
		$v_rUri = $_SERVER["REQUEST_URI"];
		if ($this->m_newPage != $v_rUri)
		{
			if ($v_rUri == $this->m_oldPage)
			{			
				$this->m_oldPage = $this->m_newPage;
				$this->m_newPage = $v_rUri;			
				$this->setState(self::GOTOPREVIOUS);
			}
			else{
				$this->m_oldPage = $this->m_newPage;
				$this->m_newPage = $v_rUri;			
				$this->setState(self::NAVIGATE);
			}
		}
		else {
			$this->setState(self::REFRESHING);			
		}	
	}
	public function getisRefreshing(){		
		return ($this->State == self::REFRESHING);
	}
	
	///add a new page to system
	public function add(){
		$n= getr("n",null); 
		if ($n)
		{
			$dir = IGKIO::GetBaseDir($n);
			mkdir($dir);
			$text = <<<EOF
<?php
include_once(dirname(__FILE__)."/../index.php");
igk_wl( igk::getInstance()->Doc->Render());
?>
EOF;
			IGKIO::WriteToFileAsUtf8WBOM($dir."/index.php", $text, false);
			igk_navtobase();
			exit;
		}		
	}
	public function InitComplete()
	{
		parent::InitComplete();
		$this->App->InitEvent->add($this, "_igk_initCalled");
		$this->App->Session->addUpdateSessionEvent($this, "_igk_session_update");
	}
	public function _igk_session_update()
	{
		// igk_debug("notice:New Page : ".$this->m_newPage);
		// igk_debug("notice:Current URI : ".$this->m_currentUri);
		$this->_igk_initCalled();
		// igk_debug("STATE:".$this->State. " : ".$_SERVER["REQUEST_URI"] ." : ".$this->m_newPage);
		$this->m_currentUri = $_SERVER["REQUEST_URI"];
		if ($this->State == 5)
			$this->View();
	}
	private function setState($state)
	{
		if( $this->m_state != $state)
		{
			$this->m_state = $state;
			//ONSTATE CHANGED
		}
	}
	public function _igk_initCalled()
	{
		if (defined("IGK_FORCSS"))
		{
			return;
		}
		
		$this->OnPageLoad();
	}
	protected function OnPageLoad(){
		$this->PageLoadEvent->Call($this, null);
	}
}
//-------------------------------------------
//dialog frame box size
//-------------------------------------------
final class  IGKMsDialogFrameSizeValue implements IHtmlGetValue {
	var $owner;
	
	public function __construct($owner){
		$this->owner = $owner;		
	}

	public function getValue()
	{
		return  igk_get_string_format('igk.winui.framebox.init(igk.getParentByTagName(igk.getlastscript(),"div"),[[0]],[[1]]);',
		igk_getsv($this->owner->Width?'"'.$this->owner->Width.'"':null,'null'),
		igk_getsv($this->owner->Height?'"'.$this->owner->Height.'"':null,'null'));
	}
}

//represent the dialog frame
final class IGKMsDialogFrame extends HtmlItem
{		
		private $m_Box;
		private $m_Content;
		private $m_Title;
		private $m_closeUri;
		private $m_closeBtn;
		private $m_Width;
		private $m_Height;
		private $m_id;
		private $m_owner;
		private $m_script;
		private $m_form;
		private $m_closeMethodUri;
		private $m_callbackMethod;
		private $m_reloadcallbackMethod;
	
		//get the id of this frame
		public function getId(){return $this->m_id;}
		//get the owner of this dialog
		public function getOwner(){return $this->m_owner;}
		public function getBox(){return $this->m_Box;} //get the box
		public function getContent(){return $this->m_Content;}//get
		public function setcloseUri($value){
			$this->m_closeBtn["href"] = $value;
		}
		public function getcloseUri(){
			return $this->m_closeBtn["href"];
		}
		public function getcloseMethodUri(){ return $this->m_closeMethod ;}
		public function setcloseMethodUri($value){$this->m_closeMethod = $value;}
		public function setWidth($value){ $this->m_Width = $value;}
		public function setHeight($value){ $this->m_Height = $value;}
		public function setTitle($value){ $this->m_Title->Content = $value;}
		public function getTitle(){ return $this->m_Title->Content;}
		public function getForm(){return $this->m_form;}
		public function setForm($value){ $this->m_form = $value; }
		public function getcallbackMethod(){return $this->m_callbackMethod;}
		public function setcallbackMethod($value){$this->m_callbackMethod = $value;}
		
		public function getWidth(){return $this->m_Width; }
		public function getHeight(){return $this->m_Height;}
		public function closeMethod()
		{
			if ($this->m_callbackMethod)
			{
				$c = $this->m_callbackMethod;
				$c($this);
			}
			
		}
		//<summary>get script node</summary>
		public function getScript(){return $this->m_script; }
		
		public function __construct($id = null, $owner=null, $reloadcallback=null){
			parent::__construct("div");
			$this["class"] = "framebox fitw fith posab loc_t loc_l";
			$this["id"] = "framebox_".$id;
			$this["igk-control-type"] = "frame";
			$this->IsVisible =true;
			$this->m_id = $id;
			$this->m_owner = $owner;
			$this->m_reloadcallbackMethod = $reloadcallback;
			$this->m_Box = $this->add("div", array("class"=>"framebox_dialog posab overflow_none resizable", "id"=>"framebox_dialog"));
			
			$tab = $this->m_Box->add("div", array("class"=>"disptable fitw fith framebox_bgcl"));			
			$c = $this->m_Box;
			
			$this->m_Title = $tab->add("div", array("class"=>"disptabr", "id"=>"framebox_".$id."_title"))->add("div", array("class"=>"framebox_dialog_title disptabc"));
			
			$this->m_Content =  $tab->add("div", array("class"=>"disptabr fith fitw"))->add("div",array("class"=>"framebox_dialog_content disptabc alignl pad4") );
			
			
			
			$v_cdiv = $this->m_Title->add("div", array("class"=>"framebox_close_btn posab"));
			$this->m_closeBtn = HtmlUtils::nBtn($v_cdiv, "" ,  "?vimg=btn_close", 48,24);			
			$this->m_closeBtn["class"] = "-btn_lnk frame_btn_close";			
			$this->m_script = $this->m_Box->addScript();
			$this->m_script->Content  = new IGKMsDialogFrameSizeValue($this);
		}

		public function Render($xmloption=null)
		{ 
			$this->m_Box["style"]="width:".$this->m_Width."px; height:".$this->m_Height."px";
			$out = parent::Render($xmloption);
			return $out;
		}
		public function ClearChilds(){
			$this->m_Content->ClearChilds();
		}
}

//used in MsBox Controller to store activities
final class IGKMsBoxItem extends HtmlItem
{
		private $msbox;
		public function __construct($msbox){
			parent::__construct("div");
			$this->msbox = $msbox;
		}
		public function Render($xmloption=null)
		{		
			if ($this->msbox->IsVisible)
			{
				$out = parent::Render($xmloption);
				$this->msbox->IsVisible = false;
				$this->msbox->clear();
				return $out;
			}
			else{
				return null;
			}
		
		}
}
// Msessabox controller
final class IGKMsBoxController extends IGKControllerBase
{
	private $m_frame;
	private $m_node;
	private $m_title;	
	private $m_boxbloc;
	private $m_errormsg;
	private $m_warningmsg;
	private $m_debugmsg;
	private $m_isvisible;
	
	public function getName(){return "msbox"; }	
	public function getIsVisible(){return $this->m_isvisible;}
	public function setIsVisible($value){$this->m_isvisible =$value;}
	public function getContent(){return $this->m_frame->Content; }
	public function __construct(){
		parent::__construct();
		$this->m_frame = new IGKMsDialogFrame("msboxframe", $this);
		$this->m_frame->setCloseUri("#/closeframe?id=msboxctrl");
		$this->m_node = new IGKMsBoxItem($this);
		$this->m_node->add($this->m_frame);
		$this->m_node["class"] = "msboxctrl posab fitw fith loc_t loc_l zback";
		$this->m_node["id"]= "msboxctrl";
		$this->m_errormsg = HtmlItem::CreateWebNode("ul");		
		$this->m_warningmsg = HtmlItem::CreateWebNode("ul");
		$this->m_debugmsg = HtmlItem::CreateWebNode("ul");
		$this->m_isvisible =false;
	}
	public function View(){
		//no views
		
	}
	
	public function clear()
	{
		$this->_freeError();
		$this->m_warningmsg->ClearChilds();
		$this->m_debugmsg->ClearChilds();
	}
	function _freeError()
	{
		if ($this->m_errormsg->Parent){
				$this->m_errormsg->Parent->remove($this->m_errormsg);
			}
			$this->m_errormsg->ClearChilds();
			
	}
	public function close(){
			if ($this->m_node->Parent)
			{
				$this->m_node->Parent->remove($this->m_node);
				$this->Content->ClearChilds();
				$this->_freeError();
				$this->m_isvisible = false;			
				igk_navtocurrent();
				exit;
			}
	}
	private function _register()
	{
		if ($this->m_node->Parent === null)
		{
				$this->App->Doc->Body->add($this->m_node);
		}
		if ($this->m_errormsg->Parent === null)
		{
			$this->Content->add($this->m_errormsg);
		}
		$this->m_title["class"] = "msbox_error_title";
		$this->m_isvisible = true;
	}
	public function addErrorr($key)
	{
		$this->addError(R::ngets($key));
	}
	public function addError($msg){
		
			if (is_string($msg))
			{
				$this->m_errormsg->add("li")->Content = $msg;
			}
			else{
				HtmlUtils::AddItem($msg, $this->m_errormsg);
			}
		
		$this->_register();
		$this->m_isvisible = true;
	}
	public function addErrori($msg_code)
	{
		$c = igk_error($msg_code);
		if ($c){
			$out = HtmlItem::CreateWebNode("div",array("class"=>"alignl"));
			$ul = $out->add("ul");
			$li = $ul->add("li");			
			$li->add("label")->Content = "Code : ";
			$li->add("span")->Content =  $c["Code"];
			$li = $ul->add("li");
			$li->add("label")->Content = "Message : ";
			$li->add("span")->Content = R::ngets($c["Msg"]);		
			$this->addError($out->Render(null));
		}
		$this->m_isvisible = true;
	}
	public function addInfo($msg){
		if (!$this->IsVisible){
			if (is_string($msg))
			{
				$this->m_errormsg->add("li")->Content = $msg;
			}
			else{
				HtmlUtils::AddItem($msg, $this->m_errormsg);
			}
		}
		$this->_register();
		$this->m_isvisible = true;
	}
	public function addDebug($msg){
		
			if (is_string($msg))
			{
				$this->m_errormsg->add("li", array("class"=>"msbox_debug"))->Content = $msg;
			}
			else{
				HtmlUtils::AddItem($msg, $this->m_errormsg);
			}		
		$this->_register();
		$this->m_isvisible = true;
	}

	public function copyChilds($errori){
	if ($errori == null)return;
			foreach($errori->getChilds() as $k)
			{
				$this->msbox->addError($k);
			}
	}
}
//-----------------------------------------------------------------------------
//used as base configurable controller class
//-----------------------------------------------------------------------------
abstract class IGKConfigCtrlBase extends IGKControllerBase 
implements IIGKConfigController
{
	private $m_configCtrl;
	
	
	public function  getConfigNode(){ return $this->m_configCtrl->getConfigNode(); }	
	public function  getConfigInfo(){ return $this->m_configCtrl->getConfigInfo(); }
	
	public function getConfigCtrl(){return $this->m_configCtrl;}
	public function getConfigPage(){return "default"; }	
	
	public function initConfigMenu()
	{
		$c = $this->ConfigPage;
		if (isset($this->App->ConfigMenuConfiguration->$c))
		{
			$cp = $this->App->ConfigMenuConfiguration->$c;
			if ($cp){
			return array(new IGKMenuItem(
			$cp->menuname, 
			$cp->pagename, 
			$this->getUri("showConfig"), 
			$cp->menuindex, 
			$cp->imagekey));
			}
			else{
				igk_debug("----no config menu found for : ".$c . " ".$this->Name);
				
			}
		}
		else{			
			if (igkServerInfo::IsLocal())
			{
				igk_debug("no config menu found for : ".$c . " ".$this->Name);				
			}
		}
		return null;
	}
	
	public function functionIsAvailable($function){
		$f = ($this->ConfigCtrl->IsConnected==true);
		return $f;
	}
	public function InitComplete()
	{
		parent::InitComplete();
		$this->m_configCtrl = igk_getctrl(IGK_CONF_CTRL, true);
		if($this->m_configCtrl)
		{
			$this->m_configCtrl->addConfigUserChangedEvent($this, "ConfUserChanged");
			$this->m_ConfigNode = $this->m_configCtrl->ConfigNode;
			$this->m_configCtrl->registerConfig($this);
		}
		
	}
	public function ConfUserChanged(){
		$this->View();
	}
	public function __construct(){
		parent::__construct();
	}
	
	
	
	//---------------------------------------------------
	//BASE::showConfig
	//---------------------------------------------------
	public function showConfig(){		
	
		$this->ConfigInfo->ClearChilds();
		$this->ConfigNode->Clear();
		$this->ConfigCtrl->setSelectedConfigCtrl($this, $this->Name."::showConfig");				
		$this->View();
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);			
		}		
		else{
			igk_html_add($this->TargetNode, $this->ConfigNode);			
			//add help 			
			igk_add_article($this, "help.".$this->Name, $this->ConfigInfo->addDiv(), null, true);		
		}
	}
	
	protected function addTitle($node, $title){
		$d = $node->addDiv();
		$d["class"] ="config_title";
		$d->Content = R::ngets($title);
	}
	public function getIsVisible()
	{	
		$v = ( ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)&& ($this->ConfigCtrl!=null) &&( $this->ConfigCtrl->SelectedConfigCtrl== $this) &&($this->ConfigCtrl->IsConnected));				
		return $v;
	}
	public function View()
	{		
		//call the parent view of IGKConfigControlerBase
		parent::View();
	}
}


class IGKPageView extends IGKObject
{
	private $m_value;
	private $m_pagelist;
	
	public function getValue(){return $this->m_value; }
	public function getPageList(){return $this->m_pagelist; }
	public function __construct()
	{
	}
	
	public function registerPages()
	{
		if (!is_array($this->m_pagelist))
			return;
		$ctrl = igk_getctrl(IGK_MENU_CTRL);
		foreach($this->m_pagelist as $k=>$v)
		{
			if (!empty($k))
				$ctrl->registerPage(strtolower(trim($k)));
		}
	}
	public function register($value)
	{
		//-------------------------------
		//register pages with -
		//-------------------------------
		$this->m_value = $value;
		$t = explode(',', $value);
		if ($value == "*")
		{
			$this->m_pagelist = true;
		}
		else {
			$this->m_pagelist = array();
			foreach($t as $k=>$v)
			{
				$this->m_pagelist[strtoupper(trim($v))] = 1;					
			}
		}
	}
	public function getIsVisible($page)
	{
		if ($this->m_value == "*")
			return true;
		if ( isset($this->m_pagelist[strtoupper($page)]))
			return true;
		if ( isset($this->m_pagelist["-".strtoupper($page)]))
			return false;
		return false;
	}
}

///-----------------------------------------------------------------------------------------
///REPRESENT A DEFAULT WEB PAGE
///-----------------------------------------------------------------------------------------


abstract class IGKCtrlTypeBase extends IGKControllerBase
{
	//return the system controller type category
	public static function GetCtrlCategory(){
		return "DEFAUTL";
	}
	//must have a static method that return a info
	public static function GetAdditionalConfigInfo()
	{
		return null;
	}
	//set addition info
	public static function SetAdditionalConfigInfo(& $t)
	{
		
	}
	//get de default string content
	public static function GetAdditionalDefaultViewContent(){
		return  "<?php\n \$this->TargetNode->ClearChilds();\n igk_add_article(\$this , \"default\", \$this->TargetNode); \n?>";
	}
}

abstract class IGKViewCtrl extends IGKCtrlTypeBase
{

	//must have a static method that 
	public static function GetAdditionalConfigInfo()
	{
		return null;
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		
	}
}

abstract class IGKDefaultPageCtrl extends IGKCtrlTypeBase
implements IIGKWebPageController
{	
	private $m_page_content;	//get the page content node
	private $m_footer_content; //get the footer content node
	private $m_menu_container; //get the menu container
	private $m_header_content; //get the header content
	private $m_header_node;// get the header node
	private $m_body_node;   //get the body node
	private $m_footer_node; //get the footer node
	private $m_menuCtrl;	//get the menu controller
	private $m_Title; 		//title of the page
	private $m_currentView; //current view name for this page controller
	///get the name of the page that control this controller
	
	public static function GetAdditionalConfigInfo()
	{
		return array("clDefaultPage");
	}
	public static function SetAdditionalConfigInfo(& $t)
	{
		$t["clDefaultPage"] = igk_getr("clDefaultPage");
	}
	protected function setheaderNode($value){$this->m_header_node = $value;}
	protected function setbodyNode($value){  $this->m_body_node = $value;}
	protected function setfooterNode($value){ $this->m_footer_node = $value;}
	
	//override this to manage error uri request
	public function manageErrorUriRequest($uri){}
	
	public function __construct()
	{
		parent::__construct();
		$this->m_currentView = "default";
	}	
	
	public function getheaderNode(){return $this->m_header_node;}
	public function getbodyNode(){ return $this->m_body_node;}
	public function getfooterNode(){ return $this->m_footer_node;}
	public function getpage_content(){return $this->m_page_content; } //get page content
	public function getheader_content(){return $this->m_header_content; }//get header content
	public function getfooter_content(){return $this->m_footer_content; }//get footer content
	public function getmenu_content(){return $this->m_menu_container; }//get menu base container
	
	
	//load web theme structure
	public function loadWebTheme($file){
	}
	
	//get or set the page name:
	public function setPageName($value){ $this->m_pageviewName; }
	protected function setfooter_content($value){$this->m_footer_content =$value; }
	protected function setpage_content($value){$this->m_page_content = $value;}
	protected function setmenu_content($value){ $this->m_menu_container = $value;}
	protected function setheader_content($value){$this->m_header_content = $value;}
	
	
	protected function _initView(){
		if ($this->App->CurrentPageFolder != IGK_CONFIG_MODE)
		{
			HtmlUtils::AddItem($this->headerNode, $this->doc->bodyheader);
			HtmlUtils::AddItem($this->bodyNode, $this->doc->bodycontent,400);			
			HtmlUtils::AddItem($this->footerNode, $this->doc->bodyfooter, -100);	
			
		}
		else {
			igk_html_rm($this->headerNode);
			igk_html_rm($this->bodyNode);
			igk_html_rm($this->footerNode);
			return;
		}		
		
	}
	public function View(){		
		extract($this->getSystemVars());			
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		else {
			igk_html_add($this->TargetNode, $this->App->Doc->bodypage);
		}
		
		$this->doc->Title = $this->m_Title ? $this->m_Title  : R::ngets("title.".$this->CurrentPage.".WebPage");
		$this->doc->Favicon = new HtmlRelativeUriValueAttribute("R/Img/favicon.ico");		
		$this->_initView();		
		
		$c = strtolower(igk_getr("c",null));
		
		if ($c ==  strtolower($this->Name))
		{
			//change the current view
			$this->m_currentView = igk_getr("v", empty($this->m_currentView) ? "default": $this->m_currentView);
		}		
		//Register parent menu FOR MENU		
			if ($this->m_menuCtrl)
				$this->m_menuCtrl->setParentView($this->menu_content);
		//
		
			$this->m_init = true;	
			$f = $this->_getViewfile($this->m_currentView);
			$d = $this->page_content;
			if($d){
				$d->ClearChilds();
			}
			if (file_exists($f))
			{
				include($f);
			}		
			else{
				igk_debug("Current view file does't exists : ".$f);
			}
			//show child controller
			$this->_showChild();
			$this->_onViewComplete();
		
	}
	
	
	public function InitComplete(){	
		parent::InitComplete();
		$this->m_menuCtrl = igk_getctrl(IGK_MENU_CTRL , true);
		$this->m_menuCtrl->addPageChangedEvent($this, "menupageChanged");
		$this->App->Session->UserChangedEvent->add($this, "View");
	}
	public function menupageChanged(){		
			$this->View();
	}
	public function getIsVisible(){
		//default page controller visible
		return ($this->CurrentPageFolder != IGK_CONFIG_MODE) && ($this->PageView->getIsVisible($this->CurrentPage) );
	}
}

///-----------------------------------------------------------------------------------------
///REPRESENT A Menu Controller
///-----------------------------------------------------------------------------------------
final class IGKMenuCtrl extends IGKConfigCtrlBase
{
	private $m_init;
	private $m_Menus; //registrated menu
	private $m_Pages; //registrated pages
	private $m_CMenus;//Config menu
	private $m_CPages; // Configs Page
	private $m_menu_selected; //base selected menu
	private $m_menu_cselected; //config selected menu
	private $m_configTargetNode; //config target node
	private $m_menuTargetNode;//sytem target node
	private $m_customMenu;//user loaded menu
	
	private $m_CurrentPage;//current page
	private $m_configCurrentPage;// config current mage
	
	private $m_CurrentPageIndex;
	private $m_configCurrentPageIndex;
	private $m_sortby;
	private $m_osortby;
	
	const MENU_CHANGE_KEY  = "CustomMenuChanged";
	
	private $m_menuChangedState;
	private $m_menuHostCtrl; //menu host constroller
	
	//EVENTS
	private $m_CurrentPageChangedEvent;
	private $m_configCurrentPageChangedEvent;
	
	//register menu page
	public function registerPage($pageName)
	{
		if (!isset($this->m_Pages[$pageName]))	
		{
			$this->m_Pages[$pageName] = array();
		}
	}
	public function unregisterPage($pageName)
	{
		if (!isset($this->m_Pages[$pageName]))	
		{
			unset($this->m_Pages[$pageName]);
		}
	}
	
	//GET PROPERTIES
	public function getName(){return IGK_MENU_CTRL;}
	public function getConfigTargetNode(){ return $this->m_configTargetNode; }
	//MENU Current PAGE
	public function getCurrentPage(){return $this->m_CurrentPage;}
	public function getConfigCurrentPage(){return $this->m_CurrentPage;}
	public function getGlobalMenu(){ if (is_array( $this->m_Menus)){$t = array(); $t = array_merge($t, $this->m_Menus); return $t;} return null;}
	public function getMenu($name){ if ($v = igk_getv($this->getGlobalMenu(),  strtoupper($name)))return $v; return null; }
	public function getRootMenu($name){ return $this->_getRootMenu($name);}
	public function getUserMenu(){return $this->m_customMenu; }
	
	
	//return the roots menus
	public function getRoots(){ 
		$t = array ();
		$h = $this->getGlobalMenu() ;
		if ($h && is_array($h)){
			foreach($h as $k)
			{
				if ($k->Parent == null)
					$t[] = $k;
			}
		}
		return $t;
	}
	public function addPageChangedEvent($obj, $method){
		$this->m_CurrentPageChangedEvent->add($obj, $method);
		
	}
	public function removePageChangedEvent($obj, $method){
		$this->m_CurrentPageChangedEvent->remove($obj, $method);
		
	}
	public function addConfigPageChangedEvent($obj, $method){
		$this->m_configCurrentPageChangedEvent->add($obj, $method);
		
	}
	public function removeConfigPageChangedEvent($obj, $method){
		$this->m_configCurrentPageChangedEvent->remove($obj, $method);		
	}
	//get registrated page list
	public function getPageList(){
		return array_keys($this->m_Pages);
	}
	private function onPageChanged(){
		$this->m_CurrentPageChangedEvent->Call($this,null);
	}
	protected function onConfigPageChanged(){
		$this->m_configCurrentPageChangedEvent->Call($this,null);
	}
	public function __construct(){
		parent::__construct();
		$this->m_init =false;
		$this->m_menu_selected = null;
		$this->m_cmenu_selected =null;
		$this->m_CurrentPage = "default";
		$this->m_CurrentPageIndex = 0;
		$this->m_CurrentPageChangedEvent = new IGKEvents($this, "CurrentPageChangedEvent");
		$this->m_configCurrentPageChangedEvent =  new IGKEvents($this, "ConfigCurrentPageChangedEvent");
		$this->m_CurrentPageChangedEvent->add($this, "View");
	}
	

	//------------------------------------------------------------
	//set the global web page
	//------------------------------------------------------------
	public function setPage($page, $index){	
	
	 
		if (!$this->ConfigCtrl->IsConfiguring)
		{	
			if (($this->m_CurrentPage != $page) || ($this->m_CurrentPageIndex != $index))
			{
				$this->m_CurrentPage = $page;
				$this->m_CurrentPageIndex = $index;
				$this->onPageChanged();	
			}
		}
		else{
			if (($this->m_configCurrentPage != $page) || ($this->m_configCurrentPageIndex != $index))
			{
				$this->m_configCurrentPage = $page;
				$this->m_configCurrentPageIndex = $index;
				$this->onConfigPageChanged();	
			}
		}
	}
	public function getConfigPage(){return "menu";}
	
	public function getDataTableInfo()
	{
		return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clIndex", IGK_FD_TYPE=>"Int")),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clController", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clMethod", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clPage", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255 )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clAvailable", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>1 ,"clDefault"=>1))
		);
	}
	
	public function initDb()
	{
	$f = igk_io_syspath(IGK_MENU_CONF_DATA);
	if (file_exists($f) == false){
	$content = <<<EOF
DEFAULT,0,,,default,1
EOF;
		IGKIO::WriteToFileAsUtf8WBOM($f, $content,true);
		$this->_ReLoadMenu();
		}
	}

	public function menu_sortby()
	{
		$r = igk_getr("n");
		$m = igk_getr("m");
		$index = 0;
		if ($m==null){
			if ($r == $this->m_sortby )
				$this->m_sortby = "r_".$r;
			else 
				$this->m_sortby = $r;
		}else{
			$index = 1;
			if ($r == $this->m_sortby )
				$this->m_osortby = "r_".$r;
			else 
				$this->m_osortby = $r;
		}
		$this->View();
		igk_wl(igk_getv($this->TargetNode->getElementsByTagName("table"), $index)->Render());
		exit;
	}
	public function sortmenu($a,$b)
	{
	
		if ($this->m_sortby)
		{
			$m = $this->m_sortby;
			if (IGKString::StartWith($this->m_sortby,"r_"))
			{
				switch(strtolower($m))
				{
					case "clindex":
						$i = igk_getv($a,"clIndex");
						$j = igk_getv($b,"clIndex");
						if ($i < $j)
							return -1;
						else if ($i > $j)
							return 1;
						break;
					case "clcontroller":
					default:
						return strcmp( igk_getv($b,$m), igk_getv($a,$m));
					
				}
				return strcmp( igk_getv($b, "clName"), igk_getv($a,"clName"));
			}
			else{
			switch(strtolower($m))
			{
				case "clindex":
					$i = igk_getv($a,"clIndex");
					$j = igk_getv($b,"clIndex");
					if ($i < $j)
						return -1;
					else if ($i > $j)
						return 1;
					break;
				case "clcontroller":
				default:
					return strcmp( igk_getv($a,$m), igk_getv($b,$m));
				
			}
			}
		}
		return strcmp( igk_getv($a, "clName"), igk_getv($b,"clName"));
	}
	public function changeDefaultPage($newPage =null)
	{
		
		$newPage = igk_gettv($newPage, igk_getr("defaultmenupage"));
		if ($newPage)
		{
			$this->App->Configs->menu_defaultPage = $newPage;
			igk_getctrl(IGK_CONF_CTRL)->saveConfig();
		}
		$this->View();
		igk_navtocurrent();
	}
	public function View(){
		if (!$this->IsVisible)
		{
			if (!$this->ConfigCtrl->IsConfiguring)
			{
				$this->selectGlobalMenu(strtolower($this->m_CurrentPage),$this->m_CurrentPageIndex);			
			}				
			igk_html_rm($this->TargetNode);
			return;
		}
		if (igk_sys_ischanged(self::MENU_CHANGE_KEY, $this->m_menuChangedState))
		{
			$this->_LoadMenu();
		}
		$t = $this->TargetNode;
		igk_html_add($t, $this->ConfigNode);
		$t->ClearChilds();
		
		//primary menu builder
		$v_mdiv = $t->addDiv();
		$v_mdiv["class"]="dispib alignt marg4";
		
		
		$frm = $v_mdiv->addForm();
		$this->addTitle($frm, "title.MenuDefaultPage");
		$frm["action"] = $this->getUri("changeDefaultPage");
		$frm["method"] = "post";
		$frm->addLabel("lb.defaultMenuPage");
		$frm->addInput("defaultmenupage", "text", igk_gettv($this->App->Configs->menu_defaultPage, "default"));
		$frm->addBr();
		$frm->addInput("btn_d", "submit", R::gets("btn.submit"));
		
		
		$c = $v_mdiv->addForm();
		$c["id"] = "config_menu_form";
		$c["action"]="#".$c["id"];
		
		$this->addTitle($c, "title.MenuManager");
		$c->addHSep();	
		
		igk_add_article($this,"menu.description", $c->addDiv());
		$c->addHSep();
		

		
		//HtmlUtils::AddBtnLnk($c, "btn.add", igk_js_post_frame($this->getUri("menu_add_menu_frame_ajx")));//, array("onclick"=>igk_js_post_frame($this->getUri("menu_add_menu_frame_ajx"))));
		$c->addBr();
		$c->addBr();
		
		$tab = $c->add("table", array("class"=>"fitw"));
		
		$ct = $this->DataTableInfo;
		$this->_m_loadTableHeader($tab);
		
		$d = $this->m_customMenu;
		
		usort($d, array($this,"sortmenu"));
		
		
		foreach($d as $k=>$v)
		{		
			$tr = $tab->add("tr");
			
			$input = $tr->add("td")->addInput("menu[]", "checkbox", $v[IGK_FD_NAME]);
			
			foreach($ct as $h=>$m)
			{
				$oi = $m->clName;
				
				
				switch(strtolower($oi))
				{
					case "clindex":
						$tr->add("td")->Content = igk_parse_num($v[$oi]);
						break;
				default:
					if (isset($v[$oi]))
					{
					if ($oi==IGK_FD_NAME){
						$tr->add("td")->add("a", array("href"=>$this->getUri("menu_editmenuframe&n=".$v[IGK_FD_NAME])))->Content =$v[$oi];
					}
					else 
						$tr->add("td")->Content =$v[$oi];
					}
					else
					$tr->add("td")->Content = IGK_HTML_WHITESPACE;//$v[$oi];
				break;
				}
			}
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("menu_editmenuframe&n=".$v[IGK_FD_NAME]), "edit");
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("menu_dropmenu&n=".$v[IGK_FD_NAME]), "drop");
					
		}
		$c->addBr();
		
		$div = $c->addDiv();
		$a = HtmlUtils::AddImgLnk($div,$this->getUri("menu_drop_selected_menu_ajx"), "drop");
		$a["onclick"] = "javascript: var q =  \$igk(this).getParentByTagName('form'); q.action = this.href; q.submit();  return false;";		
		HtmlUtils::AddBtnLnk($c, "btn.add", igk_js_post_frame($this->getUri("menu_add_menu_frame_ajx")));		
		HtmlUtils::AddBtnLnk($c,"btn.rmAll", $this->getUri("menu_clearallmenu"));			
		igk_html_toggle_class($tab);
		
		//other menu builder
		$v_mdiv = $t->addDiv();
		$v_mdiv["class"]="dispib alignt marg4";
		$this->_m_otherMenuView($v_mdiv);
	}
	private function _m_loadTableHeader($table, $oMenu=null)
	{
		$tr = $table->add("tr");
		HtmlUtils::AddToggleAllCheckboxTh($tr);			
		$ct = $this->DataTableInfo;
		foreach($ct as $k)
		{
			$tr->add("th")->add('a', array("href"=>$this->getUri("menu_sortby&n=".$k->clName. (($oMenu==null)?null:"&m=".$oMenu) ),
			"onclick"=>igk_js_ajx_post_luri('table')))->Content = R::gets($k->clName);
		}		
		$tr->add("th",array("style"=>"width:8px; "))->Content = IGK_HTML_WHITESPACE;
		$tr->add("th", array("style"=>"width:8px; "))->Content = IGK_HTML_WHITESPACE;
	}
	private function _m_otherMenuView($target)
	{
		
		$this->addTitle($target, "title.OtherMenuManager");
		$target->addHSep();
		
		igk_add_article($this,"menu.othermenudescription", $target->addDiv(), null, true);
		$target->addHSep();
		$frm = $target->addForm();
		
		
		
		$li = $frm->add("ul")->add("li");
		$li->addLabel("lb.Menus", "clMenus");
		igk_html_build_select($li,"clMenus", array());
		
		
		$table = $frm->addTable();
		
		$this->_m_loadTableHeader($table, "d");
		
		$btndiv = $frm->addDiv();
		
		igk_html_toggle_class($table);
		
	}
	public function menu_drop_selected_menu()
	{
		$this->menu_drop_selected_menu_ajx();
		
	}
	public function menu_drop_selected_menu_ajx()
	{		
		if (!$this->ConfigCtrl->IsConnected)
			return;
		$m = igk_getr("menu");
		$c = false;
		foreach($m as $k=>$n)		
		{
			$n = strtoupper($n);
			if (isset($this->m_customMenu[$n]))
			{
				unset($this->m_customMenu[$n]);			
				$c = true;
			}
		}
		if ($c)
		{
			$this->__saveConfigMenu();
			$this->_ReLoadMenu();				
			igk_notifyctrl()->addMsg("menu ".$n. " removed");			
		}
		else {
			igk_notifyctrl()->addError("menu ".$n. " not removed");
		}				
		igk_navtocurrent();
	}
	
	public function menu_clearallmenu()
	{		
		if (igk_qr_confirm()){
			$this->m_customMenu = array();
			$this->__saveConfigMenu();			
			$this->_ReLoadMenu();			
			igk_navtocurrent();
		}
		else{
			$frame = igk_add_confirm_frame($this, "menu_clearallmenu_confirm_frame", $this->getUri("menu_clearallmenu"));				
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEMENU_QUESTION);						
		}
	}
	public function menu_dropmenu()
	{
		$n = igk_getr("n","");
		$n = strtoupper($n);
		if (isset($this->m_customMenu[$n]))
		{
			unset($this->m_customMenu[$n]);			
			$this->__saveConfigMenu();
			$this->_ReLoadMenu();
			igk_notifyctrl()->addMsg("menu ".$n. " removed");			
		}
		else {
			igk_notifyctrl()->addError("menu ".$n. " not removed");
		}
		igk_navtocurrent();
	}
	public function menu_editmenuframe($name=null)
	{
		$name = ($name==null)?igk_getr("n"):$name;		
		
		if (!isset($this->m_customMenu[$name]))
				return ;
				
		$v_menu = $this->m_customMenu[$name];		
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_editMenu_frame", $this);
		HtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.EditMenu", $name);
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("save_menu");
		$div = $frm->addDiv();
		$index   = igk_getsv( igk_getv($v_menu,"clIndex"), '0');
	
		$div->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name", "text",igk_getv($v_menu,IGK_FD_NAME), null, true);
		$div->add("li")->addSLabelInput("clIndex","lb.Index", "text",$index, array("isnumeric"=>true), true);
		$div->add("li")->addSLabelInput("clPage","lb.Page","text",igk_getv($v_menu,"clPage"), null);
		
		$this->__getEditController($div, igk_getv($v_menu,"clController"));
	
		$div->add("li")->addSLabelInput("clMethod","lb.Method","text",igk_getv($v_menu,"clMethod"));		
		$div->add("li")->addSLabelInput("clGroup","lb.Group","text", igk_getv($v_menu,"clGroup"));	
		$li = $div->add("li");
		$li->add("label")->Content = R::ngets("clAvailable");
		
		$chb = $li->addInput("clAvailable", "checkbox");
		
		if (igk_getv($v_menu,"clAvailable")){
			$chb["checked"] = true;
		}
		
		$div->addInput("confirm", "hidden", 1);
		//clear info
		$div->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.save"));
	}
	public function save_menu()
	{	
		if (!igk_qr_confirm())
		{
			return;
		}		
		$this->menu_add_menu(false);			
		$this->View();
		igk_frame_close("theme_editMenu_frame", false);		
	}
	public function __getEditController($div, $selectedMenu, $key = "lb.Controller", $remove="")
	{
			$tab = $this->App->ControllerManager->getUserControllers();
			$li = $div->add("li");
			$li->add("label")->Content = R::ngets($key);
			$sel = $li->add("select");	
			$sel["id"]=$sel["name"] = "clController";
			$sel->add("option", array("value"=>"none"))->Content = IGK_HTML_SPACE;
		if (count($tab) > 0)
			{
		
			foreach($tab as $v)
			{	if (strtolower($remove) == strtolower($v->getName()))
				   continue;
				$opt = $sel->add("option", array("value"=>$v->getName()));
				if ($selectedMenu == $v->getName())
					$opt["selected"] = true;
				$opt->Content = $v->getName();				
			}
			}
			return $sel;
	}
	public function menu_add_menu_frame_ajx()
	{
	
		$frame = igk_add_new_frame($this, "theme_menu_add_menu_frame");
		
		$frame->Title = R::ngets("title.Menu");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("menu_add_menu");
		$div = $frm->addDiv();
		$div->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name", "text",null, null, true);
		$div->add("li")->addSLabelInput("clIndex","lb.Index", "text",null, array("isnumeric"=>true), true);
		$div->add("li")->addSLabelInput("clPage","lb.Page","text");
		
		$this->__getEditController($div, null);		
		$div->add("li")->addSLabelInput("clMethod","lb.Method");		
		$div->add("li")->addSLabelInput("clGroup","lb.Group");	
		$li = $div->add("li");
		$li->add("label")->Content = R::ngets("clAvailable");
		$chb = $li->addInput("clAvailable", "checkbox");
		$chb["checked"] = true;
		//clear info
		$div->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));	
		igk_wl($frame->Render());
	}
	public function getDefaultEntry()
	{
		return array(
			IGK_FD_NAME=>null,
			"clIndex"=>0,
			"clController"=>null,
			"clMethod"=>null,
			"clPage"=>null,
			"clGroup"=>null,
			"clAvailable"=>null
		);		
	}
	public function reg_menu($t, $saveconfig= true)
	{
		if (is_array($t) == false)
			return;
		extract($t);
		$clIndex = igk_getsv($clIndex, 0);
		$this->val->ClearChilds();
		if (IGKValidator::IsStringNullOrEmpty($clName)) $this->val->add("Name is null or empty");
		if (isset($this->m_customMenu[IGK_FD_NAME])){ $this->val->add("Menu already registered");}
		if ($this->val->HasChilds){
			$this->msbox->copyChilds($this->val);
		}
		else{
			$clName = strtoupper($clName);
			
			$this->m_customMenu[$clName] = array(
				IGK_FD_NAME=>trim($clName),
				"clIndex"=>trim($clIndex),
				"clController"=>trim($clController)=="none"?null:trim($clController),
				"clMethod"=>trim($clMethod),
				"clPage"=>trim($clPage),
				"clGroup"=>trim($clGroup),
				"clAvailable"=>(isset($clAvailable)?1:0)
		);
		
		$this->__storeConfigMenu($saveconfig);
	}
	}
	private function __storeConfigMenu($saveconfig=true)
	{	
		if ($saveconfig)
		{
			if ($this->__saveConfigMenu())
			{
			//reload menu
				$this->_ReLoadMenu();						
				igk_notifyctrl()->addMsgr("msg.globalmenuupdated");
				igk_debug("notice:save and reloaded");
			}
			else{
				igk_debug("error:not saved menu");
			}
		}
	}
	//add menu
	public function menu_add_menu($navigate=true)
	{
		$this->reg_menu($_REQUEST);		
		if ($navigate){
		igk_navtocurrent();
		}
	}
	//load config menu from file
	private function _LoadConfigMenu()
	{
		$this->m_customMenu = array();
		$f = igk_io_syspath(IGK_MENU_CONF_DATA);
		$txt = IGKIO::ReadAllText($f);
		$lines = explode(IGK_LF, $txt);
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$e = explode( igk_csv_sep(), $l);			
			$name = strtoupper(trim($e[0]));
			if (empty($name))continue;
			$this->m_customMenu [$name] =array(
				IGK_FD_NAME=>$name,
				"clIndex"=>trim(igk_getv($e,1)),
				"clController"=>trim(igk_getv($e,2)),
				"clMethod"=>trim(igk_getv($e,3)),
				"clPage"=>trim(igk_getv($e,4)),
				"clGroup"=>trim(igk_getv($e,5)),
				"clAvailable"=>trim(igk_getv($e,6)),
				);
		}
		igk_debug("warning: load config menu [".count($this->m_customMenu )."]");
	}
	function __clearConfigMenu($storeconfig=true)
	{
		$this->m_customMenu = array();
		$this->__storeConfigMenu($storeconfig);
	}
	//save config file to file
	function __saveConfigMenu()
	{
		igk_debug("warning: _saveConfigMenu [".igk_count($this->m_customMenu )."]");
		$out = "";
		$i = false;
		$line = null;
		foreach($this->m_customMenu as $k=>$v)
		{
			if ($i )
				$out .= "\n";
			$line = "";
			$v_sep = false;
			foreach($v as $c=>$m)
			{
				$m = trim($m);
				if ($v_sep){
					$line .= igk_csv_sep();
				}
				else{
					$v_sep = true;
				}
				if (!empty($m))
					$line .= $m;
				
			}
			$out .= $line;
			$i =true;
		}
	  
	  $v =  IGKIO::WriteToFileAsUtf8WBOM(igk_io_currentRelativePath(IGK_MENU_CONF_DATA), $out, true);	
	  if ($v)	  
	  igk_sys_regchange(self::MENU_CHANGE_KEY, $this->m_menuChangedState);
	  return $v;
	}
	private function _initMenu($ul, $menu,  &$pages =null)
	{
		$add_uri = null;
		if (isset($pages))
		{
		
				$page = strtolower($menu->CurrentPage);
				if (isset($pages [$page]))
				{
					if (!is_array($pages [$page]))
					{
					$cp = $pages [$page];
					$cp->PageIndex = 0;
					$pages[$page] = array($cp);
					$cp->MenuItem["href"] = $cp->MenuItem["href"]."&pageindex=0";
					}
					$pages [$page][] = $menu;					
					$menu->PageIndex = count($pages [$page])-1;
					$add_uri = "&pageindex=".$menu->PageIndex;
				}
				else{
					$pages [$page] = $menu;
				}
				
		}
		
		$menu->updateUri($add_uri);		
		if ($menu->HasChilds())
		{
			$menu->sortChilds();
			$v_ul = $menu->Node->add("ul", array("class"=>"submenu".$this->_getMenuLevel($menu)." "));
			foreach($menu->getChilds() as $k)
			{
				$v = $this->_initMenu($v_ul, $k, $pages);
			}
		}
		//add node to uls
		$ul->add($menu->Node);
		
	}
	private function _getMenuLevel($menu){
		if ($menu->Parent == null)
			return 0;
		return $this->_getMenuLevel($menu->Parent) + 1;
	}
	//-------------------------------------------------------------------
	//select root menu
	//-------------------------------------------------------------------
	public function selectGlobalMenu($page, $index=0)
	{		
		$page = strtolower($page);
		if (isset($this->m_Pages[$page]))
		{
			if ($this->m_menu_selected !=null)
			{
				$this->m_menu_selected["class"] = "-igk-menu_selected";
			}
			$v_rootmenu  = null;
			$v_p = $this->m_Pages[$page];
			if (!is_array($v_p))
				$v_rootmenu = $this->_getRootMenu($v_p);
			else {
				if (isset($v_p[$this->m_CurrentPageIndex]))
					$v_rootmenu = $this->_getRootMenu($v_p[$this->m_CurrentPageIndex]);				
			}
			
			if ($v_rootmenu){
				$this->m_menu_selected = $v_rootmenu->MenuItem;
				$this->m_menu_selected["class"] = "+igk-menu_selected";				
			}			
		}
		else{
			if (igkServerInfo::IsLocal())
			{
				igk_notifyctrl()->addError("web_global_menu not define [".$page."] - ". $_SERVER["REQUEST_URI"]);				
			}
		}
	}
	
	//select root menu
	public function selectConfigMenu($page, $fromcontext=null)
	{
		$page = strtolower($page);
		if (isset($this->m_CPages[$page]))
		{
			if ($this->m_menu_cselected !=null)
			{
				$this->m_menu_cselected->MenuItem["class"] = "-igk-config-menu_selected";
			}
			$this->m_menu_cselected = $this->m_CPages[$page];
			$this->m_menu_cselected->MenuItem["class"] = "+igk-config-menu_selected";				
		}
		else{
			igk_notifyctrl()->addError("Config menu not define : [".$page."]");		
		}
		//igk_wln("select config menu". $page);
	}
	
	//retreive the root menu of a menu item
	private function _getRootMenu($menu)
	{
		if (($menu == null) || is_array($menu))
			return null;
		if ($menu->Parent === null)
			return $menu;
		return $this->_getRootMenu($menu->Parent);
	}
	
	public function setParentView($node)
	{
		if ($node)
		{
			HtmlUtils::AddItem($this->m_menuTargetNode,$node);
		}
	}
	public function setConfigParentView($node)
	{
		if ($node)
		{
			HtmlUtils::AddItem($this->ConfigTargetNode, $node);
		}
	}
	protected function initTargetNode(){
		$ul =  HtmlItem::CreateWebNode("ul");
		$this->m_configTargetNode = HtmlItem::CreateWebNode("ul");
		$this->m_menuTargetNode = HtmlItem::CreateWebNode("ul");
		return $ul;
	}
		// public function InitComplete(){
		// parent::InitComplete();		
		// please enter your controller declaration complete here
	// }
	public function InitComplete()
	{
		parent::InitComplete();
		//register for menu list changed		
		$this->m_CurrentPage = igk_gettv($this->App->Configs->menu_defaultPage, "default");
		igk_sys_regchange(self::MENU_CHANGE_KEY, $this->m_menuChangedState);
		//load menu
		$this->_LoadMenu();
		$this->setMenuview();
		$this->selectGlobalMenu($this->m_CurrentPage);
	}
	//set the menu host ctrl
	public function setMenuhostCtrl($value)
	{
		if ($this->m_menuHostCtrl != $value)
		{
			
			if (is_object($this->m_menuHostCtrl))
			{
				$this->m_menuHostCtrl->unregView($this);
			}			
			$this->m_menuHostCtrl = $value;
			if ($this->m_menuHostCtrl!=null)
				$this->m_menuHostCtrl->regView($this, "setMenuview");
		}
	}
	public function setMenuview()
	{
		if ($this->App->Configs->menuHostCtrl)
		{			
			$menu_host =  igk_getctrl($this->App->Configs->menuHostCtrl);
			if ($menu_host !=null )
			{
				$this->setMenuhostCtrl($menu_host);
				$this->setParentView($menu_host->TargetNode);		
			}
		}
		
	}
	private function _ReLoadMenu()
	{
		$this->m_init = false;
		$this->_LoadMenu();
		$this->selectConfigMenu($this->m_menu_cselected? $this->m_menu_cselected->Name :"default");
		$this->View();
	}
	private function _LoadMenu()
	{
		
		//load menu from data base
		$this->_LoadConfigMenu();
		
		//setup menu to match menu item
		$v_cmenu = array();
		foreach($this->m_customMenu as $k=>$v)
		{
			if (igk_getv($v,"clAvailable"))
			{
			$v_cmenu[] = new IGKMenuItem($v[IGK_FD_NAME], 
			igk_getv($v,"clPage"),
			igk_getv($v,"clMethod"),
			igk_getv($v,"clIndex"),
			null,
			igk_getv($v,"clController"),
			igk_getv($v,"clGroup")
			);
			}
		}
		
		$ul = $this->m_menuTargetNode;
		$ul["id"] = "web_site_menu";
		$ul["class"] = "menu menufont menu_forecl menu_bgcl";
		$ul->Index = -9999;
		$ul->ClearChilds();
		
		
		
		$cul = $this->m_configTargetNode;
		$cul["class"] = "config_menu_font";
		$cul->Index = -9999;
		$cul->ClearChilds();
		//$cform = $cul->addForm();
		// if ($this->m_init == false)
		// {
			$tab = array();
			$ctab = array();
			$this->m_Menus = array();
			$this->m_Pages = array();
			$this->m_CMenus = array();
			$this->m_CPages = array();
			//create menu from configs files
			foreach(igk::getInstance()->ControllerManager->getControllers() as $k=>$v)
			{
			
				//
				//load config menu frame
				//
				$m = $v->initMenu();
				$cm = $v->initConfigMenu();
				
				if ($m !== null)					
					$tab = array_merge($tab, $m);
				if ($cm !== null)					
					$ctab = array_merge($ctab, $cm);
			}
			//register element
			//IGKMenuItem::Sort($tab);
			$r = array("IGKMenuItem", "SortMenuByIndex");
			$tab = array_merge($v_cmenu, $tab);
			igk_usort($tab, array("IGKMenuItem", "SortMenuByName"));
			
			$v_list = array();
			foreach($tab as $v)
			{
				$p = $this->_getParentName($v->Name);
				
			if (isset($v_list[$p]))
				{
					$v_list[$p]->add($v);
				}
				else{
					$v_list[$v->Name] = $v;
				}
			}
			igk_usort($tab, $r);
			igk_usort($ctab, $r);
		
			foreach($tab as $t=>$m)
			{
				if ($m->Parent ==null){
				//for root menu only
					$this->m_Menus[$m->Name] = $m;
					$this->_initMenu($ul, $m, $this->m_Pages);		
				}
			}
			$sr = $ul->add("script")->Content = <<<EOF
igk.page.menu.init();
EOF;
			
			//init config menu
			foreach($ctab as $t=>$m)
			{
				
				//$this->_initMenu($cform , $m);
				$this->_initMenu($cul , $m);
				$this->m_CPages[$m->CurrentPage] = $m;
				
				$v_a  = $m->MenuItem;								
				$v_a["page"] = $m->CurrentPage;
				$this->m_CMenus[$m->Name] = $m ;				
			}
			$sr = $cul->add("script");
			
			$sr->Content = <<<EOF
igk.configmenu.init(igk.getParentScriptByTagName());
EOF;
			
			$this->m_init = true;		
	}
	public function _getParentName($name)
	{
		$t = explode(".", $name);
		$c = count($t);
		if ($c>1)
		{
			$out = "";
			$v_sep = false;
			for	($i = 0;$i< $c-1 ; $i++)
			{
				if ($v_sep)
					$out .= ".";
				else 
					$v_sep = true;
				$out .= $t[$i];
			}
			return $out;
		}
		return null;
	}
	
}

class IGKOtherMenuCtrl extends IGKControllerBase
{
	private $m_allMenus;
	public function getMenus(){return $this->m_allMenus;}
	public function InitComplete()
	{
		parent::InitComplete();
		$this->m_allMenus = IGKMenu::GetMenus();
	}
	public function getIsVisible(){return false;}
}

final class IGKMenu extends IGKObject
{
	var $Name;
	var $m_menus;
	
	public static $sm_menus;
	
	public function getMenuFile(){
		return igk_io_currentbasePath(IGK_DATA_FOLDER ."/menu".$this->Name."conf.csv");
	}
	public function __construct($name)
	{
		$this->Name = $name;
		$this->m_menus = array();
	}
	

	public static function GetMenus()
	{
		if (self::$sm_menus == null)
		{
			self::$sm_menus = array();			
			//
			$d = igk_io_getFiles(igk_io_currentbasePath(IGK_DATA_FOLDER), IGK_MENUS_REGEX);
			foreach($d as $k=>$v)
			{
				$n = igk_regex_get(IGK_MENUS_REGEX, "name", $v);
				igk_wln($n);
			}
			
		}
		return self::$sm_menus;
	}
	
	public function loadMenu()
	{
		
	}
	public function storeMenu()
	{
		
	}
	public function addMenu($name)
	{
		$n = new IGKMenuItem($name, null,null);
		$this->m_menus[$name]  = $n;
		return $n;
	}
}

final class IGKMenuItem extends IGKObject
{
	
	var $Name;
	var $PageIndex;
	var $m_Parent;
	
	private $m_Uri;	
	private $m_Index;
	private $m_key;
	private $m_menuItem;
	private $m_CurrentPage;
	private $m_Childs;
	private $m_group;
	private $m_Visible;
	private $m_VisibleChangedEvent;
	private $m_controller;
	private $m_node;
	public function __toString(){
		return get_class($this). " [ ".$this->Name." ] ";
	}
	//get the group name
	public function getGroup(){return $this->m_group;}
	public function & getParent(){return $this->m_Parent;}
	public function getKey(){			return $this->m_key;	}
	public function HasChilds(){return (count($this->m_Childs)>0);}
	public function setMenuItem($menu){ 
		$this->m_menuItem = $menu; 		
		$this->updateView();
		
	}
	//menu item
	public function getMenuItem(){return $this->m_menuItem; }
	//MENUITEM CURRENT PAGE
	public function getCurrentPage(){return $this->m_CurrentPage; }
	public function getIndex(){return $this->m_Index;}
	public function getIsVisible(){
	if ($this->m_menuItem)
		return $this->m_menuItem->IsVisible;
	return false;
	}
	//get the html current node
	// <a></a><ul>...child...</ul>
	public function getNode(){return $this->m_node; }
	
	public function getChilds(){ return $this->m_Childs;	}
	
	public function getIsMenuSelected(){		
		$c = $this->m_menuItem["class"];
		if (!$c)
			return false;
		return $c->contain("igk-menu_selected");		
	}
	public function getUri(){
		$uri = "";
		if (!empty($this->m_Uri))
			$uri .= $this->m_Uri;
		if (!empty($this->m_CurrentPage)){
			if (strlen($uri) >0)
				$uri.="&";
			if (!empty($this->m_CurrentPage))
				$uri .= "p=".$this->m_CurrentPage;
		}
		$ctrl = $this->m_controller;
		if ($ctrl!=null){
			return $ctrl->getUri($uri);
		}
		if (IGKString::StartWith($uri,'?'))
			return $uri;
		return "?".$uri;
		
		
	}
	public function setIsVisible($value){ 
		if ($this->m_menuItem && ($this->m_controller == null))
			$this->m_menuItem->IsVisible = $value; 
		}
	public static function CreateMenu($attributes )
	{
		if (!is_array($attributes))
		return null;
		$n = igk_getv($attribute,"name");
		$uri = igk_getv($attribute,"uri");
		$i = igk_getv($attribute,"index");
		$p = igk_getv($attribute,"page");
		if (empty($n) || empty($uri) || empty($p))
			return null;
		$menu = new IGKMenuItem($n, $p, $uri, $i);
		foreach($attributes as $k=>$v)
		{
			$menu->$k = $v;  
		}
		return $menu;
	}
	public function __construct($name,$CurrentPage, $uri, $index=0, $key=null, $controller=null, $group=null, $defaulttag="li"){
	$this->m_Parent = null;
	$this->m_Childs = array();
	$this->Name = strtoupper($name);
	$this->m_Uri = $uri;
	$this->m_Index = $index;
	$this->m_CurrentPage = strtolower($CurrentPage);
	$this->m_group = $group;
	
	$this->m_controller = ($controller!=null)? igk_getctrl($controller, false):null;
	$this->PageIndex = 0;
	$this->m_node = HtmlItem::CreateWebNode($defaulttag , array("class"=>strtolower("menu_".$this->Name."")));
	$item = $this->node->add("a", array("href"=>$this->Uri));
	
	
	
	if($key == null)
		$this->m_key = strtoupper("Menu.".$name);
	else 
		$this->m_key = $name;
		
		$this->m_Visible = true;
		$this->m_VisibleChangedEvent = new IGKEvents($this, "VisibleChanged");
		$this->m_VisibleChangedEvent->add($this, "_visibleChanged");
		
		if ($this->m_controller !=null)
		{
			igk_getctrl(IGK_MENU_CTRL)->addPageChangedEvent($this, "updateview");
			igk::getInstance()->Session->addUserChangedEvent($this, "updateview");
		}
	$item->add("span")->Content = R::ngets($this->Key);
	$this->setMenuItem($item);
	
	}
	public function updateUri($adduri)
	{
		$this->MenuItem["href"] = $this->Uri.$adduri;
	}
	public function updateview(){
		if ($this->m_controller !=null){
			$this->m_menuItem->IsVisible = $this->m_controller->isAvailable;		
			$this->m_menuItem->getHtmlItemParent()->IsVisible = $this->m_controller->isAvailable;
		}
	}
	
	public function add($menu){
		if ($menu == null)return;
		$this->_removeParent($menu);
		$this->m_Childs[] = $menu;
		$menu->m_Parent = $this;
	}
	public function remove($menu){
		for($i = 0;$i<count($this->Childs); $i++){
			if ($this->Childs[$i] === $menu){
			unset($this->m_Childs[$i]);
			$this->m_Childs = array_values($this->Childs);
			$menu->m_Parent = null;
			break;
			}
		}
	}
	public function Clear(){
		$this->m_Childs = array();
	}
	private function _removeParent($menu){
		if (($menu != null) && ($menu->Parent !=null)){
			$menu->Parent->remove($menu);			
		}
	}
	//sort menu by index and by name
	//---------------------------------
	public static function SortMenuByIndex($a, $b){
		if ($a->Index < $b->Index)
			return -1;
		else if ($a->Index == $b->Index)
			return self::SortMenuByName($a, $b);
		return 1;
	}
	public static function SortMenuByName($a, $b)
	{
		return strcmp($a->Name, $b->Name);
	}
	public function sortChilds()
	{
		igk_usort($this->m_Childs, array("IGKMenuItem", "SortMenuByIndex"));
	}
}


final class IGKMenuUtils 
{
	public static function BuildMenu($targetNode, $tab, &$menus, &$pages)
	{
			$v_list = array();
			foreach($tab as $v)
			{
				$p = self::_getParentName($v->Name);
				
			if (isset($v_list[$p]))
				{
					$v_list[$p]->add($v);
				}
				else{
					$v_list[$v->Name] = $v;
				}
			}
			$r = array("IGKMenuItem", "SortMenuByIndex");
			igk_usort($tab, $r);
			foreach($tab as $t=>$m)
			{
				if ($m->Parent ==null){
				//for root menu only
					$menus[$m->Name] = self::__initMenu($targetNode, $m, $page);		
				}
			}
	}
	
	private static function __initMenu($node, $menu, &$page)
	{
		$add_uri = null;
		if (isset($pages))
		{
		
				$page = strtolower($menu->CurrentPage);
				if (isset($pages [$page]))
				{
					if (!is_array($pages [$page]))
					{
					$cp = $pages [$page];
					$cp->PageIndex = 0;
					$pages[$page] = array($cp);
					$cp->MenuItem["href"] = $cp->MenuItem["href"]."&pageindex=0";
					}
					$pages [$page][] = $menu;					
					$menu->PageIndex = count($pages [$page])-1;
					$add_uri = "&pageindex=".$menu->PageIndex;
				}
				else{
					$pages [$page] = $menu;
				}
				
		}
		$menu->updateUri($add_uri);
		
		// $li = $node->add("li" ,array("class"=>"posr"));
		// $item = $li->add("a", array("href"=>$menu->Uri.$add_uri));
		//$item->Content = R::ngets($menu->Key);
		//$menu->setMenuItem($item);
		if ($menu->HasChilds())
		{
			$menu->sortChilds();
			$v_ul = $li->add("ul", array("class"=>"submenu".$this->_getMenuLevel($menu)." "));
			foreach($menu->getChilds() as $k)
			{
				$v = $this->_initMenu($v_ul, $k, $pages);
			}
		}
		//return the menu created
		//return $menu->MenuItem;
	}	
	public static function _getParentName($name)
	{
		$t = explode(".", $name);
		$c = count($t);
		if ($c>1)
		{
			$out = "";
			$v_sep = false;
			for	($i = 0;$i< $c-1 ; $i++)
			{
				if ($v_sep)
					$out .= ".";
				else 
					$v_sep = true;
				$out .= $t[$i];
			}
			return $out;
		}
		return null;
	}
}


//represent a data adapter factory
abstract class IGKDataAdapter extends IGKObject
{
	private static $sm_regAdapter =null;
	public static function Load()
	{
		self::LoadAdapter();
	}
	public function select($tablename, $entries){}
	public function delete($tablename, $entries){}
	public function deleteAll($tablename){}
	public function update($tablename, $entrie =null) {}	
	public function drop(){$this->deleteAll(); }//shortcut to delete all
	public function selectdb($dbname){}//select db used in some data base
	public abstract function connect();//connect
	public abstract function close();//close your adapter
	public function selectAll($tbname){ return null;}
	public function selectLastId(){ return null; }
	
	public function selectAndWhere($tablename, $whereTab){return null;}
	
	//return the igk instance
	public function getApp(){return igk::getInstance(); }
	public function getIsAvailable(){ return true;}
	private static function LoadAdapter()
	{
	//init data adapter class
			$n = "/^IGK(?P<name>(.)+)DataAdapter$/i";
			self::$sm_regAdapter = array();
			foreach( get_declared_classes() as $k=>$v)
			{
				
				if (preg_match($n,$v))
				{
					$t = array();
					preg_match_all($n,$v, $t);
					$s = $t["name"][0];
					
					if (!igk_reflection_class_isabstract($v) && is_subclass_of($v, "IGKDataAdapter"))
					{
						self::$sm_regAdapter[strtoupper($s)] = new $v();
					}					
				}
			}
	}
	public static function GetAdapters()
	{
		if (self::$sm_regAdapter==null)
		{
			self::LoadAdapter();
			
		}
		return self::$sm_regAdapter;
	}
	public static function CreateDataAdapter($ctrl, $throwexception=false, $params = null){
		
		$adapt = self::GetAdapters();	
		
		$n = "";
		$key = "";
		if (is_string($ctrl))
		{
			$key = strtoupper($ctrl);
			$n = "IGK".$ctrl."DataAdapter";
		}
		else {
			$key = strtoupper($ctrl->getDataAdapterName());
			$n = "IGK".$ctrl->getDataAdapterName()."DataAdapter";
		}

		if (isset($adapt[$key]))
		{
			return $adapt[$key];
		}
		igk_wln("CreateDataApter: not found");
		exit;
		if (class_exists($n) && !igk_reflection_class_isabstract($n))
		{
			$out = new $n(!is_string($ctrl)? $ctrl: null);
		
			if (($out !=null) && ($params !=null))
			{
				$out->configure($params);
			}
			if (!$out->IsAvailable)
			{
				igk_debug("adapter ".$ctrl." not available");
				return null;
			}
			//register adapter
			$adapt[$key] = $out;
			return $out;
		}
		if ($throwexception)//ultimate case not found
			throw new Exception($n . " not found : Controller : ".$ctrl . " Name = d".$ctrl->getDataAdapterName() );
		return null;
	}
	
	
	///DATA ADAPTER OVERRIDABLE FUNCTIONS
	public function insert($table, $entries){
		igk_wln("must override insert");
	}
	public function createTable($tablename, $columninfoArray){
	}
	protected function configure($params)
	{
	}
}


class IGKDataAdapterCtrl extends IGKControllerBase
{
	public function InitComplete(){
		parent::InitComplete();
		IGKDataAdapter::Load();
	}
}

final class IGKCSVQueryResult extends IGKQueryResult
{
	private $m_columns;
	private $m_rows;
	private $m_rowcount;
	private function __construct()
	{
		
	}
	public function getRows(){return $this->m_rows; }
	public function getColumns(){return $this->m_columns; }
	public static function CreateEmptyResult($result=null, $seacharray=null)
	{		
		$out = new IGKCSVQueryResult();
		$out->m_rowcount = 0;
		$out->m_rows = array();		
		return $out;
	}
	public function AppendEntries($e, $tableinfo=null)
	{
		
		$this->m_rowcount += igk_count($e);
		
		if ($tableinfo!=null)
		{
			foreach($e as $k=>$v)
			{
				$t = array();
				foreach($v as $m=>$n)
				{
					$v_n = $tableinfo[$m];
					$t[$v_n->clName] = $n;
					
				}
				$this->m_rows[] = (object)$t;
			}
		}
		else{
			foreach($e as $k=>$v)
			{
				$this->m_rows[] = $v;
			}
		}
	}
}
final class IGKCSVDataAdapter extends IGKDataAdapter
{
	private $m_fhandle;
	private $m_ctrl;
	private $m_dbname;
	
	public function __construct($ctrl = null){
		//don't call parent adapter
		$this->m_ctrl = $ctrl;	
	}
	
	
	public function connect($datafile="file"){
		$this->m_dbname = $datafile;
	}
	///convert tab to line entry
	public function toCSVLineEntry($tab, $key = null)
	{
		$out = "";
		$v_sep = false;
		if (is_object($tab))
		{
		
			foreach($tab as $k=>$c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c;
			}
			
			return $out;
		}
		
		if (!is_array($tab))
		{
			return null;
		}
		if ($key!=null)
		{
			$v_sep = false;
			foreach($tab as $c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c->$key;
			}
		}
		else{
			foreach($tab as $c)
			{				
				if ($v_sep)
					$out .= igk_csv_sep();
				else
					$v_sep =true;
				$out .= $c;
			}
		
		}
		return $out;
	}
	public static function GetValue($value)
	{
		if (strpos($value,igk_csv_sep()) !== false)
			return "\"".$value."\"";
		return $value;
	}
	//store data entrie to kv
	public static function StoreData($filename, $entries)
	{
		$out = "";
		$v_ln = false;
		foreach($entries as $k=>$v)
		{
			if ($v_ln){
				$out .= IGK_LF;
			}
			else 
					$v_ln  = true;
			$v_sep = false;
			foreach($v as $d){
				if ($v_sep){
					$out .= igk_csv_sep();
				}
				else 
					$v_sep = true;
				$out .= self::GetValue($d);
				
			}
			
		}		
		IGKIO::WriteToFileAsUtf8WBOM($filename, $out, true);
	}
	static function __removeguillemet($data)
		{
			if (IGKString::StartWith($data,'"'))
			{
				$data = substr($data, 1);
			}
			if (IGKString::EndWith($data,'"'))
				$data = substr($data, 0, strlen($data)-1);
			return $data;
		}
		
	private static function _CSVReadLine($line)
	{
		$tab = array();
		$rtab = explode(igk_csv_sep(), $line);
		$v = false;
		$r = "";
		foreach($rtab as $k=>$i)
		{
			$s = trim($i);
			if ($v == false)
			{
				if (IGKString::StartWith($s, '"'))
				{
					$v = true;
					$r .= substr($s, 1);
				}
				else
					$r .= $i;
			}
			else{
				if (IGKString::EndWith($s, '"'))
				{
				 
					$r .= igk_csv_sep().igk_str_rm_last($s, '"');
					$v = false;
				}
				else
					$r .= igk_csv_sep().$i;
			}
			if ($v==false)
			{
				$tab[] = trim($r);
				$r = "";
			}
		}
		
		return $tab;
	}
	public static function LoadData($filename)
	{
		$txt = IGKIO::ReadAllText($filename);
		return self::LoadString($txt);
	}
	public static function LoadString($txt)
	{
		$lines = explode(IGK_LF, $txt);
		$entries = array();		
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$tab = self::_CSVReadLine($l);
			$entries[] = $tab;								
		}		
		return $entries;
	}
	
	public function selectAll($tbname)
	{
			$this->selectAllFile($dbname);
	}
	public function selectAllFile($tbname)
	{
		
		$f = igk_io_basePath(IGK_DATA_FOLDER)."/".$tbname.".csv";		
		if (file_exists($f))
		{
			$r = IGKCSVQueryResult::CreateEmptyResult();
			$r->AppendEntries(self::LoadData($f), $this->m_ctrl->getDataTableInfo());
			return $r;
		}
		return null;
	}
	public function close()
	{
		if ($this->m_fhandle)
		{
			fclose($this->m_f);
		}
	}
}


final class IGKXMLDataAdapter extends IGKDataAdapter
{
	public function connect(){
	}
	public function close(){
	}
	//load first level config node
	public static function LoadConfig($node)
	{
		if (($node ==null) || (!$node->HasChilds))
			return null;
			
		$t = array();
		
		foreach($node->Childs as $k)
		{
				$t[$k->TagName] = $k->innerHTML;
		}		
		return $t;
	}
	///load data file name of text
	public static function LoadData($filename)
	{
			function __loadData($node)
			{
				if ($node->HasChilds)
					{						
						if ($node->ChildCount == 1)
						{
							 if ($node->Childs[0]->NodeType == XmlNodeType::TEXT){
								return $node->innerHTML;
							 }
							 else{
								$t = array();
								$t[$node->TagName] = __loadData($node);
								return (object)$t;
							 }
						}
						else{
							$t = array();
							foreach($node->Childs as $k)
							{
								
								if (isset($t[$k->TagName]))
								{								
									$v = $t[$k->TagName];
									// if (is_array($v))
									// {
										
										// $v[] = __loadData($k);
									// }
									// else{
										$s = array();
										$s[] = $v;
										$s[] = __loadData($k);
										$t[$k->TagName] = $s;
									// }
								}
								else
									$t[$k->TagName] = __loadData($k);
							}
							return (object)$t;
						}
					}
					return null;
			}
			
			$f = $filename;
			if (is_string($f) == false)
				return null;
			$div = HtmlItem::CreateWebNode("div");
			$s = "";
			if (file_exists($f))
			{
				$s = file_get_contents($f);	
			}
			else{
				$s = $f;
			}			
			
			$div->Load($s);
			
			if ($div->HasChilds)
			{
				$d = $div->getChildAtIndex(0);
				if ($d)
				{
					$t = array();
					foreach($d->Childs as $k)
					{
						$t[$k->TagName] = __loadData($k);
					}					
					return (object)$t;
				}
			}
			return null;
			
	}
	public static function storeData($filename, $data)
	{
		//store configuration data
		$d = HtmlItem::CreateWebNode("config");
		//store
		foreach($data as $k=>$v)
		{
			$d->add($k)->Content = $v;
		}		
		return IGKIO::WriteToFileAsUtf8WBOM(filename, $d->Render());
	}

	public function __construct(){
		
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------
//SYSTEM CONNTROLLER
//-------------------------------------------------------------------------------------------------------------------------------------------

//@@@ USER TO CONFIGURE MySQL DATABASE ACCESS
final class IGKDbCtrl extends IGKConfigCtrlBase
{
	private $m_selectedDb;
	private $m_myadminview;
	private $m_searchtable;	
	
	//init data base
	function initDb(){return null;}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	function pinitSDb()
	{
		$this->initSDb(true);
		igk_navtocurrent();
	}
	//init system data base
	function initSDb($view=true){
		
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($mysql != null)
		{
		
			if ($mysql->connect()  == true){
						
				$r = $mysql->createdb($this->App->Configs->db_name);	
				$mysql->selectdb($this->App->Configs->db_name);
				if (function_exists("InitDb"))
				{
					//global function 
					InitDb();
				}
				else {
					//call init for all controllers
					foreach($this->App->ControllerManager->getControllers() as $k)
					{
						if ($k == $this)
							continue;
						$k->initDb();
					}
				}
			}
			else 
				igk_notifyctrl()->addError(R::ngets("E.DbNotConnected"));
			$mysql->close();			
				
		
		if ($view)
		{
			$this->View();
		}
			
		}
		else{
			igk_notifyctrl()->addError("<ul><li>Can't create a data base manager . reason : ".$this->getDataAdapterName() ." : ".$mysql."<li></ul>");
		
		}
		
	}
	public function getConfigPage(){return "database"; }

	public function View()
	{
	if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);			
			return;
		}
		
		$conf_title = array("class"=> "config_title");
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();		
		
		
		$div = $c->addDiv();
		igk_add_title($div,"title.DataBaseConfigs");
		$div->addHSep();
		igk_add_article($this, "dbdescription", $div, "div", true);
		$div->addHSep();
		
		
		$div = $c->addDiv(array("class"=>"db_info"));
		igk_add_title($div,"title.DataBaseManager");
		$div->addHSep();
			
		
		$div->addDiv()->Content = "DataBase : MySQL";
		$div->addDiv()->Content = "Available : " . igk_parsebool(defined("IGK_MSQL_DB_Adapter"));
		$div->addDiv()->Content = "MySQL : " . igk_parsebool(IGK_MSQL_DB_AdapterFunc);
		$div->addDiv()->Content = "MySQLi : " . igk_parsebool(IGK_MSQLi_DB_AdapterFunc);
		$div->addHSep();
		igk_add_title($div,"title.Config");
		$div->addHSep();
		$div = $div->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("updatedb");
		$frm->addSLabelInput("dbServer", "lb.Server", "text", $this->App->Configs->db_server); $frm->addBr();
		$frm->addSLabelInput("dbUser", "lb.User", "text", $this->App->Configs->db_user); $frm->addBr();
		$frm->addSLabelInput("dbPasswd", "lb.Password","password", null);$frm->addBr();		
		$frm->addSLabelInput("dbName", "lb.dbName","text", $this->App->Configs->db_name);$frm->addBr();	
		$frm->addBtn("btn_update", R::ngets("btn.update"));
		
		
		
		//init form
		$div = $c->addDiv(array("class"=>"db_info"));
		igk_add_title($div,"title.Operations");
		$div->addHSep();
		$frm = $div->add("form", 1);		
		HtmlUtils::AddBtnLnk($frm,  R::ngets("btn.phpmyadmin"), $this->getUri("gotophpmyadmin"), array("onclick"=>"javascript: return true;"));		
		HtmlUtils::AddBtnLnk($frm, "btn.initDb", $this->getUri("pinitSDb"));
		HtmlUtils::AddBtnLnk($frm, "btn.backupdatabase", $this->getUri("backupDb"));
		
		
		
		//get tables
		
		$frm = null;
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		$v_table = null;
		if ($mysql)
		{		
			$mysql->connect();
			$div = $c->addDiv(array("class"=>"db_info"));
			
			try{	
				//for databases  						
				$r = $mysql->sendQuery("Show DataBases;");
				if ($r){
					$this->__showDataBases($r, $div, $conf_title);									
					$div = $div->addDiv();
					HtmlUtils::AddBtnLnk($div , "btn.initDb", $this->getUri("pinitSDb"));					
					HtmlUtils::AddBtnLnk($div , "btn.backupdatabase", $this->getUri("backupDb"));
				}				
			
				//show selected data tables
				if (!empty($this->m_selectedDb))
				{					
					$this->__showSelectedDbTables($c->addDiv(array("class"=>"db_info")), $conf_title);	
				}
				else{
					$c->addDiv(array("class"=>"db_info"))->Content = R::ngets("msg.db.cantshowDataBaseTableNoSelectedDb");
				}
			}
			catch(Exception $ex)
			{
				//only for user
				$d  = $c->addDiv();
				$d->Content = "l'utilisateur \"".$this->App->Configs->db_user."\" n'est pas autoriser à lister les bases de données du serveur \"".$this->App->Configs->db_server."\"";
				
				
				$d->addBr();
				$mysql->selectdb($this->App->Configs->db_name);
				try{
				$r = $this->_getTables($this->m_searchtable);			
				$d->add("div", $conf_title)->Content= $this->App->Configs->db_name ." Tables";
				$d->addHSep();
				$d->add(new HtmlSearchItem($this->getUri("searchtable"), $this->m_searchtable));
				$d->addHSep();
				$frm = $d->addForm();
				$frm["action"]=$this->getUri("tableview");									
				$v_table = $frm->add("table");			
				if ($r && ($r->Rows!=null))
				{
					$v_theader = false;
					foreach($r->Rows as $tab)
					{					
						
						if ($tab)
						{
							if (!$v_theader)
							{
								//write table header
								$v_theader = true;
								$li = $v_table->add("tr");
								HtmlUtils::AddToggleAllCheckboxTh($li);//->Content = IGK_HTML_SPACE;
								$li->add("th", array("class"=>"fitw"))->Content = R::ngets(IGK_FD_NAME);
								$li->add("th")->Content = IGK_HTML_SPACE;
							}
							$tr = $v_table->add("tr");				
							foreach($tab as $k=>$v)
							{			
								
								$s = $v;
								$tr->add("td")->addInput("clTableName[]", "checkbox");
								$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("db_viewtableentries&n=".$s."&from=".$this->App->Configs->db_name)))->Content = $s;					
								$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("droptable&n=".$s."&from=".$this->App->Configs->db_name)))->add("img", 
								array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("info.droptable")))->Content = $s;
							}
						}
					}
					HtmlUtils::AddBtnLnk($frm, "btn.dropalltable", igk_js_ctrl_posturi($this, "dropalltable_ajx"));					
					}
				}
				catch(Exception $ex){
				}		
				igk_html_toggle_class($v_table, "tr");
			}
			$mysql->close();		
			
			
			$this->_showDataBaseBackup($c->addDiv(array("class"=>"db_info")));
		}
	}
	//@@@ $c target node
	private function __showSelectedDbTables($c, $conf_title=null)
	{
		$tab = $this->_getTablesFromSelectedDb($this->m_searchtable);
		
				if (count($tab)>0)
				{
					$div = $c->addDiv();
					$div["id"] = "igkdb_tablelist";
					$div->add("div", $conf_title)->Content= $this->m_selectedDb .".Tables";
					$div->addHSep();
					$div->add(new HtmlSearchItem($this->getUri("searchtable"), $this->m_searchtable));
					
					$frm = $div->addForm();
					$frm["action"] = $this->getUri("db_dropSelectedTable");
					$table = $frm->add("table", array("class"=>"fitw"));
					$tr = $table->add("tr");
					
				
					HtmlUtils::AddToggleAllCheckboxTh($tr);		
					$tr->add("th" , array("class"=>"fitw"))->Content = R::ngets("lb.Name");
					$tr->add("th")->Content = IGK_HTML_SPACE;
					$tr->add("th")->Content = IGK_HTML_SPACE;
					foreach($tab->Rows as $k=>$v)
					{
						$s = $v["Table"];
						$tr = $table->add("tr");
						$tr->add("td")->addInput("tname[]","checkbox", $s);
						$tr->add("td")->add("a", array("href"=>$this->getUri("db_viewtableentries&n=".$s."&from=".$this->m_selectedDb)))->Content = $s;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("db_viewtableentries&n=".$s."&from=".$this->m_selectedDb)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("edit"),"alt"=>R::ngets("tip.editdatabase")))->Content = $s;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("droptable&n=".$s)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("tip.dropdatabase")))->Content = $s;
					}
					$div = $frm->addDiv();
					
					$div->addInput("btn_delselection", "submit", R::ngets("btn.droptableselection"));	
					//HtmlUtils::AddBtnLnk($div, "btn.droptableselection", igk_js_ctrl_posturi($this,"db_dropSelectedTable&dbname=".$this->m_selectedDb ));					
					HtmlUtils::AddBtnLnk($div, "btn.dropalltable", igk_js_ctrl_posturi($this,"dropalltable_ajx"));					
					$frm->addBr();
					
				igk_html_toggle_class($table, "tr");
					
		}
	}
	private function __showDataBases( $r,$c, $conf_title)
	{
				igk_add_title($c,"title.DATABASES");
				$c->addHSep();
				if (!empty($this->m_selectedDb))
				{
					$c->addDiv()->Content= R::ngets("tip.db.selecteddb", $this->m_selectedDb) ;
				}
				else{
					$c->addDiv()->Content = R::ngets("msg.db.cantshowDataBaseTableNoSelectedDb");
				}
				$div = $c->addDiv();
				$frm = $div->add("form", 1);		
				$frm["action"]=$this->getUri("dataview");
				
				$v_table = $frm->add("table");
				$v_theader =false;
				foreach($r->Rows as $tab)
				{
					if (!$v_theader)
					{
							//write table header
							$v_theader = true;
							$li = $v_table->add("tr");	
							HtmlUtils::AddToggleAllCheckboxTh($li);			
							$li->add("th", array("class"=>"fitw"))->Content = R::ngets("clDataBaseName");
							$li->add("th")->Content = IGK_HTML_SPACE;
							$li->add("th")->Content = IGK_HTML_SPACE;
					}
					if ($tab)
					foreach($tab as $k=>$v)
					{
						$tr = $v_table->add("tr");	
						if (strtolower($v) == strtolower($this->App->Configs->db_name))
						{
							if ($this->m_selectedDb==null)
								$this->m_selectedDb = $v;
							$tr["class"] = "+igk-selectdb-row";
						}
						$tr->add("td")->addInput("","checkbox");
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("selectdb&n=".$v)))->Content = $v;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("editdb&n=".$v)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("edit"),"alt"=>R::ngets("tip.editdatabase")))->Content = $v;
						$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("dropdb&n=".$v)))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("tip.dropdatabase")))->Content = $v;
					}					
				}				
				$frm->addBr();
				igk_html_toggle_class($v_table, "tr");
				return $frm;
	}
	
	private function _showDataBaseBackup($frm)
	{	
			$v_dir = igk_io_currentRelativePath(IGK_BACKUP_FOLDER);		
			$bckdiv = $frm->addDiv();
			igk_add_title($bckdiv, "title.Backup");
			$frm->addHSep();
			$v_table = $frm->add("table", array("class"=>"fitw"));
			$v_hasfile =false;
			if (is_dir($v_dir))
			{
			$hdir = opendir($v_dir);
			$v_theader = false;//has table header
				while( ($f = readdir($hdir)))
				{
					if (($f==".") ||($f == ".."))
						continue;
						if (!$v_theader){
							$v_theader = true;
							$li = $v_table->add("tr");
							HtmlUtils::AddToggleAllCheckboxTh($li);	
							$li->add("th")->Content = R::ngets(IGK_FD_NAME);
							$li->add("th")->Content = IGK_HTML_SPACE;
							$li->add("th")->Content = IGK_HTML_SPACE;
						}
						
					$li = $v_table->add("tr");
					$li->add("td")->addInput("","checkbox");
					$li->add("td")->add("a", array("href"=>$this->getUri("downloadbackupfile&file=".$f)))->Content = $f;
					HtmlUtils::AddImgLnk($li->add("td", array( "class"=>"igk-table-img-action_16x16")), $this->getUri("dbRestore&file=".$f), "db_restore_16x16");
					HtmlUtils::AddImgLnk($li->add("td", array( "class"=>"igk-table-img-action_16x16")),$this->getUri("dropBackup&file=".$f), "drop","16px","16px", "lb.dropbackup");
					$v_hasfile = true;
					//$li->add("td")->add("a", array("href"=>$this->getUri("dropBackup&file=".$f)))->add("img"=>Content = $f;
				}
				closedir($hdir);
				
				if ($v_hasfile){			
				HtmlUtils::AddBtnLnk($frm, "btn.ClearBackup", $this->getUri("clearBackup"));
				}
				else{
					$frm->addDiv()->Content = R::ngets("Msg.NoBackgup");
				}
			}
			
			igk_html_toggle_class($v_table, "tr");
	}
	public function editdb()
	{
		$this->View();
	}
	public function searchtable(){
		$q = igk_getr("q");		
		$this->m_searchtable = $q;
		$this->View();
	}
	public function dropalltable_ajx($dbname=null)
	{		
		if (igk_qr_confirm())
		{
			$r = $this->_getTables($this->m_searchtable);
			$db = $dbname? $dbname: $this->App->Configs->db_name;
			if ($r->Rows){
				$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
				if ($mysql)
				{
					$mysql->connect($db);
					
					foreach($r->Rows as $t)
					{
						$s = $mysql->sendQuery("Drop Tables `".$t["Table"]."`;");
					}
					$mysql->close();
				}
			}
			$this->View();
			$this->TargetNode->RenderAJX();			
		}
		else{
			$frame = igk_add_confirm_frame($this, "drop_all_table_confirm_frame",$this->getUri("dropalltable_ajx"));
			$frame->Form->Div->Content = R::ngets(IGK_DELETEALLTABLE_QUESTION);
			$frame->RenderAJX();
		}
	}
	
	private function _getTablesFromSelectedDb( $searchkey = null)
	{
		if (empty($this->m_selectedDb))
			return;
			
		$r = null;
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($mysql)
		{
			$mysql->connect($this->m_selectedDb);		
			$r = $mysql->sendQuery("Show Tables;");
			$tab = $r->CreateEmptyResult($r);		
			$mysql->close();

			$n = $r->Columns[0]->name;			
			if ($searchkey !=null)
			{			
				$q = strtolower($searchkey);
				foreach($r->Rows as $t)
				{
					if (strstr(strtolower($t->$n), $q))
					{
						$tab->addRow(array("Table"=>$t->$n));	
					}
				 }
				return $tab;
			}
			else{
				foreach($r->Rows as $t)
				{	
					$tab->addRow(array("Table"=>$t->$n));						
				}
				return $tab;			
			}
		}
		return null;
	}
	
	private function _getTables($searchkey = null)
	{
		$r = null;
		
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($mysql)
		{
			
			$mysql->connect($this->App->Configs->db_name);
			$r = $mysql->sendQuery("Show Tables;");
			$tab = $r->CreateEmptyResult($r);		
			$mysql->close();

			$n = $r->Columns[0]->name;			
			if ($searchkey !=null)
			{			
				$q = strtolower($searchkey);
				foreach($r->Rows as $t)
				{
					if (strstr(strtolower($t->$n), $q))
					{
						$tab->addRow(array("Table"=>$t->$n));	
					}
				 }
				return $tab;
			}
			else{
				foreach($r->Rows as $t)
				{	
					$tab->addRow(array("Table"=>$t->$n));						
				}
				return $tab;			
			}
		}
		return null;
	}
	
	public function backupDb(){
			
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if (!$mysql)
		{ 
			igk_notifyctrl()->addError("can't get ".IGK_MYSQL_DATAADAPTER ." data adapter");
			return;
		}
		$adapter = IGKDataAdapter::CreateDataAdapter("CSV");
		if (!$adapter)
		{ 
			igk_notifyctrl()->addError("can't get csv adapter");
			return;
		}
		
		$v_date = igk_date_now("Ymd_his"); 
		$v_file = igk_io_currentbasepath(IGK_BACKUP_FOLDER."/backup_".$v_date.".cvs");
		$out = "";
	
		$db_table = $this->_getTables(null);
		$mysql->connect();
		if ($db_table){			
			foreach($db_table->Rows as $t=>$v)
			{
				
				$v_tbname = $v["Table"];
				
				$r = $mysql->sendQuery("SELECT * FROM `".$v_tbname."`;");
				if ($r){
					$out .= $v_tbname .IGK_LF;
					$v_sep = false;
					$out .= $adapter->toCSVLineEntry($r->Columns, "name").IGK_LF;
					if ($r->Rows){
						
						foreach($r->Rows as $e)
						{
							$out .=$adapter->toCSVLineEntry($e).IGK_LF;													
						}
					}
					else 
						igk_debug("notice: no data row for [".$v_tbname."]");
					$out .= IGK_LF;
				}
				else{
					igk_debug("error: mysql adapter failed");
					igk_debug($r);
					igk_notifyctrl()->addMsgr("Error.Config");
				}
			}
		}
		else{
			igk_debug("error: no table");							
			igk_notifyctrl()->addMsgr("Msg.NoTable");
		}
		
		IGKIO::CreateDir(dirname($v_file));
		if (strlen($out) > 100000)
		{
			//zip file
			igk_zip_content($v_file.".zip", basename($v_file),  $out);
		}
		else{
			igk_io_save_file_as_utf8($v_file, $out, true,0666);		
		}
		$this->View();
		igk_notifyctrl()->addMsgr("Msg.DataBaseSaved");
		igk_navtocurrent();
	}
	private function __restoredb($table, $header, $definition)
	{
		$adapt =IGKDataAdapter::CreateDataAdapter("MYSQL");
		if ($adapt!=null)
		{
			$dbname = $this->App->Configs->db_name;
			$adapt->connect($dbname);
			$e = $adapt->select($table);			
			$tentries = array();
			if ($e){
			foreach($definition as $row){
				$tab = array();
				$i = 0;
				foreach($e->Columns as $k=>$v)
				{
					if ($i < $e->ColumnCount)
					{
						$tab[igk_getv($v,"name")] = igk_getv($row, $i);
						$i++;
					}
					else
						break;
				}
				$tentries[] = $tab;
				$q = IGKQueryUtils::GetInsertQuery($table, $tab);
				
				if ($adapt->sendQuery($q, false)==null)
				{
					igk_notifyctrl()->addError("error Append in query ".$q);
				}				
				
			}
			}
			$adapt->close();
		}
	}
	public function dbRestore()
	{
		$v_f = igk_getr("file");
		if (igk_qr_confirm() && $this->App->ConfigMode)
		{
			//igk_notifyctrl()->addMsg("la restauration n'est pas implementer");
			$v_file = igk_io_currentbasepath(IGK_BACKUP_FOLDER."/".$v_f);
			if (!file_exists($v_file))
				igk_notifyctrl()->addErrorr("Msg.noDataToRestore");
			else{					
			
			$e = IGKCSVDataAdapter::LoadData($v_file);
			
			$table = null;
			$definition = null;
			$header = null;
				foreach($e as $k=>$v)
				{
					if (igk_count($v) == 1)
					{
						if ( ($table!=null) && ($definition!=null))
						{
							$this->__restoredb($table, $header, $definition);
						}
						$table = $v[0];
						$definition = array();
						$header = null;
					}
					else {
						if ($header ==null)
							$header = igk_array_tokeys($v);
						else
							$definition[] = $v;
					}
				}
				
				if ( ($table!=null) && ($definition!=null))
				{
					$this->__restoredb($table, $header, $definition);
				}
			}
			$this->View();
		}
		else 
		{
			$frame = igk_add_confirm_frame($this, "confirm_restoration", $this->getUri("dbRestore"));
			$frame->Form->Div->Content = R::ngets(IGK_MSG_RESTOREBACKUPFILE_QUESTION, $v_f);
			$frame->Form->addInput("file","hidden", $v_f);
		}
		
	}
	
	public function downloadbackupfile(){
		$v_file = igk_getr("file");
		$v_f = igk_io_currentRelativePath(IGK_BACKUP_FOLDER."/".$v_file);
		if (file_exists($v_f)){
			igk_download_file(basename($v_f), $v_f);
		}
		else{
			igk_notifyctrl()->addError("file not present");
		}
	}
	
	public function dropBackup(){
	
		$v_file = igk_getr("file");
		if (igk_qr_confirm()){
			$v_f = igk_io_currentRelativePath(IGK_BACKUP_FOLDER."/".$v_file);
			unlink($v_f);
			$this->View();
			igk_navtocurrent();
		}
		else{
				$frame = igk_add_confirm_frame($this, "confirm_clear_backup_file", $this->getUri("dropBackup"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEABACKUPFILE_QUESTION, $v_file);
				$frame->Form->addInput("file","hidden", $v_file);
		}
	}
	
	public function clearBackup(){
		if (igk_qr_confirm()){
			$v_dir = igk_io_currentRelativePath(IGK_BACKUP_FOLDER);
			IGKIO::RmDir($v_dir);
			$this->View();
			igk_navtocurrent();
		}
		else{
				$frame = igk_add_confirm_frame($this, "confirm_clear_backup_file",$this->getUri("clearBackup"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEALLDATABASEBACKUP_QUESTION);
		}
	}
	
	public function selectdb(){
		$this->m_selectedDb = igk_getr("n");
		$this->View();
		igk_navtocurrent("/#igkdb_tablelist");
	}

	public function gotophpmyadmin(){
	if ($this->m_myadminview )
	{
		$h = $this->App->Configs->db_server;
		
		switch(strtolower($h))
		{
			case "127.0.0.1":
			case "localhost":
				if ($_SERVER["SERVER_ADDR"] != "::1")
					$h = $_SERVER["SERVER_ADDR"];
				break;
		}
		igk_html_rm($this->m_myadminview);
		unset($this->m_myadminview);
		$this->m_myadminview = null;
		header("Location: http://".$h."/phpmyadmin");
		exit;
	}
		else{
			$this->m_myadminview = $this->ConfigNode->add("script");
			$uri = $this->getUri("gotophpmyadmin");
			$this->m_myadminview->Content = <<<EOFF
var w = window.open('$uri', 'phpmyadmin');
w.opener.focus();
EOFF;
			
		igk_navtocurrent();
		}
	}
	
	public function updatedb(){
	
		$server= igk_getr("dbServer");
		$user= igk_getr("dbUser");
		$pwd = igk_getr("dbPasswd");
		$dbname = igk_getr("dbName");
		
		$this->App->Configs->db_server = $server;
		$this->App->Configs->db_user = $user;
		$this->App->Configs->db_pwd = $pwd;
		$this->App->Configs->db_name = $dbname;
		
		igk_save_config();
		igk_resetr();
		$this->View();
		igk_navtocurrent();
		exit;
	}
	
	public function dropdb(){
		$n = igk_getr("n");
		if ($n != null)
		{
				$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
				$mysql->connect();
				$r = $mysql->sendQuery("Drop DataBase `".$n."`;");
				$mysql->close();				
		}
		$this->View();
		igk_navtocurrent();		
		exit;
	}
	
	public function droptable($dbname=null, $table=null){
	
		$n = igk_getr("n", $table);
		if (igk_qr_confirm()){
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if (!$mysql )
			return;
		$dbname = igk_getr("from", $dbname);		
		
		$mysql->connect($dbname);
		$r = $mysql->sendQuery("Drop Table `".$n."`;");
		$mysql->close();				
		$this->View();
		igk_navtocurrent("#igkdb_tablelist");
		exit;
		}
		else{
			$frame = igk_add_confirm_frame($this, "confirm_drop_table", $this->getUri("droptable"));
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETESINGLETABLE_QUESTION, $n);
			$frame->Form->addInput("n","hidden",$n);
		}
	}
	//view table entries
	public function db_viewtableentries($dbname=null, $table=null, $navigate=true)
	{
		$tb = $table?$table:igk_getr("n");
		$db = $dbname==null? igk_getr("from"):$dbname;
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if (!$mysql )
			return;
		$mysql->connect($db);
		$r = $mysql->selectAll($tb);		
		$frame = igk_add_new_frame($this, "db_view_entries", "#igkdb_tablelist");
		$frame->Title = R::ngets("title.db_viewtableentries");
		$frame->ClearChilds();
		$div = $frame->Content->addDiv();
		$div["class"]="igk_db_tableentries";
		$title = $div->addDiv();
		$div->addHSep();
		$title["style"]="height:32px;";
		$content = $div->addDiv();
		$content["style"]="overflow:auto;";
		$title->Content = R::ngets("title.TableInfo", $db.".".$tb);
		
		$table = $content->add("table");
		$table["class"]="fitw";
		$table["style"]= "border:1px solid black";
		$tr = $table->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$pkey  = null;
		$pkname = null;
		
		
		foreach($r->Columns as $k)
		{
			$td = $tr->add("th");	
			$td->Content = $k->name;
			if (($pkey == null) && $k->primary_key==1){
				$pkey = $k->name;
			}
		}
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($r->Rows as $k)
		{
			$tr = $table->add("tr");	
			$tr->add("td")->Content = IGK_HTML_SPACE;
			foreach($k as $e=>$v)
			{
				$tr->add("td")->Content = $v;
			}
			
			HtmlUtils::AddImgLnk($tr->add("td"), igk_js_post_frame($this->getUri("db_edit_entry_ajx&n=".$k->$pkey."&s=".$pkey)), "edit");
			HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("db_drop_entry&n=".$k->$pkey."&s=".$pkey), "drop");
		}		
		$div->addHSep();
		
		$this->setParam("db:dbname", $db);
		$this->setParam("db:table", $tb);
		$this->setParam("db:r", $r);
		$this->setParam("db:columns", $r->Columns);
		//options
		$cdiv = $div->addDiv();
		HtmlUtils::addImgLnk($cdiv, $this->getUri("db_insert_db_entry_frame"), "add");
		HtmlUtils::addImgLnk($cdiv, $this->getUri("db_clearall_db_entry"), "drop");
		
		HtmlUtils::AddBtnLnk($div, R::ngets("btn.close"), $frame->CloseUri);
		HtmlUtils::ToggleTableClassColor($table, "tr");		
		
		$this->View();		
		$mysql->Close();
		if ($navigate){
		igk_navtocurrent();
		exit;
		}
	}
	
	public function db_update_entry()
	{
		if(!$this->ConfigCtrl->IsConnected)
			return;
			
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		$n = $this->getParam("update:n");
		$s = $this->getParam("update:s");
			$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($mysql )
		{
			$o = igk_getr_obj();
			$mysql->connect($dbname);
			$q = IGKQueryUtils::GetUdpateQuery($table, $o, " `".mysql_escape_string ($s)."`='". mysql_escape_string ($n)."'");			
			$mysql->sendQuery($q);
			$mysql->close();
		}
		igk_frame_close("edit_entry_frame");	
		$this->db_viewtableentries($dbname, $table);
			
	}
	public function db_edit_entry_ajx()
	{
		
		$n = igk_getr("n");
		$s = igk_getr("s");
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		
		$frame = igk_add_new_frame($this,"edit_entry_frame");
		$frame->Title  = R::ngets("title.db_editentry");
		$frame->Content->Clear();
		
		
		
		$frm = $frame->Content->addForm();
		$frm["action"] = $this->getUri("db_update_entry");; 
		$this->setParam("update:n",$n);
		$this->setParam("update:s",$s);
		
		$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($mysql )
		{
			$mysql->connect($dbname);
			$q = "SELECT * FROM `".$table."` WHERE `".mysql_escape_string ($s)."`='". mysql_escape_string ($n)."'";
			
			$e = $mysql->sendQuery($q);			
			if ($e->RowCount == 1)
			{
				$ul = $frm->add("ul");
				
				$l = $e->getRowAtIndex(0);
				foreach($e->Columns as $k)
				{
					$li = $ul->add("li");	
					$v = $k->name;
					switch(strtolower($k->type))
					{
						case "text":
							break;
						case "string":
							$li->addSLabelInput($k->name, $k->name, "text", $l->$v);
							break;
						case "blob":
							$t = $li->addSLabelTextarea($k->name, $k->name, array("class"=>"-cltextarea"));
							$t[1]->Content = $l->$v;
							break;
						default:
							$li->addSLabelInput($k->name, $k->name,"text",  $l->$v);
							break;
					}								
				}
			}			
			$mysql->close();
		}
		$frm->addHSep();
		$frm->addInput("btn_update", "submit", R::ngets("btn.update"));
		
		igk_wl($frame->Render());
	}
	public function db_dropSelectedTable($dbname=null)
	{	
		//grand access if connected
		if(!$this->ConfigCtrl->IsConnected)
			return;		
		$db = $dbname? $dbname: $this->App->Configs->db_name;			
		
		
		if (igk_qr_confirm())
		{
				if ($db == null)
				{
					igk_wln("no db name selected");
					return;
				}
				$h = null;
				
				$mysql = IGKDataAdapter::CreateDataAdapter($this, true);
				if (!$mysql )
					return;
				$query = $this->getParam("db:dropSelectedTable");
				$h = igk_getv($query, "tname");				
				$mysql->connect($db);
				if ($h){
					foreach($h as $k=>$v)
					{
						try{
							$r = $mysql->sendQuery("Drop Table `".$v."`;");						
						}
						catch(Exception $ex)
						{
							igk_wln(" error ".$ex);
						}
					}
				}
				$mysql->close();				
				$this->setParam("frame:tname", null);				
				$this->View();	
				$this->getParam("db:dropSelectedTable",null);
		}
		else{
				$frame = igk_add_confirm_frame($this, "confirm_clear_backup_file", $this->getUri("db_dropSelectedTable"));
				$frame->Form->Div->Content = R::ngets("Q.DELETEALLSELECTEDDBTABLE");					
				$frame->Form->addInput("dbname", "hidden", $dbname);
				$this->setParam("db:dropSelectedTable", $_REQUEST);
				
		}
		igk_navtocurrent();
	}
	

	public function db_drop_entry()
	{
		$n = igk_getr("n");
		$s = igk_getr("s");
		$dbname = $this->getParam("db:dbname");
		$table = $this->getParam("db:table");
		
			$db = IGKDataAdapter::CreateDataAdapter($this, true);
			if ($db)
			{
			$db->connect();
			$db->selectdb($dbname);
			//delete
			$db->delete($table, array($s=>$n));			
			$db->close();
			}	
		
		$this->db_viewtableentries($dbname, $table);
		
	}
	public function db_insert_db_entry()
	{
		$r = $this->getParam("db:r");
		$dbname = $this->getParam("db:dbname");
		$n = $this->getParam("db:table");
		
		$b = igk_getr_obj();		
		
		$db = IGKDataAdapter::CreateDataAdapter($this, true);
		if ($db){
			$db->connect();
			$db->selectdb($dbname);
			//insert db entry
			$db->Insert($n, (array)$b);
			$db->close();
		}	
		$this->db_viewtableentries($dbname, $n);
	}
	public function db_insert_db_entry_frame(){
		$frame = igk_add_new_frame($this, "db_insert_entry_frame");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.db.insertnewentry");								
		$d = $frame->Content;
		$frm = $d->addForm();		
		$frm["action"]= $this->getUri("db_insert_db_entry");
		
		$ul  = $frm->add("ul");
		$c = $this->getParam("db:columns");
		if ($c){
			foreach($c as $k)
			{
				$li = $ul->add("li");	
				switch(strtolower($k->type))
				{
					case "text":
						break;
					case "string":
						$li->addSLabelInput($k->name, $k->name, $k->def);
						break;
					case "blob":
						$li->addSLabelTextarea($k->name, $k->name, array("class"=>"-cltextarea"));
						break;
					default:
						//igk_wln($k->type);
						$li->addSLabelInput($k->name, $k->name, $k->def);
						break;
				}				
			}
		
		}
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.add"));
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.close"), $frame->CloseUri);
		
	}
	public function db_clearall_db_entry()
	{
		$r = $this->getParam("db:r");
		$dbname = $this->getParam("db:dbname");
		$tbname= $this->getParam("db:table");
		//$n = igk_getr("confirm");
		if (igk_qr_confirm())
		{
			$db = IGKDataAdapter::CreateDataAdapter($this, true);
			if ($db){
			$db->connect();
			$db->selectdb($dbname);
			//delete all entries
			$db->deleteAll($tbname);
			$db->close();
			}	
			$this->db_viewtableentries($dbname, $tbname);
		}
		else{			
			$frame = igk_add_confirm_frame($this, "frame_clearall",$this->getUri("db_clearall_db_entry"));							
			$frame->Form->Div->Content = R::ngets("Q.WILLYOUDROPTHECONTENTOFTHISTABLE", $tbname);				
		}		
		
	}


	
}
//-----------------------------------------------------------------------------
///represent a language language controller
//-----------------------------------------------------------------------------
final class IGKLangCtrl extends IGKConfigCtrlBase
{
	private $m_searchkey;
	private $m_changeState;
	private $m_search_new_key;
	const DEFAULTLANG = "Default/Lang/lang.";
	
	public function getName(){return IGK_LANG_CTRL;}
	
	public function functionIsAvailable($funcName)
	{
		switch($funcName)
		{
			case "getlangkeys":			
				return true;
		}
		return parent::functionIsAvailable($funcName);
	}
	//publid function to get current languages file
	public function getlangkeys(){
	
		$format = igk_getr("format", "xml");
		$v_node = HtmlItem::CreateWebNode("languages");
		switch($format)
		{
			case "xml":
				header("Content-Type: application/xml");
				break;
		}
		$v_node["name"] = R::GetCurrentLang();
		$tab = R::GetLangInfo();
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		$c = 0;
		//return;
		foreach($ktab as $k)
		{
			$v = $tab[$k];
		
			$tr = $v_node->add("item");
			$tr["name"] = igk_parsexmlvalue($k);
			$tr["value"] = igk_parsexmlvalue($v);
		}
		igk_wl($v_node->Render());
		exit;
	
	}
	//get defaut saved file
	private function get_savefile()
	{
		return igk_io_currentbasePath("Data/".self::DEFAULTLANG.R::GetCurrentLang().".resources");
	}
	public function __construct(){
		parent::__construct();
	}
	public function InitComplete()
	{
		parent::InitComplete();
		R::getInstance()->LangChangedEvent->add($this, "View");
		R::getInstance()->KeysAdded->add($this, "keyAdded");	
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onLangChanged");		
		$this->App->Doc->lang = R::GetCurrentLang();
	}
	public function keyAdded($obj, $key)
	{	
		$v = $this->getParam("lang:onview");
		if (!$v){
			if (!empty($key))
			{
				$this->View();
			}
			else 
				throw new Exception("try to add empty key");
		}
	}
	public function onLangChanged($ctrl)
	{		
		$r = R::getInstance();
		$c =  $r->langChangedConf;
		if ($ctrl->isChanged("LangChanged", $c))
		{	
			$this->reloadlang();
		}
	}
	public function add_key()
	{
		igk_wln("key added");
		$n = igk_getr("clname");
		$v = igk_getr("clvalue");
		if (!empty($n))
		{
			R::AddLang($n, $v);
			R::SaveLang();
		}
		igk_navtocurrent();
	}
	public function add_key_frame()
	{
		$frame = igk_add_new_frame($this, "add_key_frame");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.editLangkeyframe");								
		$d = $frame->Content;
		$frm = $d->addForm();		
		$frm["action"]= $this->getUri("add_key");
		$ul  = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clname", "lb.name");
		$ul->add("li")->addSLabelInput("clvalue", "lb.value");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.add"));
		
	}
	public function reloadlang()
	{	
		R::LoadLang();
		$this->View();
	}
	public function get_new_keys(){
		$this->m_search_new_key = !($this->m_search_new_key);
		$this->View();
		igk_navtocurrent();
	}
	private function loadLangOptions($c)
	{	 
		HtmlUtils::AddBtnLnk($c, R::ngets("btn.add"),$this->getUri("add_key_frame"));		
		HtmlUtils::AddBtnLnk($c, R::ngets("btn.searchnewkey"),$this->getUri("get_new_keys"));		
		HtmlUtils::AddBtnLnk($c, R::ngets("btn.reload"), $this->getUri("reloadlang"));
		HtmlUtils::AddBtnLnk($c, R::ngets("btn.restoredefault"), igk_js_post_frame($this->getUri("lang_load_default")));
	}
	public function View()
	{
		$this->setParam("lang:onview",true);
		$this->App->Doc->lang = R::GetCurrentLang();
		$c = $this->TargetNode;
		$c->ClearChilds();
		if ( !$this->IsVisible)
		{
			igk_html_rm($c);
			return;
		}	
		igk_html_add($c, $this->ConfigNode);
		$c->Index = 100;		
		$div = $c->addDiv();		
		igk_add_title($div, "title.language.ctrlconfig");
		$div->addHSep();
		igk_add_article($this, "language.description",$div->addDiv());
		
		$div = $c->addDiv();
		$div["style"]="margin:16px 0px 16px 0px;";
		$div->addHSep();
		
		$frm = $div->addForm();
		$languages = $frm->add("ul");
		$languages["class"] = $languages["id"] = "igk_language_list";
		
		foreach(igk_getctrl(IGK_LANGUAGE_CTRL)->Languages as $k=>$v)
		{
			$languages->add("li")->add("a", array("href"=>"?l=".$v))->add("img", array(
			"style"=>"border:1px solib #a1a1a1;",
			"src"=>"?vimg=flag_".$v, "width"=>"16px"));
		}
		//add new lang button 
		HtmlUtils::AddImgLnk($frm, igk_js_post_frame($this->getUri("lang_add_new_frame_ajx")), "add");
		$div->addHSep();
		
		//search key button
		$c->add(new HtmlSearchItem($this->getUri("searchkey"), $this->m_searchkey));
		$c->addHSep();
		$this->loadLangOptions($c);
		$c->addBr();
		
		
		$frm = $c->addForm();		
		$frm["action"]= $this->getUri("update_language");		
		$frm["method"]="POST";
		$frm["id"]="frm_langkeys_view";
		
		$d  = $frm->addDiv();	
		$d["class"]="dispb fitw alignc";
		igk_add_loading_frame($d);
		$frm->addScript()->Content = "(function(q){window.igk.ajx.post('".$this->getUri("lang_getKeys_ajx")."',null,function(xhr){ if (this.isReady()){ this.setResponseTo(q); }}, false);})(igk.getParentScript());";		
		$this->setParam("lang:gui_langview", $frm);
		
		$c->addHSep();
		$this->loadLangOptions($c);
		
		$this->setParam("lang:onview",null);
	}
	public function lang_add_new_frame_ajx()
	{
		$frame = igk_add_new_frame($this, "add_lang_frame");
		$frame->Title = R::ngets("title.AddNewLang");		
		$frame->ClearChilds();				
		$frm = $frame->Content->addForm();
		$frm["action"]= $this->getUri("lang_add_lang"); 
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clKey", "lb.langkey");
		$ul->add("li")->addSLabelInput("clFile", "lb.picturefile","file");
		$frm->addHSep();
		$frm->addInput("btn_submit","submit" ,R::ngets("btn.add"));
		igk_wl($frame->Render());
		return $frame;
	}
	public function lang_add_lang()
	{
		$f = igk_getv($_FILES, "clFile");
		$c = igk_getr("clKey");
		igk_getctrl(IGK_LANGUAGE_CTRL)->addLang($c);
		
		if ($f["size"]> 0)
		{
			loadtempfile($f["tmp_name"], $f["name"], "flag_".c, "Flags");
		}
		$this->View();		
		igk_navtocurrent();
	}
	public function lang_getKeys_ajx()
	{		
		$frm = $this->getParam("lang:gui_langview");
		$frm->ClearChilds();
		if ($this->m_search_new_key)
		{
			$frm->addDiv()->Content = R::ngets("msg.yourfindkeykey");
		}
		$table = HtmlItem::CreateWebNode("table");
		$table["class"]="listlangentry fitw";
		$frm->add($table);
		
		$tr = $table->add("tr");
		$tr["class"]="tbh";
	 HtmlUtils::AddToggleAllCheckboxTh($tr);
	 
	 
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>"fitw"))->Content = R::ngets("Value");
		$tr->add("th")->Content = "&nbsp;";
		$i = 0;
		$tab = R::GetLangInfo();
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		$c = 0;
		//return;
		foreach($ktab as $k)
		{
			$v = $tab[$k];
			if ($this->m_search_new_key)
			{
				if (empty($k) || (($this->m_searchkey) && !strstr(strtolower($k),strtolower($this->m_searchkey))) || 
				( strtolower($v) != strtolower($k)))
					continue;				
			}
			else{
		if (empty($k) || (($this->m_searchkey) && !strstr(strtolower($k),strtolower($this->m_searchkey))) )
			continue;
			}
		
			$tr = $table->add("tr");
			
			$tr->add("td")->addInput("check_values_".$c, "checkbox");
			$tr->add("td")->add("label",array("for"=>"e_values".$c, "class"=>"-cllabel"))->Content = $k;
			$td = $tr->add("td");
			$td->add("input", array("type"=>"text", "class"=>"cltext" , "value"=>$v,"name"=>"e_values[]", "id"=>"e_values".$c ));
			
			$tr->add("input", array("type"=>"hidden","value"=>$k,"name"=>"e_keys[]", "id"=>"e_keys[]" ));
			//$tr->add("td")->Content = "&nbsp;";
			$tr->add("td")->add("li")->add("a", array("href"=>$this->getUri("rmkey&n=".base64_encode($k))))->add("img", 
						array("width"=>"16px","height"=>"16px", "src"=>R::GetImgUri("drop"),"alt"=>R::ngets("info.droptable")))->Content = $v;
				
			$c++;
		}
		
		$frm->add(HtmlUtils::nInput("btn_update", R::ngets("btn.update"), "submit"));
		$frm->addSpace();
		HtmlUtils::ToggleTableClassColor($table, "tr",1);
		HtmlUtils::AddBtnLnk($frm ,R::ngets("btn.rmAll"), $this->getUri("clearall"), array(
			"onclick"=>"javascript: var frm =igk.getParentByTagName(this,'form');    if ( frm && window.confirm('Etes vous sure de vouloir tout supprimer?')) {frm.confirm.value = 1; frm.action =this.href ; frm.submit(); }return false;"
		) );
		$frm->addInput("max_values", "hidden",$c);	
		$frm->addInput("confirm", "hidden",0);	
		$frm->addSpace();
		$frm->addInput("btn_rmsel", "submit",R::ngets("btn.rmSelection"), array("onclick"=>"this.form.action ='".$this->getUri("removeselectedmenu")."'; "));		
		HtmlUtils::AddBtnLnk($frm ,R::ngets("btn.restoredefault"), igk_js_post_frame($this->getUri("lang_load_default")));
		HtmlUtils::AddBtnLnk($frm ,R::ngets("btn.saveAsdefault"), $this->getUri("lang_save_as_default"));
		igk_wl($frm->Render());
	}
	///remove selected items
	public function removeselectedmenu()
	{
		$m = igk_getr("max_values", 0);
		$keys = igk_getr("e_keys", null) ;
		$mc = 0;
		//get the reference of the tab control
		$tab = & R::getInstance()->langRes;
		
		$before = count($tab);
		for($i = 0; $i< $m; $i++)
		{
			$t = igk_getr("check_values_".$i);
			if ($t)
			{
					$n =$keys[$i];
					//igk_wln("echo : ".$n . " : ". $tab[$n]);
					if (R::RemoveKey($n))
					{
						$mc++;
					}
			}
		}
		$after = count($tab);
		
		if (R::SaveLang())
		{
			igk_notifyctrl()->addMsg("delete selected value ".$mc .":".$before. " / ".$after ."/".count( R::getInstance()->langRes));				
		}
		else{
			igk_notifyctrl()->addErrorr("E.LangNotSave");
		}
		//$this->View();
		
	}
	public function lang_load_default()
	{
		if (igk_qr_confirm())
		{
		$file = $this->get_savefile();
		if (file_exists($file))
		{
			$v = R::getInstance();	
			copy($file, $v->_getlangpath());
			$v->LoadLang();
			$this->View();
		}
		if (!igk_sys_isAJX())
		igk_navtocurrent();
		}
		else{
			  $frame = igk_add_confirm_frame($this, "frame_restore_defaultlang",$this->getUri("lang_load_default&ajx=1"));							
			$frame->Form->Div->Content = R::ngets("Q.AREUSHURETORESTOREDEFAULTLANG");				
			if (igk_sys_isAJX())
			{
				igk_wl($frame->Render());
				exit;
			}
		}
	}
	public function lang_save_as_default()
	{
		$file = $this->get_savefile();
		
		$v = R::getInstance();		
		$out = "<?php \n";	
		$tab = $v->langRes;
		$ktab = array_keys($tab);
		igk_usort($ktab, "igk_key_sort");
		foreach($ktab as $k)
		{
			$v = $tab[$k];
			$v = str_replace("\'", "'", str_replace("\"", "&quot;",$v));
			if (!empty($k))
			{
				$out .= "R::AddLang(\"$k\", \"".$v."\"); \n"; 			
			}
		}
		$out .= "?>";
		IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);	
		igk_notifyctrl()->addMsgr("MSG.SaveLangFileOK", basename($file));
		$this->View();
		igk_navtocurrent();
	}
	public function clearall(){
		if (igk_qr_confirm()){
			R::ClearLang();
			$this->View();
		}
		else{
			    $frame = igk_add_confirm_frame($this, "frame_clearall",$this->getUri("clearall"));							
				$frame->Form->Div->Content = R::ngets("Q.AREUSHURETODELETEALL");				
			
		}
	}
	public function update_language(){
	
		if (igk_getr("btn_rmsel")!=null) { $this->removeselectedmenu(); return;}
	
		$td = igk_getr("e_keys", null);
		$tv = igk_getr("e_values", null);
		
		
		
		if(is_array($td))
		{
			foreach($td as $k=>$v)
			{
				R::AddLang($v, $tv[$k]);
			}
		}
		if (R::SaveLang())
		{
			igk_notifyctrl()->addMsgr("msg.languageupdated");
		}
		else{
			igk_notifyctrl()->addErrorr("E.LanguageNotupdated");
		}
		igk_navtocurrent();	
	}
	
	public function searchkey()
	{
		$this->m_searchkey = igk_getr("q");
		$this->View();
	}
	public function searchkey_ajx(){
		$this->searchkey();
		igk_wl( $this->TargetNode->Render());
	}
	
	public function getConfigPage(){return "langconfig"; }
	
	public function rmkey()
	{
		$n = base64_decode( igk_getr("n"));
		R::RemoveKey($n);
		R::SaveLang();
		$this->View();
		igk_navtocurrent();
	}
}

//@@@ represent the load data manager
final class IGKLanguageCtrl extends IGKControllerBase
{
	const DATAFILE = "Data/languages.csv";
	private $m_languages;
	
	public function getLanguages(){
		return $this->m_languages;
	}
	public function getName(){
		return IGK_LANGUAGE_CTRL;
	}
	public function __construct()
	{
		parent::__construct();
		$this->m_languages = array();
		$this->_loadData();
	}
	public function getLangRegex()
	{
		$o = "(";
		$i = 0;
		foreach($this->m_languages as $k)
		{
			if ($i ==1)
				$o.="|";
			$o.= $k;
			$i=1;
		}
		$o.=")";
		return $o;
	}
	private function _loadData()
	{
		$r = IGKCSVDataAdapter::LoadData(igk_io_syspath(self::DATAFILE));
		if ($r)
		{
			$this->m_languages = array();
			foreach($r as $l)
			{		
				$this->m_languages[$l[0]] = $l[0];
			}
		}
	}
	public function addLang($n)
	{
		if (!empty($n) && !isset($this->m_languages[$n]))
		{
			$this->m_languages[$n] = $n;
			$out = "";
			foreach($this->m_languages as $k=>$v){
				$out .= $v."\n";
			}
			IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $out,true);
			
		}
	}
	public function View(){
		//do nothing
	}
	public function initComplete(){
		parent::initComplete();		
	}
	public function getDataAdapterName()	{return "CSV";}
	public function initDb()
	{	
	$content = <<<EOF
fr,
en,
nl
EOF;
		IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $content,true);
		$this->_loadData();
	}
}


///<summary>
///used to configure layout controller list
///</summary>
final class IGKLayoutCtrl extends IGKControllerBase
{
	private $m_currentLayout;
	
	public function getCurrentLayout(){return $this->m_currentLayout;}
	public function setCurrentLayout($value){$this->m_currentLaout = $value;}
	public function getName(){return "layoutctrl"; }
	public function getDataAdapterName(){ return IGK_CSV_DATAADAPTER;}
	public function loadLayout(){
		IGKIO::CreateDir(IGK_LAYOUT_FOLDER);
		$n = igk_getr("clName");
		$f = igk_currentRelativePath("Layouts/".$n.".xml");
		$t = igk_getv($_FILES,"clFile");	
		if (igk_io_move_uploaded_file($t["tmp_name"], $f))
		{
			//register layout
		}
		
	}
	public function removeLayout(){
		$n = igk_getr("n");
		$f = igk_currentRelativePath("Layouts/".$n.".xml");
		if (file_exists($f))
		{
			unlink($f);
		}
	}
	public function functionIsAvailable($funcname){
		return true;
	}
	public function InitComplete()
	{
		parent::InitComplete();
	}
}

///-----------------------------------------------------------------------------------------
///PICTURES RESOURCES CONTROLLERS
///-----------------------------------------------------------------------------------------
final class IGKPICRESCtrl extends IGKConfigCtrlBase
{
	private $m_fileres;// CSV DATA  - name
					 //           - uri
	private $m_cpage;//current page
	private $m_selectedir ;
	private $m_searchentry;
	private $m_fileexts;
	private $m_changeState;
	//constante
	const DATAFILE = "Data/upload.csv";
	const TARGETDIR = "R/Img";	
	const PICRES_KEY = "PicResChanged";
	
	private $m_lastDate;
	public function InitComplete()
	{
		parent::InitComplete();
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onPicResChanged");
		$this->m_fileres = $this->App->Doc->Theme->res;
		$this->_loadData();
	}
	public function onPicResChanged($ctrl){
		if ( $ctrl->isChanged(self::PICRES_KEY, $this->m_changeState))
		{
			$this->_loadData();
		}
	}
	
	///<summary>get all pictures resources entries</summary>
	public function getAllPics()
	{
		return $this->m_fileres;
	}
	//store data
	private function _storeData()
	{
		$out = "";
		foreach($this->m_fileres as $k=>$v)
		{
			$out .= $k.igk_csv_sep().$v.IGK_LF;
		}
		if (IGKIO::WriteToFileAsUtf8WBOM(igk_io_syspath(self::DATAFILE), $out, true))
		{
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange(self::PICRES_KEY, $this->m_changeState);
			return true;
		}
		return false;
	}
	public function getName(){		return IGK_PIC_RES_CTRL;	}
	public function __construct()
	{
		parent::__construct();			
	}
	
	private function _getexts()
	{
		$tab = explode(";",strtolower(IGK_ALLOWED_EXTENSIONS));
		$this->m_fileexts = array();
		foreach($tab as $k)
		{
			$this->m_fileexts[strtolower($k)] = $k;
		}
	}
	private function _support($ext)
	{
		$this->_getexts();
		return isset($this->m_fileexts[strtolower($ext)]);
	}
	function _loadData()
	{
		//clear file list
		$this->m_fileres = array();
		$f = igk_io_syspath(self::DATAFILE);
		$txt = IGKIO::ReadAllText($f);
		$lines = explode(IGK_LF, $txt);
		
		$this->_initDefaultPictureRes();
		$this->initPicturesRes(igk_io_currentRelativePath("R/Img"));
		foreach($lines as $l)
		{
			if (empty($l))
				continue;
			$e = explode( igk_csv_sep(), $l);			
			//replace with registered files
			$this->m_fileres [$e[0]] = igk_html_uri($e[1]);
		}		
	}
	//# add resources
	public function add_res($name, $uri)
	{
		
		$this->m_fileres[$name] = $uri;
		if (!isset($this->m_fileres[$name]))
		{
			$this->m_fileres[$name] = $uri;
			return true;
		}
		return false;
		
	}
	public function initPicturesRes($dir)
	{
		if (!is_dir($dir))
			return;
		//retrive all picture file from directory
		$r = IGKIO::GetPictureFile($dir);		
		foreach($r as $k)
		{
			$n = igk_io_basenamewithoutext($k);
			if (!isset($this->m_fileres[$n]))
				$this->m_fileres[$n] = igk_html_uri(igk_io_basePath($k));
		}
	}
	//@@@ init default resources
	private function _initDefaultPictureRes()
	{	//init default controller
		$dir = dirname(__FILE__)."/Default/R/Img";
		$this->initPicturesRes($dir);
	}
	public function getConfigPage(){return "pictureresconfig";}
	
	public function viewpic($name=null){
		$n = ($name==null)? igk_getr("name",$name):$name;
	// igk_wln("call name");
	// igk_show_prev($this->m_fileres[$n]);
	
	$f = igk_io_currentRelativePath(igk_getv($this->m_fileres, $n, ""));
		if (file_exists($f))
		{
			header("Content-type: image/png");
			igk_wl( IGKIO::ReadAllText($f));
		}
		else{
			header("Content-type: image/png");
			igk_wl( IGKIO::ReadAllText(igk_io_currentRelativePath(igk_getv($this->m_fileres, "none"))));
		}
		exit;
	}
	public function getImgUri($name)
	{
		if (isset($this->m_fileres[$name]))
			return igk_html_uri($this->m_fileres[$name]);
		return null;
	}

	protected function initTargetNode(){
		return HtmlItem::CreateWebNode("div", array("class"=>strtolower($this->Name)));
	}	
	public function View(){

		$div = $this->TargetNode;
		$div->ClearChilds();
		if ($this->IsVisible)
		{
			HtmlUtils::AddItem($div, $this->ConfigNode);	
			switch($this->m_cpage)
			{
				case "showentries":
					$this->showentries();
					break;
				default:
					$this->_showdefault();
					break;
			}
		}
		else{
			igk_html_rm($div);
		}
	}
	private function _showdefault()
	{
		$div = $this->TargetNode;
		igk_add_title($div, "title.PictureResourcesManager");
		$div->addHSep();
		
		igk_add_article($this, "pictures.res", $div->addDiv());
		$div->addHSep();
		//show directory
		$tab = IGKIO::GetDirList(igk_io_currentRelativePath(self::TARGETDIR));
		
		igk_add_title($div, "title.PictureResourcesManagerFolder");
		if ($tab && (count($tab)>0))
		{
			$ul = $div->add("ul");
			foreach($tab as $k)
			{
				$li = $ul->add("li");
				$li->add("label",array("class"=>"-cllabel cell_minsize dispib"))->add("a", array(
					"href"=>$this->getUri("setdir&d=".base64_encode(urldecode($k))),
					"class"=>"config_fileviewdir"))->Content = basename($k);
				if ((count(IGKIO::GetDirList($k)) == 0) && (count(IGKIO::GetDirFileList($k)) == 0)){
					HtmlUtils::AddImgLnk($li, $this->getUri("dropdir&d=".base64_encode(urldecode($k))), "drop");
				}
				// $li = $ul->add("li");
				// $li->Content = $k;
			}
		}
		$div->addHSep();
		igk_add_title($div, "title.UploadPictures");
		$frm = $this->_addLoadPicForm($div);
		
		
		HtmlUtils::AddBtnLnk($frm, "btn.showallpics", $this->getUri("showentries"));
		HtmlUtils::AddBtnLnk($frm, "btn.rmAll", $this->getUri("deleteall"), array(
		"onclick"=>igk_js_lnk_confirm(R::ngets(IGK_MSG_ALLPICS_QUESTION)->getValue())
		));
		$frm->addInput("confirm", "hidden", 0);		
	}
	private function _addLoadPicForm($div)
	{
		$frm = $div->addForm();
		$frm["action"]=$this->getUri("loadfile");
		$frm["method"]="POST";
		$frm["enctype"]=IGK_HTML_ENCTYPE;
		
		
		$frm->addSLabelInput("dir", "lb.DirName","text", $this->m_selectedir);$frm->addBr();
		$frm->addSLabelInput("name", "lb.Name", "text", null, null,true);$frm->addBr();
		$frm->addSLabelInput("pics", "lb.File", "file",null, array("multiple"=>false, "accept"=>"image/*" ),true);$frm->addBr();
		
		$frm->add("input", array("type"=>"hidden" , "name"=>"MAXFILESIZE", "value"=>5000));
		$frm->addHSep();
		$frm->addBtn("upload",R::gets("btn.upload"));
		return $frm;
	}
	public function dropdir()
	{		
		$dir = basename(base64_decode( igk_getr("d", null)));
		$dir = igk_io_currentbasePath(self::TARGETDIR ."/".$dir);		
		if (is_dir($dir)){
		
		if (IGKIO::RmDir($dir))
			igk_notifyctrl()->addMsgr("msg.directorydrop");
		else
			igk_notifyctrl()->addErrorr("msg.directorynotdrop");
			//igk_io_currentRelativePath(self::TARGETDIR ."/".$dir));
			$this->View();
		}
		igk_navtocurrent();
	}
	public function setdir()
	{
		$this->m_selectedir = basename(base64_decode( igk_getr("d", null)));		
		$this->View();
		
	}
	public function loadtempfile($tempfile, $name, $id,  $dir)
	{
			$f = $tempfile;
			$ext = IGKIO::GetFileExt($name);
			
			if (!$this->_support(".".$ext))
			{
				igk_notifyctrl()->addError(ERR_FILE_NOT_SUPPORTED);
				return;
			}	
		if (IGKIO::CreateDir($dir))
		{//ensure that file exits
			//igk_wln("dir created");
			$dest = igk_io_getdir($dir."/".$id.".". $ext);
			if (!move_uploaded_file($f, $dest))
			{
				igk_notifyctrl()->addError("Unable to move uploaded file to ".$dest);
			}
			else{
				$this->m_fileres[$id] = igk_io_basePath($dest);
				if (!$this->_storeData())
				{
					igk_notifyctrl()->addError("Can't store data  to file \"".$id."\"");
					unlink($dest);
					unset($this->m_fileres[$id]);
				}
				else {
					igk_notifyctrl()->addMsg( R::gets("MSG.FileUploaded"));
				}
			}		
	}
	}
	public function loadfile()
	{
		$id  = igk_getr("name");
		$dir = igk_getr("dir");
		
		$target = "";
		$dest="";
		if (($id==null) || isset($this->m_fileres[$id]))
		{
			igk_notifyctrl()->addError(R::ngets("ERR.FILEISNULLORALREADYREGISTERED"));
			igk_navtocurrent();
			return;
		}
		if ($dir)
			$target = igk_io_currentRelativePath(self::TARGETDIR."/".$dir);
		else
			$target = igk_io_currentRelativePath(self::TARGETDIR);
		
		
			$f = $_FILES["pics"]["tmp_name"];	
			$name = $_FILES["pics"]["name"];
			$ext = IGKIO::GetFileExt($name);
			
			if (!$this->_support(".".$ext))
			{
				igk_notifyctrl()->addError(ERR_FILE_NOT_SUPPORTED);
				return;
			}	
		if (IGKIO::CreateDir($target))
		{//ensure that file exits
			//igk_wln("dir created");
			$dest = igk_io_getdir($target."/".$id.".". $ext);
			if (!move_uploaded_file($f, $dest))
			{
				igk_notifyctrl()->addError("Unable to move uploaded file to ".$dest);
			}
			else{
				$this->m_fileres[$id] = igk_io_basePath($dest);
				if (!$this->_storeData())
				{
					igk_notifyctrl()->addError("Can't store data  to file \"".$id."\"");
					unlink($dest);
					unset($this->m_fileres[$id]);
				}
				else {
					igk_notifyctrl()->addMsg( R::gets("MSG.FileUploaded"));
				}
			}		
		}
		else {
				$this->msbox->addError("Unable to move uploaded file to ".$dest);
				
		}	
		$this->View();		
	}
	
	//delete picture
	public function delfile(){
		$id=igk_getr("name");
		if (($id==null) || !isset($this->m_fileres[$id]))
			return;
		$f = igk_io_currentRelativePath($this->m_fileres[$id]);
		if (file_exists($f))
		{
			if (unlink($f))
			{
				unset($this->m_fileres[$id]);
				$this->_storeData();
			}
			else 
				$this->msbox->addError("unabled to delete file");
		}
		else{
				//protection
				unset($this->m_fileres[$id]);
				$this->_storeData();
		}
		$this->View();
	}
	public function searchentry(){
	
		$this->m_searchentry = strtolower(igk_getr("q"));
		$this->View();
	}
	public function show_loadfile_frame()
	{
		$frame = igk_add_new_frame($this, "load_pic_frame");
		$frame->Title = R::ngets("title.loadpictureres");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $this->_addLoadPicForm($d);
		
	}
	public function showentries()
	{
		if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
		{		
			$this->m_cpage = "showentries";
			$div = $this->TargetNode;
			$div->ClearChilds();
			igk_add_title($div, "title.images");
			$div->addHSep();
			$div->add(new HtmlSearchItem($this->getUri("searchentry"), $this->m_searchentry));
			$div->addHSep();
			$frm = $div->addForm();
			$frm["method"]="POST";
			$frm["action"]= $this->getUri();
			
			
			$v_div= $frm->addDiv();
			HtmlUtils::AddBtnLnk($v_div, "btn.Return", $this->getUri("gotodefaultview"));			
			HtmlUtils::AddBtnLnk($v_div, "btn.loadfile", $this->getUri("show_loadfile_frame"));
			HtmlUtils::AddBtnLnk($v_div, R::ngets("btn.RemoveBrokenfiles"), $this->getUri("remove_broken_file"));
			$frm->addBr();
			$info = $frm->addDiv();
			
			$tab = $frm->add("table", array("class"=>"fitw"));
			$tr = $tab->add("tr");
			HtmlUtils::AddToggleAllCheckboxTh($tr);
			$tr->add("th")->Content = R::gets(IGK_FD_NAME);
			$tr->add("th")->Content = R::gets("clLink");
			$tr->add("th")->Content = R::gets("clSize");
			$tr->add("th")->Content = IGK_HTML_WHITESPACE;
			
			$v_ttab = array_keys($this->m_fileres);
			sort($v_ttab);
			$v_count = 0;
			foreach($v_ttab as $k)
			{
				$v = $this->m_fileres[$k];
				if (empty($v) || !empty($this->m_searchentry) && !strstr(strtolower($k), strtolower($this->m_searchentry))
						&& !strstr(strtolower($v), strtolower($this->m_searchentry)))
					continue;
				$tr = $tab->add("tr" , array("class"=>"fitw"));	
				$tr->add("td")->addInput("","checkbox");
				$tr->add("td")->Content = $k;
				$tr->add("td")->add("a", array("href"=>$this->getUri("viewpic&name=".$k)))->Content = $v;				
				$file = igk_io_currentRelativePath($v);
				if (file_exists($file))
				{
					$size = @filesize( $file);
					if ($size === false)
					{
						$tr->add("td")->Content =  "?";
					}
					else 
						$tr->add("td")->Content =  IGKIO::GetFileSize( $size);
				}
				else 
					$tr->add("td")->Content = "broken";
				$tr->add("td", array("class"=>"igk-table-img-action_16x16"))->add("a", array("href"=>$this->getUri("delfile&name=".$k)))->add("img", array("src"=>R::GetImgUri("drop")));
				
				$v_count++;
			}
			$info->Content = $v_count;
			$div = $frm->add("div", null, 1000);
			HtmlUtils::AddBtnLnk($div, "btn.Return", $this->getUri("gotodefaultview"));		
			HtmlUtils::AddBtnLnk($div, "btn.loadfile", $this->getUri("show_loadfile_frame"));			
			HtmlUtils::AddBtnLnk($div, R::ngets("btn.RemoveBrokenfiles"), $this->getUri("remove_broken_file"));
		}
	
	}
		public function remove_broken_file()
		{
			$v_ttab = array_keys($this->m_fileres);
			sort($v_ttab);
			$r  = false;
			$i = 0;
			foreach($v_ttab as $k)
			{
				$v = $this->m_fileres[$k];			
				$file = igk_io_currentRelativePath($v);
				if (!file_exists($file))
				{
					unset($this->m_fileres[$k]);
					$r = true;
					$i++;
				}
			}
				if ($r){
					$this->_storeData();
					$this->View();
					igk_notifyctrl()->addMsgr("msg.brokenfilesremoved", $i);
				}
				else{
					igk_notifyctrl()->addInfor("msg.nobrokenfilesremoved");
				}
		}
		public function gotodefaultview()
		{
			$this->m_cpage = null;
			$this->View();
		}
	public function deleteall()
	{
		if (igk_qr_confirm()){
		$dir = igk_io_baseRelativePath(self::TARGETDIR);
		if (is_dir($dir) && !IGKIO::Rmdir(igk_io_baseRelativePath(self::TARGETDIR)))
		{
			$this->msbox->addError("Impossible de supprimer le repertoire.");
		}
		else{
			foreach($this->m_fileres as $k=>$v)
			{
				$f = igk_io_currentRelativePath($v);
				if (file_exists($f))
					unlink($f);
			}
			$this->m_fileres= array();
			$this->_storeData();
			$this->View();
		}
		}
		else{
			$frame = igk_add_confirm_frame($this, "delete_all_pics_frame");		
			$frame->Form["action"] = $this->getUri("deleteall");
			$frame->Form->Div->Content = R::ngets(IGK_MSG_ALLPICS_QUESTION);
			
		}
	}
	
	
}
class IGKXmlOptions
{
	var $Indent;
	var $ParentDepth;
}

///-----------------------------------------------------------------------------------------
///MODULE-CONTROLLER AND ARTICLE MANAGER
///-----------------------------------------------------------------------------------------
final class IGKControllerAndArticlesCtrl extends IGKConfigCtrlBase
{
	private $m_SelectedController;
	private $m_selectedLang;
	private $m_search_article;
	private $m_search_view;
	private $m_filter_article_lang;
	private $m_SelectedControllerChangedEvent;
	
	public function getSelectedController(){return $this->m_SelectedController; }
	public function setSelectedController($value){ 
		if ($this->m_SelectedController != $value)
		{
			$this->m_SelectedController = $value;
			$this->onSelectedControllerChanged();
		}
	}
	protected function onSelectedControllerChanged()
	{
		$this->m_SelectedControllerChangedEvent->Call($this, array());
	}
	
	//--------------------------------------------
	//get the article content	
	//--------------------------------------------
	public function getCtrlArticle(){
		$c = igk_getr("ctrl");//get the controller
		$n = igk_getr("n"); //article name
		
		igk_getctrl($c)->getArticle($n);
		exit;
	}
	
	
	public function setdefaultpage(){
		$this->App->Configs->web_pagectrl = igk_getr("clDefaultCtrl");
		igk_save_config();
		$this->View();
	}
	public function setdefaultpage_ajx(){
		$this->setdefaultpage();
	}
	
	private function _getviewid(){$this->getName()."_views";}
	
	
	//---------------------------------------------------------------------------------------
	// ARTICLES FUNCTIONS
	//---------------------------------------------------------------------------------------
	
	
	public function _viewArticles($div)
	{
		$ctrl = igk_getctrl($this->SelectedController, false);
		if ($ctrl == null)
			return null;
	
		$div->add(new HtmlSearchItem($this->getUri("search_article"), null, "m_search_article"));
		$dir = $ctrl->getArticlesDir();
		$t = IGKIO::GetDirFileList($dir);
		$lang_search = null;
		$frm = $div->addForm();
		
		if (!(($this->m_selectedLang == null) || ($this->m_selectedLang == ALL_LANG)))
			$lang_search = $this->m_selectedLang;
		if ($t && count($t)>0){
			sort($t);
				$ul = $frm->add("table", array("class"=>"fitw"));
				$ul["id"]=$this->_getarticleid();
				$tr = $ul->add("tr");
				$tr->add("th", array("style"=>"width:16px"))->Content = IGK_HTML_SPACE;
				$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
				$n = null;
				foreach($t as $k)
				{
					$n =  basename($k);
					// if (!IGKString::EndWith(strtolower($n), igk_get_article_ext()))
					// {continue;}
					if ($lang_search && !IGKString::EndWith(strtolower($n), igk_get_article_ext($lang_search)))
						continue;
					if($this->m_search_article && !strstr(strtolower($n), strtolower($this->m_search_article)))
						continue;
					$tr = $ul->add("tr");
					$tr->add("td")->Content =IGK_HTML_SPACE;
					$tr->add("td")->add("a", array("href"=>$this->getUri("download_article&n=".$n)))->Content = $n;
					HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("edit_article&n=".basename($k)), "edit");
					HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("edit_articlewtiny&n=".basename($k)), "tiny");
					HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("drop_article&n=".basename($k)), "drop","16px","16px", null, array("onclick"=>"javascript:igk_confirm_article_del(igk.getParentByTagName(this,'a'));"));
				}
			}
		$frm["action"]= $this->getUri("add_articleframe");
		$frm->addBtn("btn_addarticle", R::ngets("btn.AddArticle"));
	}
	
	private function _getarticleid(){
		return $this->getName()."_articles";
	}
	
	public function search_view()
	{
		$this->m_search_view = igk_getr("m_search_view");
		$this->View();
	}
	
	private  function __write_article($file, $v_content, $property=null)
	{
		if (empty($file))
			return false;
		
		$v_dummy = HtmlItem::CreateWebNode("dummy");
		$v_dummy->Load($v_content);
		
		if ($v_dummy->HasChilds){
			
			
			if ($property)
			{
				if ($property->RemoveImgSize)
				{
					$tab  = $v_dummy->getElementsByTagName("image");
					igk_wln("remove image style");
					foreach($tab as $k)
					{
						$k["width"] = null;
						$k["height"] = null;
					}
				}
				$tab  = $v_dummy->getElementsByTagName("*");
				if ($property->RemoveStyles)
				{					
					foreach($tab as $k)
					{
						$k["style"] = null;
					}
				}
			}
			
			$s = null;// (object)array("Indent"=>true, "ParentDepth"=>null);
			if ($v_dummy->ChildCount === 1)
			{
				$s = new IGKXmlOptions();
				$s->Indent = true;
				$s->ParentDepth = $v_dummy->Childs[0];						
				IGKIO::WriteToFileAsUtf8WBOM($file, $s->ParentDepth->getinnerHTML($s), true);	
				
			}
			else{
				$s = new IGKXmlOptions();
				$s->Indent = true;
				$s->ParentDepth = $v_dummy;
				IGKIO::WriteToFileAsUtf8WBOM($file,  $s->ParentDepth->getinnerHTML($s), true);					
			}
			return true;
		}
		else{
			IGKIO::WriteToFileAsUtf8WBOM($file, "", true);	
			return true;
		}
		return false;
	}
	private function __updateview($ctrl)
	{
				if ($ctrl && $ctrl->IsVisible)
				{					
					if (($this->CurrentPageFolder == IGK_CONFIG_PAGEFOLDER) && is_subclass_of(get_class($ctrl), "IGKConfigCtrlBase" ))
						$ctrl->showConfig();
					else
						$ctrl->View();	
				}
	}
	public function update_articlewtiny(){
		
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_line( igk_html_unscape(igk_getr("clContent")));
		$id = igk_getr("clctrl");
		$v_frame = igk_getr("clframe");
		$property = (object)array(
			"RemoveImgSize" =>igk_getr("clRemoveImgSize"),
			"RemoveStyles" =>igk_getr("clRemoveStyles")
		);
		
		$ctrl = igk_getctrl($id, false);
		if ($this->__write_article($f, $v_c, $property))
		{
			$this->__updateview($ctrl);
			igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved" , basename($f)));
		}
		else {
			igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
		}
	}
	
	public function update_article(){
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_line(igk_html_unscape(igk_getr("clContent")));		
		$v_frame = igk_getr("clframe");
		$v_dummy = HtmlItem::CreateWebNode("div");
		$id = igk_getr("clctrl");
		$ctrl = igk_getctrl($id, false);
		if (!empty($f))
		{	
			try{
			$v_dummy->Load($v_c);
			if (igk_io_save_file_as_utf8($f, utf8_decode($v_c), true))		
			{
				$this->__updateview($ctrl);
				igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved" , basename($f)));
			}
			else 
				igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
			igk_frame_close($v_frame);		
			}
			catch(Exception $ex){
				igk_notifyctrl()->addError(R::ngets("ERR.FileNotSAVED" , basename($f)));
			}
		}
		
	}
	///<summary> edition d'article simple par une demande ajax</summary>
	public function ca_edit_article_ajx($ctrlid=null, $name=null)
	{
	//fc : force creation
		$frame = $this->ca_edit_article_frame($ctrlid, igk_getr("n", igk_getr("fn")), 1, igk_getr("m", 0), igk_getr("fc") );
		if ($frame)
			$frame->RenderAJX();
		
		
	}
	///<summary> create d'un FrameDialog pour l'édition d'article </summary>
	///<params>
	///$ctrlid: controller ou id du controller
	///$name: nom ou chemin d'accèss au fichier
	///$ajx:  s'il s'agit d'un context ajax ou nom
	///$mode: si mode = 1 alors le name un le chemin d'accès complet au fichier sinon il s'agit du nom dans le repertoire Articles du controlleur
	///$force: force creation if not exists
	///<params>
	public function ca_edit_article_frame($ctrlid=null, $name=null, $ajx=0, $mode=0, $force=false)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);
		
		if ($force || file_exists($f))
		{
		
			$frame = igk_add_new_frame($this, "frame_edit_article", $ajx==1?null: "#".$this->_getarticleid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticle", basename($f));						
			$str = IGKIO::ReadAllText($f);
			
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_article".( ($ajx==1)?null: "#".$this->_getarticleid()));
			$ul = $frm->add("ul");
			$txt = $ul->add("li")->addTextArea("clContent", utf8_decode( $str));			
			$txt["class"] = "frame_textarea";
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
		
			return $frame;
		}
		
		return null;
	}

	
	public function ca_edit_articlewtiny_frame($ctrlid=null, $name=null, $ajx=0, $mode=0)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);			
		if (file_exists($f))
		{
		//TODO:
			$frame = igk_add_new_frame($this, "frame_edit_article", $ajx==1?null: "#".$this->_getarticleid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticle", basename($f));					
			$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_articlewtiny".( ($ajx==1)?null: "#".$this->_getarticleid()));
			$ul = $frm->add("ul");
			$ul->add("li")->addSLabelInput("clRemoveStyles", R::ngets("lb.RemoveStyle"), "checkbox");
			$ul->add("li")->addSLabelInput("clRemoveImgSize", R::ngets("lb.clRemoveImgSize"), "checkbox");
			$ul->add("li")->addTextArea("clContent",utf8_decode($str));
			igk_js_enable_tinymce($ul, "exact", "clContent");
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));	
			return $frame;			
		}
		return null;
	}
	public function ca_edit_articlewtiny_f_ajx($ctrlid=null, $name=null)
	{
		$frame = $this->ca_edit_articlewtiny_f_frame($ctrlid,$name?$name: igk_getr("n", igk_getr("fn")), 1, igk_getr("m", 0), igk_getr("fc") );
		if ($frame)
			$frame->RenderAJX();		
	}
	public function ca_update_articlewtiny_f()
	{
		//full
		if (!$this->App->ConfigMode)
		{
			igk_navtocurrent();
			return;
		}		
		$this->update_articlewtiny();
		//reload frame
		$_REQUEST["ctrlid"] = igk_getr("clctrl");
		$_REQUEST["n"] = basename(urldecode(base64_decode(igk_getr("clfile"))));
		igk_frame_close("frame_edit_article");	
		igk_navtocurrent();
	}
	public function ca_edit_articlewtiny_f_frame($ctrlid=null, $name=null, $ajx=0, $mode=0,$force = false)
	{
		$ctrl = igk_getctrl($ctrlid?$ctrlid:igk_getr("ctrlid"), false);
		$n = $name?$name:igk_getr("n");
		
		if (($ctrl == null) || !isset($n))
			return null;
		if ($mode==0)
			$f= igk_io_getdir($ctrl->getArticlesDir()."/".$n);			
		else
			$f = base64_decode($n);				
		if ($force || file_exists($f))
		{
			//TODO:
			$frame = igk_add_new_frame($this, "frame_edit_article");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editarticle", basename($f));					
			$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("ca_update_articlewtiny_f");
			$ul = $frm->add("ul");
			$ul->add("li")->addSLabelInput("clRemoveStyles", R::ngets("lb.RemoveStyle"), "checkbox");
			$ul->add("li")->addSLabelInput("clRemoveImgSize", R::ngets("lb.clRemoveImgSize"), "checkbox");
			$ul->add("li")->addTextArea("clContent",utf8_decode($str));
			igk_js_enable_tinymce($ul, "exact", "clContent");
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("clctrl", "hidden", $ctrl->Name);
			$frm->addBtn("btn_update", R::ngets("btn.Update"));	
			return $frame;			
		}
		return null;
	}
	public function edit_article()
	{
		$this->ca_edit_article_frame($this->SelectedController, igk_getr("n"));		
	}
	public function edit_articlewtiny(){
		$this->ca_edit_articlewtiny_frame($this->SelectedController, igk_getr("n"));
	}
	
	/*
	*remove an article.
	*/
	public function drop_article(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getArticlesDir()."/".$n);					
		$_FRAMENAME = "frame_drop_article_confirmation";
		if (file_exists($f))
		{
			if (igk_qr_confirm()){
				unlink($f);
			}
			else{
				$frame = igk_add_confirm_frame($this, $_FRAMENAME, $this->getUri("drop_article"));
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION, $n);
				$frame->Form->addInput("n", "hidden",$n);		
			}
			$this->View();
		}
	}
	/*
	*get an article. download it 
	*/
	public function download_article(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getArticlesDir()."/".$n);			
		if (file_exists($f))
		{
			igk_download_file(basename($f), $f);
			exit;
		}
	}
	
	//filter article by language
	public function filter_article_by_lang(){
		$this->m_filter_article_lang = igk_getr("n");
		$this->View();
	}
	/*
	*search article . reload the view
	*/
	public function search_article(){
		$this->m_search_article = igk_getr("m_search_article");		
		$this->View();
	}
	
	private function _buildViewArticle($div){
			$v_divarticle = $div->addDiv();
			$v_divarticle["id"] = "view_articles";
			igk_add_title($v_divarticle, "title.Articles");	
			$frm = $v_divarticle->addForm();			
			$frm["action"]= $this->getUri("add_articleframe");
			$frm->add("label")->Content = R::ngets("lb.Language");						
			$tab =array_merge(array(ALL_LANG), igk_getctrl(IGK_LANGUAGE_CTRL)->Languages);			
			$select = igk_html_build_select($frm, "clLang", $tab, array("allowEmpty"=>false, "keysupport"=>false),$this->m_selectedLang);							
			$select["onchange"]="javascript:  (function(p){var q = p.form.parentNode; igk.ajx.post('".$this->getUri("select_lang_ajx&n=").
			"'+p.value, null, function(xhr){ if (this.isReady()){ this.setResponseTo(\$igk(q).getChildById('igk-div-articles').owner); }});})(this);";
			$this->_viewArticles($v_divarticle->addDiv(array("id"=>"igk-div-articles")));				
	}
	
	//-----------------------------------------------
	//-----------------------------------------------
	// VIEWS FUNCTIONS
	//-----------------------------------------------
	//-----------------------------------------------
	
	
	public function _viewViewFiles($div){
	$ctrl = igk_getctrl($this->SelectedController, false);
		if ($ctrl == null)
			return null;
		$div->add(new HtmlSearchItem($this->getUri("search_view#frm_ctrl_view"), null, "m_search_view"));
		$frm = $div->addForm();
		$frm["id"]=$frm["name"] = "frm_ctrl_view";
		$frm["action"]= $this->getUri("add_viewframe");
		$dir = $ctrl->getViewDir();
			$t = IGKIO::GetDirFileList($dir);
		if ($t && count($t)>0){
		sort($t);
		$ul = $frm->add("table", array("class"=>"fitw"));
		$ul["id"]=$this->_getviewid();
		$tr = $ul->add("tr");
		$tr->add("th", array("style"=>"width:16px"))->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
		$tr->add("th",array("style"=>"width:16px"))->Content =IGK_HTML_SPACE;
		foreach($t as $k)
		{
			if ($this->m_search_view && !strstr(strtolower($k), $this->m_search_view))
				continue;
			$tr = $ul->add("tr");
			
			$tr->add("td")->Content = IGK_HTML_SPACE;
			$tr->add("td")->add("a", array("href"=>$this->getUri("download_view&n=".basename($k))))->Content = basename($k);
			HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("edit_view&n=".basename($k)), "edit");
			HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("drop_view&n=".basename($k)), "drop");
		}
		}
		
		$frm->addBtn("btn_addView", R::ngets("btn.AddView"));
	}
	
	
	public function update_view(){
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c = igk_str_remove_line(igk_getr("clContent"));
		$v_frame = igk_getr("clframe");		
		$ctrl = igk_getctrl($this->SelectedController, false);	
		$v_old = IGKIO::ReadAllText($f);
		
		
		//save the content from text area 
		igk_io_saveContentFromTextArea($f, $v_c, true);		
		$error = array();		
		$code = 0;
		@exec("php -l \"".$f."\"", $error, $code);
		
		igk_show_prev($error);
		
		// if (igk_php_check_and_savescript($f, $v_c, $error, $code) == false)
		// {
			// $this->edit_view($v_c, count($error)."update_view::failed code:".$code." ".  implode("<br />",$error), true);			
		// }	
		// else{
			igk_notifyctrl()->addMsg(R::ngets("MSG.ViewFileSaved" , basename($f)));
			$ctrl->View();
			igk_frame_close($v_frame);
		// }	
	}
	public function edit_view($oldcontent=null, $errormesage=null, $error=null){
		//edit frame 	
		$ctrl = igk_getctrl($this->SelectedController, false);
		$n = igk_getr("n");
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir($ctrl->getViewDir()."/".$n);			
		if (file_exists($f))
		{
			//view edit frame
			$frame = igk_add_new_frame($this, "frame_edit_view", "#".$this->_getviewid());
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editview", basename($f));	
			$str=null;
			if (!$oldcontent)
				$str =utf8_decode( IGKIO::ReadAllText($f));					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_view#".$this->_getviewid());
			if ($error)
			{
				$frm->add("div", array("class"=>"notification_bad"))->Content = "Somme Error Append When try to save the file: <br/ >" 
				. $errormesage.
				"<br/>".$oldcontent;
			}
			$ul = $frm->add("ul");
			$ul->add("li")->addTextArea("clContent", ($oldcontent==null)? $str: $oldcontent);		
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);
			$frm->addInput("n", "hidden", $n);
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
		}
	}
	public function drop_view(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getViewDir()."/".$n);					
		$_FRAMENAME = "frame_drop_view_confirmation";
		if (file_exists($f))
		{
			if (igk_qr_confirm()){
				unlink($f);
			}
			else{
				$frame = igk_add_confirm_frame($this, $_FRAMENAME,$this->getUri("drop_view"));			
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION,$n);
				$frame->Form->Div->addInput("n", "hidden",$n);		
			}
			$this->View();
		}
	}
	//download view file
	public function download_view(){
		$n = igk_getr("n");
		$ctrl = $this->SelectedController;
		if (($ctrl == null) || !isset($n))
			return null;
		$f= igk_io_getdir(igk_getctrl($ctrl)->getViewDir()."/".$n);			
		if (file_exists($f))
		{
			igk_download_file(basename($f), $f);
			exit;
		}
	}
	
	
	
	
	//-----------------------------------------------
	// CONTROLLLERS  FUNCTIONS
	//-----------------------------------------------
	
	
	public function update_ctrl($oldcontent=null){
		
		$f = urldecode(base64_decode(igk_getr("clfile")));
		$v_c =utf8_encode( igk_html_unscape(igk_getr("clContent"),""));
		$v_frame = igk_getr("clframe");		
		$ctrl = igk_getctrl($this->SelectedController, false);	
		
		if (igk_php_check_and_savescript($f, $v_c, $error, $code) == false)
		{
			$this->edit_view($v_c, count($error)."update_ctrl::failed: code : ".$code." ".  implode("<br />",$error), true);			
		}	
		else{
			igk_notifyctrl()->addMsg(R::ngets("MSG.ViewFileSaved" , basename($f)));
			$ctrl->View();
			igk_frame_close($v_frame);
		}
	}
	public function ca_edit_ctrl_ajx($oldcontent =null){
	//controller frame
		$ctrl = igk_getctrl($this->SelectedController, false);
		if ($ctrl == null)
			return null;
		$f= igk_io_getdir($ctrl->getDeclaredFileName());			
		if (file_exists($f))
		{
			$frame = igk_add_new_frame($this, "frame_edit_ctrl",".");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editctrl", basename($f));	
			$str=null;
			if (!$oldcontent)
				$str = IGKIO::ReadAllText($f);					
			$d = $frame->Content;
			$frm = $d->addForm();
			$frm["action"]=$this->getUri("update_ctrl");
			if ($oldcontent){
				$frm->add("div", array("class"=>"notification_bad"))->Content = "Error HAppend : <br/ >" . $errormesage;
			}
			$ul = $frm->add("ul");
			$ul->add("li")->addTextArea("clContent", ($oldcontent==null)? $str: $oldcontent);		
			$frm->addInput("clfile", "hidden", base64_encode(urlencode($f)));
			$frm->addInput("clframe", "hidden", $frame["id"]);			
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
			igk_wl($frame->Render());
		}
	}
	
	public function ca_edit_ctrl_properties_ajx()
	{
			//edit controller frame
			$ctrl = igk_getctrl($this->SelectedController, false);
			if ($ctrl == null)
				return null;
			$f= igk_io_getdir($ctrl->getDeclaredFileName());
			$frame = igk_add_new_frame($this, "frame_edit_ctrl_properties",".");
			$frame->ClearChilds();			
			$frame->Title = R::ngets("title.editctrl.properties", $ctrl->Name);
			
			$frm = $frame->Content->addForm();
			$frm["action"]=$this->getUri("update_ctrl_properties");
			$frm->addInput("frame_name", "hidden", $frame->Id);
			$ul = $frm->add("ul");
			
			$d = igk_sys_getdefaultCtrlConf();
			
			foreach($d as $k=>$v)
			{
				
				$vv = igk_getv($ctrl->Configs, $k);
				
				switch(strtolower($k))
				{			
					case "clparentctrl":
						$t = igk_getctrl(IGK_MENU_CTRL)->__getEditController($ul, $vv, "lb.ParentController", $this->SelectedController);
						$t["id"] = $t["name"]= $k;
					break;
					case "cldataadaptername":
						$t = IGKDataAdapter::GetAdapters();
						$li = $ul->add("li");
						$li->add("label", array("for"=>$k))->Content = R::ngets("lb.".$k);
						$sl = $li->add("select");
						$sl["id"] = $sl["name"] = $k;
						foreach($t as $m=>$c)
						{
							$opt = $sl->add("option");
							$opt["value"] = $m;
							if ($m == $vv)
								$opt["selected"]="true";
							$opt->Content = $m;
						}
						break;
					default:
						$li = $ul->add("li");
						$li->add("label", array("for"=>$k))->Content = R::ngets("lb.".$k);
						$li->addInput($k,"text", $vv);
					break;
				}
			}
			
			$this->_buildAdditionalInfo($ctrl, $ul);
			$frm->addHSep();			
			$frm->addBtn("btn_update", R::ngets("btn.Update"));
			
		igk_wl($frame->Render());
	}
	public function update_ctrl_properties()
	{
		$ctrl = igk_getctrl($this->SelectedController, false);
		if ($ctrl == null)
			return null;
		foreach($ctrl->Configs as $k=>$v)
		{
			$s = igk_getr($k);
			switch($k)
			{
				case "clParentCtrl":
				{
					if ($s == "none")
					{
						$ctrl->Configs->$k =null;						
					}
					else {
						$ctrl->Configs->$k = $s;
					}
				}
				break;
				
				default : 
				$ctrl->Configs->$k = $s;
				break;
			}
		}	
		$ctrl->__storeConfig();
		igk_notifyctrl()->addMsg(R::ngets("msg.ctrlsettingupdated" , $ctrl->Name));
		$this->View();
		igk_frame_close(igk_getr("frame_name"));
	}
	
	

	//select controller ajx
	public function select_controller_ajx(){
		$this->SelectedController = igk_getr("n");		
		$this->View();
		igk_wl( $this->TargetNode->innerHTML);		
	}
	
	public function select_lang_ajx(){
		$this->m_selectedLang  = igk_getr("n");
		$div = HtmlItem::CreateWebNode("div");
		$this->_viewArticles($div);
		igk_wl($div->innerHTML);
	}
	
	private function setup_defaultpage($ctrltab =null)
	{
		$ctrltab = $ctrltab == null ? igk_get_default_pagesctrl() : $ctrltab;

		if ((count($ctrltab)==1) || ($this->App->Configs->web_pagectrl==null))
		{
			$n = $ctrltab[0]->getName();					
			if ($this->App->Configs->web_pagectrl != $n)
			{
				$this->App->Configs->web_pagectrl = $ctrltab[0]->getName();
				igk_save_config();
			}
		}
	}
	
	private function __getVisibleCtrl()
	{
		return $this->App->ControllerManager->getUserControllers();		
	}
	
	
	function __viewDefaultPageCtrl($t)
	{
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("setdefaultpage");
			
			igk_add_title($frm, "title.defaultpagectrl");	
			
			$frm->add("label", array("for"=>"clDefaultCtrl"))->Content = R::ngets("lb.defaultpagectrl");
			$sl = $frm->add("select");
			$sl["id"]=$sl["name"] = "clDefaultCtrl";
			$sl["onchange"]="javascript:window.igk.ajx.post('".$this->getUri('setdefaultpage_ajx&')."'+this.id+'='+this.value, null, null);"; 
			
			$ctrltab = igk_get_default_pagesctrl() ;
			if (count($ctrltab) == 0)
			{
				$this->App->Configs->web_pagectrl = null;
				$frm->add("span")->Content = R::ngets("Warning.NoDefaultController");
			}
			else
			{
				$this->setup_defaultpage($ctrltab);
				foreach($ctrltab as $k)
				{
					$opt = $sl->add("option");
					$n = strtolower($k->Name);
					$opt["value"] = $k->Name;
					if ($n == strtolower($this->App->Configs->web_pagectrl))
					{
						$opt["selected"] ="true";
					}
					$opt->Content = $k->getDisplayName();
				}
			}			
			$frm->addDiv()->add("noscript")->addInput("btn_add", "submit");
	}
	private function __viewMenuHostCtrl($t)
	{
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("ca_setmenuhost");
			
			$tab = $this->__getVisibleCtrl();
			if (igk_count($tab) == 0)
			{
			}
			else{
			
			$frm->add("label", array("for"=>"clCtrlMenuHost"))->Content = R::ngets("lb.MenuHostCtrl");
			$sl = $frm->add("select");
			$sl["id"]=$sl["name"] = "clCtrlMenuHost";
			$sl["onchange"]="javascript:window.igk.ajx.post('".$this->getUri('ca_setmenuhost_ajx&')."'+this.id+'='+this.value, null, null);"; 
			
			$sl->add("option",array("value"=>""))->Content = IGK_HTML_SPACE;
			
			$v_menuhost = $this->App->Configs->menuHostCtrl;
			foreach($tab as $v)
			{				
				//select the first controller				
				$opt = $sl->add("option", array("value"=>$v->getName()));
				if ($v->getName() == $v_menuhost)
				{
					$opt["selected"]="true";
				}
				$opt->Content = $v->getDisplayName();
				
			}
			$frm->addDiv()->add("noscript")->addInput("btn_add", "submit");
			}
	}
	//ca for controller and article
	public function ca_setmenuhost()
	{
		$v_n = igk_getr("clCtrlMenuHost");
		$this->App->Configs->menuHostCtrl = $v_n;
		igk_save_config();
		$this->View();
			//refresh the controller
			
		$ctrl = igk_getctrl($v_n);
		igk_getctrl(IGK_MENU_CTRL)->setMenuhostCtrl($ctrl);		
		igk_sys_viewctrl($v_n);
		
	}
	public function ca_setmenuhost_ajx()
	{
		$this->ca_setmenuhost();
	}
	
	private function _view_ctrl_EditCtrl($t)
	{	
		
			$frm = $t->AddForm();
			$frm["action"] = $this->getUri("drop_controller");	
			$frm->add("label")->Content = R::ngets("lb.Controllers");
			$select = $frm->add("select");
			 $select["onchange"]=<<<EOF
javascript: (function(i){ var q = window.igk.getParentById(i, '{$this->TargetNode["id"]}'); window.igk.ajx.post('{$this->getUri('select_controller_ajx&n=')}'+i.value, null, function(xhr){  if (this.isReady()){ this.setResponseTo(q);  var p = q.getElementsByTagName('select')[0]; p.focus(); }})})(this); 
EOF;
			$select["name"]=$select["id"]= "controlleur";
			
			$tab = $this->__getVisibleCtrl();
			if (count($tab) > 0)
			{
			
			foreach($tab as $v)
			{				
				//select the first controller
				if ($this->SelectedController === null)
					$this->SelectedController = $v->getName();
				$opt = $select->add("option", array("value"=>$v->getName()));
				if ($v->getName() == $this->SelectedController)
					$opt["selected"] = "true";
				$opt->Content = $v->getDisplayName();
				
			}
				$ctrl = igk_getctrl($this->SelectedController);
				HtmlUtils::AddImgLnk($frm, igk_js_post_frame($this->getUri("ca_add_ctrl_frame_ajx")), "add");
				$this->_view_ctrl_options($ctrl, $frm);
			}
		
	}
	private function _view_ctrl_options($ctrl, $targetNode)
	{
	
		
		HtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_ctrl_ajx")), "edit");
		HtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_ctrl_properties_ajx")), "setting");
		
		if ($ctrl->CanEditDataTableInfo){
			HtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("ca_edit_db_ajx")), "ico_db");
		}
			
		HtmlUtils::AddImgLnk($targetNode, igk_js_post_frame($this->getUri("edit_ctrl_drop_ajx")), "drop");
	}
	
	public function ca_selectedCtrlChanged()
	{
		$t = $this->getParam("ctrl:ca_tabInfo");
		if ($t !=null)
			$t->ClearChilds();
		//reset table info
		$this->setParam("ctrl:ca_tabInfo",null);
	}
	public function ca_update_dbdata()
	{
		$obj = igk_getr_obj();
		
		$e = HtmlItem::CreateWebNode("DataDefinition");
		$e["TableName"] = igk_getr("clTableName");
		unset($obj->clTableName);
		$v_kexist = array();
		for ($i = 0; $i < igk_count($obj->clName); $i++)
		{
			if (empty($obj->clName[$i]) || isset($v_kexist[$obj->clName[$i]]))
				continue;
				
			$v_kexist[$obj->clName[$i]] = 1;
			$cl = $e->add("Column");
			foreach($obj as $k=>$v)
			{
				$cl[$k] = $v[$i];
			}			
		}
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		igk_io_save_file_as_utf8($f, $e->Render((object)array("Indent"=>true)));		
		igk_frame_close("add_edit_db_frame");
		
		//reset table info
		$this->setParam("ctrl:ca_tabInfo",null);
		$this->View();
	}
	///<summary>request edit data base with ajx </summary>
	public function ca_edit_db_ajx()
	{
		//edit db frame
		
		$ctrl = igk_getctrl($this->SelectedController);
		if ($ctrl==null)
			return;
		$frame = igk_add_new_frame($this, "add_edit_db_frame");
		$frame->Title = R::ngets("title.editdbArticle", $this->SelectedController );
		$d = $frame->Content;
		$d->ClearChilds();
		
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("ca_update_dbdata");
		$div = $frm->addDiv();
		$div["style"]="max-width:824px; max-height:400px; min-height: 200px;  overflow:auto;";
		
		$ul = $div->add("ul");
		$ul->Index = -10;
		$ul->add("li")->addSLabelInput("clTableName", "lb.TableName", "text", $ctrl->DataTableName);
		
		$div->add($this->ca_getTableInfo());
		
		$frm->addHSep();
		$div = $frm->addDiv();
		$a = HtmlUtils::AddImgLnk($div,"#", "add");
		$a["onclick"] =  igk_js_ajx_post_auri($this->getUri("ca_addfield_ajx"),"window.igk.ctrl.ca_update");
		$a = HtmlUtils::AddImgLnk($div,"#", "drop");
		$a["onclick"] =  igk_js_ajx_post_auri($this->getUri("ca_clearTableList_ajx"),"window.igk.ctrl.ca_updatetable");
	
		
		$frm->addInput("btn.update", "submit",  R::ngets("btn.update"));
		igk_wl($frame->Render());
		
	}
	public function ca_getTableInfo()
	{		
		$t = $this->getParam("ctrl:ca_tabInfo");
		if ($t !=null)
			return $t;
		else 
			$table = HtmlItem::CreateWebNode("table");

		$ctrl = igk_getctrl($this->SelectedController);

		$tr = $table->add("tr");
		$t = IGKdbColumnInfo::GetColumnInfo();
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($t as $v=>$k)
		{
			$tr->add("th")->Content = R::ngets($v);
		}
		$tr->add("th")->Content = IGK_HTML_SPACE;	
		
		
		
		if (file_exists($ctrl->getDBConfigFile()))
		{
			$tab = $ctrl->getDataTableInfo();
			foreach($tab as $k)
			{				
				$table->add( $this->ca_getFieldInfo($k));
			}
			
		}
		else{
			$info = IGKdbColumnInfo::NewEntryInfo();
			$info->clIsPrimary = true;
			$table->add( $this->ca_getFieldInfo($info));
		}
		$this->setParam("ctrl:ca_tabInfo", $table);
		return $table;
	}
	public function ca_getFieldInfo($info)
	{
		$tr = HtmlItem::CreateWebNode("tr");
		$tr["__id"] = igk_new_id();
		$tr->add("td")->Content = IGK_HTML_SPACE;
		foreach($info as $v=>$k)
		{
			$td = $tr->add("td");
			switch(strtolower($v))
			{
				case "clisunique":
				case "clautoincrement":
				case "clisprimary":
				case "clnotnull":
				case "clisuniquecolumnmember":
				case "clisnotinqueryinsert":
					//$td["class"]="alignc";
					$c = $td->add("div", array("class"=>"dispb fitw", "style"=>"text-align:center;"))->addInput("__cl".$v."[]","checkbox", null, array("onchange"=>"javascript:(function(q){window.igk.ctrl.ca_update_checkchange(q, '".$v."[]');})(this);"));
					if ($k) 
						$c["checked"]="true";
					$td->addInput($v."[]", "hidden", $k);
					break;
				case "cltype":
					//igk_html_build_select($target, $name, $tab, $attributes=null, $selectedvalue = null, $attr=null)
					igk_html_build_select($td, $v."[]",  IGKdbColumnDataType::GetDbTypes() ,
					null,
					$k); 
					break;
				default:
				$i = $td->addInput($v."[]","text", $k);
				$i["class"]="-cltext";
				$i["style"]="max-width:125px;";
				break;
			}
		}
		HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("ca_dropfield&n=".$tr["__id"]), "drop");
		
		return $tr;
	}
	public function ca_addfield_ajx()
	{			
		$c = $this->ca_getFieldInfo(IGKdbColumnInfo::NewEntryInfo());	
		if ($table = $this->getParam("ctrl:ca_tabInfo"))
		{
			igk_html_add($c, $table);
		}
		igk_wln($c->Render());
	}
	public function ca_dropfield()
	{
		$n = igk_getr("n");
		$table = $this->getParam("ctrl:ca_tabInfo");
		$tr = $table->getElementByAttribute("__id", $n);
		if ($tr)
		{		
			igk_html_rm($tr);
		}
	}
	public function ca_clearTableList_ajx()
	{
		$this->setParam("ctrl:ca_tabInfo", null);
		$f = igk_getctrl($this->SelectedController)->getDBConfigFile();
		if (file_exists($f))
			@unlink($f);
		igk_wl($this->ca_getTableInfo()->Render());
	}
	
	/*
	*CTRL ARTICLE AND CONFIGURATION VIEW ARTICLE
	*/
	public function View(){
		//VIEW: CTRLANDARTICLE
		$t = $this->TargetNode;
		if ($this->IsVisible)
		{

					
			HtmlUtils::AddItem($t, $this->ConfigNode);
			$t->ClearChilds();			
			
			igk_add_title($t, "title.ControllerManager");
			$t->addHSep();
			igk_add_article($this, "controller_and_article", $t->addDiv(), null,true);
			$t->addHSep();
			//add default form ctrl
				
			$this->_view_ctrl_EditCtrl($t);
			$t->addHSep();
			$this->__viewDefaultPageCtrl($t);
			$this->__viewMenuHostCtrl($t);
			
			$t->addHSep();
			
			$dv = $t->addDiv();
			$dv["class"] = "controller_info";
		    $this->_view_ctrl_info(igk_getctrl($this->SelectedController), $dv);
			
			$frm = $t->addForm();
			$frm->addBr();
			
			$frm->addBtn("btn_remove", R::ngets("btn.removeController") , "submit", array(
			"onclick"=>
			"javascript: return window.igk.ctrl.confirm_frame(this,'".
			R::ngets(IGK_MSG_DELETEFILE_QUESTION,$this->SelectedController)->getValue().
			"', '".$this->getUri("drop_controller") .
			"');"));
			
			$frm->addInput("confirm", "hidden", 0);			
			HtmlUtils::AddBtnLnk($frm, "btn.addcontroller",  igk_js_post_frame($this->getUri("ca_add_ctrl_frame_ajx")) );
			HtmlUtils::AddBtnLnk($frm, "btn.showcontrollerview",  igk_getctrl(IGK_CONF_CTRL)->getUri("cc_view_controllerschema"));
			
			$t->addHSep();
			
			$this->_buildViewArticle($t);			
			$t->addHSep();			
			$this->_buildViewView($t);
			
			$this->TargetNode->addScript()->Content = <<<EOF
window.igk.system.createNS("igk.fn.config", {select_ctrl: function(i, targetid, uri){var q = window.igk.getParentById(i, targetid ); window.igk.ajx.post(uri, null, function(xhr){  if (this.isReady()){ this.setResponseTo(q); var p = q.getElementsByTagName('select')[0]; p.focus(); }})}});
EOF;
			
		}
		else{
			$this->TargetNode->ClearChilds();
			igk_html_rm($this->TargetNode);
		}
		
	}
	public function _buildViewView($div)
	{	
		igk_add_title($div, "title.Views");
		$this->_viewViewFiles($div);
	}
	
	
	
	private function _view_ctrl_info($ctrl, $target)
	{
		if ($ctrl==null)
			return;
		
		
		
		$p = $target->addDiv();
		$p["class"]="conf_ctrl_info";
		$p->addDiv(array("class"=>"conf_selected_ctrl", "style"=>"color:#4D4E4D;text-shadow: 1px 0px gray; font-size:2em; font-family: 'centgot';" ))->Content = $this->SelectedController;
		
		$p->addDiv()->Content = R::ngets("Q.IsWEBPAGECTRL", igk_parsebools(is_subclass_of(get_class($ctrl), "IGKDefaultPageCtrl" ))->getValue());
		$p->addDiv()->Content = R::ngets("lb.CtrlType")->getValue() . " : ". igk_sys_ctrl_type($ctrl);
		
		$p->addBr();
		$table = $p->add("table");
		$table->add("tr")->add("th")->Content = R::ngets("title.Parent");
		
		if ( $ctrl->Configs->clParentCtrl != null)
		{
			$table->add("tr")->add("td")->add("li")->add("a", array("href"=>"#", "onclick"=>"javascript:window.igk.fn.config.select_ctrl(this, '".$this->TargetNode["id"]."', '".$this->getUri('select_controller_ajx&n='.$ctrl->Configs->clParentCtrl)."'); "))->Content = $ctrl->Configs->clParentCtrl;
		}
		else 
			$table->add("tr")->add("td")->Content =  R::ngets("msg.noparent");
		
		$p->addBr();
		$table = $p->add("table");
		$tr = $table->add("tr");
		$tr->add("th")->Content = R::ngets("title.Childs");
		$tr->add("th")->Content = R::ngets("title.index");
		
		if (igk_count($ctrl->Childs) > 0)
		{
	
			$tab = $ctrl->Childs;
			
			usort($tab, "igk_sort_byNodeIndex");
			
			foreach($tab as $k)
			{
				$tr = $table->add("tr");
				$tr->add("td")->add("a", array("href"=>IGK_JS_VOID,"onclick"=>"javascript:window.igk.fn.config.select_ctrl(this, '".$this->TargetNode["id"]."', '".$this->getUri('select_controller_ajx&n='.$k->Name)."'); return false; "))->Content = $k->Name; 				
				$tr->add("td")->Content = $k->TargetNode->Index;
			}
		}
		else {
			$tr = $table->add("tr");
			$tr->add("td")->Content = R::ngets("msg.nochilds");
			$tr->add("td")->Content = IGK_HTML_SPACE;
		}		
		$p->addHSep();
		//additional info entertaiment
		$table = $p->add("table");
		
			foreach($ctrl->Configs as $k=>$v)
			{
				if ($k == "clParentCtrl")
					continue;
				$tr = $table->add("tr");
				$tr->add("td")->add("label")->Content =R::ngets( "lb.".$k);
				$tr->add("td")->add("label")->Content = $v;			
			}
		//add controller info options
		$div =  $p->addDiv();
		$this->_view_ctrl_options($ctrl, $div);
	}
	
	public function edit_ctrl_drop_ajx()
	{
		$this->drop_controller($this->SelectedController);
	}	
	public function add_articleframe(){
		$frame = igk_add_new_frame($this, "add_article_frame", "#article");
		$frame->Title = R::ngets("title.addArticle", $this->m_selectedLang );
		$this->m_selectedLang = igk_getr("clLang", $this->m_selectedLang );
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("add_article");
		$frm->addSLabelInput(IGK_FD_NAME, "lb.Name");
		$frm->addBr();
		$lg = $this->m_selectedLang?$this->m_selectedLang:"fr";
		$frm->add("label")->Content = R::ngets("lb.currentlang",$lg );
		$frm->addInput("clLang", "hidden", $lg);
		$frm->addInput("clCtrl", "hidden", $this->SelectedController);
		
		
		$frm->addBr();
		$txt = $frm->addTextArea("clContent", null);
		igk_js_enable_tinymce($frm);
		$frm->addHSep();
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	public function add_viewframe(){
		$frame = igk_add_new_frame($this, "add_view_frame");
		$frame->Title = R::ngets("title.addView");
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("add_view");
		$frm->addSLabelInput(IGK_FD_NAME, "lb.Name");
		$frm->addBr();
		$frm->addTextArea("clContent");
		$frm->addHSep();
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}	
	public function drop_controller($ctrl=null)
	{	
		$a = $ctrl? $ctrl: igk_getr("controlleur");
		if ($a)
		{
			$is_ajx = (igk_sys_isAJX());
			if (igk_qr_confirm()){
				
				//throw new Exception(
				//igk_wln("EEE :::: ".igk_parsebool($is_ajx) . " " . self::CurrentUri());
				
				$ctrl = igk_getctrl($a);
				if ($ctrl->canDelete)
				{				
					igk_getctrl(IGK_CTRL_MANAGER)->removeController($a);	
					$this->SelectedController = null;
					$this->View();
					//clear an reconnect
					$ctrl = igk_getctrl(IGK_CONF_CTRL);		
					
					
					if ($is_ajx)
					{
						$out = $this->TargetNode->Render();
						$uri = $ctrl->getReconnectionUri()."&ajx=1";
						$index = igk_io_currentRelativePath("index.php");
						session_destroy();
						igk_navtocurrent($uri);
						return;
					}
					else 
						$ctrl->clearSessionAndReconnect(false);
				}
				else{
					$this->msbox->addError("impossible de supprimer le controller. cela peut entrainer des incohérences");
				}
			}
			else{
				$frame = igk_add_confirm_frame($this, "drop_controller_frame", $this->getUri("drop_controller&ajx=1"));				
				$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETECTRL_QUESTION, $a);
				$frame->Form->addInput("controlleur", "hidden", $a);
				if (igk_sys_isAJX())
				{
					$frame->Form->addInput("ajx", "hidden", "1");
					igk_wl($frame->Render());
				}
			}
		}
		
	}
	//::::
	public function _buildAdditionalInfo($ctrl, $p)
	{
		$d = null;
		if (is_object($ctrl))
		{
			$n = igk_sys_ctrl_type($ctrl);
			$d = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $n);
		}
		else if (is_string($ctrl))
		{
			$d = igk_getv(IGKCtrlTypeManager::GetControllerTypes(), $ctrl);
		}
		if ($d==null)
			return;
			
		$tab = call_user_func( array($d, "GetAdditionalConfigInfo"));
	if (is_array($tab))
		{
			foreach($tab as $k=>$v)
			{				
				if (is_object($v))
				{
					$li = $p->add("li");
					$li->addLabel("lb.".$k, $k);
					switch(strtolower($v->clType))
					{
						case "select":
							igk_html_build_select($li, $k, $li, $v->clValues, $v->clDefaultValue);
							break;
						case "file":
							break;
						case "bool":
							$li->addInput($k, "checkbox");
							break;
					}
					
				}
				else{
					$p->add("li")->addSLabelInput($v, $v , "text",  igk_getv( igk_getv($ctrl, "Configs"), $v) );
				}
			}
		}
	}
	public function ca_get_ctrl_type_info_ajx()
	{
		$p = $this->getParam("ca:view_frame");
		$n = igk_getr("n");
		if ($p!=null)
		{
			$p->ClearChilds();				
			$this->_buildAdditionalInfo($n, $p);
			igk_wl($p->innerHTML);	
		}
		else{
			igk_wl("no frame setup");
		}
		
	}
	//add controller frame
	public function ca_add_ctrl_frame_ajx($addframe=true)
	{
	
		$frame = igk_add_new_frame($this, "add_ctrl_frame");
		$frame->Title = R::ngets("title.AddController");
		$frame->ClearChilds();				
		$frm = $frame->Content->addForm();
		$frm["action"]= $this->getUri("ca_add_ctrl"); 
		$frm["onsubmit"]= "javascript: window.igk.ajx.postform(this,'".$this->getUri("ca_add_ctrl_ajx")."', new window.igk.ajx.targetResponse(document.body,null).update
		, false);  return false;";
		
		
		$frm->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name","text", null,null, true);
		$frm->add("li")->addSLabelInput("clDisplayName","lb.DisplayName");
		$li = $frm->add("li");
		$li->add("label", array("for"=>"clCtrlType"))->Content = R::ngets("lb.ctrlType");		
		//controller type
		$sel = igk_html_build_select($li, "clCtrlType", array_keys(IGKCtrlTypeManager::GetControllerTypes()), null, null);
		
		$sel["onchange"]="javascript: (function(q){window.igk.ajx.post('".
		$this->getUri("ca_get_ctrl_type_info_ajx&n=").
		"'+q.value,null,function(xhr){if (this.isReady()){ ".
		"var s = \$igk(q.form).getChildById('view_frame'); ".		
		" this.setResponseTo(s); ".
		"}})})(this);";
		$p = $this->getParam("ca:view_frame");
		if ($p == null)
		{
			$p = $frm->addDiv(array("id"=>"view_frame"));
			$this->setParam("ca:view_frame", $p);			
		}
		$p->ClearChilds();
		igk_html_add($p, $frm);
		$li = $frm->add("li");		
		$this->_frm_tablevisiblectrl($li, "clParentCtrl");
		$frm->add("li")->addSLabelInput("clTargetNodeIndex","lb.TargetNodeIndex");
		$frm->add("li")->addSLabelInput("clVisiblePages","lb.VisiblePages");
		$frm->add("li")->addSLabelInput("clDescription","lb.Description");
		$frm->addHSep();
		$frm->addInput("confirm", "hidden", "1");
		$frm->addBtn("btn_add", R::ngets("btn.Add"));			
		$frm->addScript()->Content ="(function(){var q = \$igk(igk.getParentScriptByTagName(\"form\")); var p = q.select(\"#liPageName\"); q.select(\"#clWebPage\").reg_event(\"change\",function(){ if (this.checked) p.css('display:block;'); else p.css('display:none'); });})();";
		if ($addframe)
			igk_wl($frame->Render());
		return $frame;
	}
	private function _frm_tablevisiblectrl($li, $name, $value =null, $showspace=true)
	{
		
		$tab = $this->__getVisibleCtrl();
		if (count($tab) > 0)
		{
			$li->add("label")->Content = R::ngets("lb.parentctrl");
			$sel = $li->add("select");	
			$sel["id"]=$sel["name"] = $name;
			if ($showspace)
				$sel->add("option", array("value"=>""))->Content = IGK_HTML_SPACE;
			foreach($tab as $v)
			{	
				$opt = $sel->add("option", array("value"=>$v->getName()));
				$opt->Content = $v->DisplayName;
				if ($value && !$value == $v->getName())
				{
					$this->value = $v->getName();
				}
			}
		}
	}
	//add controller
	function ca_add_ctrl_ajx()
	{

		if (igk_qr_confirm() && $this->ConfigCtrl->IsConnected)
		{
			if (igk_getctrl(IGK_CTRL_MANAGER)->add_ctrl(igk_getr("clWebPage",false), igk_getr("clParentCtrl",null)))
			{			
				igk_notifyctrl()->addMsgr("msg.controllerupdate");
			}
			igk_resetr();
			$this->setParam("ca:view_frame",null);
			$this->View();
			$this->ca_add_ctrl_frame_ajx(false);
			//load all page
			igk_wl($this->App->Doc->Render());//body->innerHTML);
			
		}
	}
	public function ca_add_ctrl(){
		
		if (igk_qr_confirm() && $this->ConfigCtrl->IsConnected)
		{		
			igk_getctrl(IGK_CTRL_MANAGER)->add_ctrl(igk_getr("clWebPage",false), igk_getr("clParentCtrl",null));		
			igk_resetr();
			$this->setParam("ca:view_frame",null);
			$this->View();
		}
		igk_navtocurrent();
	}
	
	public function add_article(){
		$ctrl = igk_getr("clCtrl");
		$name = igk_getr(IGK_FD_NAME);
		$content = igk_getr("clContent");
		$lang = igk_getr("clLang");
		$e = HtmlItem::CreateWebNode("error");
		if (IGKValidator::IsStringNullOrEmpty($name)){ $e->add("li")->Content = "name not defined";}
		if (IGKValidator::IsStringNullOrEmpty($content)){ $e->add("li")->Content = "Content not defined";}
		if (IGKValidator::IsStringNullOrEmpty($lang)){ $e->add("li")->Content = "Language not define";}
		
		if (!$e->HasChilds)
		{
		$obj_ctrl = igk_getctrl($ctrl);
		$d = dirname($obj_ctrl ->getDeclaredFileName());
		
			$a = $d."/Articles";
			IGKIO::CreateDir($a);
			if (preg_match("/\.phtml$/i", $name))
				$file = $a."/".$name;
			else{				
				$file =$a."/".$name.".".strtolower($lang).".phtml";
			}
			
			if ($this->__write_article($file, igk_html_unscape($content)))
			{
				igk_resetr();
				igk_setr("controlleur", $ctrl );
				$obj_ctrl->View();
			}
			else{
				igk_notifyctrl()->addError(R::ngets("Err.FileNotSAVED"));
			}
		}
		else{
			$this->msbox->copyChilds($e);
		}
		$this->View();
		igk_navtocurrent();
	}
	
	public function add_view(){
		$n = igk_getr(IGK_FD_NAME);
		$ctrl = $this->SelectedController;
		$content = igk_getr("clContent");
		$this->val->ClearChilds();
		
		if (IGKValidator::IsStringNullOrEmpty($n)){ $this->val->add("li")->Content = "Name not defined";}
		
		if (!$this->val->HasChilds)
		{
			
			$a = igk_getctrl($ctrl)->getViewDir();
			if (IGKIO::CreateDir($a)){
				$file =$a."/".$n.".phtml";
				IGKIO::WriteToFileAsUtf8WBOM($file, igk_html_unscape($content), true);						
			}
		}
		else{
			$this->msbox->copyChilds($this->val);
		}
		$this->View();
		igk_navtocurrent();
		
	}

	public function getConfigPage()
	{
		return "articleconfig";
	}
	
	
	
	public function InitComplete()
	{
		parent::InitComplete();
		$this->setup_defaultpage();
	}
	
	public function __construct(){
		parent::__construct();
		$this->m_SelectedController = null;
		$this->m_SelectedControllerChangedEvent = new IGKEvents($this, "SelectedControllerChanged");
		$this->m_SelectedControllerChangedEvent->add($this, "ca_selectedCtrlChanged");
	}

}


//File Manager
final class IGKFileManagerCtrl extends IGKConfigCtrlBase
{
	private $m_directory;
	
	public function fm_updatefile()
	{
		$url = igk_getr("uri");
		$content = igk_getr("content");
		if (($url == null) || is_file($url))
		{
				return;
		}
		IGKIO::WriteToFileAsUtf8WBOM($url, $content , true);		
	}
	public function createfile()
	{
		$url = igk_getr("uri");
		if (($url == null) || is_file($url))
		{
				return;
		}
		IGKIO::WriteToFileAsUtf8WBOM($url, "", true);		
	}
	public function getConfigPage()
	{
		return "filemanager";
	}
	
	public function __construct(){
		parent::__construct();
	}
	public function loadfiles_frame()
	{
		$frame = igk_add_new_frame($this, "upload_files_frame");
		$frame->Content->ClearChilds();
		$frame->Title = R::ngets("title.loadFilesFrames");
		$frame->Width = "300px";
		$d = $frame->Content;
		$frm  = $d->addForm();
		$frm["action"] = $this->getUri("loadfiles");
		
		$frm->addFile("clFile", true);
		$frm->addInput("MAX_FILE_SIZE", "hidden", "15000000");
		$frm->addHSep();
		$frm->addBtn("btn_confirm", R::ngets("btn.upload"));
	}
	public function createdir_frame()
	{
		$frame = igk_add_new_frame($this, "createdir_frame");
		$frame->Title = R::ngets("title.createDirFrame");
		$frame->Content->ClearChilds();
		$frame->Width = "300px";
		$d = $frame->Content;
		$frm  = $d->addForm();
		$frm["action"] = $this->getUri("createdir");
		
		$frm->addSLabelInput(IGK_FD_NAME, "lb.dirname");
		$frm->addHSep();
		$frm->addBtn("btn_confirm", R::ngets("btn.create"));
	}
	public function createdir()
	{
		$ndir = igk_getr(IGK_FD_NAME);
		if (empty($ndir))
			return;
		$path = igk_io_getdir(igk_io_currentRelativePath($this->m_directory)."/".$ndir);
		if (!is_dir($path))
		{
			mkdir($path);
			$this->View();
		}
	}
	public function loadfiles()
	{
		$t = igk_getv($_FILES,"clFile");		
		$path = igk_io_currentRelativePath($this->m_directory);
		igk_frame_close("upload_files_frame");
		$error = false;
		if (is_array($t["name"]))
		{
			for($i =0; $i< count($t["name"]) ; $i++)
			{
				if ($t["error"][$i] == 0)
				 {
				move_uploaded_file($t["tmp_name"][$i], igk_io_getdir($path."/".$t["name"][$i]));
				}
				else{
					igk_notifyctrl()->addError("can't upload file [".$t["name"][$i]."] error : ".$t["error"][$i]." " .ini_get("upload_max_filesize")." file is authorized" );
					$error = true;
				}
			}
		}
		else{
			if ($t["error"]==0)
			{
				move_uploaded_file($t["tmp_name"], igk_io_getdir($path."/".$t["name"]));
				$error = true;
			}
		}
		if (!$error)
		{
			igk_notifyctrl()->addMsgr("MSG.FileUploadSuccess");
		}
		$this->View();		
		//exit;
		igk_navtocurrent();
		
	}
	
	
	public function View()
	{
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$c = $this->TargetNode;
		
		HtmlUtils::AddItem($c, $this->ConfigNode);
		$c->ClearChilds();
		
		$d = $c->addDiv();
		igk_add_title($d, "title.FileManager");
		$d->addHSep();
		igk_add_article($this, "filesystem.description", $d->addDiv());
		$d->addHSep();
		//action list
		HtmlUtils::AddBtnLnk($d, R::ngets("btn.loadFiles") , $this->getUri("loadfiles_frame"));		
		HtmlUtils::AddBtnLnk($d, R::ngets("btn.createDir") , $this->getUri("createdir_frame"));
		$d->addHSep();		
		//show path list
		$sep = explode(DIRECTORY_SEPARATOR , $this->m_directory);
		if (($count = count($sep))>0)
		{
			$path = $d->addDiv();
			//$path->Content = $this->m_directory;
			$cpath =null;
			for($i = 0; $i<$count; $i++)
			{
				if ($i!= 0){
					$path->add("span", array("class"=>strtolower($this->getName()."_dirseparator")))->Content  = "&gt;";
					$cpath .= DIRECTORY_SEPARATOR;
				}
				$cpath .=  $sep[$i];
				$path->add("span",  array("class"=>strtolower($this->getName()."_dir")))->add("a", 
				array(
					//"href"=>$this->getUri("open_fulldir&d=".urlencode($cpath)),
					"onclick"=>"javascript: (function(i){var q= window.igk.getParentById(i, '".
					$this->TargetNode["id"]."'); if (q){ window.igk.ajx.post('".
					$this->getUri("gotoparent_ajx")."', null, function(xhr){ if (this.isReady()){ q.innerHTML = xhr.response;}});}})(this); return false;",
					)
				)->Content  = $sep[$i];
			}
		
		}
		//
		$this->_showdir($this->m_directory);
		
	}
	public function open_fulldir()
	{
		$this->m_directory = igk_getr("d");
		$this->View();
	}
	public function open_fulldir_ajx()
	{
		$this->open_fulldir();
		igk_wl($this->TargetNode->innerHTML);		
	}
	
	
	private function _showdir($dir)
	{
		$path = igk_io_currentRelativePath($dir);
		//protection
		if (!is_dir ($path))
		{
			$this->m_directory = null;
			$this->_showdir($this->m_directory);
			return;
		}
		$tab = $this->TargetNode->add("table", array("class"=>"config_file_listview fitw"));
		$tr = $tab->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = R::ngets("clSize");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		
		
		$hdir = opendir($path);
		$cangotoperent = false;
		if ($hdir)
		{
			$files = array();
			$dirs = array();
			while(($cdir = readdir($hdir)))
			{
				if (($cdir==".") || ($cdir== ".."))
				{			
					if (($dir!=null) && ($dir != '/') && ($cdir =="..") && ($dir!="."))
					{	
						$cangotoperent = true;
					}
					continue;
				}
				
				$cf = igk_io_getdir($path."/".$cdir);
				if (is_dir($cf))
				{
					$dirs[$cdir] = $cf;
				}
				else if (is_file($cf))
				{
					$files[$cdir] = $cf;
				}
			}			
			closedir($hdir);
			
			//sorlist 
			igk_array_sortkey($files);
			igk_array_sortkey($dirs);
			
			if ($cangotoperent)
			{	
				$tr = $tab->add("tr");
				$tr->add("td")->Content = IGK_HTML_SPACE;
				$tr->add("td", array("colspan"=>"6"))->add("li")->add("a", array(
				"href"=>$this->getUri("gotoparent"),
				"onclick"=>"javascript: (function(i){var q= window.igk.getParentById(i, '".$this->TargetNode["id"].
				"'); if (q){ window.igk.ajx.post('".$this->getUri("gotoparent_ajx")."', null, function(xhr){ if (this.isReady()){ q.innerHTML = xhr.response; }});}})(this); return false;",
				"class"=>"config_fileviewdir"))->Content ="..";
				
			}	
			
			foreach($dirs as $k=>$v)
			{
	
			$f = base64_encode(urldecode($k));
				$tr = $tab->add("tr");
				
						$li = $tr->add("td",array("style"=>"width:16px;"))->add("li");
				$li->addInput("", "checkbox",null,null);
				
				$tr->add("td")->add("li")->add("a", array(
					"href"=>$this->getUri("opendir&d=".urldecode($k)),
					"class"=>"config_fileviewdir",
					"onclick"=>"javascript:(function(i){var q= window.igk.getParentById(i, '".$this->TargetNode["id"]."');if (q){ window.igk.ajx.post('".$this->getUri("opendir_ajx&d=".urldecode($k)).
					"', null, function(xhr){ if (this.isReady()){ this.setResponseTo(q); window.igk.window.saveHistory(i.href);}}); return false;}})(this); return false;"))->Content = $k;
					
				$tr->add("td",array("style"=>""))->Content = IGK_HTML_SPACE;
				$tr->add("td",array("style"=>""))->Content = IGK_HTML_SPACE;
				HtmlUtils::AddImgLnk($tr->add("td",array("style"=>"min-with:16px; min-height:16px;")),$this->getUri("change_authorization&d=".$f),"ico_auth");
				
				if (IGKIO::IsDirEmpty($v)){
					
					
					HtmlUtils::AddImgLnk($tr->add("td",array("style"=>"with:16px; height:16px;")),$this->getUri("drop_dir_or_file&d=".$f),"drop");
				}
				else
					$tr->add("td")->Content = IGK_HTML_SPACE;
				$tr->add("td",array("style"=>""))->Content = IGK_HTML_SPACE;
			}
			//select|filename|size|edit|changeautorisation|drop
			foreach($files as $k=>$v)
			{
				$f = base64_encode(urldecode($k));
				$tr = $tab->add("tr");
				
				$li = $tr->add("td", array("style"=>"width:16px;"))->add("li");
				$li->addInput("", "checkbox",null, null);
				$li = $tr->add("td")->add("li");
				$li->add("a", array("href"=>$this->getUri("getfile&d=".$f),
				"class"=>"config_fileviewfile"))->Content = $k;
				$file = igk_io_currentRelativePath($this->m_directory ."/".$k);
				if (file_exists($file))
				{
					$size = @filesize($file);
					if ($size === false)
					{
						$tr->add("td", array("class"=>"alignr"))->Content = "?";
					}
					else
						$tr->add("td",array("class"=>"alignr"))->Content = IGKIO::GetFileSize( $size);
				}
				else 
					$tr->add("td")->Content = "broken";
				
				HtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("edit&d=".$f),"edit");
				HtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("change_authorization&d=".$f),"ico_auth");
				HtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px; min-height:16px")),$this->getUri("fc_renameframe&d=".$f),"ico_rename");
				HtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px")),$this->getUri("drop_dir_or_file&d=".$f),"drop");
			}
			
			$this->TargetNode->addHSep();
			HtmlUtils::AddBtnLnk($this->TargetNode, R::ngets("btn.rmAll"), $this->getUri("removeAll"));
			igk_html_toggle_class($tab);
		}
	}
	public function fc_renameframe()
	{
		$d = urldecode(base64_decode(igk_getr("d")));
		$frame = igk_add_confirm_frame($this, "rename_file_frame", $this->getUri("fc_rename"));		
		$frame->Title = R::ngets("title.renamefile",$d);
		$div = $frame->Form->Div;		
		$div->addInput("d", "hidden", igk_getr("d"));
		$div->addSLabelInput(IGK_FD_NAME, IGK_FD_NAME, "text", $d);
		
		
	}
	//rename file
	public function fc_rename()
	{
		$d = urldecode(base64_decode(igk_getr("d")));
		$e = igk_getr(IGK_FD_NAME);
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		$out = igk_io_currentRelativePath($this->m_directory ."/".$e);
		rename($file, $out);
		$this->View();	
	}
	public function removeAll()
	{
		if (igk_qr_confirm())
		{
		  igk_notifyctrl()->addError("Dont be so .... No Implement ".  __LINE__);
		}
		else{
			$frame = igk_add_confirm_frame($this, "confirm_remove_all", $this->getUri("removeAll"));		
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DROPALL_QUESTION);
		}
	}
	public function change_authorization()
	{
	
		if (!igk_is_conf_connected())
			return;
		$d = urldecode(base64_decode(igk_getr("d")));
		
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);	
		if (!igk_qr_confirm())
		{
		function addcheckbox($li, $name, $check, $key){
			$li->addInput($name, "checkbox", false, array("checked"=>$check));
			$li->add("label", array("for"=>$name))->Content = R::ngets($key);
		}
		
		$frame = igk_add_confirm_frame($this, "change_authorization_frame", $this->getUri("change_authorization"));		
		$frame->Title = R::ngets("title.changeFileAuthorization", $d);
		$div = $frame->Form->Div;
		$div->addDiv()->Content = R::ngets("lb.user");
		$div->addHSep();
		$c = $div->add("ul");
		$perms = @fileperms($file); 
		addcheckbox($c->add("li"),"ur",false,"lb.Read");
		addcheckbox($c->add("li"),"uw",false,"lb.Write");
		addcheckbox($c->add("li"),"ux",false,"lb.Execute");
		
		$div->addDiv()->Content = R::ngets("lb.group");
		$div->addHSep();
		$c = $div->add("ul");
		
		addcheckbox($c->add("li"),"gr",false,"lb.Read");
		addcheckbox($c->add("li"),"gw",false,"lb.Write");
		addcheckbox($c->add("li"),"gx",false,"lb.Execute");
		
		$div->addDiv()->Content = R::ngets("lb.other");
		$div->addHSep();
		$c = $div->add("ul");
		
		addcheckbox($c->add("li"),"or",false,"lb.Read");
		addcheckbox($c->add("li"),"ow",false,"lb.Write");
		addcheckbox($c->add("li"),"ox",false,"lb.Execute");
		$div->addHSep();
		$div->addDiv()->Content = R::ngets("lb.Recusivity");
		addcheckbox($div->addDiv(),"clRecursif",true,"lb.Recursive");
		
		$frame->Form->addInput("d", "hidden", base64_encode(urlencode($d)));
		}
		else{
			$u = 0;
			$g=0;
			$o=0;
			$u |= igk_getr("ur")?4:0;
			$u |= igk_getr("uw")?2:0;
			$u |= igk_getr("ux")?1:0;
			
			$g |= igk_getr("gr")?4:0;
			$g |= igk_getr("gw")?2:0;
			$g |= igk_getr("gx")?1:0;
			
			$o |= igk_getr("or")?4:0;			
			$o |= igk_getr("ow")?2:0;
			$o |= igk_getr("ox")?1:0;
			$v = '0'.$u.''.$g.''.$o;			
			if (file_exists($file) ||is_dir($file))
			{
				if (is_dir($file) && igk_getr("clRecursif"))
				{
					$r = igk_file_chmod($file, octdec($v), true);
				}
				else
					$r = @chmod($file, octdec($v));
				if ($r){
					igk_notifyctrl()->addMsg("Permission changer ", substr(sprintf('%o', $file), -4));
				}
				else
					igk_notifyctrl()->addError("Impossible de changer les autorisation de [".basename($file)."]");
			}
			// igk_wln( $file . " : ".$v);
			// igk_wln( octdec ($v));
			// igk_wln(substr(sprintf('%o', fileperms($file)), -4));
			// exit;
			
		}
		
	}
	public function drop_dir_or_file()
	{
		if (!igk_is_conf_connected())
		{return;}
		$d = urldecode(base64_decode(igk_getr("d")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			if (igk_qr_confirm()){
				unlink($file);
				$this->View();
			}
			else{
				$frm = igk_add_confirm_frame($this, "confirm_file_delete", $this->getUri("drop_dir_or_file"));				
				$frm->Form->Content = R::ngets(IGK_MSG_DELETEFILE_QUESTION, basename($file));
				$frm->Form->addInput("d","hidden",base64_encode(urlencode($d)));
			}
		}
		else if (is_dir($file))
		{
			if (igk_qr_confirm()){
				rmdir($file);				
				$this->View();
			}
			else{
				$frm = igk_add_confirm_frame($this, "confirm_file_delete",$this->getUri("drop_dir_or_file"));
				$frm->Form->Content = R::ngets(IGK_MSG_DELETEDIR_QUESTION, basename($file));
				$frm->Form->addInput("d","hidden",base64_encode(urlencode($d)));
			}
		}
	}
	public function getfile($file = null)
	{
		if (!igk_is_conf_connected())
				return ;
		$d = urldecode(base64_decode(igk_getr("d")));
		
		$file = $file? $file: igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			$size = filesize($file);
			igk_download_content(basename($file), $size,  IGKIO::ReadAllText($file));		
			exit;
		}
	}
	public function edit()
	{
		if (!igk_is_conf_connected())
				return ;
		$d = urldecode(base64_decode(igk_getr("d")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			$frame = igk_add_new_frame($this, "config_edit_file", "#filesystem",$this->App->Doc->body); 			
			$str = IGKIO::ReadAllText($file);
			$frame->Title = R::ngets("title.editFile", basename($file));		
			$frame->ClearChilds();
			$d = $frame->Content;
			$frame = $d->addForm();
			$frame["action"]=$this->getUri("updatefile#fileman");
			$ul = $frame->add("ul");
			$ul->add("li")->addTextArea("clContent", utf8_decode($str));
			$frame->addInput("clfile", "hidden", base64_encode(urlencode(basename($file))));
			$frame->addHSep();
			$frame->addBtn("btn_update", R::ngets("btn.Update"));
	
		}
	}
	public function updatefile()
	{
		if (!igk_getctrl(IGK_CONF_CTRL)->IsConnected)
				return ;
		$d = urldecode(base64_decode(igk_getr("clfile")));
		$file = igk_io_currentRelativePath($this->m_directory ."/".$d);
		if (is_file($file))
		{
			igk_io_saveContentFromTextArea($file, igk_getr("clContent"), true);			
			igk_frame_close("config_edit_file");
		}
		igk_navtocurrent();
	}
	public function opendir_ajx()
	{
		$d = (igk_getr("d"));
		if ($d)
		{
			if (($this->m_directory == null)||($this->m_directory=="/"))
				$this->m_directory = $d;
			else 
				$this->m_directory .= "/".$d;
			$this->View();			
		}
		
		igk_wl($this->TargetNode->innerHTML);
	}
	public function opendir()
	{
		$d = (igk_getr("d"));
		if ($d)
		{
			if (($this->m_directory == null)||($this->m_directory=="/"))
				$this->m_directory = $d;
			else 
				$this->m_directory .= "/".$d;
			$this->View();
			igk_navtocurrent();
		}
	}
	public function gotoparent()
	{
		$c = dirname($this->m_directory);
		if (!empty($c))
		{
				$this->m_directory = $c;
				$this->View();
		}
	}
	public function gotoparent_ajx()
	{
		$c = dirname($this->m_directory);
		if (!empty($c))
		{
				$this->m_directory = $c;
				$this->View();
				igk_wl($this->TargetNode->innerHTML);
		}
	}
}

final class HtmlNotificationItem extends HtmlItem
{
	private $m_isRendered ;
	private $m_owner;
	private $m_script;
	public function getisRendered(){return $this->m_isRendered; }
	public function __construct($owner=null)
	{
		parent::__construct("div");
		$this->m_isRendered = false;
		$this->m_script = HtmlItem::CreateWebNode("script");
		$this->m_script->Content = "igk.winui.notifyctrl.init(igk.getParentScript());";
		$this->m_owner = $owner;
		$this["class"]="igknotificationctrl";
		$this["igk-control-type"] = "notifyctrl";
		$this["id"] ="igknotificationctrl";
	}
	public function Render($xmloption=null)
	{
		igk_html_add($this->m_script, $this);
		$out = parent::Render($xmloption);
		$this->m_isRendered = true;
		$this->ClearChilds();
		$this->m_owner->MsError = false;
		return $out;
	}
	public function __toString(){return "HtmlNotificationItem"; }
}
final class IGKNotificationCtrl extends IGKControllerBase
{
	private $m_mserror;
	private $m_notifyhost;
	
	public function getMsError(){return $this->m_mserror; }
	public function setMsError($v){ $this->m_mserror = $v; }
	public function getName(){return IGK_NOTIFICATION_CTRL;}
	
	public function setNotifyHost($notifyhost)
	{
		$this->m_notifyhost = $notifyhost;
	}
	public function getNotifyHost(){
		if ($this->m_notifyhost == null)
			$this->m_notifyhost = $this->app->Doc->body;
		return $this->m_notifyhost;
	}
	
	public function InitComplete(){
		parent::InitComplete();
		$this->App->Session->addUpdateSessionEvent($this, "notifyCompleted");
		igk_getctrl(IGK_CONF_CTRL)->regView($this, "View");
	}
	public function notifyCompleted()
	{
		if ($this->TargetNode->isRendered)
		{
			$this->View();
		}
	}
	public function initTargetNode()
	{
		$v =  new HtmlNotificationItem($this);
	
		return $v;
	}
	
	public function addError($msg)
	{
		$this->TargetNode->add("li", array("class"=>"igk-notify_b"))->Content = $msg;
		$this->m_mserror = true;
		$this->View();
	}
	
	public function addErrorr($key)
	{
		$this->addError(R::ngets($key));
	}
	public function addWarningr($msg){
		$this->addWarning(R::ngets($msg));
	}
	public function addWarning($msg){
		$this->TargetNode->add("li", array("class"=>"igk-notify_w"))->Content = $msg;
		$this->m_mserror = true;
		$this->View();
	}
	public function addInfor($msg){
		$this->addInfo(R::ngets($msg));
	}
	public function addInfo($msg){
		$this->TargetNode->add("li", array("class"=>"igk-notify_i"))->Content = $msg;
		$this->m_mserror = true;
		$this->View();
	}
	public function addErrori($msgcode)
	{
		$c = igk_error($msgcode);
		if ($c){
			$li = HtmlItem::CreateWebNode("div",array("class"=>"alignl"));			
			$li->add("label")->Content = "Message : ";
			$li->add("span")->Content = R::ngets($c["Msg"]);		
			$this->addError($li->Render(null));
		}
	}
	
	public function addMsgr($msg)
	{
		$this->addMsg(R::ngets($msg));
	}
	public function addMsg($msg)
	{
		$this->TargetNode->add("li", array("class"=>"igk-notify_g"))->Content = $msg;
		$this->m_mserror = true;
		$this->View();
	}
	
	public function notify_ajx()
	{
		
		$this->TargetNode->RenderAJX();
		$this->m_mserror = false;
		$this->setParam("ajx:context", null);
	}
	public function View()
	{
		
		if (!$this->m_mserror)
		{
			igk_html_rm($this->TargetNode);
		}
		else{
			$this->TargetNode->setIndex(-10000);
			
			if ($this->TargetNode->HasChilds)
			{
					$v_target = null;
					if ($this->CurrentPageFolder == IGK_CONFIG_MODE)
					{					
						$v_target = igk_getctrl(IGK_CONF_CTRL)->ConfigNode;											
					}
					else{					
						$v_target = $this->NotifyHost;
						
					}
					
				if (igk_sys_isAJX())
				{
					//load view to this controller		
					if ($this->getParam("ajx:context") == null)
					{
						$this->setParam("ajx:context", true);					
						
						$d = HtmlItem::CreateWebNode("span");
										$js =($this->CurrentPageFolder == IGK_CONFIG_MODE)? 
											igk_getctrl(IGK_CONF_CTRL)->ConfigNode["id"] :
											(($this->NotifyHost == $this->app->Doc->body)? "" :  $this->NotifyHost["id"]); 
										
$d->addScript()->Content = <<<EOF
(function(){var r = null; var q = (r =\$igk('{$js}'))==null? document.body : r.owner; window.igk.ajx.post('{$this->getUri("notify_ajx")}', null, function(xhr){ if (this.isReady()){ this.prependResponseTo(q);  } });})();
EOF;
										$s = new HtmlSingleViewItem( $d);
										$s->RenderAJX();				
					}
					else{
						igk_debug_wln("not visible");
					}
				}
				else{
					igk_html_add($this->TargetNode, $v_target);
				}
			}
			else{
				igk_html_rm($this->TargetNode);
			}
			
			
		}
	}	
	
}

final class IGKConfigData
 {
	private $m_configCtrl;
	private $m_configEntries;
	private $m_confile;
	
	public function __toString(){
	return "IGKConfigurationData [Count: ".count($this->m_configEntries)."]";
	}
	public function SortByKeys()
	{
		$keys = array_keys($this->m_configEntries);
		sort($keys);
		$t = array();
		foreach($keys as $k)
		{
			$t[$k] = $this->m_configEntries[$k];
		}
		$this->m_configEntries = $t;
		
	}
	
	//@@@ full path to
	//@@@ conffile : configuration file
	//@@@ configctrl : hosted controller
	//@@@ entries: default entry
	public function __construct($conffile , $configCtrl, $entries){
		$this->m_confile = $conffile;
		$this->m_configCtrl = $configCtrl;
		$this->m_configEntries = $entries;
		
	}
	public function __get($key){
		if (isset($this->m_configEntries[$key]))
			return $this->m_configEntries[$key];
		return null;
	}
	public function __set($key, $value){
		
		if (isset($this->m_configEntries[$key]))
		
		{
			if ($value == null)
			{
				unset($this->m_configEntries[$key]);
			}
			else{
				$this->m_configEntries[$key] = $value;
			}
		}	
		else if (is_string($value) && !empty($value))
		{
			$this->m_configEntries[$key] = $value;
		}
	}
	//
	public function saveData(){
	
		$file = $this->m_confile; 			
		$out = "";
		$v_ln = false;
		foreach($this->m_configEntries as $k=>$v)
		{
			if ($v_ln)
			{
				$out .= IGK_LF;
			}
		
		else {
					$v_ln  = true;		
			}
			$out .= IGKCSVDataAdapter::GetValue($k).igk_csv_sep().IGKCSVDataAdapter::GetValue($v);				
		}		
		return IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);
	}

		public function getEntriesKeys()
		{
			return array_keys($this->m_configEntries);
		}
		public function getEntries(){
			return $this->m_configEntries;
		}
}


final class IGKConfigCtrl extends IGKControllerBase
implements IIGKConfigController
{
	private $m_configuration;
	private $m_ConfigUser;
	private $m_configEntries;
	private $m_ConfigNode;
	private $m_configMenuNode;
	private $m_menuCtrl;	
	private $m_connectBtn;
	private $m_selectedconfigCtrl;
	private $m_datas;
	private $m_menuName;
	private $m_headerNode;	
	private $m_connexionFrame;
	private $m_configFrame;//frame for config
	private $m_oldState;
	private $m_configInfo;
	
	
	
	
	const CHANGE_REG_KEY = "IGKConfigDataChanged";
	//---------------------------------------------------------------------------
	//events
	//---------------------------------------------------------------------------
	private $m_ConfigUserChangedEvent; //user changed
	private $m_configSettingChangedEvent;  // setting changed
	
	public function getName(){return IGK_CONF_CTRL; }
	
	
	public function  getConfigInfo(){return $this->m_configInfo; }
	public function  getConfigNode(){return $this->m_ConfigNode; }
	
	public function getConfigMenuNode(){return $this->m_configMenuNode;}
	public function getSelectedConfigCtrl(){return $this->m_selectedconfigCtrl;}
	public function getSelectedMenuName() { return $this->m_menuName; }
	public function getData(){ return $this->m_datas;}
	//get a administrative user
	public function getConfigUser(){ return $this->m_ConfigUser;}
	//get a administrative user is connected
	public function getIsConnected(){
		return ($this->ConfigUser!=null);
	}
	//get is connected and in config page
	public function getIsConfiguring()
	{		
		return ($this->getIsConnected())&&($this->App->CurrentPageFolder == IGK_CONFIG_MODE);
	}
	public function getCanConfigure()
	{
		return ($this->getIsConnected());
	}
	public function showConfig()
	{
		$this->View();
	}
	public function getConfigPage(){
		return "configs";
	}
	
	public function getReconnectionUri()
	{
		$q = array("u"=>$this->ConfigUser->Login,
			"pwd"=>md5($this->ConfigUser->Pwd),
			"selectedCtrl"=>$this->SelectedConfigCtrl? $this->SelectedConfigCtrl->Name:null,
			"selectPage"=>$this->SelectedMenuName);
		$uri = $this->getUri("startconfig&q=".base64_encode(
		'?'.http_build_query($q)));	
		return $uri;
	}
	
	public function clearSessionAndReconnect()
	{	
		if ($this->IsConnected)
		{
			
			igk_getctrl(IGK_SESSION_CTRL)->clearS(false);				
			$uri = $this->getReconnectionUri();			
			igk_navtocurrent($uri);						
		}
		else 
			igk_navtocurrent();
	}
	//cc: config controller function 
	public function cc_view_controllerschema()
	{
		$frame = igk_add_new_frame($this, "configctrlschema_frame");
		$d = $frame->Content;
		$frame->Title = R::ngets("title.viewcontrollerschema");
		$d->ClearChilds();
		$d->addDiv()->Content = "Schema structurel";
		$d->add("image" , array("src"=>$this->getUri("cc_controllerschema")));
		
	}
	public function cc_controllerschema()
	{
		$this->App->ControllerManager->cm_controllerschema();
	}
	
	
	//
	//a fin de mainternir la connexion lors de la suppression d'un controller
	//restart la configuration
	public function reloadConfig($uri)
	{
		$tab = igk_getquery_args($uri);
		igk_show_prev($tab);
		
	}
	public function startconfig()
	{
		$q = base64_decode(igk_getr("q"));
		$ajx = igk_getr("ajx");
		$tab = igk_getquery_args($q);
		
		$this->m_ConfigUser =(object)array("Login"=>$tab["u"], "Pwd"=>$tab["pwd"]);
		$ctrl = igk_getctrl(igk_getv($tab, "selectedCtrl", IGK_CONF_CTRL ));
		$p = igk_getv($tab, "selectPage","default");		
		
		if ($ctrl)
		{		
			//show controller config
			$ctrl->showConfig();		
		}
		else{
			//show this config
			$this->ShowConfig();
		}
		if (!$ajx)
		{
			igk_navtocurrent();		
			exit; 
		}
		else{
			//render selected target node from ajx context
			if($ctrl)
				igk_wl($ctrl->TargetNode->Render());
		}
	}
	//@@@ set selected menu config
	//@@@ $ctrl = selected config controller
	//@@@ $menuname = menu name
	//@@@ $context = from context. info
	public function setSelectedConfigCtrl($ctrl, $fromContext=null){ 
		
		if ($this->m_selectedconfigCtrl !== $ctrl)
		{
			$this->m_selectedconfigCtrl = $ctrl;
			if ($ctrl && $ctrl->ConfigPage)
			{
				$this->_loadConfig();
				$this->_selectMenu($ctrl->ConfigPage, "IGKConfigCtrl");
				
			}	
		}
	}
	protected function _selectMenu($page, $context=null)
	{
			$this->m_menuCtrl->selectConfigMenu($page, "IGKConfigCtrl");
			$this->m_menuName = $page;
	}
	
	protected function initTargetNode()
	{
		$node = HtmlItem::CreateWebNode("div", array("class"=>"igk-config-page fitw fith"));	
		
		$this->m_configFrame = HtmlItem::CreateWebNode("div", array("class"=>"igk-config-frame"));		
		$this->m_headerNode =$this->m_configFrame->addDiv(array("class"=>"igk-config-header-node fitw fith"));
		
		
		$div = $this->m_configFrame->addDiv(array("class"=>"fitw disptable"));
		
		
		$this->m_configMenuNode= $div->addDiv(array("id"=>"igk-config-menu", "class"=>"igk-config-menu"));
		$this->m_ConfigNode = $div->addDiv(array("id"=>"igk-config-content", "class"=>"igk-config-content"));	
		$this->m_configInfo =  $div->addDiv(array("id"=>"igk-config-info", "class"=>"igk-config-info"));	
		
		
		
		//init connection frame		
	$frm = HtmlItem::CreateWebNode("form", array("class"=>"connexion_frame"));	
	//vertical line	
	$frm["method"]="POST";
	$frm["action"]=$this->getUri("connect");
	$a = HtmlItem::CreateWebNode("a", array("href"=>new HtmlRelativeUriValueAttribute()));
	$a->Content =  "Go to index";
	$a["style"]="color:white;";
$igk_framename = IGK_FRAMEWORK;
$igk_version = IGK_VERSION;


if (igk_agent_isAndroid())
{
	$frm["class"]="-connexion_frame fitw alignc alingm connexion_frame_android ";
	$frm["style"]="height:8px; top:50%; line-height:8px; vertical-align:middle; margin-top:-4px; background-color:indigo; position:relative;";
	$div = $frm->addDiv();
	$div["class"] = "dispib ";
	$div["style"]  = "padding: 16px; height:300px; background-color: green; margin-top:-152px; line-height:normal; vertical-align:middle;";
	
	$div->add("label")->Content = "Login";
	$div->addDiv()->addInput("login", "text");
	
	$div->add("label")->Content = "Password";
	$div->addDiv()->addInput("pwd", "password");
	$div->addInput("btn_connect","submit");
	$div->addDiv()->Content = "${igk_framename} - ${igk_version}<br />
Configuration Manager";

	
}
else{


$out = <<<EOF
<div id="connectionTag" class="igk-config-conexion-div">
<div id="LayerDocument_52559464" style=" width:300px; height:400px; position:relative; color:white;  display:inline-block;" >
 
<div id="id_layer" style="width:300px; height:400px; z-index:0; position:absolute;">
<div id="id_board"  style="width:301px; height:401px; position:absolute; padding-top: 48px; background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAAGRCAYAAAAw6+XgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAU5SURBVHhe7dSxCcAwAANB7b+bZ0ogtQfIwwmuUv/bzgPQ8O12APyRaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkmJmltr04BXpXuO4PkAAAAABJRU5ErkJggg==');left:0px; top:0px;">
	<ul  >
	<li><label class="cllabel" >Login</label><input type="text" name="login" class="cltext" /><br /></li>
	<li><label class="cllabel" >Password</label><input type="password" name="pwd" class="clpassword" /><br /></li>
	</ul>	
	<br /><br />
	<li><input type="submit" class="clsubmit" name="connect" value="connexion" /></li>	
	
</div>
<div id="id_content" style="width:301px; height:131px; position:absolute;background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAACDCAYAAADYgk3EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAIqSURBVHhe7cnBCcAwAAOxDNv9Z2jw2wM4oAO97tw+gEekNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABalNgAWpTYAFqU2ABZJ0kud8wN9z4XWBD/VeQAAAABJRU5ErkJggg==');left:0px; top:270px;">
${igk_framename} - ${igk_version}<br />
Configuration Manager
</div>
<div id="id_foot" style="width:301px; height:31px; position:absolute;background-repeat:no-repeat; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS0AAAAfCAYAAACyJpv8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACRSURBVHhe7dTBCYBAEATBzT+QS88IFMWHLwO4hhooWNh/zxzXAtjfuebd7xNgN6IFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQIpoASmiBaSIFpAiWkCKaAEpogWkiBaQIlpAimgBKaIFpIgWkCJaQMoXrecAKDAza23mBqing/ZAmi1SAAAAAElFTkSuQmCC');left:0px; top:0px;">
	
</div>
	
</div>
</div>
	<div id="igk_cpv"></div>
</div>
EOF;

	$frm->Load($out);
	$i  = $frm->getElementById("id_board");
	$c  = $frm->getElementById("igk_cpv");
	if ($i)
		$i->add($a);
}
	$this->m_connexionFrame = $frm;
	$c->Content = IGK_COPYRIGHT;
		
		return $node;
	}
	private function __NoIE6supportView()
	{
		
	}
	public function View()
	{		
		//VIEW: IGKCONFCTRL
		if (igk_agent_isIE() && igk_agent_ieVersion() < 7)
		{
			 $this->__NoIE6supportView();
			 return;
		}
		
		$this->m_menuCtrl->setConfigParentView($this->m_configMenuNode);
		
		if (!$this->IsConnected)
		{
			igk_html_rm($this->m_configFrame);	
			HtmlUtils::AddItem($this->m_connexionFrame, $this->TargetNode);	
		}
		else{
			
			igk_html_rm($this->m_connexionFrame, true);	
			igk_html_add($this->m_configFrame, $this->TargetNode);				
			$this->m_headerNode->ClearChilds();
			$this->m_headerNode->addDiv(array("class"=>"config_logo"))->add("a", array("class"=>"dispb fitw fith" , "href"=>IGK_WEB_SITE))->Content = IGK_HTML_SPACE;
			$h = $this->m_headerNode->add("h1", array("class"=>"config_title"));
			$h->Content = R::ngets(IGK_CONF_PAGE_TITLE, igk_get_string_propvalue($this->App->Configs, "website_title"));			
			
			if ($this->SelectedConfigCtrl == null)
			{			
				$this->setpage();
			}		
		}		
		$this->_onViewComplete();
	}
	
	
	public function __construct(){
		parent::__construct();
		$this->m_ConfigUserChangedEvent = new IGKEvents($this, "ConfigUserChangedEvent");//raise when config user changed
		$this->m_configSettingChangedEvent = new IGKEvents($this, "ConfigSettingChangedEvent");//raise when configuration setting changed
		$this->_loadConfig();
	}
	//load configuration files configs.csv
	private function _loadConfig()
	{
		$file =IGK_CONF_DATA;
		$this->m_configEntries = array();
		$fullpath =igk_io_syspath($file);
		
		$f = IGKCSVDataAdapter::LoadData($fullpath);
		if ($f !== null)
		{
			foreach($f as $k=>$v)
			{	
				$this->m_configEntries[$v[0]] = trim(igk_getv($v, 1));
			}
		}
		$this->m_datas = new IGKConfigData($fullpath, $this, $this->m_configEntries);
		
	}
	public function registerConfig($ctrl)
	{///register config controlleur
		
	}
	public function saveConfig(){
		if ($this->m_datas==null)
			return;
		$this->m_datas->SortByKeys();
		if ($this->m_datas->saveData())
		{		
			$this->_updateCache();
			igk_sys_regchange(self::CHANGE_REG_KEY, $this->m_oldState);
		}
	}
	private function _updateCache()
	{
		$f = igk_io_currentbasePath(IGK_CACHE_DATAFILE);		
		if ($this->App->Configs->cache_loaded_file)
		{
			igk_io_save_file_as_utf8($f,"", true);
			//force cache of the files
			igk::CacheLibFiles(true);
		}
		else {
			if (file_exists($f))
			@unlink(igk_io_currentbasePath(IGK_CACHE_DATAFILE));
		}				
	}
	//get config entries
	public function getConfigEntries(){ return $this->m_configEntries;	}
	
	public function InitComplete()
	{		
		parent::InitComplete();		
		$this->m_configuration = false;		
		$this->m_menuCtrl = igk_getctrl(IGK_MENU_CTRL , true);
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "checkConfigDataChanged");
		
		igk_sys_regpagefolderChanged("home", $this, "__initPageConfig");
		igk_sys_regpagefolderChanged("Configs", $this, "__initPageConfig");
		
	}
	protected function __initPageConfig()
	{		
		
			switch($this->App->CurrentPageFolder)
			{
				case IGK_CONFIG_MODE:				
					$this->App->Doc->body["class"] = "+igk-config-page";				
					igk_html_rm($this->App->Doc->bodypage);
					igk_html_add($this->TargetNode, $this->App->Doc->body);
					break;
				default:	
					$this->App->Doc->body["class"] = "-igk-config-page";
					igk_html_rm($this->TargetNode);
					HtmlUtils::AddItem($this->App->Doc->bodypage,$this->App->Doc->body);						
					break;
			}	
	}
	
	public function checkConfigDataChanged($ctrl)
	{
		$v = $ctrl->isChanged(self::CHANGE_REG_KEY, $this->m_oldState);
		if ($v){
			$this->_loadConfig();
			$this->onConfigSettingChanged();
		}
	}
	protected function onConfigUserChanged()
	{
		if ($this->m_ConfigUserChangedEvent !=null)
			$this->m_ConfigUserChangedEvent->Call($this, null);
	}
	protected function onConfigSettingChanged()
	{
		if ($this->m_configSettingChangedEvent !=null)
			$this->m_configSettingChangedEvent->Call($this, null);
	}
	public function addConfigUserChangedEvent($obj, $method)
	{
		return $this->m_ConfigUserChangedEvent->add($obj, $method);
	}
	public function removeConfigUserChangedEvent($obj, $method=null)
	{
		$this->m_ConfigUserChangedEvent->remove($obj, $method);
	}
	public function addConfigSettingChangedEvent($obj, $method)
	{
		return $this->m_configSettingChangedEvent->add($obj, $method);
	}
	public function removeConfigSettingChangedEventt($obj, $method=null)
	{
		$this->m_configSettingChangedEvent->remove($obj, $method);
	}
	
	public function initConfigMenu(){		
		return array(
			new IGKMenuItem("Home", "default", $this->getUri("setpage"),-900),
			new IGKMenuItem("PhpInfo", "phpinfo", $this->getUri("show_phpinfo"),-800),
			new IGKMenuItem("ConfigurationMenuSetting", "configurationMenuSetting", $this->getUri("show_configuration_menu_setting"),-700),
			new IGKMenuItem("GoToIndex", null, $this->getUri("gotoindex"),10800),
			new IGKMenuItem("ClearSession",null, $this->getUri("clearsession"),10810),
			new IGKMenuItem("Reconnect",null, $this->getUri("reconnect"),10850),
			new IGKMenuItem("LogOut", null, $this->getUri("logout"),10900)
		);
	}
	
	
	
	public function gotoindex()
	{		
		igk_navtobase("");		
		exit;
	}
	public function clearsession()
	{
		$this->SelectedConfigCtrl = null;
		igk_getctrl(IGK_SESSION_CTRL)->clearS();
		igk_navtocurrent();
		exit;
			
	}
	public function reconnect()
	{		
		$this->clearSessionAndReconnect();
		return;
	}
	

	public function show_phpinfo(){
		$this->SelectedConfigCtrl = null;
		$this->setpage("phpinfo");
		
	}
	public function getphpinfo(){	
		$this->ConfigNode->ClearChilds();
		phpinfo();
		exit;
	}
	
	public function show_configuration_menu_setting()
	{
		$this->SelectedConfigCtrl = null;
		$this->setpage("configurationmenusetting");
	}
	private function _view_ConfigMenuSetting($node)
	{
		
		igk_add_title($node->addDiv(), "title.ConfigurationMenuSetting");
		$node->addHSep();
		$f = $this->getDataDir()."/config.menu.xml";
		$txt = IGKIO::ReadAllText($f);
		$dummy = HtmlItem::CreateWebNode("dummy");
		$dummy->Load($txt);
		$b = igk_getv($dummy->getElementsByTagName("configmenu"),0);
		
		$v_subdiv = $node->addDiv();
		
		foreach($b->Childs as $k=>$v)
		{
			$v_d = $v_subdiv->addDiv();
			//title
			$t = $v_d->addDiv(array("class"=>"config-menu-title"));
			$t->Content = $v->TagName;
			
			//information
			$t = $v_d->add("ul", array("class"=>"config-menu-description"));
			$t->add("li")->Content = igk_getv(igk_getv($v->getElementsByTagName("menuname"), 0), "innerHTML");
			$t->add("li")->Content = igk_getv(igk_getv($v->getElementsByTagName("pagename"), 0), "innerHTML");
			$t->add("li")->Content = igk_getv(igk_getv($v->getElementsByTagName("menuindex"), 0), "innerHTML");
			$t->add("li")->Content = igk_getv(igk_getv($v->getElementsByTagName("imagekey"), 0), "innerHTML");
			
			
			
		}
	}
	public function setpage($p="default")
	{
		$p = igk_getr("p", $p);		
		$this->ConfigNode->ClearChilds();
		$v_supported = true;
		switch($p)
		{
			case "configurationmenusetting":
				$this->SelectedConfigCtrl = null;
				$this->_selectMenu("ConfigurationMenuSetting", "IGKConfigCtrl::setpage");				
				$this->ConfigNode["class"]="posr fitw fith";
				$div = $this->ConfigNode->addDiv();
				$this->_view_ConfigMenuSetting($div);
				//uncomment to disallow web navigation
				//igk_navtocurrent();
				//exit;
				break;
			case "phpinfo":				
				$this->_selectMenu("phpinfo", "IGKConfigCtrl::setpage");				
				$this->ConfigNode["class"]="posr fitw fith";
				$iframe = $this->ConfigNode->add("iframe", array("class"=>"fitw fith noborder")); 
				$iframe["src"] = $this->getUri("getphpinfo");
				$iframe["style"]="min-height:800px; ";
			break;
			case "default":			
				$this->SelectedConfigCtrl = null;
				$this->_selectMenu("default", "IGKConfigCtrl::setpage");				
				$div = $this->ConfigNode->addDiv();				
				igk_add_title($div, "title.frameworkInfo");
				$div->addHSep();
				
				$ul = $div->add("ul");
				$ul->add("li")->Content = "FrameworkVersion : ". IGK_VERSION;
				$ul->add("li")->Content = "FrameworkRelease : ".IGK_RELEASE_DATE;
				$ul->add("li")->Content = "Author : ". IGK_AUTHOR;
				$li = $ul->add("li", array("class"=>"alignt" ));
				$li->add("span", array("class"=>"alignt -lblabel" ))->Content = "Author Contact : ";
				$li->add("a", array("class"=>"alignt deco_u", "style"=>"text-decoration:underline" , "href"=>"mailto:".IGK_AUTHOR_CONTACT))->Content = "@igkdev.be";
				$ul->add("li")->Content = "PhpVersion : ". PHP_VERSION;
				$ul->add("li")->Content = "ServerName : ".$_SERVER["SERVER_NAME"];
				$ul->add("li")->Content = "Server IP: ".igkServerInfo::ServerAddress();
				$ul->add("li")->Content = "IsLocal : ". igk_parsebool(igkServerInfo::IsLocal());
				$ul->add("li")->Content = "RemoteIP : ". igkServerInfo::RemoteIp();
				
				
				$div = $this->ConfigNode->addDiv();
				
				igk_add_title($div, "title.AdministrativeConfig");
				$div->addHSep();
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_domain");				
				$frm->addSLabelInput("website_domain", "lb.domainname", "text", $this->App->Configs->website_domain);$frm->addBr();				
				$frm->addSLabelInput("website_title", "lb.webpagedefaulttile", "text", $this->App->Configs->website_title);$frm->addBr();	
				$frm->addSLabelInput("website_prefix", "lb.websiteprefix", "text", $this->App->Configs->website_prefix);$frm->addBr();	
				$frm->addBtn("btn_domainName", R::ngets("btn.update"));
				
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_adminpwd");
				$frm->addHSep();
				$frm->addSLabelInput("passadmin", "lb.Password", "password");$frm->addBr();				
				$frm->addBtn("btn_domainName", R::ngets("btn.update"));
				
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("update_defaultlang");
				$frm->addHSep();
				if (!$this->App->Configs->default_lang)
				{
					$this->App->Configs->default_lang = R::GetCurrentLang();
				}
				
				
				$frm->addSLabelInput("cldefaulLang", "lb.DefaultLang", "text",  $this->App->Configs->default_lang);
				$frm->addBr();				
				$frm->addBtn("btn_domainName", R::ngets("btn.update"));
				
				$frm = $this->ConfigNode->addForm();	
				
				$frm["action"] = $this->getUri("conf_update_setting");
				$div = $frm->addDiv();
				$ul = $div->add("ul");
				
				$this->_checkedItemConfig($ul->add("li"), "cldebugmode", "AllowDebugging");
				$this->_checkedItemConfig($ul->add("li"), "clCacheLoadedFile", "cache_loaded_file");				
				$this->_checkedItemConfig($ul->add("li"), "clarticleconfig", "allow_article_config");
				$div->addBr();
				$ul = $div->add("ul");
				$this->_checkedItemConfig($ul->add("li"), "clautochepage", "allow_auto_cache_page");
				$ul->add("li")->addSLabelInput("clcache_file_time", "lb.cache_file_time", "text",  igk_getdv($this->App->Configs->cache_file_time, 3600));
				
				
				
				$frm->addBtn("btn_updatedebugmode", R::ngets("btn.update"));
				
				$frm = $this->ConfigNode->addForm();	
				$frm["action"] = $this->getUri("resetconfig");
				$frm->addBr();
				$frm->addHSep();
				$frm->addBtn("btn_resetconfig", R::ngets("btn.resetconfig"));
				break;
			default :
				$v_supported = false;
				break;
		}		
		if ($v_supported)
		{
			$this->ConfigInfo->ClearChilds();
			igk_add_article($this, "help.".$this->Name.".".$p, $this->ConfigInfo->addDiv(), null, true);		
		}
		else{
			//call the show config of the selected controller
		}		
	}
	function _checkedItemConfig($target, $name, $param)
	{
			$target->add("label", array("for"=>$name))->Content = R::ngets("lb.".$param);
			$chb = $target->addInput($name, "checkbox", null);
			if ($this->App->Configs->$param)
				$chb["checked"] = "true";
	}
	
	public function resetconfig(){
		if(igk_qr_confirm())
		{
			@unlink(igk_io_currentRelativePath("Data/configure"));
			igk_getctrl("igkdbCtrl")->initSDb(false);
			$this->reconnect();			
		}
		else{
			$frame = igk_add_confirm_frame($this, "frame_reset_config", $this->getUri("resetconfig"));				
			$frame->Form->Div->Content = R::ngets("msg.confirmResetConfig");	
		}
	}
	//update debug mode
	public function conf_update_setting()
	{		
		$this->App->Configs->AllowDebugging = igk_getr("cldebugmode", false);
		$this->App->Configs->cache_loaded_file = igk_getr("clCacheLoadedFile", false);
		$this->App->Configs->allow_article_config = igk_getr("clarticleconfig", false);
		$this->App->Configs->allow_auto_cache_page = igk_getr("clautochepage", false);
		$this->App->Configs->cache_file_time = igk_getr("clcache_file_time", false);
		
		igk_save_config();		
		igk_notifyctrl()->addMsgr("msg.ConfigOptionsUpdated");
		igk_resetr();
		$this->View();
		igk_navtocurrent();
	}
	
	public function update_defaultlang()
	{
		$this->App->Configs->default_lang = igk_getr("cldefaulLang","Fr");		
		igk_save_config();		
		$this->View();
		igk_notifyctrl()->addMsgr("msg.langupdated");
		igk_navtocurrent();
	}
	public function update_adminpwd()
	{
		$d = igk_getr("passadmin");
		if ($d && (strlen($d)> IGK_MAX_CONFIG_PWD_LENGHT)){
			$this->App->Configs->admin_pwd = md5($d);				
			$this->View();
			igk_notifyctrl()->addMsgr("msg.pwdupdated");
			igk_save_config();	
			
		}
		igk_navtocurrent();
	}
	public function update_domain()
	{
		$d = igk_getr("website_domain");
		$title = igk_getr("website_title");
		$prefix = igk_getr("website_prefix");
		if ($d){
			$this->App->Configs->website_domain = $d;
			$this->App->Configs->website_title = $title;
			$this->App->Configs->website_prefix = $prefix;
			igk_save_config();
			$this->View();
			igk_notifyctrl()->addMsgr("msg.domainupdate");
		}
		igk_navtocurrent();
	}

	public function connect($u=null,$pwd=null, $redirect=true)
	{
		if ($this->IsConnected )
			return;
	
		
		$u = ($u==null)? strtolower(igk_getr("login",$u)) : $u;
		$pwd = ($pwd==null)? strtolower(md5(igk_getr("pwd",$pwd))) :md5($pwd);
		
		if (empty($u) || empty($pwd))
		{
			$this->msbox->addError(R::gets(igk_geterror_key(IGK_ERR_LOGORPWDNOTVALID)));
		}
		else {
		$adm = strtolower($this->App->Configs->admin_login);
		$adm_pwd = strtolower($this->App->Configs->admin_pwd);
		

			if ( 
				 ($adm == $u) && 
				 ($adm_pwd ==$pwd)
				)
			{
				$us = (object)array("Login"=>$u, "Pwd"=>$u);
				$this->m_ConfigUser = $us;
				$this->onConfigUserChanged();
				$this->View();
				igk_debug("config login ok");
				
			}
			else {
				$this->msbox->addError(R::gets(igk_geterror_key(IGK_ERR_LOGORPWDNOTVALID)));
				igk_debug("config login no tok");
			}
		}
		if ($redirect){
			igk_navtocurrent();
		}
	}
	
	public function PageChanged()
	{	
		parent::PageChanged();		
	}

	public function logout($redirect=true, $detroysession=true){
	
		if ($this->IsConnected)
		{
		
			$this->m_ConfigUser = null;
			$this->setSelectedConfigCtrl(null);			
			$this->onConfigUserChanged();
		}
		if ($detroysession )
			session_destroy();
		$this->View();
		if ($redirect)
		{
			igk_navtocurrent();		
			exit;
		}
	}
}
//mail controller
class IGKMailCtrl extends IGKConfigCtrlBase
{
	private $m_mailSendEvent; 
	
	public function __construct(){
		parent::__construct();
		$this->m_mailSendEvent = new IGKEvents($this, "MailSend");
	}
	public function addMailSendEvent($obj, $func){
		if( $this->m_mailSendEvent!=null)
		$this->m_mailSendEvent->add($obj, $func);
	}
	public function removeMailSendEvent($obj, $func)
	{
		if( $this->m_mailSendEvent!=null)
		$this->m_mailSendEvent->remove($obj, $func);
	}
	public function onMailSended($args)
	{
		if( $this->m_mailSendEvent!=null)
			$this->m_mailSendEvent->Call($this, $args);
	}
	
	public function send_contactmail($fromName, $message=null)
	{
		$obj = igk_getr_obj();		
		
		$enode = HtmlItem::CreateWebNode("div");
		$mail = new IGKMail();
			
		$this->initMailSetting();
		$this->init_mail_config($mail);

			
			
			$mail->addTo($this->App->Configs->mail_contact);			
			$div = HtmlItem::CreateWebNode("div");
			$div["style"] = "border:1px solid black; min-height:32px;";
			$ul = $div->add("ul");
			$ul->add("li")->Content = "Message From: ".$fromName;
			$ul->add("li")->Content = "Email: ".$obj->clYourmail;
			
			$msg = $div->addDiv();
			$msg->Content = $obj->clMessage;			
			
			$mail->HtmlMsg = utf8_decode($div->Render()); 
			$mail->Title = utf8_decode($obj->clSubject);
			$mail->ReplyTo = $obj->clYourmail;
			$mail->From =  "website@".$this->App->Configs->website_domain;
			if ($mail->sendMail())
			{				
				igk_resetr();	
				$div = HtmlItem::CreateWebNode("div");
				$div->Content = R::ngets("msg.email.correctlysend");
				$div->addScript()->Content = "igk.animation.autohide(igk.getParentScript(), 3000);";
				$e = new HtmlSingleViewItem($div);				
				$this->onMailSended(array(
					"clEmail"=>$obj->clYourmail,
					"clFirstName"=>$obj->clFirstName,
					"clLastName"=>$obj->clLastName
				));
				return  array(true, $e);		
			}
			else{
				$enode->Add("li")->Content = R::ngets("msg.mail.sendmailfailed");				
				return  array(false, $enode);		
			}
			
	}
	
	public function functionIsAvailable($func = null)
	{
		switch($func)
		{
			case "sendmailto":
			return true;
		}
		return parent::functionIsAvailable($func);
	}
	public function sendmailto()
	{
		$to = igk_getr("n");
		$s = igk_getr("s");
		
		$m = HtmlItem::CreateWebNode("script");
		$m->Content =<<<EOF
window.open("mailto:$to?subject=$s","sendmail");

EOF;
		$this->App->Doc->body->add(new HtmlSingleViewItem($m));
		igk_navtocurrent();
		
	}
	public function initMailSetting()
	{	
		 ini_set("smpt_port", $this->App->Configs->mail_port);
		 ini_set("SMTP", $this->App->Configs->mail_server);
		 ini_set("sendmail_from", $this->App->Configs->mail_admin);
	}
	private function init_mail_config($mail)
	{
		$mail->UseAuth = $this->App->Configs->mail_useauth;
		$mail->User = $this->App->Configs->mail_user;//"igkdevbe"; //"bondje.doue@gmail.com";
		$mail->Pwd = $this->App->Configs->mail_password;//"bonajehost1983"; //"bonaje123";
		$mail->Port = $this->App->Configs->mail_port; //587;//  465; //587;
		$mail->SmtpHost = $this->App->Configs->mail_server;
		$mail->SocketType = $this->App->Configs->mail_authtype;//"ssl";
	}
	//send mail to element
	public function sendmail($from, $to,$subject, $message){
	     // Pour envoyer un mail HTML, l'en-tête Content-type doit être défini
		$header = null;
		$this->initMailSetting();
		$mail = new IGKMail();
		$this->init_mail_config($mail);

		$mail->HtmlMsg = $message;
		$mail->Title = $subject;
		$mail->From = $from;
		$mail->HtmlCharset = "utf-8";
		$mail->TextCharset = "utf-8";
		$mail->addTo($to);
		return $mail->sendMail();	
	}
	
	public function getConfigPage()
	{
		return "mailserver";
	}
	public function View(){
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$c = $this->TargetNode;		
		igk_html_add($c, $this->ConfigNode);
		
		$c->ClearChilds();
		igk_add_title($c, "title.ConfigMailServer");
		$c->addHSep();
		igk_add_article($this, "mailserver", $c->addDiv(), null, true);
		$c->addHSep();
		
		
		$div = $c->addDiv();
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("mail_update");
		$frm->addSLabelInput("server", "lb.Server", "text", $this->App->Configs->mail_server); $frm->addBr();
		$frm->addSLabelInput("baseFrom", "lb.ContactEmail","text", $this->App->Configs->mail_admin);$frm->addBr();
		$frm->addSLabelInput("port", "lb.Port","text", $this->App->Configs->mail_port);$frm->addBr();
		$frm->addSLabelInput("useauth", "lb.UseAuth","checkbox", $this->App->Configs->mail_useauth);$frm->addBr();
		$frm->addLabel("cl.mailAuthType", "clAuthType");
		igk_html_build_select($frm, 
		"clAuthType", 
		array("ssl"=>"ssl","tsl"=>"tsl"),
		null,
		$this->App->Configs->mail_authtype
		); $frm->addBr();
		
		
		$frm->addSLabelInput("clMailUser", "lb.AuthLogin","text", $this->App->Configs->mail_user);$frm->addBr();
		$frm->addSLabelInput("clMailPwd", "lb.Password","password", $this->App->Configs->mail_password);$frm->addBr();
		$frm->addBtn("btn_update", R::ngets("btn.update"));
		
		$frm = $div->addForm();
		$frm["method"]="POST";
		$frm["action"]=$this->getUri("mail_testmail");
		
		$frm->addSLabelInput("clContactTo", "lb.Testmail","text", $this->App->Configs->mail_contact);$frm->addBr();
		
		$frm->addBtn("btn_testmail", R::ngets("btn.TestMail"));
	}
	public function mail_testmail()
	{
		$to  = igk_getr("clContactTo");
		$this->App->Configs->mail_contact = igk_getr("clContactTo");
		igk_save_config();
			$mailctrl = igk_getctrl("igkmailctrl");			
			$c = $this->App->Configs->mail_contact;
			if ( ($mailctrl!= null) && !empty($c))
			{
			//from 
			//to
				if (
				$mailctrl->sendmail(					
					$this->App->Configs->mail_admin, 				
					$to,
				"Mail test: ".$this->App->Configs->website_domain, 
				"From: " .$this->App->Configs->website_domain))
				{
					igk_notifyctrl()->addMsgr("Msg.MailSend");
				}
				else{
					igk_notifyctrl()->addError("Msg.MailNotSend");
				}
			}
			else 
				$this->msbox->addError("error ... ".$this->App->Configs->mail_contact);
		
		$this->View();
	}
	public function mail_update(){
	
		$server= igk_getr("server");
		$mail= igk_getr("baseFrom");
		$port = igk_getr("port");
		$useauth = igk_getr("useauth");
		$this->App->Configs->mail_server = $server;
		$this->App->Configs->mail_port = $port;
		$this->App->Configs->mail_admin = $mail;
		$this->App->Configs->mail_useauth = $useauth;
		$this->App->Configs->mail_authtype = igk_getr("clAuthType");

		$this->App->Configs->mail_user=igk_getr("clMailUser");
		$this->App->Configs->mail_password = igk_getr("clMailPwd");
		
		igk_save_config();
		igk_notifyctrl()->addMsgr("msg.mailupdatedd");
		$this->View();
		igk_navtocurrent();
		exit;
	}
	
}

final class IGKPoweredCtrl extends IGKControllerBase
{
	private $m_confNode;
	public function __construct(){
		parent::__construct();
		$this->m_confNode = HtmlItem::CreateWebNode("div");
		
	}
	public function getConfigPage()
	{
		return "powered";
	}
	public function getIsVisible(){
		return $this->App->Configs->show_powered;
		//return true;
	}
	public function View(){		
			$this->TargetNode->ClearChilds();
			$this->TargetNode->Content = "This site is powered by <a href=\"".IGK_WEB_SITE."\" >www.igkdev.be</a>";
			$c = igk_getctrl($this->App->Configs->web_pagectrl);
			if ($c )
			{
				$def_id = $c->TargetNode["id"];
				$this->TargetNode->addScript()->Content = "window.igk.powered_manager(window.igk.getParentScriptByTagName('div'),'".$def_id."');";
			}
			igk_html_add($this->TargetNode, $this->App->Doc->Body,1000);
	}
	public function initTargetNode(){
		$t = HtmlItem::CreateWebNode("div");
		$t["id"] ="powered-node";
		$t["class"]="igk-powered posfix";
		return $t;
	}
	public function initConfigMenu(){
		return null;
	}
	
}
//
//BACKGROUND IMAGE ADORATOR 
//
final class IGKBackgroundImgCtrl extends IGKConfigCtrlBase
{
		private $m_imglist;
		private $m_configTargetNode;
		private $m_currentIndex;
		private $m_allowRandom;
		private $m_lastChanged;
		const PROP_CHANGED = "BackgroundAdoratorChanged";
		public function __construct()
		{
			parent::__construct();
			$this->m_currentIndex = null;
			$this->m_imglist = array();
		}
		private function _getadoratordir()
		{
			return  igk_io_syspath("R/Img/".(($this->App->Configs->adorator_fade_directory)?$this->App->Configs->adorator_fade_directory:"Adorator"));	
		}
		
		public function functionIsAvailable($function)
		{
			return true;
		}
		
		
		public function InitComplete()
		{
			parent::InitComplete();
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "SettingChanged");
			
		}
		public function SettingChanged($ctrl)
		{			
			if ($ctrl->isChanged(self::PROP_CHANGED, $this->m_lastChanged))
			{
				$this->View();
			}
		}
		public function initTargetNode()
		{
			$this->m_configTargetNode = HtmlItem::CreateWebNode("div", array("class"=>strtolower($this->getName())));
			return HtmlItem::CreateWebNode("div");
		}
			
		public function getConfigPage()
		{
			return "backgroundsetting";
		}
		private function __viewConfig()
		{
				$this->m_configTargetNode->ClearChilds();
				$this->ConfigNode->ClearChilds();
				HtmlUtils::AddItem($this->m_configTargetNode, $this->ConfigNode);				
				
				$d = $this->m_configTargetNode;
				igk_add_title($d, "title.BackgroundAdoratorSetting");
				$d->addHSep();
				$frm = $d->addForm();
				$frm["action"] = $this->getUri("updatevalue");
				$ul = $frm->add("ul");				
				
				$ul->add("li")->addSLabelCheckbox("clEnabled", "lb.adoratorenable", $this->App->Configs->adorator_fade_enabled);
				$ul->add("li")->addSLabelInput("clFadeinterval", "lb.fadeinterval", "text", igk_gettv($this->App->Configs->adorator_fade_interval , 500));
				$ul->add("li")->addSLabelInput("clRotationInterval", "lb.rotationinterval", "text", igk_gettv($this->App->Configs->adorator_rotation_interval, 10000));
				$ul->add("li")->addSLabelCheckbox("clRandom", "lb.bgad_randomEnabled",$this->App->Configs->adorator_random_enabled);
				$frm->addHSep();
				$ul = $frm->add("ul");
				$ul->add("li")->addSLabelInput("clDir", "lb.dirname","text", $this->App->Configs->adorator_fade_directory?$this->App->Configs->adorator_fade_directory:"Adorator" );				
				$frm->addBtn("btn_update", R::ngets("btn.update"));							
		}
		public  function showConfig()
		{
			parent::showConfig();
			if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
			{
				$this->__viewConfig();				
			}
			else {
				igk_html_rm($this->m_configTargetNode);
			}
		}
		public function updatevalue()
		{
			$this->App->Configs->adorator_fade_directory =   igk_getr("clDir","Adorator");
			$this->App->Configs->adorator_fade_enabled = igk_getr("clEnabled",false);
			$this->App->Configs->adorator_fade_interval = igk_getr("clFadeinterval");
			$this->App->Configs->adorator_rotation_interval = igk_getr("clRotationInterval");
			$this->App->Configs->adorator_random_enabled = igk_getr('clRandom');
			igk_getctrl(IGK_CHANGE_MAN_CTRL)->registerChange(self::PROP_CHANGED, $this->m_lastChanged);
			igk_save_config();
			$this->showConfig();
			igk_notifyctrl()->addMsg("Msg.BackgroundImageAdorator.updated");			
			$this->View();
			igk_navtocurrent();
			
		}
		public function getIsVisible()
		{
			return $this->App->Configs->adorator_fade_enabled;
		}
		public function getfilelist_ajx()
		{
				$s = $this->_getadoratordir();
				if (is_dir($s))
				{
				$tab = IGKIO::GetDirFileList($s);		
				$node = HtmlItem::CreateWebNode("images");
				foreach($tab as $k){
					$node->add("image", array("src"=>igk_io_baseuri(igk_io_basePath($k))));
				}
				igk_wl($node->Render());
				}
		}
		public function View()
		{	
			$c = $this->TargetNode;
			$c->ClearChilds();		
			if (!$this->IsVisible)
			{
				
				igk_html_rm($c);
				return;
			}
			
			$c["class"]="web_background_img posab zback loc_t loc_l fith fitw";
		
			HtmlUtils::AddItem($c, $this->App->Doc->body);
			//default picture
			$c->add("div", 	array("class"=>"front posab loc_t loc_l fitw fith"));//->Content = "nbsp;";

	$out = "";
	$s = $this->_getadoratordir();
	$tab = IGKIO::GetDirFileList($s);	
	
	if ($tab && count($tab>0)){
			$script = $c->addScript();
			
	$afi = $this->App->Configs->adorator_fade_interval;
	$ari = $this->App->Configs->adorator_rotation_interval;
	$rnd = igk_parsebool( $this->App->Configs->adorator_random_enabled? true: false);
	$defindex = -1;
	if ($this->m_currentIndex)
{
	$defindex = $this->m_currentIndex;
}
			$p =<<<EOF
igk.animation.InitBgAdorator(igk.getParentScriptByTagName('div'), 20, $ari, $afi,$rnd,  '{$this->getUri('getfilelist_ajx')}',{$defindex}, '{$this->getUri('updateindex_ajx&index=')}');
EOF;
				$script->Content = $p;
		
		}
		}
		
		
		public function updateindex_ajx()
		{
			$this->m_currentIndex = igk_getr("index");
			$this->View();
			exit;
		}
	
}


final class IGKPaletteCtrl extends IGKControllerBase
{
	private $m_palettes;
	
	public function getisVisisble(){return false;}
	public function getName(){ return IGK_PALETTE_CTRL;}
	public function getPalettes(){ return $this->m_palettes; }
	
	public function getPaletteDir(){
		return igk_io_currentbasePath("R/Palettes");
	}	
	public function loadFile($fname)
	{
		if (!file_exists($fname))return;
		
		$v_name = igk_io_basenamewithoutext($fname);
		
		$v_t = null;
		if (isset($this->m_palettes[$v_name]))
		{
			$v_t = $this->m_palettes[$v_name];
		}
		else 
			$v_t = array();		
		
		$e = HtmlItem::CreateWebNode("pal");
		try{
		$e->Load(IGKIO::ReadAllText($fname));
		
		$e = igk_getv($e->getElementsByTagName("gkpal"), 0);
		
		foreach($e->Childs as $k)
		{
			if (strtolower($k->TagName)=="color")
			{
				$v = $k["Value"];
				$v_t[$v] = $v;
			}
		}
		
		
		$this->m_palettes[$v_name] = $v_t;
		}
		catch (Exception $ex) {
		}
	}
	public function InitComplete()
	{
		parent::InitComplete();
		$this->loadPalette();
	}
	public function loadPalette()
	{
		if(IGKIO::CreateDir($this->getPaletteDir()))
		{
			$v_tfiles = IGKIO::GetFiles($this->getPaletteDir(), "/\.gkpal$/i", false);
			foreach($v_tfiles as $f)
			{
				$this->loadFile($f);
			}
		}
	}
	public function __construct()
	{
		parent::__construct();
		$this->m_palettes = array();
	}
	public function getIsVisible(){return false;}
	
}
//------------------------------------------------------------------------------------
///- THEME CONTROLLER
//------------------------------------------------------------------------------------
final class IGKThemeCtrl extends IGKConfigCtrlBase
{
	private $m_search;
	private $m_searchkey;
	private $m_searchColor;
	private $m_searchRes;
	private $m_rendering;
	private $m_selectedMenu;
	private $m_lastThemeChanged; //last language key changed
	private $m_cssFileTable;
	
	public static function GetRegClass(){
		return HtmlClassValueAttribute::GetRegClass();
	}
	public static function UnRegClass($key){
		return HtmlClassValueAttribute::UnRegClass($key);
	}
	public function __construct(){
		parent::__construct();
		$this->m_search = null;
		$this->m_rendering =false;
		$this->m_cssFileTable = array();
	}
	public function getName(){
		return IGK_THEME_CTRL;
	}
	//load theme by name
	public function loadTheme()
	{
		igk_debug("notice:loadtheme");
		$f = igk_io_syspath("R/Themes/".$this->App->Doc->Theme->Name.".phtml");		
		if (file_exists($f))
		{
			$this->App->Doc->Theme->load($f);
		}
	}
	public function saveTheme(){		
		$this->App->Doc->Theme->save();		
	}
	public function initComplete()
	{
		parent::initComplete();
		igk::getInstance()->Session->RegClasses->regEvent->add($this, "ReloadView");		
		igk_getctrl(IGK_CHANGE_MAN_CTRL)->addLoadConfigEvent($this, "onThemeChangedProc");				
		//load custom theme
		$this->_initTheme();
	}
	private function _initTheme()
	{	
		//remove all themes
		//$this->app->Doc->clearStyle();
		//init system theme
		$this->App->Doc->initSysTheme();
		//load system theme
		$this->loadTheme();
		//load additional css theme
		$this->themeLoadCssFiles();
	}
	public function onThemeChangedProc($ctrl)
	{
		$n = $this->App->Doc->Theme->RegChangedKey;		
		if ($ctrl->isChanged($n, $this->m_lastThemeChanged))
		{
			//merge theme with the current
			$this->loadTheme();
			if ($this->IsVisible)
				$this->View();
		
		}
	}
	public function ReloadView()
	{
		if ($this->m_rendering)
			return;
		$this->View();
	}
	function _adddel_action($frm)
	{
			$frm->addInput("btn_delaction","button", R::ngets("btn.rmSelection"), array("onclick"=>"javascript:this.form.btn_action.value = 1; this.form.submit()"));
	}
	public function delete_selection()
	{
		
		
		$tab = igk_getr("keytab");
		igk_debug("notice:IGKThemeCtrl::delete_selection");
		
		$x = igk_getr("ccount", 0);
		for($i = 0; $i<$x; $i++)
		{
			$t = igk_getr("css_i_".$i);
			if ($t)
			{
				$this->App->Doc->Theme->Attributes[$tab[$i]] = null;
			}
		}
			
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
	}
	public function save_as_default(){
	$frame_name = "save_as_default_frame";
		if (igk_qr_confirm())
		{
		 $n = igk_getr(IGK_FD_NAME,"default");
		 $f = igk_io_syspath(IGK_DEFAULT_THEME_FOLDER."/".$n.".themes");
		
		if ( !IGKIO::CreateDir(dirname($f))|| !$this->App->Doc->Theme->save($f))
		{
			igk_notifyctrl()->addError(R::gets("ERR.CANTSAVEFILE"));
		}
		else{
			igk_notifyctrl()->addMsg(R::ngets("MSG.FileSaved", basename($f)));
		}
		igk_frame_close($frame_name);
		igk_navtocurrent();
		}
		else{
			$frame = igk_add_new_frame($this, $frame_name);
			$d = $frame->Content;
			$frame->Title = R::ngets("title.SAVEDefaultTheme");
			$d->ClearChilds();
			$frm = $d->addForm();
			$frm["action"] = $this->getUri("save_as_default");
			$frm->addSLabelInput(IGK_FD_NAME, "lb.Name", "text", "default", true);
			$frm->addHSep();
			$frm->addInput("confirm", "hidden", 1);
			$frm->addBtn("btn_save", R::ngets("btn.Save"),"submit");
			
		}
	}
	public function select_menu(){
		$this->m_selectedMenu = igk_getr("n","default");
		$this->View();
	}
	public function View(){					
		$this->TargetNode->ClearChilds();
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		//rendering to ignored theme management update
		$this->m_rendering = true;
		//load not registrated registrated class
		foreach(IGKThemeCtrl::GetRegClass() as $k)
		{
			if(!isset($this->App->Doc->Theme->Attributes[$k]))
				$this->App->Doc->Theme->Attributes[$k]="";
		}
		HtmlUtils::AddItem($this->TargetNode, $this->ConfigNode);
		$node = $this->TargetNode;	
		$node->ClearChilds();
		igk_add_title($node, R::ngets("title.themeManager"));
		$node->add(new HtmlSeparatorItem());
		
		
		
		$this->m_selectedMenu = $this->m_selectedMenu?$this->m_selectedMenu: "themes";
		$div = $node->addDiv();
		igk_add_article($this,"themes.description", $div);
		$node->addHSep();
		//view menu
		$menut = array("themes", "cssFiles", "palette","color", "font", "system_theme");
		$t = array();
		foreach($menut as $k)
		{
			$t[$k] = $this->getUri("select_menu&n=".$k);
		}
		HtmlUtils::CreateConfigSubMenu($node, $t, $this->m_selectedMenu);
		unset($t);
		$node->addHSep();
		
		$frm = $this->TargetNode->addForm();
		$frm["action"] = $this->getUri("update_name");	
		$frm["id"]="class_editor";
		$frm->addBr();
		$frm->addSLabelInput("theme_name","lb.Name", "text",$this->App->Doc->Theme->Name);				
		
		$node->addHSep();
		switch(strtolower($this->m_selectedMenu))
		{
			case "palette":			
				$this->_th_showPalette();
				break;
			case "cssfiles":
				$this->themeShowCssFiles();
				break;
			case "font":			
				$this->_showFont();	
				break;
			case "color":
				$this->_showColor();
			break;
			case "system_theme":
				$this->_showSystemTheme();
			break;
			default:
				$this->_showThemes();
				break;
		}
		
		$this->TargetNode->addHSep();
		HtmlUtils::AddBtnLnk($this->TargetNode,R::ngets("btn.savetheme"), $this->getUri("save_as_default"));	
		
		$this->m_rendering = false;
	}
	//-----------------------------------------------------------------------------------------------------
	// THEMES FUNCTION . SHOW CURRENT THEME
	//-----------------------------------------------------------------------------------------------------
	private function _showThemes()
	{
		$div = $this->TargetNode;		
		$div = $div->addDiv();
		igk_add_loading_frame($div);		
		$div->addScript()->Content = "(function(q){ igk.ajx.post('".$this->getUri("themeViewPrimaryConfig_ajx")."',null, function(xhr){if (this.isReady()){ this.setResponseTo(q); }}, false);})(igk.getParentScript());";
		
	}
	
	public function themeViewPrimaryConfig_ajx()
	{	
		$c = HtmlItem::CreateWebNode("div");
		$div = $c;
		igk_add_title($div, R::ngets("title.CSSClass"));
		$div->addHSep();
		
		
		igk_setr("q", igk_getr("q", $this->m_searchkey));
		$div->add(new HtmlSearchItem($this->getUri("search")));
		$div->addBr();
		$frm = $div->addForm();
		$frm["action"] = $this->getUri("theme_update");
		//view all themes
		$tab = null;
		$ttab = null;		
		$v_index= 0;
		if ($this->m_search === null)
		{
			$tab =  $this->App->Doc->Theme->Attributes->toArray();
			$ttab =$this->App->Doc->Theme->Attributes->toArray();
		}
		else{
			$tab =  $this->m_search;
			$ttab = $this->m_search;
		}
		if (count($ttab)>0)
		{
		$ctab = array_keys($ttab);
		igk_usort($ctab, "igk_key_sort");
		$this->_adddel_action($frm);
		$frm->addSpace();
		$this->_themeFormControl($frm);

		$tcount = $frm->addDiv();		
		$ul  = $frm->add("table", array("class"=>"fitw"));	
		$tr = $ul->add("tr");		
		
		HtmlUtils::AddToggleAllCheckboxTh($tr);
		
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>"fitw") )->Content =  R::ngets("clValue");
		$tr->add("th",array("class"=>"box_16x16"))->Content = IGK_HTML_SPACE;
		$tr->add("th",array("class"=>"box_16x16"))->Content = IGK_HTML_SPACE;
		
		foreach($ctab as $k)
		{
			$kk = $this->App->Doc->Theme->def[".".$k];
			if (!empty($kk) || empty($k))
				continue;
				
			$v = $tab[$k];
			$li = $ul->add("tr");
			$chbox = $li->add("td")->add("input", array("type"=>"checkbox"));//Content = IGK_HTML_SPACE;
			$chbox["name"] = "css_i_".$v_index;
			
			$li->add("td" ,array("class"=>"nowrap"))->add("span", array("for"=>"key_".$v_index, "class"=>"-cllabel dispb nowrap"))->Content = ".".$k;
			$txt = $li->add("td")->addInput("key_".$v_index, "text", $v);
			
			$v_id = htmlentities($k);			
			$li->add("td" ,array("class"=>"box_16x16"))->add("a", array("href"=>$this->getUri("editkey&id=".$v_id)))->add("img", array("src"=>R::GetImgUri("edit")));
			$li->add("td" ,array("class"=>"box_16x16"))->add("a", array("href"=>$this->getUri("rmkey&id=".$v_id)))->add("img", array("src"=>R::GetImgUri("drop")));
			$v_index++;
			
		$li->addInput("keytab[]","hidden", $v_id);
		}
		
		igk_html_toggle_class($ul, "tr");
		$tcount->Content  =  $v_index;
		}
		
		
		$frm->addInput("ccount","hidden",$v_index);
		$frm->addInput("btn_action","hidden","0");
		$frm->addBtn("btn_update", R::ngets("btn.Update"));		
		$frm->addSpace();
		$this->_adddel_action($frm);
		$this->_themeFormControl($frm);
		igk_wln($c->innerHTML);
		return;
	}
	public function restore_theme(){
		$n  = base64_decode(igk_getr(IGK_FD_NAME));		
		if(!empty($n)){
		$this->App->Doc->Theme->Name = $n;
		$this->loadTheme();		
		$this->View();
		}
		igk_navtocurrent();
	}
	private function _showSystemTheme(){
		$node = $this->TargetNode;
		igk_add_title($node, R::ngets("title.SystemThemeManager"));
		$node->addHSep();
		$frm = $node->addForm();
		$frm["action"] = $this->getUri("restore_theme");
		
		$dir = igk_io_currentRelativePath(IGK_DEFAULT_THEME_FOLDER);
		$tab = IGKIO::GetDirFileList($dir);
		if ($tab && (count($tab)>0))
		{
			$frm->add("label", array("for"=>IGK_FD_NAME))->Content = R::ngets(IGK_FD_NAME);		
			$sl = $frm->add("select");		
			$sl["id"]=$sl["name"] = IGK_FD_NAME;			
			foreach($tab as $k)
			{
				$opt = $sl->add("option");
				$s = igk_io_remove_ext(basename($k));
				$opt["value"]=base64_encode ($s);
				$opt->Content =$s;
			}
		}
		else{
			$frm->addDiv()->Content = "no theme found: ". $dir;
		}
		$frm->addHSep();
		$frm->addBtn("btn_validate", R::ngets("btn.restore"));
	}
	private function _th_showPalette(){
		$node = $this->TargetNode;
		igk_add_title($node, R::ngets("title.paletteManager"));
		$node->add(new HtmlSeparatorItem());
		
		igk_add_article($this,"themes.palette.description", $node);
		$frm = $node->addForm();
		
		$div = $frm->add("div", array("style"=>"height: auto; line-height: 16px; max-width : 300px;"));
		
		$w = 16;
		$h = 16;
		$p = "";		
		$cl = "#000";
		foreach(igk_getctrl(IGK_PALETTE_CTRL)->Palettes as $k=>$v)
		{
		
			// $e = HtmlItem::CreateWebNode("pal");
			// $e->Load(igk_io_getdir(IGKIO::ReadAllText($v)));
			
			$cdiv = $div->addDiv();
			igk_add_title($cdiv, $k);			
			foreach($v as $m=>$n)
			{
				$p = $n;
				$f = $cdiv->add("a", array("style"=>"display: inline-block; width:".$w."px; 
				height:".$h."px; margin: 1px; background-color:".$p.";"));	
				$f->Content = IGK_HTML_SPACE;
				$f["href"]=$this->getUri("setColor&cl=".$p);
			}
		}
		HtmlUtils::AddBtnLnk($frm,R::ngets("btn.AddPalette"), $this->getUri("th_addPalette"));
	}
	private function _showFont(){
		$d = $this->TargetNode;
		igk_add_title($d, R::ngets("title.FontManager"));
		$d->add(new HtmlSeparatorItem());
		
		igk_add_article($this,"themes.fontmanager.description", $d);		
		$d->add(new HtmlSearchItem($this->getUri("searchfont"), $this->m_searchfont,"qft"));
		$d->addHSep();
		
		$frm = $this->__getfontform();
		$d->add($frm);
	}
	public function getFontDir(){ 
	return igk_io_syspath(IGK_RES_FONTS);
	}
	public function add_font(){
		$f = igk_getv($_FILES, "clfile");
		$n = igk_getr(IGK_FD_NAME);
		if (($f["error"] == 0) && igk_qr_confirm() ){
			if (IGKIO::CreateDir($this->FontDir))
			{
				$destination = $this->FontDir."/".$f["name"];
				
				if (!file_exists($destination))
				{
					if (!igk_io_move_uploaded_file($f["tmp_name"],$destination))
					{
						igk_notifyctrl()->addError("move upload file failed");
					}
					else{
							$d = igk_io_basePath($destination);
							igk_notifyctrl()->addMsg("Font added : ".$d);
							$this->App->Doc->Theme->addFont($n, $d);
					}
				}
				else{
					igk_notifyctrl()->addError("failed file already exists");
					$d = igk_io_basePath($destination);
					$this->App->Doc->Theme->addFont($n, $d);
				}
				
			}
			else{				
				igk_notifyctrl()->addError("can't create a directory");
			}
		}
		else{
				igk_notifyctrl()->addError("can't add font ". $f["error"] );
		}
		$this->View();
		igk_navtocurrent();
	}
	public function add_font_frame(){
		$frame = igk_add_new_frame($this, "add_font_frame", "?#font_list");
		$frame->Title = R::ngets("title.addfont");		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("add_font");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput(IGK_FD_NAME, IGK_FD_NAME);
		$ul->add("li")->addSLabelInput("clfile", "clFile", "file");
		$frm->addInput("confirm", "hidden", 1);
		$frm->addHSep();
		$frm->addInput("btn_confirm", "submit", R::ngets("btn.addfont"));
		
	}
	private function __getfontform(){
		$frm = HtmlItem::CreateWebNode("form");
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.addNewFont"), $this->getUri("add_font_frame"));
	
		$table  = $frm->add("table", array("class"=>"fitw"));
		$ul = $frm->add("ul", array("id"=>"font_list", "class"=>"font_list"));
		//header
		$tr = $table->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = R::ngets("clPath");
		//$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th", array("style"=>"width:24px;"))->Content = IGK_HTML_SPACE;
		
		//had content
		$dir = igk_io_currentRelativePath(IGK_RES_FONTS);	
		$ft = $this->App->Doc->Theme->getFont();
		foreach($ft->Attributes as $k=>$v)
			{
				$tr = $table->add("tr");
				$tr->add("td",array("style"=>"width:16px;"))->Content = IGK_HTML_SPACE;
				$tr->add("td")->Content = $k;
				if (file_exists(igk_io_currentRelativePath($v)))
				{
					$tr->add("td")->add("a",array("href"=>$this->getUri("getfontfile&n=".base64_encode($v))))->Content = $v;
				}
				else{
					$tr->add("td")->Content = "????";
				}				
				HtmlUtils::AddImgLnk($tr->add("td", array("style"=>"width:16px;")),$this->getUri("drop_font&n=".base64_encode($k)), "drop");		
				$ul->add("li", array("igk-tool-tip"=>$k, 
					"igk-drop-font"=>$this->getUri("drop_font&n=".base64_encode($k)),
					"igk-drop-font-uri"=>igk_html_uri(igk_io_currentbasePath(R::GetImgUri("drop")))))->addDiv(array("style"=>"font-family: '".$k."';"))->Content = "Abg";
			}
			
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.addNewFont"), $this->getUri("add_font_frame"));		
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.rmAll"),$this->getUri("clear_all_font"), array("onclick"=>"if(confirm('".R::gets("MSG.CONFIRMALLFONTSUPRESSIONQUESTION")."')){ igk_confirm_lnk(this);} return false;"));
		$frm->addInput("confirm", "hidden", 0);
		
		return $frm;
	}
	public function drop_font(){
		$v = base64_decode(igk_getr("n"));		
		$this->App->Doc->Theme->removeFont($v);
		$this->View();
		//igk_navtocurrent();
	}
	public function clear_all_font(){
		if (igk_qr_confirm())
		{
			$this->App->Doc->Theme->clearFont();
			$this->View();		
		}
		else{
			$frame = igk_add_confirm_frame($this, "clearallfont_confirm_frame", $this->getUri("clear_all_font"));				
			$frame->Form->Div->Content = R::ngets(IGK_MSG_DELETEALLFONT_QUESTION);						
	
		}
	}
	public function getfontfile(){
		$v = base64_decode(igk_getr("n"));
		igk_getctrl(IGK_FILE_MAN_CTRL)->getfile(igk_io_currentRelativePath($v));
	}
	private function __addbtn($frm, $ctrl){		
			HtmlUtils::AddBtnLnk($frm, R::ngets("btn.add"), $ctrl->getUri("addnewcolorframe#colorman"));			
			HtmlUtils::AddBtnLnk($frm, R::ngets("btn.importcolorfile"), $ctrl->getUri("th_importcolorfileframe#colorman"));			
			HtmlUtils::AddBtnLnk($frm, R::ngets("btn.downloadcolor"), $ctrl->getUri("th_downloadcolorfile#colorman"));			
			HtmlUtils::AddBtnLnk($frm, R::ngets("btn.clearthemecolor"), $ctrl->getUri("th_clearthemecolor#colorman"));
	}
	public function th_clearthemecolor()
	{
		$this->App->Doc->Theme->cl->Attributes->Clear();
		igk_notifyctrl()->addMsgr("Msg.ColorUpdated");
		$this->View();
	}
	public function th_downloadcolorfile()
	{
		$v_div = HtmlItem::CreateWebNode("Colors");
		foreach($this->App->Doc->Theme->cl->Attributes as $k=>$v)
		{
			$v_div->add("color", array("name"=>$k, "value"=>$v));
		}
		igk_download_content("colortheme.xml", 0,  $v_div->Render());
		exit;
	}
	public function th_importcolorfile()
	{
		
		igk_wln("th_importcolorfile");
		$v_f = igk_getv($_FILES, "clColorFile");
		$text = IGKIO::ReadAllText($v_f["tmp_name"]);
		$v_t = HtmlItem::CreateWebNode("div");		
		$v_t->Load($text);		
		$v_clt = igk_getv($v_t->getElementsByTagName("Colors"), 0);		
		if ($v_clt !== null)
		{
			igk_wln("load color");
			foreach($v_clt->Childs as $k=>$v)
			{
				if ($v->TagName=="color")
				{
					$this->App->Doc->Theme->addColor($v["name"], $v["value"]);	
					
				}
			}
			$this->View();			
		}	
		igk_notifyctrl()->addMsgr("Msg.ColorUpdated");
		igk_frame_close("theme_importcolorfile");
		
	}
	public function th_importcolorfileframe()
	{
		$frm = igk_add_new_frame($this, "theme_importcolorfile", "#colorman",$this->App->Doc->body); 
		
		 
		$frm->Title = R::ngets("title.importcolorfile");		
		$frm->ClearChilds();
		$d = $frm->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("th_importcolorfile#colorman");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clColorFile","lb.ColorName", "file",null);		
		$frm->addHSep();
		$frm->addBtn("btn_import",R::ngets("btn.import") );
	}
	//--------------------------------------------------
	//COLOR FUNCTION
	//--------------------------------------------------
	private function _showColor(){
		
		$d = $this->TargetNode;
		$t = igk_add_title($d, R::ngets("title.ColorManager") );		
		$d->addHSep();
		$t["id"]="colorman";
		igk_add_article($this,"themes.colormanager.description", $d);
		$d->add(new HtmlSearchItem($this->getUri("searchcolor"), $this->m_searchColor,"qcl"));
		$d->addHSep();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("changecl");
		//get colors
		$colors = igk_getv($this->App->Doc->Theme->getElementsByTagName("Colors"),0);
		
		
		$this->__addbtn($frm, $this);
		$frm->addBr();
		$frm->addBr();
		$tab = $frm->add("table", array("class"=>"fitw"));
		$ctab = $colors->Attributes->toArray();
		
		$stab = array_keys($ctab);
		igk_usort($stab, "igk_key_sort");
		$tr = $tab->add("tr");
		HtmlUtils::AddToggleAllCheckboxTh($tr);
		
		$tr->add("th", array("class"=>""))->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th", array("class"=>""))->Content = R::ngets("clValue");		
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		
		foreach($stab as $k)
		{
			if (($this->m_searchColor) && !strstr($k, $this->m_searchColor) )
				continue;
				$v= $ctab[$k];
				
				$tr = $tab->add("tr");
				$tr->add("td")->add("input", array("type"=>"checkbox"));
				$tr->add("td")->Content = $k;
				$tr->add("td")->Content = $v;
				$tr->add("td")->add($this->_newColorBox(igk_css_treatcolor($colors, $v),array("href"=>$this->getUri("editColor&n=".$k."&cl=".urlencode($v)))));				
				HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("dropcolor&n=".$k), "drop");
				
		}
		$frm->addBr();
		$this->__addbtn($frm, $this);
		igk_html_toggle_class($tab);
		
	}
	public function editColor(){
		$n = urldecode(igk_getr("n"));
		$cl = igk_getr("cl");
		$this->addnewcolorframe( $n, $cl);
	}
	public function addnewcolorframe($name=null, $color=null){
		$frm = igk_add_new_frame($this, "theme_addcolor", "#colorman",$this->App->Doc->body); 
		$edit = $name !=null;
		if (!$edit)
			$frm->Title = R::ngets("title.addColorTheme");		
		else 
			$frm->Title = R::ngets("title.editColorTheme");		
		$frm->ClearChilds();
		$d = $frm->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("addColorThemeKey#colorman");
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name", "text", $name);
		$ul->add("li")->addSLabelInput("clColor","lb.ColorName", "text", $color);		
		if ($edit)
			$ul->add("li")->addInput("clEdit", "hidden", true);
		$frm->addBtn("btn_add", $edit? R::ngets("btn.Edit") :R::ngets("btn.Add"));
	}
	public function addColorThemeKey(){
		$cl = igk_getr(IGK_FD_NAME);
		$cv = igk_getr("clColor");
		if (!empty($cl))
		{
			$this->App->Doc->Theme->addColor($cl, $cv);	
			igk_notifyctrl()->addMsg("Color modifier ".$cl." = ".$cv);
			if (igk_getr("clEdit"))
			{
				$this->View();
				igk_frame_close("theme_addcolor");
			}
		}
		$this->View();
	}
	public function dropcolor(){
		$cl = igk_getr("n");
		$this->App->Doc->Theme->removeColor($cl);		
		$this->View();
		
	}
	private function _newColorBox($cl, $attribs =null, $width=16, $height=16){
		$box = HtmlItem::CreateWebNode("a", array("class"=>"color_view nodecoration dispib", "style"=>
"width:".$width."px; height:".$height."px; background-color:".$cl.";"));
		$box->AppendAttributes($attribs);
		$box->Content = "&nbsp;";
		return $box;
	}
	public function searchcolor(){
		$this->m_searchColor = igk_getr("qcl");
		$this->View();
	}
	//--------------------------------------------------
	//RES FUNCTION
	//--------------------------------------------------
	
	private function _showRes(){
		$d = $this->TargetNode;
		
		igk_add_title($d, R::ngets("title.resManager"));
		$d->add(new HtmlSeparatorItem());
		$d->add(new HtmlSearchItem($this->getUri("searchres"),$this->m_searchRes,"qres"));
		$frm = $d->addForm();
	}
	public function searchres(){
	$this->m_searchRes = igk_getr("qres");
		$this->View();
	}
	private function _themeFormControl($frm){
		HtmlUtils::AddBtnLnk($frm,R::ngets("btn.Add"), $this->getUri("addKey")); 
	}
	
	public function search($searchkey=null){
		$q = igk_getr("q",$searchkey);
		
		
		if (empty($q))
		{			
			$this->m_search = null;
			$this->m_searchkey = null;
			$this->View();
			return;
		}
		$tab = $this->App->Doc->Theme->Attributes->toArray();
		$out = array();
		foreach($tab as $k=>$v)
		{
			if (strstr($k, $q))
			{
				$out[$k]=$v;
			}
		}
		$this->m_search = $out;
		$this->m_searchkey = $q;
		$this->View();
	}
	public function update_name(){
		$n = igk_getr("theme_name", "default");
		$this->App->Doc->Theme->Name = $n;
		$this->View();
	}
	
	public function th_addPalette(){
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addPalette", $this,  "#palette_form");
		HtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.AddPalette");
		
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("th_addThemePalette");
		$frm->add("li")->addSLabelInput(IGK_FD_NAME,"lb.Name");
		$li = $frm->add("li");
		$li->add("label", array("for"=>"clFile"))->Content = R::ngets("lb.palette");
		$li->addInput("clFile","file","file");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));
	}
	public function th_addThemePalette()
	{
		$v_c = igk_getv($_FILES, "clFile");
		
		if ($v_c)
		{
			$v_fname = igk_getctrl(IGK_PALETTE_CTRL)->getPaletteDir()."/".igk_getr(IGK_FD_NAME).".gkpal";
			igk_io_move_uploaded_file($v_c["tmp_name"], $v_fname);
			igk_notifyctrl()->addMsgr("msg.paletteAdded");			
			igk_getctrl(IGK_PALETTE_CTRL)->loadFile($v_fname);
			$this->View();
		}		
	}
	
	//--------------------------------------------------
	//CSS CLASS KEYS FUNCTION
	//--------------------------------------------------	
	public function rmkey(){
		$key = igk_getr("id");
		if (!empty($key))
		{
		$this->App->Doc->Theme[$key] = null;
		IGKThemeCtrl::UnRegClass($key) ;		
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
		}
		//igk_navtocurrent();
	}
	public function addKey(){
		
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addkey", $this, "#class_editor");
		HtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.AddClass");
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("addThemeKey");
		$frm->add("li")->addSLabelInput("colName","lb.Name");
		$frm->add("li")->addSLabelInput("colValue","lb.Value");
		$frm->addHSep();
		$frm->addBtn("btn_add", R::ngets("btn.Add"));	
		
	}
	public function editKey()
	{
		$n = igk_getr("id");
		
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("theme_addkey", $this, "#class_editor");
		HtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.editclassentry");
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("addThemeKey");
		$frm->add("li")->add("label")->Content = $n;
		$frm->add("li")->Content = IGK_HTML_SPACE;
		
		$frm->add("li")->addSLabelInput("colValue","lb.Value","text", $this->App->Doc->Theme[$n] );
		$frm->addInput(IGK_FD_NAME, "hidden", $n);
		$frm->addInput("clUpdated", "hidden", $n);
		$frm->addHSep();
		$frm->addBtn("btn_update", R::ngets("btn.update"));	
	}
	public function addThemeKey(){
		$n = trim( igk_getr("colName"));
		$v = igk_getr("colValue");
		if ($n){
			$this->App->Doc->Theme[$n] = $v;
		}
		
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
		$t = igk_getr("clUpdated" , false);
		if ($t)
		{
			igk_frame_close("theme_addkey");
		}
		igk_navtocurrent();
	}
	public function theme_update(){
	
		if (igk_getr("btn_action") == 1){ $this->delete_selection(); return;}
		
		 $keytab= igk_getr("keytab");
		 $hv = igk_getr("ccount");
		 $n = igk_getr("theme_name");
		
		
		for($i = 0 ; $i< $hv; $i++)
		{
			$this->App->Doc->Theme[$keytab[$i]] = igk_getr("key_".$i);//$v[$i];
		}
		//TODO: save the theme;
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		$this->search($this->m_searchkey);
		$this->View();
		
		try{
		igk_notifyctrl()->addMsgr("msg.themeupdated");
		igk_navtocurrent();
		}catch(Exception $ex){
			igk_show_exception($ex);
		}
	}
	public function initTargetNode(){
		$t = HtmlItem::CreateWebNode("div", array("class"=>strtolower($this->getName())));
		return $t;
	}
	
	public function getConfigPage()
	{
		return "themectrlconfig";
	}
	
	private function getCssDataFile()
	{
		return igk_io_currentRelativePath(IGK_DATA_FOLDER."/StylesData.xml");
	}
	public function themeCurrentMedia(){
		if(IGKUserAgent::IsIE())return "ie";
		if(IGKUserAgent::IsMod())return "mod";
		if(IGKUserAgent::IsChrome()) return "chr";
		if(IGKUserAgent::IsSafari()) return "saf";
		if(IGKUserAgent::IsAndroid())return "android";
		if(IGKUserAgent::IsIOS())return "ios";
		
		return "ie";
	}
	public function themeIsSupportMedia($target)
	{
		if ($target=="*")return true;
		if (strstr($target, $this->themeCurrentMedia()))
			return true;
		return false;
	}
	private function themeLoadCssFiles()
	{
		$this->m_cssFileTable = array();
		$t =  HtmlItem::LoadNode(IGKIO::ReadAllText($this->getCssDataFile()));

		if (($t!=null) && ($t->HasChilds))
		{			
			
			foreach($t->Childs as $k=>$v)
			{
				$k = igk_html_uri($v["file"] );
				if ($this->themeAddCss($k, $v["target"], $v["block"]))
				{
					if (!igk_is_debuging())
					{
						$this->app->Doc->addStyle($k);
					}
				}
			}
		}
		
	}
	private function themeAddCss($file, $device="ie" , $block=false)
	{
		if (!isset($this->m_cssFileTable[$file]))
		{
			$v_cssObj = new StdClass;
			$v_cssObj->Uri = $file;
			$v_cssObj->Target = $device;
			$v_cssObj->Block = $block;
			$this->m_cssFileTable[$file] = $v_cssObj;				
			return true;
		}
		return false;
	}
	///add css file to system
	public function themeAddCssFile($file, $device="ie")//supported device all, ie, mod, android, ios
	{
		if ($this->themeAddCss(igk_html_uri($file), $device))
		{
			$this->themeSaveCssData();
		}
	}
	function themeSaveCssData()
	{
		$o = HtmlItem::CreateWebNode("cssData");
		foreach($this->m_cssFileTable as $k=>$v)
		{
			$css = $o->add("css");
			$css["file"] = $v->Uri;
			$css["target"] = $v->Target;
			$css["block"] = $v->Block;
		}
		IGKIO::WriteToFileAsUtf8WBOM($this->getCssDataFile(), $o->Render());
	}
	public function themeGetCss()
	{
		//if debugging retun nothing
		//else merge all style
		
		//if (igk_is_debuging())
			//return null;
		$t = "";
		foreach($this->m_cssFileTable as $k=>$v)
		{
			if ( !$v->Block && $this->themeIsSupportMedia($v->Target))
			{
				$t .="/* ". $k. "*/\n";
				$t .= IGKIO::ReadAllText(igk_io_currentRelativePath($k))."\n";
			}
		}
		return $t;
		
	}
	//remove css file to system
	public function themeRemoveCssFile()
	{
	}
	//clear all css files
	public function themeRemoveAllCssFile()
	{
	}
	public function themeShowCssFiles()
	{
		$t = HtmlItem::CreateWebNode("table");
		$t["class"]="fitw";
		
		$b =  array("style"=>"width:16px;");
		$tr = $t->add("tr");
		$tr->add("th", $b)->addSpace();
		$tr->add("th");
		$tr->add("th");
		$tr->add("th", $b)->addSpace();
		$tr->add("th", $b)->addSpace();
		$tr->add("th", $b)->addSpace();
		foreach($this->m_cssFileTable as $k=>$v)
		{
			$tr = $t->add("tr");
			$tr->add("td", $b)->addSpace();
			$tr->add("td")->add("a", array("href"=>$this->getUri("themeDownloadCssFile&n=".base64_encode($k))))->Content = $v->Uri;
			$tr->add("td")->Content = $v->Target;			
			
			HtmlUtils::AddImgLnk($tr->add("td"),igk_js_post_frame($this->getUri("themeEditFile_ajx&n=".base64_encode($k))), "edit", "16px", "16px","dropCSS File" );
			//HtmlUtils::AddImgLnk($tr->add("td"),igk_js_post_frame($this->getUri("themeBlockCssFile&n=".base64_encode($k))), "block", "16px", "16px","dropCSS File" );
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("themeBlockCssFile&n=".base64_encode($k)),
			$v->Block? "block": "unblock", "16px", "16px","dropCSS File" );
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("themeDropFile&n=".base64_encode($k)), "drop", "16px", "16px","dropCSS File" );
			
		}
		$this->TargetNode->add($t);
		//actions button div
		$t = HtmlItem::CreateWebNode("div");
		//9
		HtmlUtils::AddBtnLnk($t, "btn.addCssFile", igk_js_post_frame($this->getUri("themeAddNewCssFile_ajx")));
		$this->TargetNode->add($t);
	}
	public function themeAddNewCssFile_ajx()
	{
		//$t = HtmlItem::CreateWebNode("div");
		//$t->Content  = "Add New Css File Not Implement";
		
		
		$frame = igk_add_new_frame($this, "frame_themeAddNewCssFile");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.addCssFile");		
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("themeAddCssFileFunc");
		$ul = $frm->add("ul");			
		$ul->add("li")->addInput("clName", "text", "newfile");		
		$sl = $ul->add("li")->add("select");
		$sl["id"]=$sl["name"]="clFor";
		$sl->add("option")->Content = "ie";
		$sl->add("option")->Content = "mod";
		
		$frm->addHSep();
		$frm->addBtn("btn_update", R::ngets("btn.add"));		
		if (igk_sys_isAJX())
		{
			$frame->RenderAJX();
		}
		
		//$t->RenderAJX();
	}
	public function themeAddCssFileFunc(){
		$n = igk_getr("clName", null);
		
		if ($n && preg_match("/([a-zA-Z_][a-zA-Z0-9_]+)/i", $n) )
		{
			$f = igk_io_currentRelativePath("Styles/".$n.".css");
			IGKIO::WriteToFileAsUtf8WBOM($f, "/* ".$n." */", true);
			igk_frame_close("frame_themeAddNewCssFile");
			$this->themeAddCssFile(igk_html_uri(igk_io_basePath($f)),  igk_getr("clFor","ie"));
			$this->View();
		}
	}
	public function themeBlockCssFile()
	{
		$n = base64_decode(igk_getr("n"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			return;			
		}
		$this->m_cssFileTable[$n]->Block = !$this->m_cssFileTable[$n]->Block;
		$this->themeSaveCssData();
		$this->View();
	}
	public function themeEditFile_ajx()
	{
		$n = base64_decode(igk_getr("n"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			igk_wl("ERROR: no file to edit");
			return;			
		}
		$p = $this->m_cssFileTable[$n];
		$f = igk_io_currentRelativePath($p->Uri);
		
		if(file_exists($f))
		{
		$frame = igk_add_new_frame($this, "frame_themeEditFile");
		$frame->ClearChilds();			
		$frame->Title = R::ngets("title.editCssFile", basename($n));						
		$str = IGKIO::ReadAllText($f);					
		$d = $frame->Content;
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("themeUpdateCssFile");
		$ul = $frm->add("ul");
		$txt = $ul->add("li")->addTextArea("clContent",utf8_decode($str));			
		$txt["class"] = "frame_textarea";
		$frm->addInput("clfile", "hidden", base64_encode($n));
		$frm->addInput("clframe", "hidden", $frame["id"]);
		$frm->addBtn("btn_update", R::ngets("btn.Update"));
		
		if (igk_sys_isAJX())
		{
			$frame->RenderAJX();
		}
		}
		else{
			igk_wl("ERROR: FILE NOT EXISTS");
		}
	}
	public function themeUpdateCssFile()
	{
		$n = base64_decode(igk_getr("clfile"));
		if (!isset($this->m_cssFileTable[$n]))
		{
			return;			
		}
		igk_io_saveContentFromTextArea(igk_io_currentRelativePath($n), igk_getr("clContent"), true);
		igk_frame_close("frame_themeEditFile");
	}
	public function themeDropFile()
	{
		$n = base64_decode(igk_getr("n"));
		if (isset($this->m_cssFileTable[$n]))
		{
			@unlink(igk_io_currentRelativePath($n));
			unset($this->m_cssFileTable[$n]);
			$this->themeSaveCssData();
			$this->View();
		}
	}
	
}

//represent a frame controller
final class IGKFrameDialogCtrl extends IGKControllerBase
{
	private $m_frames;
	public function getName(){
	return IGK_FRAME_CTRL;
	}
	
	public function closeFrame_ajx()
	{
		$id = igk_getr("id");
		igk_frame_close($id);
	}
	public function __construct(){
		parent::__construct();
		$this->m_frames = array();
	}
	public function View(){
	//notion to view
	}
	
	public function createFrame($id, $owner, $closeuri=null, $reloadcallback = null){
		if (($id == null ) ||!is_string($id))
			return null;
			
		if ( isset($this->m_frames[$id]))
		{
			$v_dial =  $this->m_frames[$id];
			if ($v_dial->Owner == $owner)
				return $v_dial;
			return null;
		}
		$v_dial = new IGKMsDialogFrame($id, $owner, $reloadcallback);
		$v_dial->ClearChilds();
		$cluri = null;
		if ($closeuri){
			$cluri = "&closeuri=".urlencode($closeuri);
		}
		else{
			$cluri="&navigate=1";
		}
		$v_dial->setCloseUri($this->getUri("closeFrame&id=".$id.$cluri));	
		$v_dial["id"] = $id;
		$this->m_frames[$id]= $v_dial;			
		return $v_dial;
	}
	public function getFrame($id)
	{
		if ( isset($this->m_frames[$id]))
		{
			return $this->m_frames[$id];
		}
		return null;
	}
	
	public function close_frame_ajx()
	{
		$href = base64_decode(igk_getr("href"));
		$tag = igk_getquery_args($href);
		$this->closeFrame(igk_getv($tag, "id"));
		igk_wl( $this->App->Doc->body->Render());
		exit;
		
	}
	public function closeFramre_ajx()
	{
		$this->closeFrame();
	}
	public function closeFrame($id=null, $navigate = false){			
		$v_id = ($id!=null)? $id:igk_getr("id",0);
		$closeuri = null;
		$navigate = !$navigate ? igk_getr("navigate", false): false;
		if ( isset($this->m_frames[$v_id]))
		{
			$frame = $this->m_frames[$v_id];
			$args = igk_getquery_args($frame->closeUri);
			if (($closeuri = urldecode(igk_getr("closeuri")))==null)
				$closeuri = urldecode(igk_getv($args, "closeuri"));
			igk_html_rm($frame);				
			if (method_exists(get_class($frame->Owner), "frameClosed"))
			{
				$frame->Owner->frameClosed();
			}
			$frame->closeMethod();				
			//unset frame id
			unset($this->m_frames[$v_id]);
			//unset frame
			unset($frame);
		}	

		if (!igk_sys_isAJX() ){
	
			if ($closeuri){				
				igk_navtocurrent( $closeuri);
				exit;
			}
			else if ($navigate)
			{
				igk_navtocurrent();
				exit;
			}
		}
	}
}


//page  controlleurs
final class IGKPageManagerCtrl extends IGKConfigCtrlBase
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getIsVisible()
	{
		return true;
	}
	public function initTargetNode()
	{
		$t = HtmlItem::CreateWebNode("div");
		$t["class"]="web_pageinfo";
		return $t;
	}
	public function InitComplete()
	{
		parent::InitComplete();
		
		//::register page change event
		$this->App->addCurrentPageEvent($this, "View");
	}
	public function View()
	{	
		//view Configs
		if ($this->IsVisible)
		{			
		
			switch ($this->CurrentPageFolder)
			{
				case IGK_CONFIG_PAGEFOLDER:					
					$this->_viewConfig();	
					break;
				default:
					$this->_showPage();
					break;
			}
		}
		else {		
			igk_html_rm($this->TargetNode);
		}
			
	}
	public function showConfig(){			
		parent::showConfig();		
	}
	private function _showPage()
	{
		$page = igk_getctrl(IGK_MENU_CTRL)->CurrentPage;
		$t = $this->TargetNode;	
		$t->ClearChilds();
		$dir = $this->getPageFolderFullPath ();	
		
		$file = igk_io_getdir($dir."/".$page.".".R::GetCurrentLang().".phtml");
		if ($this->App->CurrentPageFolder == IGK_CONFIG_MODE)
		{
			return;
		}
		igk_html_add($this->TargetNode, $this->App->Doc->body,-500);
		
		if(file_exists($file))
		{
			$v_str = @file_get_contents($file);						
			$t->Load($v_str);
		}
	}
	private function _viewConfig(){
		if ( $this->ConfigCtrl->SelectedConfigCtrl !== $this) 
			return;
	
		$div = HtmlItem::CreateWebNode("div");
		igk_html_add($div, $this->ConfigNode);		
		
		
		$node = $div;
		$this->addTitle($node, "title.PageManagerEditor");
		$node->addHSep();
		igk_add_article($this,"page.description", $node->addDiv());
		$node->addHSep();

		$node->addDiv()->add("label")->Content = "CurrentLang : ". R::GetCurrentLang();
		$frm = $node->addForm();
	
		//get page list
		$p = igk_getctrl(IGK_MENU_CTRL)->getPageList();
		
		$tab = $frm->add("table");
		$tab["class"] ="fitw" ;
		$tr = $tab->add("tr");
		$tr->add("th", array("style"=>"min-width:200px"))->Content = R::ngets(IGK_FD_NAME);
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		foreach($p as $k)
		{
			$tr = $tab->add("tr");
			$tr->add("td")->add("a" ,array("href"=>$this->getUri("getfile&n=".$k)))->Content = $k;
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("editPageFrame&name=".$k), "edit", "16px", "16px","editpage" );
			HtmlUtils::AddImgLnk($tr->add("td"),$this->getUri("editPageFrameWTiny&name=".$k), "tiny", "16px", "16px","editpage" );
		}
	}
	public function editPageFrame($wtiny=false)
	{
		$n = igk_getr("name");
		$frm = igk_getctrl(IGK_FRAME_CTRL)->createFrame("page_editframe", $this);
		HtmlUtils::AddItem($frm,  $this->App->Doc->body);	
		$frm->Title = R::ngets("title.EditPage", $n);
		$d = $frm->Content;
		$frm->ClearChilds();
		$frm = $d->addForm();
		$frm["action"]=$this->getUri("savePage");
		$frm->add("li")->add("label")->Content ="" ;
		$frm->addInput("name", "hidden", $n);
		$file = $this->getPageFile($n);
		$area = $frm->add("li")->addTextArea("clContent", file_exists($file)? utf8_decode(IGKIO::ReadAllText($file)):null );
		if ($wtiny)
			igk_js_enable_tinymce($frm, 'exact', array("clContent"));
		
		$frm->addBtn("btn_save", R::ngets("btn.Update"));	
	}
	public function editPageFrameWTiny()
	{
		$this->editPageFrame(true);
	}
	public function getPageFile($n)
	{	
		$dir = $this->getPageFolderFullPath ();
		$file =  igk_io_getdir($dir."/".$n.".".R::GetCurrentLang().".phtml");
		return $file;
	}
	public function getfile(){
		$n = igk_getr("n");
		$file = $this->getPageFile($n);
		if (file_exists($file))
		{
			igk_download_file(basename($file), $file);
		}
		else{
			igk_notifyctrl()->addError("impossible d'obtenir le fichier ".basename($file));
		}
	}
	private function getPageFolderFullPath(){
		return igk_io_currentbasepath(IGK_PAGE_FOLDER);
	}
	public function savePage(){
		//save content with tiny in utf8 without bom
		$n = igk_getr("name");		
		
		$content = igk_getr("clContent");
		
		$dir = $this->getPageFolderFullPath();
		
		IGKIO::CreateRDir($dir);
		
		$file = igk_io_getdir($dir."/".$n.".".R::GetCurrentLang().".phtml");
		$out = igk_html_unscape( $content);	
		IGKIO::WriteToFileAsUtf8WBOM($file, $out, true);	
		igk_frame_close("page_editframe");
	}
	
	public function getConfigPage()
		{
			return "pageconfig";
		}
}

///group controlleur
final class IGKUserGroupController extends IGKControllerBase
{
	
	
	
	public function getDataTableName(){return "tbigk_usergroups"; }
	public function getDataTableInfo()
	{
	return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clUserId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10, "clIsUniqueColumnMember"=>true ,"clFromTable"=>"tbigk_users" )),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGroupId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10,"clIsUniqueColumnMember"=>true , "clFromTable"=>"tbigk_groups" ))
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->Insert($n, array("clUserId"=>1, "clGroupId"=>2));
		
	}
	public function View()
	{
		//do nothing
	}
}

//group controlleur
final class IGKGroupController extends IGKConfigCtrlBase
{
public function getConfigPage()
	{
		return "groupconfig";
	}
	
	
	public function getDataTableName(){return "tbigk_groups"; }
	public function getDataTableInfo()
	{
	return array(
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
		new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255, "clIsUnique"=>true ))
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->Insert($n, array(IGK_FD_NAME=>"users"));
		$db->Insert($n, array(IGK_FD_NAME=>"admin"));
	}
	public function View()
	{
		$this->TargetNode->ClearChilds();
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);			
			return;
		}
		$this->_showConfig();
	}
	private function _showConfig()
	{
		igk_html_add($this->TargetNode, $this->ConfigNode);
		$node = $this->TargetNode;
		$this->addTitle($node, "title.GroupEditor");
		$node->addHSep();
		igk_add_article($this,"group.description", $node->addDiv());
		$node->addHSep();
		
		$frm = $node->addForm();
		
		$table = $frm->add("table");
		$tr = $table->add("tr");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = R::ngets("clName");
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$tr->add("th")->Content = IGK_HTML_SPACE;
		$e = $this->getDbEntries();
		if ($e)
		foreach($e->Rows as $k=>$v)
		{
			$tr = $table->add("tr");
			$tr->add("td")->Content = IGK_HTML_SPACE;
			$tr->add("td")->Content = $v;
		}
	
	}
}
//groups and autorisation
final class IGKGroupAutorisations extends IGKConfigCtrlBase
{
	public function getDataTableInfo()
	{
		return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGroupId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10 , "clFromTable"=>"tbigk_Groups" )),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clAuthId", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10 , "clFromTable"=>"tbigk_Autorisations" )),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clGrant", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>10, "clDescription"=>"Grand Access depending on the autorisation usage" , "clFromTable"=>"tbigk_Autorisations" )),
		);
	}
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function getDataTableName(){return "tbigk_groupautorisations"; }
	public function getConfigPage()
	{
		return "groupauth";
	}
	
	public function View(){
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_add_title($t, "title.manageauth");
		
		$t->addHSep();
		igk_add_article($this, "auth.managerdesc" , $t->addDiv(), null, true);
		$t->addHSep();
		$frm = $t->addForm();
		
	}

}


final class IGKAutorisationsCtrl extends IGKControllerBase
{
	public function getDataTableName(){return "tbigk_autorisations" ;}
	
	public function getIsVisible(){return false;}
	
	public function getDataAdapterName(){
		return IGK_MYSQL_DATAADAPTER;
	}
	public function getDataTableInfo(){
		return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_ID, IGK_FD_TYPE=>"Int","clAutoIncrement"=>true,IGK_FD_TYPELEN=>10, "clIsUnique"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>50, "clIsUnique"=>true))		
		);
	}
	public function initDb(){
		parent::initDb();
	}
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->Insert($n, array(IGK_FD_NAME=>"mod_articles"));
		$db->Insert($n, array(IGK_FD_NAME=>"mod_view"));
		$db->Insert($n, array(IGK_FD_NAME=>"mod_post"));
	}
	
}



final class IGKDebugCtrl extends IGKControllerBase
{
	private $m_topdiv;
	private $m_optionsdiv;
	public function View()
	{
	}
	public function getIsVisible()
	{
		return igkServerInfo::IsLocal() ;
	}
	public function InitComplete()
	{
		parent::InitComplete();
		
	}
	public function addMessage($div)
	{
		$this->m_topdiv->add($div);
	}
	public function initTargetNode()
	{
		$node = parent::initTargetNode();
		$cl = strtolower($this->getName());
		$node["class"]=$cl." loc_t loc_l zback posr";
		$this->m_topdiv = $node->add("div",array("class"=>$cl."_content"));
		$this->m_optionsdiv = $node->add("div", array("class"=>$cl."_options posr loc_b loc_l"));
		HtmlUtils::AddBtnLnk($this->m_optionsdiv, "btn.clearDebug",$this->getUri("clearDebug"));
		
		return $node;
		
	}
	public function clearDebug()
	{
		$this->m_topdiv->ClearChilds();
	}
	
}
class IGKErrorCtrl extends IGKControllerBase{

	var $target;
	
	private $m_errorUri;
	
	public function getName(){
		return IGK_ERROR_CTRL;
	}

	public function __construct(){
		parent::__construct();
		$this->m_visible = false;
	}
	///@@@ redirect requested uri to sub page
	public function redirect()
	{
		 
	}
	/*public function show_error()
	{
		$code = igk_getr("code");
		if ($this->target == null)
		{
			$this->target = new HtmlSingleViewItem(HtmlItem::CreateWebNode("div"));
		}
		HtmlUtils::AddItem($this->target, $this->App->Doc->bodypage);	
		
		//error URI 
		$str = "".igk_getbase_serverdir();		
		$b = "".$_SERVER["REQUEST_URI"];
		$uri = "";
		igk_wln("queryuri : ".$b);
		igk_wln("basedir : ".$str);
		if (!empty($str) && strstr($b, $str))
		{
			$uri = substr($b, strlen($str));
		}
		igk_wln("uri: ".$uri);
		$k = igk_getwebpagectrl();
		if ($k!=null) 
			$k->manageErrorUriRequest($uri);
		$this->target->targetNode->addDiv()->Content = ("Requested page not found : ".$code . "<br /> Referer ".$uri ."<br />");		
		$this->m_visible  = true;
		$this->View();
		$this->m_visible  = false;
	}*/
	
	public function addError($uri)
	{
		if ($this->m_errorUri == null)
			$this->m_errorUri = array();
		$this->m_errorUri[] = $uri;
	}
	public function getIsVisible()
	{
		return igk_count($this->m_errorUri);
	}
}

//@@@ controller de changement. permet à un controlleur de signaler un changement de configuration
final class IGKChangeManagerCtrl extends IGKConfigCtrlBase
{
	private $m_datas;
	private $m_propertyChangedEvent;
	private $m_loadConfigEvent;	
	private $m_vChange;
	private $m_ConfigNode;
	
	
	const DATE_CONST = 'Y-m-d H:i:s';
	public function getName(){		return IGK_CHANGE_MAN_CTRL;	}
	
	//ajout et suppression d'évènement
	public function addPropertyChangedEvent($obj, $method){
		$this->m_propertyChangedEvent->add($obj, $method);
	}
	public function removePropertyChangedEvent($obj, $method)
	{
		$this->m_propertyChangedEvent->remove($obj, $method);
	}
	//register to config event
	public function addLoadConfigEvent($obj, $method)
	{
		$this->m_loadConfigEvent->add($obj, $method);
	}
	public function removeLoadConfigEvent($obj, $method)
	{
		$this->m_loadConfigEvent->remove($obj, $method);
	}
	//donné sauvegarder par le controlleur
	public function getData(){
		return $this->m_datas;
	}
	public function __construct(){
		parent::__construct();
		$this->m_propertyChangedEvent = new IGKEvents($this, get_class($this)."::PropertyChanged");
		$this->m_loadConfigEvent =  new IGKEvents($this, get_class($this)."::loadConfigEvent");
		$this->loadConfig();
	}
	public function getConfigPage()
	{
		return "changectrl";
	}
	
	//enregistrer les changements sur un paramètre de configuration. 
	//cela a pour effet de mettre a jour la ligne de temps.
	public function registerChange($itemname, & $entrynewdata)
	{
		$d = date(self::DATE_CONST);
		$this->m_datas->$itemname = $d;
		$this->m_datas->LastChange = $this->m_datas->$itemname ;
		//igk_wln("registerChanged : ".$itemname);
		$this->m_datas->saveData();		
		$entrynewdata = $d;
	}
	//supprimer la sauvegarde sur un paramètre de configuration
	public function unregisterChange($itemname){
		$d = date(self::DATE_CONST);
		$this->m_datas->$itemname = null;
		$this->m_datas->LastChange = $d;
		$this->m_datas->Save();		
	}
	//detecter si la propriété a changer au cour du temp. retourne true si besoin de recharge sinon false
	public function isChanged($entryname, & $entrynewdata =null ){
		$n = $entryname;
		if ($this->Data->$n ==null)
			return;
		$data = $this->Data->$n ;
		$m = (($data != null) && (!empty($entrynewdata))) ;
		$reload = $m && ($data != $entrynewdata);
		if ($this->Data->$n != $entrynewdata)
		{
			$entrynewdata = $data;
		}
		return $reload;	
	}
	public function InitComplete()
	{
		parent::InitComplete();
		//a chaque fois que la session doit être mis a jour recharger la configuration
		$this->App->Session->addUpdateSessionEvent($this, "loadConfig");		
	}
	public function getIsVisible(){
		return true;
	}
	public function functionIsAvailable($function)
	{
		return true;
		// switch($function)
		// {
			// case "checkchange_ajx":
			// case "checkforupdate_ajx":
				// return true;
		// }
		// return parent::functionIsAvailable($function);
	}
	public function View(){
		//not visible
		$this->TargetNode->ClearChilds();
		if ($this->App->Configs->changectrl_checkchange)
		{
			$i = $this->App->Configs->changectrl_interval? $this->App->Configs->changectrl_interval : 'null';
			igk_html_add($this->TargetNode, $this->App->Doc->Body);		
			$this->TargetNode->addScript()->Content = "igk.ctrl.changement.init('".$this->getUri("checkforupdate_ajx")."', ".$i.");";
		}
		else{
			igk_html_rm($this->TargetNode);
		}
		
	}
	public function checkforupdate_ajx()
	{
		$this->loadConfig();
		if ($this->isChanged("LastChange", $this->m_vChange))
		{
			igk_wl(R::ngets("MSG.DATACHANGED"));
		}
		else 
			igk_wl("");
		exit;
	}
	

	public function update_change()
	{
		$this->App->Configs->changectrl_checkchange = igk_getr("clCheckChange", false);
		$this->App->Configs->changectrl_interval = igk_getr("clChangeInterval");		
		igk_save_config();
		igk_resetr();
		$this->showConfig();
		$this->View();
	}
	//configuration view
	public function showConfig()
	{
		parent::showConfig();
		//view Config
		$c = $this->m_ConfigNode;
		$c->ClearChilds();
		HtmlUtils::AddItem($c, $this->ConfigNode);
		igk_add_title($c, "title.ChangeCtrlManager");
		$c->addHSep();
		
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("update_change");
		
		$ul = $frm->add("ul");
		$t = array();
		if ($this->App->Configs->changectrl_checkchange) 
			$t["checked"] = "true";
		
		$ul->add("li")->addSLabelInput("clCheckChange", "lb.clActivateChangement","checkbox", true, $t);
		$ul->add("li")->addSLabelInput("clChangeInterval", "lb.clChangementInterval", "text", $this->App->Configs->changectrl_interval);
		
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	public function loadConfig()	
	{
		$fullpath = igk_io_syspath(IGK_CHANGE_CONF_DATA);
		$f = IGKCSVDataAdapter::LoadData($fullpath);
		if ($this->m_datas == null)
			$this->m_datas = new IGKConfigData($fullpath, $this, array());
		if ($f != null)
			{			
		foreach($f as $k=>$v)
		{	
			$c  = igk_getv($v,0);
			if ($c){
			// if ( igk_getv($this->m_datas,$v[0]) != $v[1])
			// {
				// $this->m_datas->$c =igk_getv($v, 1);	
			// }
			// else{
				$this->m_datas->$c = igk_getv($v, 1);
			// }
			}
		}
		}
		$this->__onLoadConfigEvent();
	}
	protected function __onLoadConfigEvent()
	{
		$this->m_loadConfigEvent->Call($this, null);
	}
	
	public function showinfo()
	{
		$this->TargetNode->ClearChilds();
		HtmlUtils::AddItem($this->TargetNode, $this->App->Doc->body);
		$ul = $this->TargetNode->add("ul");
		foreach($this->m_datas->getEntries() as $k=>$v)
		{
			$ul->add("li")->Content = $k.":".$v;
		}
	}

	private static function CompareDate($date1, $date2)
	{
		return igk_date_compare($date1, $date2);
	}
	public function initTargetNode()
	{
		$this->m_ConfigNode = HtmlItem::CreateWebNode("div");
		return parent::initTargetNode();
	}
	
}
//-----------------------------------------------------------------------------------
//represent a method controller
//-----------------------------------------------------------------------------------
class IGKMetaController extends IGKConfigCtrlBase
{
	var $Description;
	var $EndocingType;
	var $Keyword;
	var $Copyright;
	var $title;
	
	public function __construct()
	{
		parent::__construct();
		$this->Description = new IGKMetaValue();
		$this->Author = new IGKMetaValue();
		$this->EndocingType = new IGKMetaValue();
		$this->Keyword = new IGKMetaValue();
		$this->Copyright = new IGKMetaValue();		
		$this->title = new IGKMetaValue();		
		$this->EndocingType->Value = IGK_ENCODINGTYPE; //default encoding type value
		$this->Copyright->Value =IGK_COPYRIGHT; //default copyright value
		$this->title->Value = "";
		
	}
	public function getConfigPage()
	{
		return "metactrl";
	}
	
	public function View ()
	{
	
		$c = $this->TargetNode;		
		if (!$this->IsVisible)
		{
			igk_html_rm($c);
			return;
		}
		$c->ClearChilds();
		HtmlUtils::AddItem($c, $this->ConfigNode);
		igk_add_title($c, "title.MetaController");
		$c->addHSep();
		igk_add_article($this, "metaconfig", $c->addDiv(),null, true);
		$c->addHSep();
		
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("meta_update");
		
		$ul = $frm->add("ul");
		$ul->add("li")->addSLabelInput("clDesc", "lb.MetaDefaultDescription","text", $this->App->Configs->meta_description);
		$ul->add("li")->addSLabelInput("clCopyright", "lb.MetaCopyRight", "text", $this->App->Configs->meta_copyright);
		$ul->add("li")->addSLabelInput("clKeysWords", "lb.MetaKeywords", "text" , $this->App->Configs->meta_keysword);
		$ul->add("li")->addSLabelInput("clEncType", "lb.MetaEncType", "text" , $this->App->Configs->meta_enctype);
		$ul->add("li")->addSLabelInput("clDefaultTitle", "lb.MetaDefaultTitle", "text" , $this->App->Configs->meta_title);
		
		$frm->addBtn("btn_save", R::ngets("btn.save"));
	}
	function __reset_value()
	{
			$this->Description->Value = 	$this->App->Configs->meta_description;	
			$this->EndocingType->Value = $this->App->Configs->meta_enctype;
			$this->Keyword->Value = $this->App->Configs->meta_keysword;
			$this->Copyright->Value = $this->App->Configs->meta_copyright ;
			$this->title->Value = $this->App->Configs->meta_title ;
			
	}
	public function meta_update()
	{
		$this->App->Configs->meta_description = igk_getr("clDesc");
		$this->App->Configs->meta_copyright = igk_getr("clCopyright");
		$this->App->Configs->meta_keysword = igk_getr("clKeysWords");
		$this->App->Configs->meta_enctype= igk_getr("clEncType");
		$this->App->Configs->meta_title = igk_getr("clDefaultTitle");
		igk_save_config();
		$this->__reset_value();
		$this->View();
		igk_notifyctrl()->addMsgr("Msg.metaUpdated");
		igk_navtocurrent();
	}
	public function InitComplete()
	{
		parent::InitComplete();
		//init default property
		$this->__reset_value();	
		$this->App->Doc->Metas->Author = IGK_AUTHOR; 
		$this->App->Doc->Metas->Copyright = $this->Copyright;		
		$this->App->Doc->Metas->Description = $this->Description ;
		$this->App->Doc->Metas->Keywords = $this->Keyword;		
		$this->App->Doc->Metas->ContentType =  $this->EndocingType; 			
		
	}	
}
//meta value 
class IGKMetaValue extends IGKObject implements IHtmlGetValue
{
	private $m_value;
	public function getValue(){ return $this->m_value;}
	public function setValue($value){ $this->m_value = $value;}
	
	public function __toString(){
		return "IGKMetaValue[". $this->getValue()."]";
	}
}

//view references controller
final class IGKReferenceCtrl extends IGKConfigCtrlBase
{
	private $m_selectedMenu;
	private $m_selectedClass;
	private $m_selectedInterface;
	private $m_searchkey;
	
	public function getConfigPage()
	{
		return "referencectrl";
	}
	public function View()
	{
		extract($this->getSystemVars());
		$c = $this->TargetNode;		
		if (!$this->IsVisible)
		{
			igk_html_rm($c);
			return;
		}
		HtmlUtils::AddItem($c, $this->ConfigNode);		
		$c->ClearChilds();
		igk_add_title($c,"References");
		$c->addHSep();
		$menut = array("vars", "const", "functions", "class","interface");
		$t = array();
		foreach($menut as $k)
		{			
			$t[$k] = $this->getUri("select_menu&n=".$k);
		}
		
		$dv = $c->addDiv();
		
		
		$c->addHSep();
		$div = $c->addDiv(array("id"=>"div_ref_output"));
		$pmenu = "";
		switch(strtolower($this->m_selectedMenu))
		{
			
			case "const":
				$pmenu = "const";
				$this->getGlobalConst($div);
				break;
			case "vars":
				$pmenu = "vars";
				$this->getGlobalVars($div);
				break;
			case "class":
				$pmenu = "class";
				$this->getDeclaredClass($div);				
				break;
			case "interface":
				$pmenu = "interface";
				$this->getDeclaredInterface($div);
				break;
			case "interfaceinfo":
				$pmenu = "interface";
				$this->getInterfaceDefinition($div);
				break;
			case "classinfo":
				$pmenu = "class";
				$this->getClassInfo($div);
				break;
			case "functions":
			default:
				$pmenu = "functions";
				$this->getGlobalFunctions($div);
			break;
		}
		
		HtmlUtils::CreateConfigSubMenu($dv, $t, $pmenu);
		unset($t);
	}
	public function getInterfaceDefinition($div)
	{
		$name =igk_getr("n");
$div->add("h2")->Content = "Interface : ".$name;
$div->add("p")->Content = "Properties";
$t = get_class_vars($name);
if (count($t)== 0)
{
	$div->addDiv()->Content =  "no vars defined";
}
else{
$div->add("pre")->Content = count($t);
foreach($t as $k=>$v)
{
	$div->add("span", array("style"=>'display:block; float:left; width:200px; overflow:hidden'))->Content = "var ".$v."();";
	
}
}

$div->addBr(array("style"=>"clear:both"));
$div->add("h3")->Content = "Methods";

$t = get_class_methods($name);
if (count($t) == 0)
{
	$div->add("label")->Content =  "no methods";
}
else {
foreach($t as $k)
{
	$div->add("span", array("style"=>'display:block; float:left; width:200px; overflow:hidden'))->Content = "function ".$k."();";
}
}
	}
	
	public function showinterfaceinfo(){
	$name = igk_getr("n");
if (!interface_exists($name))
{
	igk_debug("warning:". $name." not a valid interface");
	return;
}
$this->m_selectedMenu = "interfaceinfo";
$this->View();


	}
	private function getClassInfo($node, $name=null){
		$n = ($name == null)? igk_getr("n") : $name;
		if (!class_exists($n)){
			$node->addDiv()->Content = "class does't exits";
			return;
		}
		
		$node->add("h2")->Content = "Class : ".$n ;
		$d = new ReflectionClass($n);
		$fname = $d->getFileName();
		
		$info = $node->addDiv();
		$ul = $info->add("ul");
		$ul->add("li")->Content = "FileName  : ". ((empty($fname))? "unknow" : $fname);
		$ul->add("li")->Content = "Parent : " . get_parent_class($n);
		$imps = class_implements($n);
		if (count($imps) > 0){
			$timp = $info->addDiv();
			$timp->add("h2")->Content = "implements : ";
			$tul = $timp->add("ul");
			foreach($imps as $k=>$v){
			  $tul->add("li")->add("a", array("href"=>$this->getUri("showinterfaceinfo")))->Content = $k;	
			}
		}
		$node->addHSep();
		$info = $node->addDiv();
		$info->add("h2")->Content = "Properties";
		$this->App->Doc->Theme["w200px"] = "width:200px; ";
		$t = get_class_vars($n);
		if (count($t)>0){
		
			foreach($t as $k=>$v){
				$info->add("span", array("class"=>"floatl dispb w200px "))->Content = $k;
			}
		}
		else{
			$info->addDiv()->Content = "No Properties";
		}
		//get mehods
		$t = get_class_methods($n);
		
		$node->add("div", array("class"=>"clearb", "style"=>"clear:both"));
		
		$node->addHSep();
		$info = $node->addDiv();
		$info->add("h2")->Content = "Methods";
		if (count($t)> 0){
			sort($t);
			foreach($t as $k=>$v){
			$info->add("span", array("class"=>"floatl dipsb w200px"))->Content = $v;
			}
		}
		else{
		$info->addDiv()->Content = "No Public methods";
		}
	
	}
	private function getMethodInfo($node){
	}
	private function getDeclaredClass($node){
	igk_add_title($node, "title.globalclass");
		
		$node->add(new HtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());		
		$tab = get_declared_classes();
		sort($tab);
		foreach($tab as $v)
		{
			
			
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl overflow_none", "style"=>"width:230px"))->add("a",
				array("href"=>$this->getUri("showclassinfo&n=".$v))
				)->Content = $v;
			
			
		}
	}
	public function showclassinfo(){
		$n = igk_getr("n");
		$this->m_selectedMenu = "classinfo";
		$this->View();
	}
	private function getDeclaredInterface($node){
	igk_add_title($node, "title.globalinterface");
		
		$node->add(new HtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		$tab = get_declared_interfaces();
		sort($tab);		
		foreach($tab as $v)
		{
			
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl overflow_none", "style"=>"width:230px"))->add("a", array("href"=>$this->getUri("showinterfaceinfo&n=".$v)))->Content = $v;
			
			
		}
	}
	private function getGlobalVars($node){
		igk_add_title($node, "title.globalvars");
		
		$node->add(new HtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		extract($this->getSystemVars());
		$tab = get_defined_vars() ;
			
		foreach($tab as $k=>$v)
		{
			
				if ($this->m_searchkey && !strstr(strtolower($k),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl overflow_none", "style"=>"width:230px"))->Content = $k;
			
			
		}
	}
	private function getGlobalConst($node){
		igk_add_title($node, "title.globalconst");
		
		$node->add(new HtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array());	
		$tab = get_defined_constants();			
		foreach($tab as $k=>$v)
		{
				if ($this->m_searchkey && !strstr(strtolower($k),strtolower($this->m_searchkey)))
					continue;
				$div->add("li" , array("class"=>"dispib floatl overflow_none", "style"=>"width:430px"))->Content = $k ."=".$v ;
		}
	}
	private function getGlobalFunctions($node){
		igk_add_title($node, "title.globalfunctions");
		
		$node->add(new HtmlSearchItem($this->getUri("searchgfunc"),$this->m_searchkey));
		$div = $node->addDiv(array("class"=>"cl_functionslist"));		
		foreach(get_defined_functions() as $k)
		{
			sort($k, SORT_STRING);
			foreach($k as $v){
				
				if ($this->m_searchkey && !strstr(strtolower($v),strtolower($this->m_searchkey)))
					continue;
				$s = new ReflectionFunction($v);
				
				$href = "";
				if ($s->getFileName())
				{
					$href="#";
				}
				else{
					$href = "http://php.net/manual/".R::GetCurrentLang()."/function.".str_replace("_","-",$v).".php";
				}
				$div->add("li" , array("class"=>"dispib floatl overflow_none", "style"=>"width:230px"))->add("a", 
				array("class"=>"", "href"=>$href))->Content = $v;
			}
			
		}
	}
	public function searchgfunc(){
		$this->m_searchkey = igk_getr("q");
		$this->View();
		igk_navtocurrent();
	}
	public function select_menu()
	{
		$this->m_selectedMenu = igk_getr("n");
		$this->m_searchkey = null;
		$this->View();
		igk_navtocurrent();
	}
}
//view configs tools
final class IGKToolsCtrl extends IGKConfigCtrlBase
{
	private $m_tools;
	public function __construct()
	{
		parent::__construct();
		$this->m_tools = array();
	}
	public function getConfigPage()
	{
		return "toolctrl";
	}
	public function RegisterTool($ctrl)
	{
		$this->m_tools[$ctrl->Name] = $ctrl;
		$this->regController($ctrl);
	}
	
	public function View()
	{
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		
		$t = $this->TargetNode;
		$t->ClearChilds();
		igk_html_add($t, $this->ConfigNode);
		igk_add_title($t,"Tools");
		$t->addHSep();
		$d = $t->addDiv();
		
		
		foreach($this->m_tools as $k=>$v)
		{	
			$v->showTool($d);			
		}
	}
}
///represent a base class for a tool
abstract class IGKToolCtrlBase extends IGKControllerBase
{
	public function getIsSystemController(){
		return true;
	}
	public function getImageUri(){ return "";
	}
	public function InitComplete()
	{
		parent::InitComplete();
		igk_getctrl("IGKToolsCtrl")->RegisterTool($this);
	}
	public function View(){
	}
	public function doAction(){
		//configure and do action
	}
	public function showTool($ownernode)
	{
		igk_html_add( $this->TargetNode, $ownernode);
		$t = $this->TargetNode;
		$t["class"]= "dispib alignc alignt";
		$t["style"]= "min-width: 96px; min-height:72px;";
		$t->ClearChilds();
		$d = $t->addDiv();
		$a = $d->add("a", array("class"=>"alignc dispib", "href"=>$this->getUri("doAction")));
		$a->add("img", array("style"=>"width: 48px; height:48px;display:inline-block;", "src"=>$this->getImageUri()));
		$a->addDiv()->Content = R::ngets("tool.".$this->Name);
		
	}
	public function hideTool($ownernode)
	{
		igk_wln("hidde ".$ownernode);
		igk_html_rm($this->TargetNode);
		$t = $this->TargetNode;
		$t->ClearChilds();
		
	}
}



///community default manager
final class IGKCommunityLink extends IGKConfigCtrlBase
{
	
	public function getConfigPage()
	{
		return "community";
	}
	public function View(){
		$c = $this->TargetNode;		
		if (!$this->IsVisible)
		{
			igk_html_rm($c);
			return;
		}
		HtmlUtils::AddItem($c, $this->ConfigNode);		
		$c->ClearChilds();
		
		$frm = $c->addForm();
		$frm["action"] = $this->getUri("update_community");
		igk_add_title($frm,"title.configure.community");
		$frm->addHSep();
		igk_add_article($this, "community_desc", $frm->addDiv());
		$frm->addHSep();
		$ul = $frm->add("ul");
		$ul->addLi()->addSLabelInput("clFacebookUri", "lb.community.FacebookUri", "text",$this->App->Configs->community_facebook_uri);
		$ul->addLi()->addSLabelInput("clTwitterUri", "lb.community.TwitterUri", "text",$this->App->Configs->community_twitter_uri);
		$ul->addLi()->addSLabelInput("clGooglePlusUri", "lb.community.GooblePlus", "text",$this->App->Configs->community_googleplus_uri);
		$ul->addLi()->addSLabelInput("clLinkeInUri", "lb.community.LinkedInUri", "text",$this->App->Configs->community_linkedin_uri);
		$frm->AddHSep();
		$frm->addBtn("btn_send", R::ngets("btn.update"));
		
	}
	public function update_community()
	{
		$this->App->Configs->community_facebook_uri = igk_getr("clFacebookUri");
		$this->App->Configs->community_twitter_uri = igk_getr("clTwitterUri");
		$this->App->Configs->community_googleplus_uri = igk_getr("clGooglePlusUri");
		$this->App->Configs->community_linkedin_uri = igk_getr("clLinkeInUri");
		igk_save_config();
		$this->View();
		igk_notifyctrl()->addMsgr("msg.CommunityLinkUpdated");
		igk_navtocurrent();
	}
	
	public function addGooglePlus($target){
		$lnk = $this->App->Doc->addLink("googleplus:uri");
		$lnk["rel"] = "canonical";
		$lnk["href"] = $this->App->Configs->community_googleplus_uri;
		$src = $this->App->Doc->addScript("https://apis.google.com/js/plusone.js");
		$gdiv = $target->add("span");
		$gdiv->add("g:plusone")->addNothing();
	}
	
}



//-----------------------------------------------------------------------------------
//REPRESENT FINAL FPDF CONTAINS
//-----------------------------------------------------------------------------------
final class IGKPDF extends IGKObject
{
	private $m_fpdf;
	private $m_title;
	private $m_author;
	private $m_subject;
	private $m_keywords;
	
	public function getFpdf (){
		return $this->m_fpdf;
	}
	public function __construct()
	{		
		$this->init('P','mm','A4');
	}
	//-------------------------------------------------------------------
	//set properties 
	//-------------------------------------------------------------------
	public function setTitle($value){$this->m_title = $value;}
	public function setAuthor($value){$this->m_author = $value;}
	public function setSubject($value){$this->m_subject = $value;}
	public function setKeywords($value){$this->m_keywords = $value;}
	public function setXY($x, $y){ $this->FPDF->SetXY($x, $y); }
	public function setMargin($left, $top, $right){		$this->FPDF->SetMargins($left, $top, $right);	}
	public function setWidth($w){	$this->FPDF->SetLineWidth($w);	}
	public function setFontSize($w){	$this->FPDF->SetFontSize($w);	}
	public function setFont($name, $type, $size){	$this->FPDF->SetFont($name, $type, $size);	}
	//get title
	//-------------------------------------------------------------------
	public function getTitle(){ return $this->m_title; }
	public function getAuthor(){ return $this->m_author; }
	public function getSubject(){ return $this->m_subject; }
	public function getKeywords(){ return $this->m_keywords; }
	public function getStringWidth($s){ return $this->FPDF->GetStringWidth($s); }
	public function getX(){ return $this->FPDF->GetX(); }
	public function getY(){ return $this->FPDF->GetY(); }
	public function getPageNo(){ return $this->FPDF->PageNo(); }
	
	
	public function init($type="P", $unit="mm", $format="A4", $firstpage=true)
	{
		$this->m_fpdf = new FPDF($type, $unit,$format);
		$this->m_fpdf->SetFont("Arial", "", 12);
		if ($firstpage){
		//add first page
		$this->addPage();
		}
	}
	
	public function addPage()
	{
		$this->m_fpdf->AddPage();
	}
	
	public function addCPage($type="P", $format="A4")
	{
		$this->m_fpdf->AddPage($type,$format);
	}
	public function addBr($h=null)
	{
		$this->m_fpdf->Ln($h);
	}
	public function addFont($fn, $style="", $file=null)
	{
		$this->m_fpdf->AddFont($fn,$style, $file);
	}
	
	public function drawImg($file, $x=null, $y=null,$w=0,$h=0,$type=null,$link=null)
	{
		$this->FPDF->Image($file, $x,$y,$w,$h,$type,$link);
	}
	public function setfColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetFillColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	public function setdColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetDrawColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	public function settColorf($r,$g=null,$b=null)
	{
		$this->FPDF->SetTextColor($r*255, $g?$g*255:$g,$b?$b*255:$b);
	}
	
	
	
	public function drawLine($x1, $y1, $x2, $y2)
	{
		$this->m_fpdf->Line($x1, $y1, $x2, $y2);
	}
	public function drawCText($x, $y, $text, $border=0, $ln=1, $align= "L", $fill=false , $link=null)
	{
		$this->m_fpdf->Cell($x, $y, $text, $border, $ln, $align, $fill, $link);
	}
	public function drawText($x, $y, $text)
	{
		$this->m_fpdf->Text($x, $y, $text);
	}
	public function drawWText($h, $text , $link=null)
	{
		$this->m_fpdf->Write($h, $text, $link);
	}
	public function drawMultiTextCell($w, $h, $text , $border=0,  $align="L", $filcolor=false)
	{
		$this->m_fpdf->MultiCell($w, $h, $text , $border,  $align, $filcolor);
	}
	public function drawRect($x,$y,$w,$h){
		$this->FPDF->Rect($x,$y,$w,$h);
	}
	public function fillRect($x,$y,$w,$h){
		$this->FPDF->Rect($x,$y,$w,$h, 'F');
	}
	public function drawLink($x,$y,$w,$h, $link){
		$this->FPDF->Rect($x,$y,$w,$h, $link);
	}
	//link funciton
	//-
	public function createLink()
	{
		return $this->FPDF->AddLink();
	}
	public function setLink($id, $y=0, $p=-1 )
	{
		return $this->FPDF->SetLink($id, $y,$page);
	}
	//to end 
	public function Render($name="pdfdocument.pdf", $dest="I")
	{
		$this->m_fpdf->title = $this->Title;
		$this->m_fpdf->author = $this->Author;
		$this->m_fpdf->subject = $this->Subject;
		$this->m_fpdf->keywords = $this->Keywords;
		$this->m_fpdf->Output($name, $dest);		
	}
}

//-----------------------------------------------------------------------------------------
/// MAIL FUNCTION
//-----------------------------------------------------------------------------------------
//represent a mail attachement
class IGKMailAttachement extends IGKObject
{
	var $Type;
	var $ContentType;
	var $Link;	
	var $CID;
	var $Visible;
	var $Name;
	
	private  $m_Data;
	
	public function __construct()
	{
		$this->ContentType = "text/plain";
		$this->Visible = false;
		
	}
	public function setContent($content)
	{
		$this->m_Data = $content;
	}
	public function getContent(){ return $this->m_Data; }
	public function getData()
	{
		if ($this->Type == "Content")
			return chunk_split(base64_encode( $this->m_Data),76,"\n");	
		return chunk_split(base64_encode( file_get_contents($this->Link)),76,"\n");	
	}
}
//represent a mail object
class IGKMail extends IGKObject
{
	private $m_to;
	private $m_tocc;
	private $m_toBcc;
	private $m_files;
	private $m_textmsg;
	private $m_htmlmsg;
	private $m_title;
	private $m_from;
	private $m_replyto;
	
	private $m_smtp_port;
	private $m_useAuth;
	private $m_user;
	private $m_pwd;
	private $m_socketType="tls"; //tls or ssl
	private $m_socketTimeout = 15;
	private $m_smtphost ;
	
	
	private  $html_charset =  "iso-8859-1";
	private  $text_charset = "iso-8859-1";
	
	const PART_ALTERNATIVE = "multipart/alternative";	
	const PART_MIXED = "multipart/mixed";
	
	const CONTENT_PLAIN_TEXT = "text/plain";
	const CONTENT_HTML_TEXT = "text/html";
	const CONTENT_IMG_PNG = "image/png";
	
	public function getFrom(){return $this->m_from;}
	public function setFrom($value){ $this->m_from = $value; }
	public function getTitle(){return $this->m_title;}
	public function setTitle($value){ $this->m_title = $value; }
	
	
	public function getSocketType(){return $this->m_socketType;}
	public function setSocketType($v){ switch(strtolower($v)){ case "tls": case "ssl":$this->m_socketType = strtolower($v); break; }}
	
	public function getSocketTimeout(){return $this->m_socketTimeout;}
	public function setSocketTimeout($value){ $this->m_socketTimeout = $value; }
	
	public function getReplyTo(){return $this->m_replyto;}
	public function setReplyTo($value){ $this->m_replyto = $value; }
	
	public function getUser(){return $this->m_user;}
	public function setUser($value){ $this->m_user = $value; }
	
	public function getPwd(){return $this->m_pwd;}
	public function setPwd($value){ $this->m_pwd = $value; }
	
	public function getSmtpHost(){return $this->m_smtphost;}
	public function setSmtpHost($value){ $this->m_smtphost = $value; }
	
	public function getPort(){return $this->m_smtp_port;}
	public function setPort($value){ $this->m_smtp_port = $value; }
	
	public function setHtmlCharset($v){ $this->html_charset = $v;  }
	public function setTextCharset($v){ $this->text_charset = $v;  }
	
	public function getHtmlCharset(){ return $this->html_charset;  }
	public function getTextCharset(){ return $this->text_charset;  }
	
	
	public function __construct()
	{
		$this->m_files = array();
		$this->m_to = array();
		$this->m_tocc = array();
		$this->m_toBcc = array();
	}
	public function setTextMsg($content)	{		$this->m_textmsg = $content;	}
	public function setHtmlMsg($content)	{		$this->m_htmlmsg = $content;	}
	public function getHtmlMsg() { return $this->m_htmlmsg ;}
	public function getTextMsg(){return $this->m_textmsg; }
	public function getUseAuth(){return $this->m_useAuth; }
	
	public function setUseAuth($value){ $this->m_useAuth = $value; }
	
	
	public function attachFile($file, $contentType="text/plain", $cid=null)
	{
		$attach = new IGKMailAttachement();
		$attach->Link = $file;
		$attach->ContentType = $contentType;
		$attach->CID = $cid;
		$attach->Type  = "Uri";
		$this->m_files[] = $attach;
		return $attach;
	}
	public function attachContent($content, $contentType="text/plain", $cid=null)
	{
		$attach = new IGKMailAttachement();
		$attach->Content = $content;
		$attach->ContentType = $contentType;
		$attach->CID = $cid;
		$attach->Type  = "Content";
		$this->m_files[] = $attach;
		return $attach;
	}
	public function addTo($to)
	{
		$this->m_to[] = $to;
	}
	public function clearTo()
	 {
		$this->m_to = array();
	 }
	public function addToCC($to)
	{
		$this->m_tocc[] = $to;
	}
	public function addToGCC($to)
	{
		$this->m_toBcc[] = $to;
	}
	public function getToString(){
		return self::GetMailList($this->m_to);
	}
	static function GetMailList($tab)
	{
			$o = "";
		foreach($tab as $k=>$v)
		{
			if ($k>0)
				$o.=",";
			$o .= self::MailEntry($v);
		}
		return $o;
	}
	static function MailEntry($c)
	{
		$out = "";
		if (is_numeric($c) || (is_string($c) &&  !empty($c)))
		{
			$out.=$c;
		}
		else if (is_object($c) && (method_exists(get_class($c),"getValue")) )
		{
			$out .= $c->getValue();
		}
		return $out;
	}
	private function _getHeader($boundary)
	{
		$header = "";
		if ($this->m_from)
		$header .= "From: ".$this->m_from."\r\n";
		if ($this->m_replyto)
		$header .= "Reply-To: ".$this->m_replyto."\r\n";
		$CC  = self::GetMailList($this->m_tocc);
		if (!empty($cc))
		{
			$header .= "CC: ".$cc."\r\n";	
		}
		$CC  = self::GetMailList($this->m_toBcc);
		if (!empty($cc))
		{
			$header .= "Bcc: ".$cc."\r\n";	
		}
		$header .= "MIME-Version: 1.0\r\n";
		//cause problem with thunderbird
		//$header .= "Content-Type: multipart/mixed; boundary=$boundary\n";
		//correct problem with thunderbird
		$header .= "Content-Type: multipart/related; boundary=$boundary\r\n";
		
		return $header;
	}
	public function sendMail()
	{
		
		$boundary = igk_new_id();
		$to = $this->getToString();
		$title = $this->getTitle();
		$header = $this->_getHeader($boundary);
	
		$message = "\n";
		$message .= "This is a multi-part message in MIME Format.\n";
		$message .= "--$boundary\n";			
		
		$j1 = $this->TextMsg;
		$j2 = $this->HtmlMsg;
		
		if (!((empty($j1) && empty($j2))))
		{
		$message .= "Content-Type: multipart/alternative; boundary=sub_$boundary\n";
		
		if (!empty($j1))
		{
			
			$message .= "\n\n--sub_$boundary\n";
			$message .="Content-Type: text/plain; charset=\"".$this->text_charset."\"\n\n";
			$message .= $j1;
		}		
		
		if(!empty($j2))
		{
			$message .= "\n\n--sub_$boundary\n";			
			$message .= "Content-Type:text/html; charset=\"".$this->html_charset."\"\n\n";		
			$message .= $j2;
		}
		$message .= "\n\n--sub_$boundary--\n";		
		}
			
		
		foreach($this->m_files as $k=>$v)
		{
		// attach files
		$data = $v->Data;//chunk_split(base64_encode( file_get_contents($v->Link)));	
		//$message .= "Content-Type: image/gif; name=\"attachment.txt\"\n";//with name
		$message .= "\n\n--$boundary\n";	
		$message .= "Content-Type: ".$v->ContentType.";";
		if ($v->Name){
			$message .= "name=\"".$v->Name."\"";
		}
		$message .= "\n";//with name
		$message .= "Content-Transfer-Encoding: base64\n";
		if (!$v->Visible)
			$message .= "Content-Disposition: attachment\n"; //suppress view
		if ($v->CID)
			$message .= "Content-ID: <".$v->CID.">\n"; //les crochet sont important pour ajouter une image 
		
		$message .= "\n".$data;
		
		}
		$message .= "\n--$boundary--\n";
		$message .= "end of the multi-part";
	
		if ($this->UseAuth)
		{		
			
			if (extension_loaded("openssl"))
			{
				
				//igk::$DEBUG = true;
				$v = $this->__sendMailTLS($header, $message);		
				//igk::$DEBUG = false;
				return $v;
			}
			igk_debug_wln("no openssl extension loaded");
			return false;
		}
		else{			
			if (@mail($to, $title, $message,$header) == true)
			{			
				return true;
			}
		}
		return false;
	}
	
	
	
	
	//Function to Processes Server Response Codes
	private function server_parse($socket, $expected_response)
	{
		if (igk_getv(socket_get_status($socket), "eof"))
		{			
			return false;
		}		
		$server_response = '';
		while (substr($server_response, 3, 1) != ' ')
		{
			if (!($server_response = fgets($socket, 256)))
			{			
			  igk_debug_wln('Error while fetching server response codes.');
			  return false;
			}            
		}
		igk_debug_wln('OK : "'.$server_response.'"');
		if (!(substr($server_response, 0, 3) == $expected_response))
		{
		  igk_debug_wln('Unable to send e-mail."'.$server_response.'"');
		  return false;
		}
		return true;
	}
	private function _closeSocket($socket)
	{
		fwrite($socket, 'QUIT'."\r\n");
		fclose($socket);
	}
	private function __sendMailTLS($headers, $message)
	{
			$errno = "";
		$errstr="";
		$host = $this->m_smtphost;
		$user = $this->m_user;
		$pass = $this->m_pwd;
		$port = $this->m_smtp_port;
		$timeout = $this->m_socketTimeout;
	
	  $socket = @fsockopen($host , $port, $errno, $errstr, $timeout);
	  if(!$socket)
	  {
		igk_debug_wln("ERROR: ".$host." ".$port." - $errstr ($errno)");
		return false;
	  }
	  else
	  {
		igk_debug_wln("SUCCESS: ".$host." ".$port." - ok");

	$recipients = $this->m_to;
	$subject = $this->Title;
		
		

		if (!$this->server_parse($socket, '220')) { $this->_closeSocket($socket); return false;}   
		
		fwrite($socket, 'EHLO '.$host."\r\n");				
		if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
		
		if ($this->SocketType =="tls")
		{
			 
			fwrite($socket, 'STARTTLS'."\r\n");		
			if (!$this->server_parse($socket, '220')) { $this->_closeSocket($socket); return false;}    
			
			if(false == @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT))
			{
				$this->_closeSocket($socket);
				igk_debug_wln("unable to start tls encryption");
				return false;
			}

			
				fwrite($socket, 'HELO '.$host."\r\n");		
				if (!$this->server_parse($socket, '250')) return false;

		}	
			igk_debug_wln("AUTH LOGIN");
			fwrite($socket, 'AUTH LOGIN'."\r\n");    
			if (!$this->server_parse($socket, '334')) { $this->_closeSocket($socket); return false;}    


			igk_debug_wln("AUTH USER " .$user);
			fwrite($socket, base64_encode($user)."\r\n");    
			if (!$this->server_parse($socket, '334')) { $this->_closeSocket($socket); return false;}    

			igk_debug_wln("AUTH pass " .igk::getInstance()->Configs->mail_password);
			fwrite($socket, base64_encode($pass)."\r\n");    
			if (!$this->server_parse($socket, '235')) { $this->_closeSocket($socket); return false;}    

			igk_debug_wln("AUTH USER " .$this->FROM);
			fwrite($socket, 'MAIL FROM: <'.$this->From.'>'."\r\n");    
			if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
			foreach ($recipients as $email)
			{
				fwrite($socket, 'RCPT TO: <'.$email.'>'."\r\n");
				if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}    
			}
			fwrite($socket, 'DATA'."\r\n");    
			if (!$this->server_parse($socket, '354')) { $this->_closeSocket($socket); return false;}

			fwrite($socket, 'Subject: '
			.$subject."\r\n".'To: <'.implode('>, <', $recipients).'>'
			."\r\n".$headers."\r\n\r\n".$message."\r\n");
			//end
			fwrite($socket, '.'."\r\n");
			
			if (!$this->server_parse($socket, '250')) { $this->_closeSocket($socket); return false;}
			
			$this->_closeSocket($socket);
			return true;

	  }
	}
	
	
	
}



//for script managemenent
final class IGKScriptController extends IGKControllerBase
{
	private $m_script;
	public function setScript($value){$this->m_script = $value;}
	public function getScript()
	{
		header('Content-type: Application/javascript;  charset=\"utf-8\";');
		igk_wl($this->m_script);
		exit;
	}
	public function getIsVisible(){return false;}
}

//for script managemenent
final class IGKArticlesCtrl extends IGKControllerBase
{
	public function getQueryArticle(){
		$q = base64_decode(igk_getr("q"));
		igk_wln($q);
		igk_wln(igk_io_basePath($q));
		exit;
	}
	public function getIsVisible(){return false;}
}

class IGKCountryCtrl extends IGKControllerBase
{
	private $m_countries;
	
	public function getIsVisible(){return false;}
	
	public function __construct()
	{
		parent::__construct();
		$this->_loadData();
	}
	public function getCountries()
	{
		return $this->m_countries;
	}
	public function getDataTableName(){return "tbcountries"; }
	public function getDataAdapterName(){return "CSV"; }
	
	private function _loadData()
	{
		$r = IGKCSVDataAdapter::LoadData(igk_io_syspath("Data/tbcountries.csv"));
		if ($r)
		{
			$this->m_countries = array();
			foreach($r as $l)
			{		
				$this->m_countries[$l[0]] = $l[0];
			}
		}
	}
	
}
// - user variables

final  class IGKUserVarsCtrl extends IGKConfigCtrlBase
{
	private $m_vars;
	private $m_searchkey;
	public function getName(){return IGK_USERVARS_CTRL; }
	public function getdataFileName(){return igk_io_currentbasePath(IGK_DATA_FOLDER.DIRECTORY_SEPARATOR."usersvar.csv");}
	public function getConfigPage()
	{
		return "uservarctrl";
	}
	public function getVars()
	{
		return $this->m_vars;
	}
	public function regVars($name, $value,$comment)
	{
		if (empty($name))
			return;
		$this->m_vars[$name] = 
						array(
							"value"=> $value,
							"comment"=> $comment
						);
	}
	public function __construct(){
		parent::__construct();
		
		$this->__loadVars();
	}
	private function __loadVars()
	{
		$this->m_vars = array();
		$e = IGKCSVDataAdapter::LoadData($this->dataFileName);
		if ($e)
		{
			foreach($e as $k=>$v)
			{
					$this->m_vars[$v[0]] = 
						array(
							"value"=> igk_getv($v, 1),
							"comment"=> igk_getv($v, 2)
						);
			}
		}
	
	}
	public function vc_addvars()
	{
		$obj = igk_getr_obj();
		$this->m_vars[$obj->clName] = array("value"=>$obj->clValue, "comment"=>$obj->clComment);
		$this->__storeVars();
	}
	public function vc_dropvars()
	{
		$obj = igk_getr("n");
		if (isset($this->m_vars[$obj]))
		{
		unset($this->m_vars[$obj]);		
		$this->__storeVars();
		$this->View();		
		}
		igk_navtocurrent();
	}
	public function vc_clearvars($store=true)
	{	
		$this->m_vars = array();
		if ($store)
			$this->__storeVars();
	}
	public function __storeVars()
	{
		$f = igk_io_currentbasePath(IGK_DATA_FOLDER.DIRECTORY_SEPARATOR."usersvar.csv");
		$out = "";
		foreach($this->m_vars as $k=>$v)
		{
			$v_cv = igk_getv($v, "value");
			$v_cc = igk_getv($v, "comment");
			if (!empty($out))
			{
				$out .= "\n";
			}
			$out .= $k.",".igk_csv_getvalue($v_cv).",".igk_csv_getvalue($v_cc);
		}
		if (igk_io_save_file_as_utf8($f, $out)){
	
			igk_notifyctrl()->addMsgr("MSG.UserVarsCtrl.VarSaved");
		}
		else{
			igk_wln($out);
			exit;
		}
		$this->View();
	}
	public function search_var()
	{
		$this->m_searchkey = igk_getr("q");
		$this->View();
	}
	public function View()
	{
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_add_title($t, "title.uservariables");
		
		$t->addHSep();
		igk_add_article($this, "uservariableinfo" , $t->addDiv(), null, true);
		$t->addHSep();
		
		$t->add(new HtmlSearchItem($this->getUri("search_var"), $this->m_searchkey));
		
		
		
		$frm = $t->addForm();
		$frm["action"] = $this->getUri("vc_saveAllVars");
		$table = $frm->add("table", array("class"=>"fitw"));
		$tr = $table->add("tr");
		HtmlUtils::AddToggleAllCheckboxTh($tr);
			$tr->add("th")->Content =R::ngets(IGK_FD_NAME);
			$tr->add("th")->Content =R::ngets("clValue");
			$tr->add("th")->Content =R::ngets("clComment");
			$tr->add("th")->Content = IGK_HTML_SPACE;
		
		if (is_array($this->m_vars))
		{
			foreach($this->m_vars as $k=>$v)
			{
				$obj = (object)$v;				
				if ($this->m_searchkey && !strstr(strtolower($k), strtolower($this->m_searchkey)))
					continue;
				$tr = $table->add("tr");
				$td = $tr->add("td");
				$td->addInput("clName[]", "checkbox",$k);
				$td->addInput("clHName[]", "hidden", $k);
				$tr->add("td")->Content = $k;
				
				$tr->add("td")->addInput("clValue[]", "text", $obj->value);
				$tr->add("td")->addInput("clComment[]", "text", $obj->comment);	
				HtmlUtils::AddImgLnk($tr->add("td"), $this->getUri("vc_dropvars&n=".$k), "drop");
				
			}
		}
		$frm->addHSep();
		$frm->addInput("btn_save", "submit", R::ngets("btn.save"));		
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.addvars"), igk_js_post_frame($this->getUri("vc_addvarframe_ajx")));
		////
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.rmSelection"), "#", array("onclick"=>igk_js_a_postform($this->getUri("vc_rm_selection"))));
		igk_html_toggle_class($table);
	}
	public function vc_rm_selection()
	{
	
		$n = igk_getr("clName");
		if (is_array($n))
		{
		foreach($n as $k=>$v)
		{
			unset($this->m_vars[$v]);
		}
		$this->__storeVars();
		}
		$this->View();
		igk_navtocurrent();
		
	}
	public function vc_addvarframe_ajx()	
	{
		$frame = igk_add_new_frame($this,"new_uservars_frame");
		$frame->Title = R::ngets("title.addUserFrame");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("vc_addvars");
		$ul = $frm->add("ul");
		
		$ul->add("li")->addSLabelInput(IGK_FD_NAME, IGK_FD_NAME);
		$ul->add("li")->addSLabelInput("clValue", "clValue");
		$ul->add("li")->addSLabelInput("clComment", "clComment");
		$frm->addHSep();
		$frm->addInput("btn_savevar", "submit", R::ngets("btn.savevar"));
		igk_wl($frame->Render());
	}
	public function vc_saveAllVars()
	{
		$tn = igk_getr(IGK_FD_NAME);
		$tv =igk_getr("clValue");
		$tc = igk_getr("clComment");
		
		if(igk_getr("btn_save"))
		{
			$tn = igk_getr("clHName");
		}
		
		for($i = 0; $i< igk_count($tn);$i++)
		{
			$n = $tn[$i];
			$v = igk_getv($tv, $i);
			$c = igk_getv($tc, $i);
			
			$this->regVars($n, $v, $c);
		}
		$this->__storeVars();
		igk_navtocurrent();
	}
	
	
	public function InitComplete()
	{
		parent::InitComplete();
		$file = igk_io_currentbasePath(IGK_MODS_FOLDER."/register_uvar.phtml");
		if (file_exists($file ))
		{
			include($file);
		}
	}
}

//---------------------------------------------------------------------------
// - template ...
//---------------------------------------------------------------------------
final class IGKTemplateCtrl extends IGKConfigCtrlBase
{
	
	public function getConfigPage()
	{
		return "template";
	}
	public function gettemplateFolder()
	{
		return igk_io_currentbasePath(IGK_TEMPLATES_FOLDER);
	}
	public function View(){
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		
		
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_add_title($t, "title.template");
		
		$t->addHSep();
		igk_add_article($this, "template" , $t->addDiv(), null, true);
		$t->addHSep();
		$frm = $t->addForm();
		$frm["action"]=$this->getUri("loadTemplate");
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.loadTemplate"), igk_js_post_frame($this->getUri("loadTemplateFrame_ajx")));
			
		
		$t->addBr();
		
		
		$frm = $t->addForm();
		$frm["action"]=$this->getUri("saveTemplate");
		HtmlUtils::AddBtnLnk($frm, R::ngets("btn.saveTemplate"), $this->getUri("saveTemplateFrame"));
		$t->addHSep();		
		$frm = $t->addForm();
		igk_add_title($frm, "title.templates");
		$frm->addDiv()->addScript()->Content = "(function(q){window.igk.ajx.post('".$this->getUri("tm_gettemplates_ajx")."',null,function(xhr){if (this.isReady()){ this.setResponseTo(q); }}); })(window.igk.getParentScript());";
		
	}
	public function getTemplateImg(){
		$n = igk_getr("n");
		$v_file = $this->templateFolder."/".$n.".template";
		
		header("Content-type: image/png");
		$f = false;
		if (is_file($v_file))
		{			
			
			$hzip = zip_open($v_file);
			if (is_resource($hzip))
			{
				while( ($e = zip_read($hzip)))
				{
				$n = zip_entry_name($e);				
				if ($n == "__image.png")
				{
					igk_wl(zip_entry_read($e,zip_entry_filesize($e)));
					$f =true;
					break;
				}
				}
				zip_close($hzip);
			}
		}
		if (!$f){			
			igk_wl(IGKIO::ReadAllText(igk_io_currentbasePath("R/notemplatepic.png")));
		}
		exit;
	}
	//<summary>get templates</summary>
	public function tm_gettemplates_ajx($uri=null)
	{
		//::: get template list
		$ul = HtmlItem::CreateWebNode("ul");
		$ul["class"] = "igk_templates_list";
		$v_tfiles = IGKIO::GetFiles($this->templateFolder, "/\.template$/i", false);
		if ($v_tfiles)
		{
		foreach($v_tfiles as $f)
		{
			$li = $ul->add("li");
			$div = $li->addDiv();
			$n = igk_io_basenamewithoutext($f);
			$div->addDiv(array("class"=>"title"))->Content =  $n;
			$cdiv = $div->addDiv();
			$cdiv->add("img", array("src"=>igk_io_baseuri().$this->getUri("getTemplateImg&n=".$n), "width"=>"100%"));
			$cdiv = $div->addDiv();
			
			HtmlUtils::AddBtnLnk($cdiv, R::ngets("btn.installTemplate"), $this->getUri("tm_installTemplate&n=".$n));
			
			HtmlUtils::AddBtnLnk($cdiv, R::ngets("btn.uninstallTemplate"), $this->getUri("tm_uninstallTemplate&n=".$n));
		}}
		else
			$ul->add("li")->Content = R::ngets("tip.notemplates");
		igk_wl($ul->Render());
	}
	public function tm_installTemplate()
	{
		$n = igk_getr("n");
		$this->__installTemplate($this->templateFolder. "/". $n.".template");
		$this->View();
	}
	public function tm_uninstallTemplate()
	{
		$n = igk_getr("n");
		$v_f = $this->templateFolder. "/". $n.".template";
		if (file_exists($v_f))
		{
			@unlink($v_f);
		}
		$this->View();
	}
	public function loadTemplateFrame_ajx($tempfile=null){
		$frame = igk_add_new_frame($this,"new_template_frame");
		$frame->Title = R::ngets("title.loadtemplate");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("loadTemplate");
		$frm->addInput("clTemplateFile", "file");
		$frm->addHSep();
		$frm->addInput("btn_savetemplate", "submit", R::ngets("btn.loadtemplate"));
		igk_wl($frame->Render());		
	}
	private function __installTemplate($file)
	{
		if( !file_exists($file))
			return;
		$hzip = zip_open($file);
		$outdir =  realpath(igk_io_currentbasePath(""));
		
		if (is_resource($hzip))
		{
			
			while( ($e = zip_read($hzip)))
			{
				$n = zip_entry_name($e);				
				if ($n == "__template.def")
				{
					//load environment
					$this->__loadEnvironment(zip_entry_read($e,zip_entry_filesize($e)));
				}
				else{				 
					//extract zip
					if (igk_zip_entry_isdir($e))
					{	
						igk_zip_create_dir($outdir, $n);
					}
					else{
						if (!(strpos($n, "/")===FALSE))
							igk_zip_extract($outdir, $hzip , $e);
					}
				}
			}
			zip_close($hzip);
			igk_notifyctrl()->addMsg("Msg.TemplateLoaded");			
			igk_getctrl(IGK_CONF_CTRL)->reconnect();
			exit;
			
		}
		else{
			igk_notifyctrl()->addError("Msg.TemplateFileNotValid");			
		}		
	}
	public function loadTemplate($tempfile=null){
		$f = igk_getv($_FILES, "clTemplateFile");
		if ($f && isset($f["tmp_name"]) && ($f["error"]===0))
		{
			$this->__installTemplate($f["tmp_name"]);
			
			$this->ConfigCtrl->reconnect();
			exit;
		}		
		else
			igk_notifyctrl()->addError("Msg.TemplateLoadTemplateError");
	}
	private function __loadEnvironment($env)
	{
		//load environemnt
		$e = HtmlItem::CreateWebNode("env");
		$e->Load($env);
		$n = "";
		$v = "";
		
		
		$t = igk_getv($e->getElementsByTagName("Template"), 0);	
		$this->App->Configs->templateLoad = true;
		$this->App->Configs->templateName = $t["name"];
		$this->App->Configs->templateVersion = $t["version"];
		
		
		$t = igk_getv($e->getElementsByTagName("TemplateInfo"), 0);
		foreach($t->Childs as $k=>$v)
		{
			switch(strtolower($v->TagName))
			{
				case "defaultctrl":
					$this->App->Configs->web_pagectrl = trim($v->innerHTML);
				break;
			}
		}
		
		igk_save_config();
		
		//load colors
		$cls = igk_getv($e->getElementsByTagName("Colors"), 0);		
		foreach($cls->Childs as $k)
		{
			$this->App->Doc->Theme->cl[$n] = $v;
		}
		$cls = igk_getv($e->getElementsByTagName("Styles"), 0);		
		foreach($cls->Childs as $k)
		{
			$this->App->Doc->Theme[$n] = $v;
		}
		//save theme
		igk_getctrl(IGK_THEME_CTRL)->saveTheme();
		
		//load menu
		$cls = igk_getv($e->getElementsByTagName("Menus"), 0);		
		$ctrl = igk_getctrl(IGK_MENU_CTRL);
		$ctrl->__clearConfigMenu(false);
		foreach($cls->Childs as $k)
		{
			$t = $ctrl->getDefaultEntry();
			
			foreach($k->Attributes as $s=>$r )
			{
				$t[$s] = $r;
			}
			
			$ctrl->reg_menu($t,false);
		}
		$ctrl->__saveConfigMenu();
		
		$cls = igk_getv($e->getElementsByTagName("UserVariables"), 0);		
		$ctrl  = igk_getctrl(IGK_USERVARS_CTRL);
		$ctrl->vc_clearvars(false);
		foreach($cls->Childs as $k)
		{			
			$ctrl->regVars($k["name"], $k["value"], $k["description"]);
		}
		$ctrl->__storeVars();
	}
	public function getCurrentTemplateDefinition($name= null, $desc=null, $cat = null, $image=null)
	{
		$e = HtmlItem::CreateWebNode("Template");
		$e["name"] = $name;
		$e["version"] = IGK_VERSION;
		$e["description"] = $desc;
		$e["category"] = $cat;
		$e["created"] = igk_date_now();
		
		//template info
		$v_ti = $e->add("TemplateInfo");
		$v_ti->add("DefaultCtrl")->Content = igk_getv($this->App->Configs, "web_pagectrl");	
		$v_ti->add("Image")->Content = $image;
		$menu = $e->add("Menus");
		
		//save menu
		
		foreach(igk_getctrl(IGK_MENU_CTRL)->UserMenu as $k)
		{
			$m = $menu->add("menu");
			foreach($k as $s=>$sv)
			{
				$m[$s] = trim($sv);
			}
		}
		
		$ctrls = $e->add("Controllers");		
		//
		foreach($this->App->ControllerManager->getUserControllers() as $k)
		{
				$ctrls->add("Ctrl", array(
					IGK_FD_NAME=>$k->Name,					
				));
		}
		$ctrls = $e->add("UserVariables");				
		foreach(igk_getctrl(IGK_USERVARS_CTRL)->getVars() as $k=>$v)
		{
			$obj = (object)$v;
				$ctrls->add("var", array(
					"name"=>$k,
					"value"=>$obj->value,
					"comment"=>$obj->comment
				));
		}		
		$theme = $e->add("Themes");
		$clt = $theme->add("Colors");
		foreach($this->App->Doc->Theme->cl->Attributes as $k=>$v)
		{
		
			if (empty($v))continue;
			$clt->add("Color", array(
				"name"=>$k,
				"value"=>$v
			));
		}
		$clt = $theme->add("Styles");
		foreach($this->App->Doc->Theme->Attributes as $k=>$v)
		{
			if (empty($v))continue;
			$clt->add("css", array(
				"name"=>$k,
				"value"=>$v
			));
		}		
		$option = (object)array("Indent"=>true);
		return igk_ansi2utf8(utf8_encode($e->Render($option)));
	}
	public function saveTemplate()
	{
		$tname = igk_getr("clTemplateName");
		$inc = igk_getr("clTemplateAllowInc");
		$desc = igk_getr("clTemplateDesc");
		$img = igk_getv($_FILES, "clTemplateImage");
		
		$e = HtmlItem::CreateWebNode("error");
		$val = "IGKValidator";		
		IGKValidator::Init();
		if (IGKValidator::IsStringNullOrEmpty($tname)){ IGKValidator::Error()->add("li")->Content = "string is null or empty"; }
		if (($img==null) || !igk_io_fileIsPicture($img["type"])){ IGKValidator::Error()->add("li")->Content = "image not specified"; }
		
		if (!IGKIO::CreateDir($this->templateFolder))
		{
			igk_notifyctrl()->addError(R::ngets("Msg.TemplateFolderCantBeCreated"));
			igk_frame_close("new_template_frame");
			return;
		}		
		if (IGKValidator::Error()->HasChilds)
		{
			igk_notifyctrl()->addWarning(R::ngets("Msg.ErrorWhenTemplate"));
			return;
		}
		
		$file = IGKIO::GetDir($this->gettemplateFolder()."/".$tname.".template");
		
		
	
		$zip = new ZipArchive();
		
		if ($zip->open($file, ZIPARCHIVE::CREATE))
		{
		
			$zip->addFromString("__template.def", $this->getCurrentTemplateDefinition($tname, $desc, igk_getr("clTemplateCat")));
			$zip->addFromString("__image.png", IGKIO::ReadAllText($img["tmp_name"]));
			//save Mods folder
			
			$dir = igk_io_currentbasePath(IGK_MODS_FOLDER);//."/".$tname.".template");
			$this->__zipDir($dir, $zip, "Mods");
			$this->__zipDir(igk_io_currentbasePath(IGK_RES_FOLDER), $zip, "R", "/\.(gkds)$/i");
			
			if ($inc)
			{
				$this->__zipDir(igk_io_currentbasePath(IGK_INC_FOLDER), $zip, "Inc");
			}
			
			$zip->close();				
			
			igk_frame_close("new_template_frame");	
			igk_notifyctrl()->addMsgr("Msg.TemplateSaved");					
		}	
		else{
			igk_notifyctrl()->addError(R::ngets("Msg.TemplateNotSaved"));
		}
		$this->View();
		
	}
	public function saveTemplateFrame()
	{
		$frame = igk_add_new_frame($this,"new_template_frame");
		$frame->Title = R::ngets("title.newtemplate");
		
		$d = $frame->Content;
		$d->ClearChilds();
		$frm = $d->addForm();
		$frm["action"] = $this->getUri("saveTemplate");
		
		$frm->addDiv(array("class"=>"hide"))->Content= IGK_HTML_SPACE;
		$ul = $frm->add("ul");
		//($id, $text, $type="text",$value=null, $attributes=null, $require=false){	
		$ul->add("li")->addSLabelInput("clTemplateName", R::ngets(IGK_FD_NAME),"text", null, null, true);
		$ul->add("li")->addSLabelInput("clTemplateAllowInc", R::ngets("clInclude"), "checkbox");
		$ul->add("li")->addSLabelInput("clTemplateCat", R::ngets("clCategory"), "text", null, null, true);
		$ul->add("li")->addSLabelInput("clTemplateDesc", R::ngets("clDescription"));
		$ul->add("li")->addSLabelInput("clTemplateImage", R::ngets("clImage"), "file", null,null, true);
		$frm->addHSep();
		$frm->addInput("btn_savetemplate", "submit", R::ngets("btn.savetemplate"));
	}
	
	private function __zipDir($dir, $zip, $folder=null, $regex = null)
	{
		
		$hdir = opendir($dir);		
		if (is_resource($hdir))
		{
			
			while( $d  = readdir($hdir))
			{
				
				if (($d==".") || ($d=="..") || (($regex!==null) && preg_match($regex, $d)))
				{					
					continue;
				}
				$f = $dir."/".$d;
				if (is_dir($f))
				{
					$zip->addEmptyDir($folder==null ? $d : $folder."/".$d);
					$this->__zipDir($f,$zip, $folder==null ? $d : $folder."/".$d, $regex);
				}
				else if (is_file($f))
				{
					$zip->addFile($f, $folder==null ? $d : $folder."/".$d);
				}
			}			
			closedir($hdir);
		}
	}
	
	
}

class IGKUsersCtrl extends IGKConfigCtrlBase
{
	private $m_Users;
	
	public function getUsers(){ return $this->m_Users; }
	
	public function getDataTableInfo(){
		return array(
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clId", IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true, "clIsPrimary"=>true)),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLogin", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60", "clIsUnique"=>true)),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clPwd", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60")), //md5 passwd
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clFirstName", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLastName", IGK_FD_TYPE=>"VarChar", IGK_FD_TYPELEN=>"60")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clLevel", IGK_FD_TYPE=>"Int", IGK_FD_TYPELEN=>"1")),
			new IGKDbColumnInfo(array(IGK_FD_NAME=>"clStatus", IGK_FD_TYPE=>"Int", "clDefault"=>"-1", "clDescription"=>"state of the account, -1 = not activated, 1=activated, 0or2=blocked" ))
			);
	}
	//init - 
	public function initDataEntry($db){		
		$n = $this->DataTableName;
		$db->Insert($n, array("clLogin"=>"bondje.doue@gmail.com","clPwd"=>md5("test123"), "clFirstName"=>"Charles", "clLastName"=>"BONDJE DOUE", "clLevel"=>-1, "clStatus"=>-1));
		$db->Insert($n, array("clLogin"=>"admin@".$this->app->Configs->domain, "clPwd"=>md5("test123"), "clFirstName"=>"admin", "clLastName"=>"Administrator", "clLevel"=>-1, "clStatus"=>1));
	
	}
	public function getConfigPage()
	{
		return "users";
	}
	public function getDataAdapterName()
	{
		return IGK_MYSQL_DATAADAPTER;
	}
	
	public function us_reguser(){
		
	}
	public function us_lockuser()
	{
		$email = igk_getr("email");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>igk_getr("email")));
		if ($t && is_object($t))
		{			
			$t->clStatus = 2;
			$this->update($t);
			igk_navtocurrent("userlocked");
		}	
		
			else{
		igk_navtocurrent();
		}
	}
	public function us_activate(){
		
		$email = igk_getr("email");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>igk_getr("email")));
		if ($t && is_object($t))
		{
			$t->clStatus = 1;
			$this->update($t);
			igk_navtocurrent("confirmregistration");	
		}	
		else{
		igk_navtocurrent();
		}
			
	}
	public function us_resetpwd()
	{
		$npwd = igk_getr("clNewPwd");
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clPwd"=>igk_getr("clLogin")));
		if ($t && is_object($t))
		{
			$t->clStatus = 1;
			$this->update($t);
			igk_navtocurrent("pwdchanged");
		}	
		else{
			igk_navtocurrent();
		}
		
	}
	
	
	public function getDataTableName(){return "tbigk_users" ;}
	
	//connect to user
	public function connect($log, $pwd)
	{
		if ($this->m_User != null)
			return false;
		
		$e = $this->getDbEntries();		
		$t = $e->searchEqual(array("clLogin"=>$log, "clPwd"=>md5($pwd)));
		if ($t){
			if (is_object($t))
			{
				
				if ($t->clStatus == 1)
				{
					$this->m_User = $t;
					$this->App->Session->User = $t;									
					return true;
				}
				else{
					$this->app->Session->ErrorString = "connectfailed : status of the requested user is not activated";
					return false;
				}
			}
		}
		return false;
	}
	public function logout()
	{
		$this->App->Session->User = null;
		return true;
	}
	public function View(){
		if (!$this->IsVisible)
		{
			igk_html_rm($this->TargetNode);
			return;
		}
		$t = $this->ConfigNode;
		$t->ClearChilds();
		igk_add_title($t, "title.users");
		
		$t->addHSep();
		igk_add_article($this, "users" , $t->addDiv(), null, true);
		$t->addHSep();
		$frm = $t->addForm();		
	}
	public function functionIsAvailable($func)
	{
		return true;
	}
}
///used to register controls
//--------------------------------------------------------------------------------
final class IGKCtrlTypeManager
{
	static  $tabManager;
	//get all available controller byte
	public static function GetControllerTypes()
	{
	
		if ( self::$tabManager == null){
		$tab = array();
		$exp = "/^(IGK){0,1}(?P<name>[\w_-]+)Ctrl$/i";
		foreach(get_declared_classes() as $k=>$v)
		{
			if (is_subclass_of( $v,  "IGKCtrlTypeBase") && igk_reflection_class_isabstract($v) && preg_match($exp, $v) )
			{
				preg_match_all($exp, $v, $t);
				$tab[$t["name"][0]] =$v;
			}
		}
		self::$tabManager = $tab;
		return $tab;
		}
		return self::$tabManager;
		
	}
	
}

//TEMP : Preload Images
class IGKPics extends IGKControllerBase
{
	public function getIsVisible(){
		return true;
	}
	public function View()
	{	
		$this->TargetNode->Clear();	
	}
	public function loadAllImgs()
	{
			//for shortcut
		$t = $this->TargetNode;
		$pics = igk_getctrl(IGK_PIC_RES_CTRL)->getAllPics();
		$t->ClearChilds();
		//igk_wln($pics);
		//->getAllPics();
		$out ="igk.ready(function(){var v =null;";
		foreach($pics as $k=>$v)
		{
			$out .= "v = document.createElement('img'); v.src='".igk_io_baseuri()."/".R::GetImgUri($k)."'; document.body.AppendChild(v);\n";
		}
		$t->addScript()->Content = $out. "});";
		igk_html_add($t, $this->App->Doc->bodypage);
		//igk_wln("pic call");*/
	}
}

final class IGKCacheCtrl extends IGKControllerBase
{
	public function getName(){return "cachectrl"; }
	public function getCacheFile($name)
	{
		return igk_io_currentbasePath(IGK_CACHE_FOLDER."/".$name);
	}
	public function __construct()
	{
		parent::__construct();
	}
	public function __toString(){ return "cacheController"; }
	
	public function InitComplete()
	{
		parent::InitComplete();
		$meta = HtmlItem::CreateWebNode("meta");
		$meta["http-equiv"] = "Cache-control";
		$meta["content"]="public";
		$this->App->Doc->Metas->addMeta("CacheControl", $meta); //"Cache-control" content="public">
	}
	public function storeCache($name, $out)
	{
			$f = $this->getCacheFile($name);
			ob_start();						
			igk_wl($out);
			ob_end_clean();
			igk_io_save_file_as_utf8($f, utf8_decode($out));				
			igk_wl($out);
	}
	
	public function loadCache($name, $ctrl=null)
	{
		$t = igk_getdv($this->App->Configs->cache_file_time, 3600);
		$expire = time()-$t;
		$f = $this->getCacheFile($name);
		
		if (file_exists($f) && (filemtime($f) > $expire))
		{
			
			//header("HTTP/1.1 304 Not Modified");			
			readfile($f);
			return true;
		}
		else{
			if (($ctrl!=null))
			{
				ob_start();
				$ctrl->View();				
				$o = $ctrl->TargetNode->Render();
				igk_wl($o);
				ob_end_clean();
				igk_io_save_file_as_utf8($f, utf8_decode($o));				
				igk_wl($o);
			}
		}
		return false;
	}
	public function getIsVisible(){return false;}
	public function getCanAddChild(){return false; }
}

abstract class IGKCatachableViewCtrl extends IGKControllerBase
{
	public function getisCachable(){
		return true;
	}
	public function View(){
		if ($this->isCachable)
		{
			if (!igk_getctrl("cache")->loadCache($this->Name))
			{
				parent::View();
				igk_getctrl("cache")->storeCache($this->Name, $this->TargetNode->Render());
			}
		}
		else{
			parent::View();
		}
	}
}

//system uri actions
final class IGKSystemUriAction extends IGKControllerBase
{
		private $m_actions;
		
		public function getName(){return IGK_SYSACTION_CTRL; }
		public function getIsVisible(){return false;}
		public function getCanAddChild(){return false;}
		
		public function getDataTableInfo()
		{
			return array(
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clId", IGK_FD_TYPE=>"Int", "clAutoIncrement"=>true, "clIsPrimary"=>true)),
			new IGKdbColumnInfo(array(IGK_FD_NAME=>IGK_FD_NAME, IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>50, "clIsUnique"=>true, "clIsPrimary"=>true)),			
			new IGKdbColumnInfo(array(IGK_FD_NAME=>"clUri", IGK_FD_TYPE=>"VARCHAR", IGK_FD_TYPELEN=>255))
			);
		}
		public function getDataTableName(){
			return "tbigk_systemUri";
		}
		public function getDataAdapterName()
		{
			return IGK_MYSQL_DATAADAPTER;
		}
		public function gotoconfig(){
			igk_navtocurrent("Configs");			
		}
		public function InitComplete()
		{
			parent::InitComplete();
			$this->m_actions =array();
			$this->m_actions["conf"] = parent::getUri("gotoconfig");
			$this->m_actions["config.php"] = parent::getUri("gotoconfig");
			$this->m_actions["clr"] = "?c=sessionctrl&f=clearS";
			$this->m_actions["clearsession.php"] = "?c=sessionctrl&f=clearS";
			$this->m_actions["initsdb"] = "?c=igkdbctrl&f=pinitSDb";
			
			$e = $this->getDbEntries();
			if ($e)
			{
				foreach($e->Rows as $k=>$v)
				{
					$this->sys_ac_register($v->clName, $v->clUri);
					igk_debug_wln("register ".$v->clName);
				}
			}
			
		}
		public function contains($key)
		{
			return array_key_exists($key, $this->m_actions);			
		}
		public function getUri($key=null)
		{
			if ($this->contains($key))
				return $this->m_actions[$key];
			return null;
		}
		public function invokeUri($key)
		{
			$this->App->ControllerManager->InvokeUri($this->getUri($key));
			igk_render_doc();
			exit;
		}
		public function sys_ac_register($p, $uri)
		{
			if (isset($this->m_actions[$p])){
				igk_debug_wln("Action name ".$p." already register "); return;
			}
			$this->m_actions[$p] = $uri;
		}
}

function igk_io_getdbconf_file($dir)
{
	return igk_io_getdir($dir."/".IGK_DATA_FOLDER."/".IGK_CTRL_DBCONF_FILE);
}
function igk_io_getconf_file($dir)
{
	return igk_io_getdir($dir."/".IGK_DATA_FOLDER."/".IGK_CTRL_CONF_FILE);	
}
function igk_sys_uri_regpage($page, $uri=null){
	igk_getctrl(IGK_SYSACTION_CTRL)->sys_ac_register($page, $uri);
}



include_once("igk_api.php");



if (!igk::LoadCacheLibFiles())
{
	//include extensions	
	include_once("igk_extensions.phtml");
}


?>