﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGK.PreviewWebDocumentDemo
{
    using IGK.ICore;
    using IGK.ICore.WinCore;
    using IGK.ICore.WinCore.Tools;

    [CoreApplication("CSSBuilderApp")]
    class App : WinCoreApplication
    {
        public override void Initialize()
        {
            base.Initialize();
            WinCoreService.RegisterIE11WebService();
        }

        public override void AddMessageFilter(ICore.WinUI.ICoreMessageFilter messageFilter)
        {
            
        }

        public override void RemoveMessageFilter(ICore.WinUI.ICoreMessageFilter messageFilter)
        {
        }

        public override bool RegisterServerSystem(Func<CoreSystem> __initInstance)
        {
            __initInstance();
            return true;
        }

        public override bool RegisterClientSystem(Func<CoreSystem> __initInstance)
        {
            return false;
        }
    }
}
