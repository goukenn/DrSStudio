﻿using IGK.ICore.WinCore.WinUI.Controls;
using IGK.ICore.WinUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.WinUI
{
    public class CssEditorSurface :        
        IGKXWinCoreWorkingFileManagerSurface ,
        ICoreWorkingSurface
    {
        IGKXWebBrowserControl c_webBrowser;


        public WebBrowser WebControl {
            get {
                return c_webBrowser.WebControl;
            }
        }
        public CssEditorSurface()
        {
            this.InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.c_webBrowser = new IGK.ICore.WinCore.WinUI.Controls.IGKXWebBrowserControl();
            this.SuspendLayout();
            // 
            // c_webBrowser
            // 
            this.c_webBrowser.CaptionKey = null;
            this.c_webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c_webBrowser.Location = new System.Drawing.Point(0, 0);
            this.c_webBrowser.Name = "c_webBrowser";
            this.c_webBrowser.Size = new System.Drawing.Size(510, 253);
            this.c_webBrowser.TabIndex = 0;
            // 
            // CssEditorSurface
            // 
            this.Controls.Add(this.c_webBrowser);
            this.Name = "CssEditorSurface";
            this.Size = new System.Drawing.Size(510, 253);
            this.ResumeLayout(false);

        }
    }
}
