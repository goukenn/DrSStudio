﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.WinUI
{
    using $safeprojectname$.WinUI;
    using IGK.ICore.IO;
    using IGK.ICore.Resources;
    using IGK.ICore.Web;
    using IGK.ICore.WinCore.Web;
    using IGK.ICore.WinCore.WinUI.Controls;
    using IGK.ICore.Xml;

    public partial class MainForm : Form,
        ICoreWebReloadListener,
        ICoreWebScriptListener,
        IIGKXWebrowserReloadViewListener
    {
        private CoreXmlWebDocument m_document;
        private CSSBuilderScriptViewerProfile m_script;
        private string m_View;
        /// <summary>
        /// get or set the view
        /// </summary>
        public string View
        {
            get { return m_View; }
            set
            {
                if (m_View != value)
                {
                    m_View = value;
                    OnViewChanged(EventArgs.Empty);
                }
            }
        }
        public event EventHandler ViewChanged;

        protected virtual void OnViewChanged(EventArgs e)
        {
            if (ViewChanged != null)
            {
                ViewChanged(this, e);
            }
        }


        public MainForm()
        {
            InitializeComponent();
            this.m_View = "css_builder_main.html";
            this.Load += _Load;
            this.ViewChanged += MainForm_ViewChanged;
        }

        void MainForm_ViewChanged(object sender, EventArgs e)
        {
            this.Reload(this.m_document);
        }

        private void _Load(object sender, EventArgs e)
        {
            InitDocument();
        }

        private void InitDocument()
        {
            m_document = CoreXmlWebDocument.CreateICoreDocument();
            m_document.AddScript(PathUtils.GetPath("%startup%/Sdk/Scripts/drs.js"));
            m_document.AddLink(PathUtils.GetPath("%startup%/Sdk/bootstrap/css/bootstrap.min.css"));

            var d = new CSSBuilderScriptViewerProfile();
            d.SetReloadListener(this);
            d.SetScriptListener(this);
            this.m_script = d;
            this.c_webBrowser.WebControl.ObjectForScripting = d;
            d.Document = m_document;

            
            Reload(m_document);
            this.c_webBrowser.SetReloadViewListener(this);

        }

        public void InvokeScript(string script)
        {
            if (this.c_webBrowser.WebControl.Document != null)
            {
                this.c_webBrowser.WebControl.Document.InvokeScript("eval", new string[] { script });
            }
        }

        public void Reload(CoreXmlWebDocument document)
        {
            document.Body.Clear();
            document.Body.LoadString(
                CoreWebUtils.EvalWebStringExpression(
                CoreResources.GetResourceString (string.Format (CSSBuilderConstant.RES_FORMAT_1 , this.View)),
                this.m_script)
            );
            document.AttachToWebbrowser(this.c_webBrowser.WebControl, true);
        }



        public void Reload()
        {
            this.Reload(this.m_document);
        }
    }
}
