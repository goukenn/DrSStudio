﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public static class CSSBuilderConstant
    {
        internal const string VERSION = "1.0";
        internal const string AUTHOR = "C.A.D BONDJE DOUE";
        internal const string EXT = "css";        
        internal const string RES_FORMAT_1 = "Resources/{0}";
    }
}
